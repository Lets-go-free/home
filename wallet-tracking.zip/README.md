# Wallet Tracking – modularer Umbau Phase 1

## Zielstruktur

- `wallet-tracking/index.html` – zentrale Seite
- `wallet-tracking/css/wallet-tracking.css` – gemeinsames Layout
- `wallet-tracking/js/app.js` – bisherige Hauptlogik
- `wallet-tracking/projects/tln-vow/tln-vow.js` – ausgelagerte TLN/VOW-Projektlogik
- `wallet-tracking/projects/dao1/dao1.js` – neues DAO1/Apertum-Projektmodul
- `wallet-tracking/sql/001-dao1-apertum.sql` – DAO1-Projekt + Miner-/Preis-Tabellen
- `wallet-tracking.html` – optionale Root-Weiterleitung für alte Bookmarks

## Vor Deployment

1. SQL `001-dao1-apertum.sql` in Supabase ausführen.
2. Ordner `wallet-tracking/` und Root-Redirect ins GitHub-Pages-Repository kopieren.
3. In Supabase Auth die Redirect-URL `https://letsgofree.me/wallet-tracking/` erlauben.
4. Danach TLN/VOW und DAO1 im Browser testen.

## DAO1

`DAO1` wird in `defi_projects` angelegt. Native APTM wird als Projekt-Referenz in `defi_project_tokens` geführt. Weitere DAO1-spezifische Token können über die bestehende Admin-Maske bei den vordefinierten Token dem Projekt `DAO1` zugeordnet werden.

Der DAO1-Tab wird sichtbar, wenn ein DAO1-Projektasset aktuell im Wallet oder historisch in einem Snapshot vorkommt. Mining-NFT-Zuordnungen werden in `project_miners` gespeichert. Historische APTM/wUSDT-Poolzustände werden zentral in `aptm_price_history` gecacht und können dadurch von mehreren Wallets wiederverwendet werden.


## Phase 2 – 27.08.2026 13:55 CEST
DAO1/Apertum: Wallet-Auswahl, automatische Miner-NFT-Ermittlung über Blockscout ERC-721 Transfers, historische Besitzerermittlung pro NFT und manuelle NFT-ID als Fallback. Neue Migration: `wallet-tracking/sql/002-dao1-miner-ownership.sql`.
