import { readFileSync } from 'node:fs';
import assert from 'node:assert/strict';
const source=readFileSync(new URL('../supabase/functions/dao-reward-refresh/index.ts',import.meta.url),'utf8');
for(const cursor of ['reward_server_raw_transactions_v1','reward_server_raw_flows_v1'])assert.ok(source.includes(cursor),`separate server cursor ${cursor}`);
for(const canonical of ["state(job,'transactions_wallet_v1')","state(job,'token_flows_wallet_v2')", "updateState(job,'transactions_wallet_v1'", "updateState(job,'token_flows_wallet_v2'"]){assert.ok(!source.includes(canonical),`must not alter canonical cursor: ${canonical}`)}
assert.match(source,/await saveScan\(job,kind,cursor,/);
assert.match(source,/await saveScan\(job,kind,highest,null\)/);
assert.match(source,/if\(!Number\.isSafeInteger\(log\)\|\|log<0\)throw Error/);
assert.match(source,/if\(minute<245\|\|minute>=330\)/);
assert.match(source,/async function insertRawWithoutReplacing/);
assert.match(source,/ignoreDuplicates:true/);
assert.match(source,/from===address&&to===address\?'intern'/);
assert.doesNotMatch(source,/const merged=\{\.\.\.old\}/);
assert.doesNotMatch(source,/await upsert\('project_transactions'/);
assert.doesNotMatch(source,/cron\.schedule|CREATE EXTENSION|createSnapshot/i);
console.log('Reward staging worker safety checks passed');

// Contract-pinned referral evidence may be observed but must not rewrite enriched claims.
for (const constant of ['REFERRAL_WALLET','REFERRAL_REWARD_CONTRACT','REFERRAL_WUSDT_TOKEN','isVerifiedReferralTransaction']) assert.ok(source.includes(constant));
assert.match(source, /classification:'observational-only'/);
assert.doesNotMatch(source, /claim_nft_subtype\s*:/);

// Selector mapping must match the canonical DAO1 application. Selector identification
// is not sufficient evidence of a completed or correctly assigned bot payout.
assert.match(source,/const CLAIM_SELECTOR='0x86bb8f37', NEW_MINER_CLAIM_SELECTOR='0x19da4078'/);
assert.match(source,/method:canonicalMethod\(input,t\.method/);
