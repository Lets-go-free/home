// Phase 6.46 · 27.09.2026 20:19:27 CEST: TLN-Team-Restore Zusatzregistry korrigiert. Realtest 6.45 zeigte weiterhin >1000 eth_getTransactionByHash-Requests; Ursache war der automatische historische Zusatzregistry-Join-Aufbau bei leerem Cache. Normaler Team-Tab startet weder diesen History-Pfad noch die Evidence-Tx-Parent-Hydrierung; nur Step 7 darf beides explizit ausführen. P10 Cross-User-Negativtest bleibt offen. Build 20260927-201927.
// Phase 6.39 · 27.09.2026 12:05:26 CEST: P10 Supabase-Security-Audit dokumentiert; produktiv bereits ausgeführtes RPC-Hardening (5 REVOKE EXECUTE) als Migration nachgeführt. Shared-Cache-Browserwrites bleiben als bewusst akzeptiertes Integritätsrisiko unverändert. Build 20260927-120526.
// Phase 6.37 · 27.09.2026 11:25:02 CEST: P9 Invalidierungs-/Versionierungs-Audit abgeschlossen. Block-versionierte TLN/VOW-Staking- und technische Persistenz-Caches erhalten monotone Write-Guards gegen Rückschreiben älterer Browser-Stände; bestehende DATA_VERSIONS-/Schema-/Partial-Schutzverträge bestätigt. P9 = erledigt. Build 20260927-112502.
// Phase 6.36 · 27.09.2026 11:22:14 CEST: P9 Cache-Ownership-Inventur abgeschlossen: Cache-Domänen nach Scope, Source of Truth, Invalidierung und Delete-Verhalten klassifiziert; keine akute Cross-User-/Delete-Lücke gefunden. Nächster P9-Schritt ist die gezielte Prüfung der Versions-/Invalidierungsverträge. Build 20260927-112214.
// Phase 6.34 · 27.09.2026 03:45:02 CEST: P8 Session-Verlust zentral behandelt: fehlende Supabase-Session schaltet App in sichtbaren Re-Login-/Cache-only-Zustand, private/Edge-Aufrufe werden vor dem Request blockiert und 401-Kaskaden vermieden. Build 20260927-034502.
// Phase 6.33 · 27.09.2026 03:34:30 CEST: P7 Fresh-Wallet-Realtest abgeschlossen (nur UUID in DB-wallet_id, Lifecycle complete); P8 Auth-Diagnose ergänzt: 401 der Apertum-NFT-Historie protokolliert Session-/User-Status ohne Tokeninhalt und klassifiziert den Pfad als partial. Build 20260927-033430.
// Phase 6.30 · 27.09.2026 02:19:44 CEST: P6-Testblocker behoben: fehlende DAO1 Claim-Receipt-/Asset-Flow-Helper aus dem bewährten 6.21-Pfad wiederhergestellt; Lifecycle/Snapshot-Gate kann P6 nun wieder vollständig erreichen. Build 20260927-021944.
// Phase 6.29 · 27.09.2026 01:55:00 CEST: Audit P5 nach Realtest abgeschlossen (Asset-Flow-SoT, historische Preise, 0 Post-Launch-Missing); P6 NFT/Bot Current-State gestartet. Build 20260927-015500.
// Phase 6.28 · 26.09.2026 19:15:59 CEST: P5: globale APTM-Preishistorie/Exact-Anker bis zu offenen Post-Launch-Claims nachziehen; Nicht-Admins erhalten lokalen read-only Exact-Fallback. Prelaunch ist wallet-unabhängig durch den ersten On-Chain-Marktpreis definiert. Build 20260926-191559.
// Phase 6.26 · 26.09.2026 17:56:20 CEST: P5: offene native APTM-Claim-Preise werden beim App-Start/DAO1-Refresh nachgezogen; Prelaunch-Fälle dauerhaft markiert; DAO1 Dark-Mode-Tabellen korrigiert. Build 20260926-175620.
// Phase 6.25 · 26.09.2026 17:31:56 CEST: Audit P5 Diagnose: Missing-Claim-Preise werden mit Exact-/Nachbar-/Legacy-Ankern protokolliert; Preislogik unverändert. Build 20260926-173156.
// Phase 6.24 · 26.09.2026 17:17:59 CEST: Audit P5 UI-Fix: Historischer APTM-Stückpreis im Claim-Tab kommt nun aus project_transaction_asset_flows.price_usd; 10 wirklich unbewertete Flows bleiben offen. Build 20260926-171759.
// Phase 6.21 · 26.09.2026 12:12:27 CEST: Audit P5 Schritt 3: sichtbare Claim-, Transaction- und Export-Lesepfade lesen Auszahlungen nur noch aus project_transaction_asset_flows; Legacy Reward-Felder bleiben Alt-/Kompatibilitätsdaten. Build 20260926-121227.
// Phase 6.18 · 25.09.2026 18:33:32 CEST: P4: unabhängige Apertum-Owner-/Collections-Abfragen werden parallel geladen; Ownership-, Kaufpreis- und Cache-Fachlogik unverändert. Build 20260925-183332.
// Phase 6.12 · 24.09.2026 18:30:01 CEST: P3 Realtest abgeschlossen. Persistierte Resolver-v3-Ergebnisse (auch bewusst offene) werden beim NFT-Tab cache-first wiederverwendet; kein erneuter Kaufpreis-Lauf beim ersten Öffnen ohne geänderte Erwerbs-Evidenz. P4 Asset-Flow-Fresh-Build entkoppelt Vollbewertung. Build 20260924-183001.
// Phase 6.11 · 24.09.2026 17:32:01 CEST: P3 zentraler NFT-Kaufpreisresolver v3; historische Kauf-Tx bleibt über spätere Walletwechsel erhalten. P4 Messung bestätigt Asset-Flows als Hauptengpass. Build 20260924-173201.
// Phase 6.10 · 24.09.2026 16:30:30 CEST: P3 Fresh-Build-Finalisierung: Ownership/Global-First/Purchase-Readmodel werden nach DAO1-Aufbau frisch geladen und NFT-UI neu gerendert; P4 erhält Lifecycle-Timings. Build 20260924-163030.
// Phase 6.09 · 24.09.2026 14:22:47 CEST: Audit P3 Ursache nachgewiesen: Dashboard/Shared-Cache ueberschrieb den frischen DB-Ownership-Read; Cache-Priorität korrigiert. P3 bleibt bis Retest in Arbeit. Build 20260924-142247.
// Phase 6.08 · 24.09.2026 12:31:39 CEST: Audit P3 Lifecycle-Konsistenz bewertet persistierte Besitzabdeckung getrennt vom Enrichment-Repair; P3 bleibt bis Retest in Arbeit. Build 20260924-123139.
// Phase 6.04 · 23.09.2026 02:51:28 CEST: Audit P3 umgesetzt: DAO1 Fresh-Build rekonstruiert historische NFT-Kandidaten aus unabhängiger Wallet-Transferhistorie statt aus vorhandenem User-Ownership-Cache; Legacy-Self-Heal ist vom automatischen Fresh-Build entkoppelt. Build 20260923-025128.
// Phase 6.03 · 23.09.2026 01:44:44 CEST: Audit P2 umgesetzt: Automatische Fresh-Build-Snapshots werden nur noch bei vollständig abgeschlossenem Lifecycle erzeugt; partial / deferred / failed blockieren den finalen Snapshot. Build 20260923-014444.
// Phase 6.00 · 23.09.2026 00:26:45 CEST: TLN Dashboard-Summary schützt Supabase-UUID-Filter vor transienten lokalen Wallet-IDs beim Fresh-Import. Build 20260923-002645.
// Phase 5.99 · 23.09.2026 00:15:00 CEST: DAO1 Fresh-Build-Fixes: NFT-Runtime-Sync, native Claim-Trace-Fallback und schneller historische Pool-State-Preispfad. Build 20260923-001500.
// Phase 5.98 · 22.09.2026 23:40:05 CEST: DAO1-Fresh-Import-Performance: ERC-20-Vollscan wird als Evidenz wiederverwendet; Claim-Nativevidenz parallel statt hunderten seriellen Detailrequests. Build 20260922-234005.
// Phase 5.96 · 22.09.2026 21:35:26 CEST: Wallet-Speichern bleibt bis zum gezielten Lifecycle-Ende im zentralen Ladejob; Teilfehler werden sichtbar gemeldet; Snapshot erst nach fehlerfreiem Fresh-Build. Build 20260922-213526.
// Phase 5.94 Rebuild · 22.09.2026 14:03:48 CEST: Systemübersicht um „Zu testen“ ergänzt; ZIP-Struktur korrigiert. Build 20260922-140348.
// Phase 5.94 · 22.09.2026 14:03:48 CEST: Userweite vollständige WalletTracking-Datenlöschung über transaktionale DB-RPC; Browser-Userdaten werden danach lokal gelöscht und der User abgemeldet. Auth-Login bleibt bestehen. Build 20260922-140348.
// Phase 5.93 · 22.09.2026 12:15:22 CEST: Apertum-RPC-Proxy erlaubt gezielte APTMDAO eth_call-Reads; DATA_MIGRATIONS partial ist DB-seitig vorgesehen; NFT-Migration v4 läuft automatisch erneut. Build 20260922-121522.
// Phase 5.91 · 22.09.2026 10:46:15 CEST: NFT-Metadatenresolver CORS-sicher: Explorer-Webseiten/external_url werden nie als JSON-Metadaten gefetcht; nur echte Metadata-/Token-URIs. Datenmigration v2 erzwingt eine einmalige saubere Wiederholung. Build 20260922-104615.
// Phase 5.89 · 22.09.2026 03:05:55 CEST: Zentrales Release-/DATA_MIGRATIONS-Management, userbezogene quittierungspflichtige Release-Popups, automatische NFT-5.88-Normalisierung; Dashboard-Vermögen vertikal responsiv. Build 20260922-030555.
// Phase 5.90 · 22.09.2026 03:44:20 CEST: Apertum-NFT-Namensresolver erweitert: DAO-Projektname + Store-/Metadata-Attribute werden vor generischem MineBot-Fallback priorisiert; bestehende Apertum-NFT-Caches werden per Datenmigration automatisch erneut geprüft. Build 20260922-034420.
// Phase 5.88 · 22.09.2026 02:20:48 CEST: NFT-Typfilter, bevorzugte DAO-Store-/Metadata-Namen (Bild + Name + ID), manueller Apertum-Refresh repariert offene Ownership-Lücken gezielt; APTMDAO-Identitäts-NFTs zählen als DID. Build 20260922-022048.
// Phase 5.87 · 22.09.2026 01:36:51 CEST: NFT-Statusbegriffe präzisiert (Besitzhistorie vs. Kaufpreisprüfung); Systemübersicht dokumentiert DAO1-Self-Heal für ältere Wallet-Erstaufbauten. Build 20260922-013651.
// Phase 5.86 · 22.09.2026 01:06:00 CEST: Systemübersicht dokumentiert DAO1-Summary als Current-State-Ansicht; historische Bot-Zuordnungen zählen nicht in den aktuellen Bestand. Build 20260922-010600.
// Phase 5.82 · 21.09.2026 23:57:38 CEST: Chain-Logos datengetrieben über public.chains.icon_path; gezielter Erstaufbau neuer/gespeicherter Wallets statt breitem loadAll(), inkl. Current State und projektbezogener Lazy-/Target-Initialisierung. Build 20260921-235738.
/* WalletTracking Phase 5.79 · 21.09.2026 17:57:25 CEST · Build 20260921-175725 */
// WalletTracking Release 4.91 · 18.09.2026 10:42:44 CEST · Build 20260918-104244
// ---- Supabase: Auth + Datenbank ----
const SUPABASE_URL = "https://cfnxuesibpnlgyklzqkj.supabase.co";
const SUPABASE_ANON_KEY = "sb_publishable_mz_vXAY0Z6sm7iXMg_bjyQ_beZDiQ1N";
const REDIRECT_URL = "https://letsgofree.me/wallet-tracking/";

// ---- Zentraler Request-Audit (Phase 5.75) ----
// Leichtgewichtige Laufzeitmessung aller fetch-basierten Supabase-/RPC-/API-Requests.
// Es werden bewusst keine Auth-Header, API-Keys, Klartext-Wallets oder Request-Bodies gespeichert.
// Die Messdaten leben nur im RAM des aktuellen Browser-Tabs und sind ausschließlich im
// Admin-Systembereich sichtbar/exportierbar.
const WT_REQUEST_AUDIT_LIMIT = 800;
const WT_REQUEST_AUDIT = { startedAt:new Date().toISOString(), entries:[], marks:[] };
const WT_NATIVE_FETCH = window.fetch.bind(window);
function wtAuditShortValue(v){
  let s=String(v??"");
  s=s.replace(/0x[0-9a-f]{40}/ig,m=>`${m.slice(0,8)}…${m.slice(-6)}`);
  s=s.replace(/[0-9a-f]{8}-[0-9a-f-]{20,}/ig,m=>`${m.slice(0,6)}…${m.slice(-4)}`);
  return s.length>110?`${s.slice(0,107)}…`:s;
}
function wtAuditSafePath(path){
  return String(path||"").split("/").map(seg=>{if(/^0x[0-9a-f]{40}$/i.test(seg))return wtAuditShortValue(seg);if(/^[A-Za-z0-9_-]{28,}$/.test(seg))return `${seg.slice(0,6)}…${seg.slice(-4)}`;return seg;}).join("/");
}
function wtAuditCaller(){
  try{
    const lines=String(new Error().stack||"").split("\n").slice(2);
    const line=lines.find(x=>/wallet-tracking\//.test(x)&&!/wtAudit|window\.fetch/.test(x))||lines.find(x=>!/wtAudit|window\.fetch/.test(x))||"";
    return line.trim().replace(/^at\s+/,"").replace(/https?:\/\/[^/]+\/wallet-tracking\//,"/").slice(0,180);
  }catch(_){return "";}
}
function wtAuditDescribe(input,init={}){
  let raw="";try{raw=typeof input==="string"?input:(input?.url||String(input||""));}catch(_){}
  let u=null;try{u=new URL(raw,location.href);}catch(_){}
  const method=String(init?.method||input?.method||"GET").toUpperCase();
  let kind="api",resource=u?`${u.hostname}${wtAuditSafePath(u.pathname)}`:wtAuditShortValue(raw),scope="",rpcMethod="";
  if(u?.hostname===new URL(SUPABASE_URL).hostname){
    kind="supabase";
    const m=u.pathname.match(/^\/rest\/v1\/([^/?]+)/);
    const f=u.pathname.match(/^\/functions\/v1\/([^/?]+)/);
    const r=u.pathname.match(/^\/rest\/v1\/rpc\/([^/?]+)/);
    resource=r?`rpc:${r[1]}`:m?m[1]:f?`edge:${f[1]}`:u.pathname.replace(/^\//,"");
    if(u.searchParams.size){
      const parts=[];
      for(const [k,v] of u.searchParams.entries()){
        if(["apikey","token","access_token"].includes(k.toLowerCase()))continue;
        const safe=/user_id/i.test(k)?"self":wtAuditShortValue(v.replace(/^(eq|neq|gt|gte|lt|lte|like|ilike|in)\./,"$1."));
        parts.push(`${k}=${safe}`);
      }
      scope=parts.join(" & ").slice(0,360);
    }
  }
  const body=init?.body;
  if(typeof body==="string"&&body.length<50000){
    try{const j=JSON.parse(body);if(j?.jsonrpc&&j?.method){kind="rpc";rpcMethod=String(j.method);resource=u?u.hostname:"rpc";scope=`${rpcMethod}${Array.isArray(j.params)?` · params:${j.params.length}`:""}`;}}catch(_){}
  }
  return {kind,resource:wtAuditShortValue(resource),method,scope,rpcMethod,caller:wtAuditCaller()};
}
function wtAuditPush(entry){
  WT_REQUEST_AUDIT.entries.push(entry);
  if(WT_REQUEST_AUDIT.entries.length>WT_REQUEST_AUDIT_LIMIT)WT_REQUEST_AUDIT.entries.splice(0,WT_REQUEST_AUDIT.entries.length-WT_REQUEST_AUDIT_LIMIT);
}
window.fetch=async function(input,init){
  const meta=wtAuditDescribe(input,init||{}),t0=performance.now(),startedAt=new Date().toISOString();
  try{
    const res=await WT_NATIVE_FETCH(input,init);
    wtAuditPush({...meta,startedAt,durationMs:Math.round((performance.now()-t0)*10)/10,status:res.status,ok:res.ok,bytes:Number(res.headers?.get?.("content-length")||0)||null,contentRange:res.headers?.get?.("content-range")||null});
    return res;
  }catch(e){
    wtAuditPush({...meta,startedAt,durationMs:Math.round((performance.now()-t0)*10)/10,status:0,ok:false,error:String(e?.message||e).slice(0,160)});
    throw e;
  }
};
function markRequestAudit(label){WT_REQUEST_AUDIT.marks.push({label:String(label||""),at:new Date().toISOString(),entryIndex:WT_REQUEST_AUDIT.entries.length});if(WT_REQUEST_AUDIT.marks.length>120)WT_REQUEST_AUDIT.marks.shift();}
function resetRequestAudit(){WT_REQUEST_AUDIT.startedAt=new Date().toISOString();WT_REQUEST_AUDIT.entries.length=0;WT_REQUEST_AUDIT.marks.length=0;markRequestAudit("audit-reset");renderAdminSystemOverview?.();}
function requestAuditSnapshot(){return {startedAt:WT_REQUEST_AUDIT.startedAt,generatedAt:new Date().toISOString(),marks:[...WT_REQUEST_AUDIT.marks],entries:[...WT_REQUEST_AUDIT.entries]};}
function exportRequestAudit(){
  const snap=requestAuditSnapshot(),lines=[`WalletTracking Request-Audit`, `Start: ${snap.startedAt}`, `Export: ${snap.generatedAt}`, "", "MARKS", ...snap.marks.map(m=>`${m.at} · #${m.entryIndex} · ${m.label}`), "", "REQUESTS", ...snap.entries.map((e,i)=>`${i+1}. ${e.kind} · ${e.method} · ${e.resource}${e.scope?` · ${e.scope}`:""} · ${e.durationMs} ms · HTTP ${e.status}${e.caller?` · ${e.caller}`:""}`)];
  const blob=new Blob([lines.join("\n")],{type:"text/plain;charset=utf-8"}),a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=`wallettracking-request-audit-${new Date().toISOString().replace(/[:.]/g,"-")}.txt`;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);
}
window.getRequestAuditSnapshot=requestAuditSnapshot;window.resetRequestAudit=resetRequestAudit;window.exportRequestAudit=exportRequestAudit;window.markRequestAudit=markRequestAudit;
markRequestAudit("script-start");

const sb = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

let currentUser = null;
let isAdmin = false;
let adminDebugMode = false;
const ADMIN_DEBUG_SESSION_KEY = "wallet_tracking_admin_debug_v1";
const UI_FONT_SCALE_KEY = "wallet_tracking_font_scale_v1";
const UI_FONT_SCALE_DEFAULT = 100;
const UI_THEME_KEY = "wallet_tracking_theme_v1";
let uiPreferencesSaveTimer=null;
function currentUiPreferences(){return {theme:document.documentElement.dataset.theme==="dark"?"dark":"light",font_scale:Math.max(85,Math.min(125,Number(document.getElementById("uiFontScale")?.value)||UI_FONT_SCALE_DEFAULT))};}
async function saveUiPreferencesToDb(){
  if(!currentUser?.id||!sb)return;
  const pref=currentUiPreferences();
  try{const {error}=await sb.from("user_ui_preferences").upsert({user_id:currentUser.id,theme:pref.theme,font_scale:pref.font_scale,updated_at:new Date().toISOString()},{onConflict:"user_id"});if(error)throw error;}catch(e){console.warn("UI-Einstellungen speichern",e);}
}
function scheduleUiPreferencesSave(){clearTimeout(uiPreferencesSaveTimer);uiPreferencesSaveTimer=setTimeout(saveUiPreferencesToDb,250);}
async function loadUiPreferencesFromDb(){
  if(!currentUser?.id||!sb)return;
  try{
    const {data,error}=await sb.from("user_ui_preferences").select("theme,font_scale").eq("user_id",currentUser.id).maybeSingle();if(error)throw error;
    if(data){applyUiFontScale(data.font_scale,false);applyUiTheme(data.theme,false);try{localStorage.setItem(UI_FONT_SCALE_KEY,String(data.font_scale));localStorage.setItem(UI_THEME_KEY,data.theme);}catch(_){}return;}
    // Einmalige Übernahme bestehender lokaler Einstellungen in die userbezogene DB.
    await saveUiPreferencesToDb();
  }catch(e){console.warn("UI-Einstellungen laden; lokaler Fallback bleibt aktiv",e);}
}
function applyUiFontScale(value, persist=true){
  const n=Math.max(85,Math.min(125,Number(value)||UI_FONT_SCALE_DEFAULT));
  document.documentElement.style.setProperty("--ui-font-scale",String(n/100));
  const slider=document.getElementById("uiFontScale");
  const label=document.getElementById("uiFontScaleValue");
  if(slider)slider.value=String(n);
  if(label)label.textContent=`${n}%`;
  if(persist){try{localStorage.setItem(UI_FONT_SCALE_KEY,String(n));}catch(_){}scheduleUiPreferencesSave();}
}
function initUiFontScale(){let n=UI_FONT_SCALE_DEFAULT;try{n=Number(localStorage.getItem(UI_FONT_SCALE_KEY)||UI_FONT_SCALE_DEFAULT);}catch(_){}applyUiFontScale(n,false);}
window.applyUiFontScale=applyUiFontScale;
function stepUiFontScale(delta){const slider=document.getElementById("uiFontScale");applyUiFontScale((Number(slider?.value)||UI_FONT_SCALE_DEFAULT)+Number(delta||0));}
function resetUiFontScale(){applyUiFontScale(UI_FONT_SCALE_DEFAULT);}
window.stepUiFontScale=stepUiFontScale;window.resetUiFontScale=resetUiFontScale;
function applyUiTheme(theme,persist=true){
  const mode=theme==="dark"?"dark":"light";document.documentElement.dataset.theme=mode;
  const btn=document.getElementById("uiThemeToggle");if(btn){btn.textContent=mode==="dark"?"☀":"☾";btn.title=mode==="dark"?"Hellmodus einschalten":"Dunkelmodus einschalten";}
  if(persist){try{localStorage.setItem(UI_THEME_KEY,mode);}catch(_){}scheduleUiPreferencesSave();}
}
function initUiTheme(){let mode="light";try{mode=localStorage.getItem(UI_THEME_KEY)||"light";}catch(_){}applyUiTheme(mode,false);}
function toggleUiTheme(){applyUiTheme(document.documentElement.dataset.theme==="dark"?"light":"dark");}
window.toggleUiTheme=toggleUiTheme;

const MAIN_SECTION_TABS={
  dashboard:["dashboard"],
  overview:["tracking","tax","fees","nfts","approvals"],
  wallets:["wallets","predefined","custom","discovery"],
  support:["chat","help","account-data"],
  admin:["admin"], projects:["projects-overview","tlnvow","dao1"]
};
function mainSectionForTab(name){
  for(const [section,tabs] of Object.entries(MAIN_SECTION_TABS)) if(tabs.includes(name)) return section;
  return "overview";
}
function updateContextNavigation(tabName){
  const section=mainSectionForTab(tabName);
  document.querySelectorAll("[data-main-section]").forEach(b=>b.classList.toggle("active",b.dataset.mainSection===section));
  document.querySelectorAll("[data-nav-section]").forEach(g=>g.style.display=(g.dataset.navSection===section?"block":"none"));
  const context=document.getElementById("contextNav");
  if(context) context.style.display=section==="dashboard"?"none":"block";
}
function showMainSection(section,preferredTab){
  const tabs=MAIN_SECTION_TABS[section]||["tracking"];
  showTab(preferredTab||tabs[0]);
}
window.showMainSection=showMainSection;
// Navigation bleibt während asynchroner Start-/Refresh-Läufe beim vom User gewählten Ziel.
// Ein Daten-Refresh darf die Ansicht nach Abschluss niemals ungefragt zurücksetzen.
let userNavigationTouched=false;
document.addEventListener("click",e=>{
  if(e.target?.closest?.("[data-tab],[data-main-section],.project-subtabs .tab-btn,[data-admin-tab],[data-open-admin]")) userNavigationTouched=true;
},true);
// Phase 5.78: Ein echter Benutzerklick ist fuer die optische Navigation autoritativ.
// Einzelne Projekt-/Admin-Loader duerfen den Active-State nicht versehentlich stehen lassen
// oder entfernen. Das laeuft in der Bubble-Phase NACH den Inline-Handlern und korrigiert
// ausschliesslich die jeweilige sichtbare Button-Gruppe; die Daten-/Fachlogik bleibt unberuehrt.
document.addEventListener("click",e=>{
  const btn=e.target?.closest?.(".tab-btn,[data-main-section],[data-admin-tab],[data-open-admin]");
  if(!btn)return;
  if(btn.matches(".project-subtabs .tab-btn")){
    const group=btn.closest(".project-subtabs");
    group?.querySelectorAll(":scope > .tab-btn").forEach(x=>x.classList.toggle("active",x===btn));
    return;
  }
  if(btn.matches("[data-admin-tab]")){
    const name=btn.dataset.adminTab;
    document.querySelectorAll("[data-admin-tab]").forEach(x=>x.classList.toggle("active",x.dataset.adminTab===name));
    document.querySelectorAll("[data-open-admin]").forEach(x=>x.classList.toggle("active",x.dataset.openAdmin===name));
    return;
  }
  if(btn.matches("[data-open-admin]")){
    const name=btn.dataset.openAdmin;
    document.querySelectorAll("[data-open-admin]").forEach(x=>x.classList.toggle("active",x.dataset.openAdmin===name));
    document.querySelectorAll("[data-admin-tab]").forEach(x=>x.classList.toggle("active",x.dataset.adminTab===name));
    return;
  }
  if(btn.matches("[data-tab]")){
    const name=btn.dataset.tab;
    const section=btn.closest("[data-nav-section]");
    if(section)section.querySelectorAll(".tab-btn[data-tab]").forEach(x=>x.classList.toggle("active",x===btn || (name==="chat"&&x.dataset.tab===name&&x.offsetParent!==null)));
    return;
  }
  if(btn.matches("[data-main-section]")){
    const section=btn.dataset.mainSection;
    document.querySelectorAll("[data-main-section]").forEach(x=>x.classList.toggle("active",x.dataset.mainSection===section));
  }
},false);
function initUiDisplay(){initUiFontScale();initUiTheme();}
if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",initUiDisplay,{once:true});else initUiDisplay();
let defiProjectsCache = [];
let predefinedTokenProject = {};
let predefinedTokenDashboardVisible = {};

// ---- Zentraler Datenjob-Manager (Phase 4.69) ----
// Datenaufbauten laufen strikt seriell. Solange ein Job aktiv ist, bleibt die
// Navigation gesperrt. Erst bei >2 s Laufzeit wird ein globaler Hinweis gezeigt.
const DATA_JOB_NOTICE_DELAY_MS=0;
let dataJobTail=Promise.resolve();
let dataJobActiveCount=0;
let dataJobNoticeTimer=null;
function ensureDataJobNotice(){
  let el=document.getElementById("globalDataJobNotice");
  if(el)return el;
  el=document.createElement("div");el.id="globalDataJobNotice";el.className="global-data-job-notice";
  el.innerHTML='<span class="global-data-job-spinner" aria-hidden="true"></span><div class="global-data-job-copy"><strong id="globalDataJobText">Daten werden geladen …</strong><span class="global-data-job-sub">Navigation ist während des Datenaufbaus gesperrt.</span><span class="global-data-job-bar" aria-hidden="true"><i></i></span></div>';
  document.body.appendChild(el);return el;
}
function setDataJobUi(active,label="Daten werden aktualisiert …"){
  document.body.classList.toggle("data-job-active",!!active);
  document.querySelectorAll("[data-main-section], .context-nav .tab-btn[data-tab]").forEach(b=>{b.disabled=!!active;b.setAttribute("aria-disabled",active?"true":"false");});
  const el=ensureDataJobNotice(),txt=document.getElementById("globalDataJobText");if(txt)txt.textContent=label||"Daten werden aktualisiert …";
  if(!active){clearTimeout(dataJobNoticeTimer);dataJobNoticeTimer=null;el.classList.remove("visible");}
}
function beginDataJobUi(label){
  dataJobActiveCount++;setDataJobUi(true,label);
  if(dataJobActiveCount===1){clearTimeout(dataJobNoticeTimer);dataJobNoticeTimer=null;ensureDataJobNotice().classList.add("visible");}
}
function endDataJobUi(){dataJobActiveCount=Math.max(0,dataJobActiveCount-1);if(!dataJobActiveCount)setDataJobUi(false);}
function runDataJob(label,job){
  const execute=async()=>{beginDataJobUi(label);try{return await job();}finally{endDataJobUi();}};
  const result=dataJobTail.then(execute,execute);dataJobTail=result.catch(()=>{});return result;
}
window.runDataJob=runDataJob;
window.isDataJobActive=()=>dataJobActiveCount>0;

const WT_ASYNC_ISSUE_LEVELS=new Set(["optional","retryable","partial","fatal"]);
const wtAsyncIssues=[];
function wtReportAsyncIssue(level,area,error,meta={}){
  const severity=WT_ASYNC_ISSUE_LEVELS.has(String(level))?String(level):"retryable";
  const message=String(error?.message||error||"Unbekannter Fehler");
  const item={at:new Date().toISOString(),severity,area:String(area||"Unbekannt"),message,meta:meta&&typeof meta==="object"?meta:{}};
  const key=`${item.severity}|${item.area}|${item.message}`;
  const prior=wtAsyncIssues.find(x=>x._key===key);
  if(prior){prior.count=(prior.count||1)+1;prior.at=item.at;prior.meta=item.meta;return prior;}
  wtAsyncIssues.push({...item,_key:key,count:1});
  if(wtAsyncIssues.length>100)wtAsyncIssues.shift();
  const label=`WalletTracking ${severity} · ${item.area}`;
  if(severity==="fatal"||severity==="partial")console.warn(label,{message,meta:item.meta,error});
  else console.info(label,{message,meta:item.meta,error});
  return item;
}
window.getWalletTrackingAsyncIssues=()=>wtAsyncIssues.map(({_key,...x})=>({...x}));
window.reportWalletTrackingAsyncIssue=wtReportAsyncIssue;


async function checkIsAdmin() {
  try {
    const { data, error } = await sb.from("admins").select("email").eq("email", currentUser.email).maybeSingle();
    if (error) { console.error(error); return false; }
    return !!data;
  } catch (e) {
    wtReportAsyncIssue("retryable","Admin-Berechtigung",e);
    return false;
  }
}

function applyAdminDebugMode(){
  const enabled=!!(isAdmin&&adminDebugMode);
  document.body.classList.toggle("admin-user",!!isAdmin);
  document.body.classList.toggle("admin-debug-mode",enabled);
  const btn=document.getElementById("adminDebugModeBtn");
  if(btn){
    btn.textContent=`🛠️ Debug-Modus: ${enabled?"AN":"AUS"}`;
    btn.classList.toggle("debug-on",enabled);
    btn.title=enabled?"Technische Diagnose-/DEV-Bereiche sind sichtbar.":"Technische Diagnose-/DEV-Bereiche sind verborgen.";
  }
}
// Zentrale Sichtbarkeitsfunktion für dynamisch gerenderte DEV-/Diagnose-Bereiche.
// Sichtbar ausschließlich bei Admin + explizit aktiviertem Debug-Modus.
window.applyDebugModeVisibility=applyAdminDebugMode;
function toggleAdminDebugMode(){
  if(!isAdmin)return;
  adminDebugMode=!adminDebugMode;
  try{sessionStorage.setItem(ADMIN_DEBUG_SESSION_KEY,adminDebugMode?"1":"0");}catch(_){ }
  applyAdminDebugMode();
  if(document.getElementById("tab-tax")?.classList.contains("active"))renderTaxResults(document.getElementById("taxDate")?.value||"",document.getElementById("taxTimezone")?.value||"");
}

async function sendMagicLink() {
  const email = document.getElementById("authEmail").value.trim();
  const statusEl = document.getElementById("authStatus");
  if (!email) { statusEl.textContent = "Bitte E-Mail-Adresse eingeben."; return; }
  statusEl.textContent = "Sende Login-Link...";
  const { error } = await sb.auth.signInWithOtp({
    email,
    options: { emailRedirectTo: REDIRECT_URL }
  });
  statusEl.textContent = error
    ? "Fehler: " + error.message
    : "Link verschickt - check dein E-Mail-Postfach und klick auf den Link.";
}

function bindAuthEmailEnter(){
  const input=document.getElementById("authEmail");
  if(!input||input.dataset.enterBound==="1")return;
  input.dataset.enterBound="1";
  input.addEventListener("keydown",e=>{
    if(e.key!=="Enter"||e.isComposing)return;
    e.preventDefault();
    sendMagicLink();
  });
}
if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",bindAuthEmailEnter,{once:true});else bindAuthEmailEnter();

const WELCOME_META_KEY = "wallet_tracking_welcome_dismissed_v1";
const DONATION_EVM_ADDRESS = "0x76882e6Fc045391Ba4F19d8a15eA4D8699Ff7382";

// ---- Release-Management + einmalige Datenmigrationen (Phase 5.89) ----
// Build-Version und Datenversion sind bewusst getrennt. Nur Releases mit echter
// Datenwirkung registrieren einen Migrationsjob; reine UI-/Text-Releases lösen
// keinen On-Chain-/API-Neuaufbau aus. Abschluss wird userbezogen in Supabase gespeichert.
const WT_CURRENT_RELEASE = "6.31";
const WT_RELEASE_REGISTRY = Object.freeze({
  "6.23": {
    title: "Korrektur der historischen APTM-Claim-Preisaktualisierung",
    userNotice: true,
    dataImpact: true,
    migrations: ["dao1:native-claim-flow-prices-v1"],
    bullets: [
      "Die in 6.22 gestartete historische USD-Bewertung nativer APTM-Claim-Flows wird korrigiert erneut ausgeführt.",
      "Ein nur zur Anzeige ergänztes Wallet-Adressfeld wird vor dem Supabase-Upsert entfernt; die Tabelle bleibt weiterhin sauber über wallet_id zugeordnet.",
      "Es ist keine SQL-Migration und kein Löschen des Wallets nötig; eine fehlgeschlagene 6.22-Datenmigration bleibt offen und wird automatisch erneut versucht."
    ]
  },
  "6.22": {
    title: "Historische USD-Werte für native APTM-Claims",
    userNotice: true,
    dataImpact: true,
    migrations: ["dao1:native-claim-flow-prices-v1"],
    bullets: [
      "Die bereits kanonisch gespeicherten nativen APTM-Claim-Flows erhalten ihren historischen APTM/USD-Kurs und USD-Wert direkt im Asset-Flow.",
      "Vorhandene historische Transaktionspreise werden zuerst wiederverwendet; nur noch offene Claim-Blöcke werden gesammelt über die bestehende exact-v13 Price-Anchor-Engine bewertet.",
      "Neue native APTM-Claims werden künftig beim Anlegen des Asset-Flows über denselben zentralen Bewertungsweg bewertet; Claim-Mengen und NFT-Zuordnung bleiben unverändert."
    ]
  },
  "6.20": {
    title: "Native APTM-Claims werden als Asset-Flows vereinheitlicht",
    userNotice: true,
    dataImpact: true,
    migrations: ["dao1:native-claim-flows-v1"],
    bullets: [
      "Native APTM-Auszahlungen aus Bot-Claims werden jetzt wie ERC-20-Claims als kanonische Asset-Flows gespeichert.",
      "Bestehende bestätigte native Claims werden einmalig aus dem Claim-Cache in project_transaction_asset_flows nachgezogen; dafür ist kein neuer Blockchain-Vollscan nötig.",
      "Die bisherigen Claim-Reward-Felder bleiben vorerst nur als Kompatibilitätscache erhalten; sichtbare Summen lesen weiterhin asset-flow-first."
    ]
  },
  "5.93": {
    title: "NFT-Datenmigration und APTMDAO-RPC wurden korrigiert",
    userNotice: true,
    dataImpact: true,
    migrations: ["dao1:nft-store-metadata-v3"],
    bullets: [
      "Der Apertum-RPC-Proxy erlaubt jetzt gezielt die für APTMDAO-DID-Owner/Parent benötigten eth_call-Abfragen; andere eth_call-Ziele/Funktionen bleiben gesperrt.",
      "Teilweise abgeschlossene Datenmigrationen können nun als Status partial in Supabase gespeichert werden und werden nicht mehr durch den alten Status-Constraint abgewiesen.",
      "Die NFT-/Ownership-Prüfung wird als Datenversion 4 automatisch erneut ausgeführt; bei technischen Restfehlern bleibt sie offen statt fälschlich als abgeschlossen zu gelten."
    ]
  },
  "5.92": {
    title: "NFT-Datenquellen werden serverseitig und vollständig geprüft",
    userNotice: true,
    dataImpact: true,
    migrations: ["dao1:nft-store-metadata-v3"],
    bullets: [
      "APTMDAO-Metadaten von api.aptmdao.io werden serverseitig über die bestehende geschützte Wallet-Edge-Funktion geladen; Browser-CORS blockiert diese Quelle nicht mehr.",
      "Die NFT-Datenmigration unterscheidet jetzt erfolgreich, teilweise und fehlgeschlagen. Technisch nicht erreichbare Datenquellen werden nicht mehr fälschlich als abgeschlossen markiert.",
      "Legitime APTMDAO-eth_call-Abfragen für DID-Owner/Parent dürfen den vorhandenen RPC-Proxy verwenden. Die NFT-Prüfung läuft automatisch erneut; kein manueller NFT-Refresh ist nötig."
    ]
  },
  "5.91": {
    title: "NFT-Metadaten werden CORS-sicher neu geprüft",
    userNotice: true,
    dataImpact: true,
    migrations: ["dao1:nft-store-metadata-v3"],
    bullets: [
      "Apertum-Explorer-Webseiten werden nicht mehr fälschlich als JSON-Metadatenquelle geladen.",
      "Nur echte Metadata-/Token-URIs werden für Bild und NFT-Namen abgefragt; generische Botnamen bleiben weiterhin nur Fallback.",
      "Die NFT-Metadatenprüfung wird einmalig automatisch wiederholt. Bestehende Besitz-, Kaufpreis-, Spam- und Safe-Daten bleiben erhalten."
    ]
  },
  "5.90": {
    title: "DAO-NFT-Namen werden genauer erkannt",
    userNotice: true,
    dataImpact: true,
    migrations: ["dao1:nft-store-metadata-v3"],
    bullets: [
      "Apertum-NFTs werden erneut auf den echten DAO-Store-/Metadata-Namen geprüft (z. B. Nebula, Galactic, Lunar oder Solar).",
      "Neben dem NFT-Namen werden jetzt auch Store-/Metadata-Attribute und vorhandene DAO-Projektbezeichnungen ausgewertet; generische Bezeichnungen wie MineBot #12345 bleiben nur Fallback.",
      "Bestehende NFT-Caches werden automatisch aktualisiert; Bild, NFT-ID, Kauf-/Besitzhistorie und manuelle Spam-/Safe-Markierungen bleiben erhalten."
    ]
  }
});
let wtLastMigrationSummary={storageAvailable:true,results:[]};
function wtReleaseLocalAckKey(releaseKey){return `wallet_tracking_release_ack_${currentUser?.id||"anon"}_${releaseKey}`;}
function wtIsMissingReleaseTable(error){
  const code=String(error?.code||"");const msg=String(error?.message||"").toLowerCase();
  return code==="PGRST205"||code==="42P01"||msg.includes("user_release_acknowledgements")||msg.includes("user_data_migrations");
}
async function wtLoadMigrationStates(){
  if(!currentUser?.id)return {available:false,rows:new Map()};
  try{
    const {data,error}=await sb.from("user_data_migrations").select("migration_key,data_version,status,completed_at,last_error,details").eq("user_id",currentUser.id);
    if(error)throw error;return {available:true,rows:new Map((data||[]).map(r=>[String(r.migration_key),r]))};
  }catch(e){
    if(!wtIsMissingReleaseTable(e))console.warn("Datenmigrationen laden",e);
    return {available:false,rows:new Map(),error:e};
  }
}
async function wtSaveMigrationState(key,dataVersion,status,extra={}){
  if(!currentUser?.id)return false;
  const payload={user_id:currentUser.id,migration_key:key,data_version:Number(dataVersion||0),status,updated_at:new Date().toISOString(),...extra};
  try{const {error}=await sb.from("user_data_migrations").upsert(payload,{onConflict:"user_id,migration_key"});if(error)throw error;return true;}catch(e){if(!wtIsMissingReleaseTable(e))console.warn("Datenmigration speichern",e);return false;}
}
let wtNftMigrationTechnicalIssues=null;
function wtTrackNftMigrationIssue(kind,url,error){
  if(!Array.isArray(wtNftMigrationTechnicalIssues))return;
  const item={kind:String(kind||"metadata"),url:String(url||"").slice(0,500),error:String(error?.message||error||"Unbekannter technischer Fehler").slice(0,500)};
  const key=`${item.kind}|${item.url}|${item.error}`;
  if(!wtNftMigrationTechnicalIssues.some(x=>x._key===key))wtNftMigrationTechnicalIssues.push({...item,_key:key});
}
window.reportWalletTrackingMigrationIssue=(kind,url,error)=>wtTrackNftMigrationIssue(kind,url,error);
async function wtMigrationDao1NftMetadataOwnership(){
  await ensureNftCacheLoaded();
  const targets=wallets.filter(w=>!!walletAddressForChain(w,"apertum"));
  let refreshedWallets=0,nftCount=0,repaired=0,remaining=0,failed=0;
  wtNftMigrationTechnicalIssues=[];
  try{
    for(const w of targets){
      const nr=await refreshNftsForWallet(w,null,{onlyChains:["apertum"]});
      refreshedWallets++;nftCount+=Number(nr?.count||0);failed+=(nr?.errors||[]).length;
      if(window.DAO1Project?.repairNftOwnershipForWallet){
        const rr=await window.DAO1Project.repairNftOwnershipForWallet(w);
        repaired+=Number(rr?.repaired||0);remaining+=Number(rr?.remaining||0);failed+=Number(rr?.failed||0);
      }
    }
    await window.DAO1Project?.loadDashboardSummary?.().catch(e=>wtTrackNftMigrationIssue("dao-dashboard-summary","",e));
    refreshDashboardProjectSummaries?.().catch(e=>wtReportAsyncIssue("optional","Dashboard-Projektsummen",e));
    const issues=wtNftMigrationTechnicalIssues.map(({_key,...x})=>x);
    const details={wallets:refreshedWallets,nfts:nftCount,repaired,remaining,failed,technicalIssues:issues};
    if(failed>0||issues.length>0){
      const reasons=[];
      if(failed>0)reasons.push(`${failed} NFT-/Ownership-Prüfung(en)`);
      if(issues.length>0)reasons.push(`${issues.length} technische Datenquelle(n)`);
      return {migrationStatus:"partial",details,lastError:`${reasons.join(" und ")} konnten nicht vollständig abgeschlossen werden.`};
    }
    return {migrationStatus:"complete",details};
  }finally{
    wtNftMigrationTechnicalIssues=null;
  }
}
async function wtMigrationDao1NativeClaimFlows(){
  if(!window.DAO1Project?.backfillNativeClaimAssetFlows)throw new Error("DAO1 Native-Claim-Flow-Migration ist nicht verfügbar.");
  const result=await window.DAO1Project.backfillNativeClaimAssetFlows();
  await window.DAO1Project?.loadDashboardSummary?.().catch(e=>console.warn("DAO1 Dashboard nach Native-Claim-Migration",e));
  refreshDashboardProjectSummaries?.().catch(e=>wtReportAsyncIssue("optional","Dashboard-Projektsummen",e));
  return {migrationStatus:"complete",details:result||{wallets:0,claims:0,persisted:0}};
}
async function wtMigrationDao1NativeClaimFlowPrices(){
  if(!window.DAO1Project?.backfillNativeClaimAssetFlowPrices)throw new Error("DAO1 Native-Claim-Flow-Preis-Migration ist nicht verfügbar.");
  const result=await window.DAO1Project.backfillNativeClaimAssetFlowPrices();
  await window.DAO1Project?.loadDashboardSummary?.().catch(e=>console.warn("DAO1 Dashboard nach Native-Claim-Preis-Migration",e));
  refreshDashboardProjectSummaries?.().catch(e=>wtReportAsyncIssue("optional","Dashboard-Projektsummen",e));
  return {migrationStatus:"complete",details:result||{wallets:0,flows:0,reusedTxPrices:0,enginePriced:0,prelaunch:0,missing:0,persisted:0}};
}

const WT_DATA_MIGRATIONS = Object.freeze({
  "dao1:native-claim-flow-prices-v1": {version:1,release:"6.22",label:"DAO1 native APTM-Claim-Flows → historische USD-Bewertung",run:wtMigrationDao1NativeClaimFlowPrices},
  "dao1:native-claim-flows-v1": {version:1,release:"6.20",label:"DAO1 native APTM-Claims → kanonische Asset-Flows",run:wtMigrationDao1NativeClaimFlows},
  "dao1:nft-store-metadata-v3": {version:4,release:"5.93",label:"DAO1/APTM NFT-Metadaten + Ownership/DID-Repair · RPC/partial Fix",run:wtMigrationDao1NftMetadataOwnership}
});
async function runPendingDataMigrations(){
  const state=await wtLoadMigrationStates();
  const summary={storageAvailable:state.available,results:[]};
  for(const [key,m] of Object.entries(WT_DATA_MIGRATIONS)){
    const prior=state.rows.get(key);
    if(prior?.status==="complete"&&Number(prior.data_version||0)>=Number(m.version||1)){summary.results.push({key,label:m.label,status:"already_complete",details:prior.details||null});continue;}
    if(!state.available){summary.results.push({key,label:m.label,status:"storage_unavailable"});continue;}
    await wtSaveMigrationState(key,Number(prior?.data_version||0),"running",{started_at:new Date().toISOString(),last_error:null});
    try{
      const outcome=await m.run();
      const requestedStatus=String(outcome?.migrationStatus||"complete");
      const details=outcome?.details??outcome??null;
      if(requestedStatus==="partial"){
        const msg=String(outcome?.lastError||"Datenmigration nur teilweise abgeschlossen.");
        await wtSaveMigrationState(key,Number(prior?.data_version||0),"partial",{completed_at:null,last_error:msg,details});
        summary.results.push({key,label:m.label,status:"partial",error:msg,details});
        continue;
      }
      await wtSaveMigrationState(key,m.version,"complete",{completed_at:new Date().toISOString(),last_error:null,details});
      summary.results.push({key,label:m.label,status:"complete",details});
    }catch(e){
      const msg=String(e?.message||e);
      await wtSaveMigrationState(key,Number(prior?.data_version||0),"failed",{completed_at:null,last_error:msg,details:null});
      summary.results.push({key,label:m.label,status:"failed",error:msg});
      console.warn("Datenmigration fehlgeschlagen",key,e);
    }
  }
  wtLastMigrationSummary=summary;return summary;
}
async function wtReleaseAckState(releaseKey){
  const localKey=wtReleaseLocalAckKey(releaseKey);let local=false;try{local=localStorage.getItem(localKey)==="1";}catch(_){}
  if(!currentUser?.id)return local;
  try{
    const {data,error}=await sb.from("user_release_acknowledgements").select("release_key").eq("user_id",currentUser.id).eq("release_key",releaseKey).maybeSingle();
    if(error)throw error;
    if(data)return true;
    if(local){await sb.from("user_release_acknowledgements").upsert({user_id:currentUser.id,release_key:releaseKey,acknowledged_at:new Date().toISOString()},{onConflict:"user_id,release_key"});return true;}
    return false;
  }catch(e){if(!wtIsMissingReleaseTable(e))console.warn("Release-Quittierung laden",e);return local;}
}
function wtReleaseMigrationStatusText(release){
  const wanted=new Set(release?.migrations||[]),rows=(wtLastMigrationSummary?.results||[]).filter(r=>wanted.has(r.key));
  if(!rows.length)return release?.dataImpact?"Datenaktualisierung: kein Status verfügbar.":"";
  if(rows.some(r=>r.status==="failed"))return "Datenaktualisierung: fehlgeschlagen. Die offene Migration wird beim nächsten Start erneut versucht.";
  if(rows.some(r=>r.status==="partial"))return "Datenaktualisierung: teilweise abgeschlossen. Mindestens eine technische Datenquelle war nicht vollständig erreichbar; die Migration bleibt offen und wird beim nächsten Start erneut versucht.";
  if(rows.some(r=>r.status==="storage_unavailable"))return "Datenaktualisierung: Migrationsspeicher noch nicht verfügbar. Bitte die mitgelieferte SQL-Migration ausführen.";
  if(rows.every(r=>["complete","already_complete"].includes(r.status)))return "✓ Datenaktualisierung abgeschlossen";
  return "Datenaktualisierung wird verwaltet.";
}
async function maybeShowReleaseNotice(){
  const release=WT_RELEASE_REGISTRY[WT_CURRENT_RELEASE];if(!release?.userNotice||await wtReleaseAckState(WT_CURRENT_RELEASE))return false;
  const modal=document.getElementById("releaseNoticeModal"),title=document.getElementById("releaseNoticeTitle"),body=document.getElementById("releaseNoticeBody"),status=document.getElementById("releaseNoticeStatus");
  if(!modal)return false;if(title)title.textContent=release.title||`Neu in Version ${WT_CURRENT_RELEASE}`;
  if(body)body.innerHTML=`<p>Version <strong>${WT_CURRENT_RELEASE}</strong> enthält Änderungen, die deine gespeicherten Daten betreffen können.</p><ul>${(release.bullets||[]).map(x=>`<li>${escapeAttr(x)}</li>`).join("")}</ul>`;
  if(status){status.textContent=wtReleaseMigrationStatusText(release);status.className="note";}
  modal.classList.add("open");modal.setAttribute("aria-hidden","false");return true;
}
async function acknowledgeReleaseNotice(btn){
  if(btn){btn.disabled=true;btn.textContent="Wird gespeichert…";}
  const releaseKey=WT_CURRENT_RELEASE,localKey=wtReleaseLocalAckKey(releaseKey);let saved=false;
  try{
    const {error}=await sb.from("user_release_acknowledgements").upsert({user_id:currentUser.id,release_key:releaseKey,acknowledged_at:new Date().toISOString()},{onConflict:"user_id,release_key"});
    if(error)throw error;saved=true;
  }catch(e){if(!wtIsMissingReleaseTable(e))console.warn("Release-Quittierung speichern",e);}
  try{localStorage.setItem(localKey,"1");}catch(_){}
  const modal=document.getElementById("releaseNoticeModal");modal?.classList.remove("open");modal?.setAttribute("aria-hidden","true");
  if(btn){btn.disabled=false;btn.textContent="Schliessen";}
  if(!saved)console.warn("Release-Quittierung nur lokal gespeichert; Supabase-Migration 071 prüfen.");
  maybeShowWelcomeModal();
}
window.acknowledgeReleaseNotice=acknowledgeReleaseNotice;

function maybeShowWelcomeModal() {
  if (!currentUser?.user_metadata?.[WELCOME_META_KEY]) {
    document.getElementById("welcomeModal")?.classList.add("open");
  }
}
function closeWelcomeModal() { document.getElementById("welcomeModal")?.classList.remove("open"); }
function welcomeGoToHelp() { closeWelcomeModal(); showTab("help"); }
async function dismissWelcomeForever(btn) {
  if (btn) { btn.disabled = true; btn.textContent = "Wird gespeichert…"; }
  const merged = { ...(currentUser?.user_metadata || {}), [WELCOME_META_KEY]: true };
  const { data, error } = await sb.auth.updateUser({ data: merged });
  if (error) {
    console.error("Willkommens-Hinweis speichern:", error);
    if (btn) { btn.disabled = false; btn.textContent = "Nicht mehr anzeigen"; }
    alert("Die Einstellung konnte nicht gespeichert werden. Bitte später nochmals versuchen.");
    return;
  }
  if (data?.user) currentUser = data.user;
  closeWelcomeModal();
}

function openDonationModal() {
  document.getElementById("donationModal")?.classList.add("open");
  renderDonationQr();
}
function closeDonationModal() { document.getElementById("donationModal")?.classList.remove("open"); }
function renderDonationQr() {
  const chain = document.getElementById("donationChain")?.value || "bsc";
  const token = document.getElementById("donationToken")?.value || "USDT";
  const chainLabel = { bsc:"BNB Smart Chain (BSC)", eth:"Ethereum", matic:"Polygon" }[chain] || chain;
  const qr = document.getElementById("donationQr");
  const note = document.getElementById("donationSelectionNote");
  if (note) note.innerHTML = `<strong>${token}</strong> über <strong>${chainLabel}</strong>`;
  if (!qr) return;
  qr.innerHTML = "";
  if (typeof QRCode === "undefined") { qr.innerHTML = '<span style="color:#111;font-size:.75rem;text-align:center">QR-Code konnte nicht geladen werden.</span>'; return; }
  new QRCode(qr, { text:DONATION_EVM_ADDRESS, width:180, height:180, correctLevel:QRCode.CorrectLevel.M });
}
async function copyDonationAddress() {
  const status = document.getElementById("donationCopyStatus");
  try {
    await navigator.clipboard.writeText(DONATION_EVM_ADDRESS);
    if (status) status.textContent = "Kopiert ✓";
  } catch (_) {
    if (status) status.textContent = "Bitte Adresse manuell kopieren.";
  }
}


let wtAuthSessionLost=false;
let wtAuthSessionLossReason="";
let wtAuthSessionCheckPromise=null;

function wtRenderSessionExpiredState(reason="Sitzung abgelaufen"){
  wtAuthSessionLost=true;
  wtAuthSessionLossReason=String(reason||"Sitzung abgelaufen");
  currentUser=null;
  isAdmin=false;
  adminDebugMode=false;
  try{sessionStorage.removeItem(ADMIN_DEBUG_SESSION_KEY);}catch(_){ }
  applyAdminDebugMode();
  const gate=document.getElementById("authGate");
  const app=document.getElementById("appContent");
  const actions=document.getElementById("heroUserActions");
  const label=document.getElementById("userEmailLabel");
  const status=document.getElementById("authStatus");
  if(app)app.style.display="block"; // Cache-/DB-Stand bleibt sichtbar, aber ohne private Nachladejobs.
  if(gate){
    gate.style.display="block";
    gate.classList.add("wt-session-expired");
    const h=gate.querySelector("h3");if(h)h.textContent="Sitzung abgelaufen – bitte neu anmelden";
  }
  if(status)status.innerHTML=`<strong>${escapeAttr(wtAuthSessionLossReason)}</strong><br>Der vorhandene Stand bleibt sichtbar. Private Daten werden erst nach erneuter Anmeldung wieder aktualisiert.`;
  if(actions)actions.style.display="none";
  if(label)label.textContent="Sitzung abgelaufen";
  document.body.classList.add("wt-auth-session-expired");
  dataJobActiveCount=0;setDataJobUi(false);
  try{if(globalPriceTimer){clearTimeout(globalPriceTimer);globalPriceTimer=null;}}catch(_){ }
  console.warn("WalletTracking Auth Session Lost",{reason:wtAuthSessionLossReason});
}
window.handleWalletTrackingSessionLost=(reason,error)=>{
  if(!wtAuthSessionLost)wtRenderSessionExpiredState(reason||error?.message||"Sitzung abgelaufen");
  return false;
};

async function wtRequireActiveSession({reason="Sitzung abgelaufen",silent=false}={}){
  if(wtAuthSessionLost)return null;
  if(!wtAuthSessionCheckPromise){
    wtAuthSessionCheckPromise=(async()=>{
      try{
        const {data,error}=await sb.auth.getSession();
        if(error)throw error;
        const session=data?.session||null;
        if(!session?.user?.id||!session?.access_token){
          wtRenderSessionExpiredState(reason);
          return null;
        }
        currentUser=session.user;
        return session;
      }catch(e){
        if(!silent)console.warn("WalletTracking Session-Prüfung",e);
        wtRenderSessionExpiredState(reason);
        return null;
      }finally{
        setTimeout(()=>{wtAuthSessionCheckPromise=null;},0);
      }
    })();
  }
  return await wtAuthSessionCheckPromise;
}
window.requireWalletTrackingSession=wtRequireActiveSession;

function wtRestoreAuthenticatedUi(session){
  if(!session?.user)return;
  wtAuthSessionLost=false;wtAuthSessionLossReason="";currentUser=session.user;
  document.body.classList.remove("wt-auth-session-expired");
  const gate=document.getElementById("authGate");
  const status=document.getElementById("authStatus");
  if(gate){gate.style.display="none";gate.classList.remove("wt-session-expired");const h=gate.querySelector("h3");if(h)h.textContent="Login";}
  if(status)status.textContent="";
}

async function logout() {
  await sb.auth.signOut();
  location.reload();
}

async function initAuth() {
  const { data: { session } } = await sb.auth.getSession();
  sb.auth.onAuthStateChange((event, newSession) => {
    if(newSession?.user){
      wtRestoreAuthenticatedUi(newSession);
      if (!document.getElementById("appContent")?.style.display) {
        beginDataJobUi("Daten werden geladen …");
        onLoggedIn(newSession).finally(()=>endDataJobUi());
      }
      return;
    }
    if(event==="SIGNED_OUT"||event==="USER_DELETED"){
      wtRenderSessionExpiredState(event==="SIGNED_OUT"?"Sitzung beendet – bitte neu anmelden.":"Benutzerkonto ist nicht mehr angemeldet.");
    }
  });
  if (session) {
    wtRestoreAuthenticatedUi(session);
    beginDataJobUi("Daten werden geladen …");
    try { await onLoggedIn(session); } finally { endDataJobUi(); }
  } else {
    currentUser=null;
  }
}

async function onLoggedIn(session) {
  markRequestAudit("login-start");
  wtRestoreAuthenticatedUi(session);
  currentUser = session.user;
  document.getElementById("authGate").style.display = "none";
  // Das App-Gerüst und der Dashboard-Tab werden sofort sichtbar. Chain-/DB-Konfiguration
  // lädt danach; dadurch blockiert kein Supabase-Read die sichtbare Startseite.
  document.getElementById("appContent").style.display = "block";
  document.querySelectorAll(".tab-panel").forEach(p => p.classList.remove("active"));
  document.getElementById("tab-dashboard")?.classList.add("active");
  document.querySelectorAll(".tab-btn[data-tab]").forEach(b => b.classList.toggle("active", b.dataset.tab === "dashboard"));
  // Startzustand vollständig wie bei einem manuellen Dashboard-Klick synchronisieren.
  // showTab() ist während des Start-Datenjobs absichtlich gesperrt, daher Navigation hier direkt setzen.
  updateContextNavigation("dashboard");
  document.getElementById("userEmailLabel").textContent = "Eingeloggt als " + currentUser.email;
  document.getElementById("heroUserActions").style.display = "block";

  // Chain-Konfiguration ist zwingend. Ohne public.chains wird NICHT mit versteckten
  // HTML-Fallbacks weitergearbeitet.
  try {
    await loadChainConfigFromDb();
  } catch (e) {
    console.error(e);
    const gate = document.getElementById("authGate");
    if (gate) {
      gate.style.display = "block";
      gate.innerHTML = `<div class="auth-card"><h2>Konfigurationsfehler</h2>
        <div class="error">${escapeAttr(e.message || String(e))}</div>
        <p class="note">Das Dashboard benötigt die Chain-Konfiguration aus Supabase und startet ohne diese Daten bewusst nicht.</p></div>`;
    }
    return;
  }

  document.getElementById("appContent").style.display = "block";
  // Dashboard sofort als sichtbare Startseite setzen; die Cache-Daten füllen sich danach schrittweise.
  if(!userNavigationTouched) showTab("dashboard");

  // Unabhängige Start-Reads parallel ausführen. Das Dashboard bleibt währenddessen sichtbar.
  // Dieses Muster entspricht den Projekt-Trees: kleiner Startkern, Cache/DB parallel, keine Discovery.
  loadTokenMetaCache();
  const [adminResult]=await Promise.all([
    checkIsAdmin(),
    loadDefiProjectsCache(),
    loadPredefinedTokensFromDb(),
    loadWalletsFromDb(),
    loadCustomSafeTokensFromDb()
  ]);
  isAdmin=!!adminResult;
  await loadUiPreferencesFromDb();
  restoreDashboardProjectCacheStats();
  try{adminDebugMode=isAdmin&&sessionStorage.getItem(ADMIN_DEBUG_SESSION_KEY)==="1";}catch(_){adminDebugMode=false;}
  applyAdminDebugMode();
  document.getElementById("adminNavGroup").style.display = isAdmin ? "block" : "none";
  const adminMainNavBtn=document.getElementById("adminMainNavBtn"); if(adminMainNavBtn) adminMainNavBtn.style.display=isAdmin?"flex":"none";
  document.getElementById("userChatTabBtn").style.display = isAdmin ? "none" : "inline-block";
  document.getElementById("adminChatTabBtn").style.display = isAdmin ? "inline-block" : "none";
  document.getElementById("feesTabBtn").style.display = "inline-block";
  document.getElementById("adminAddPredefinedTokenCard").style.display = isAdmin ? "block" : "none";
  if (isAdmin) document.getElementById("newPredefChain").innerHTML = Object.keys(CHAIN_META).map(c => `<option value="${c}">${CHAIN_META[c].label}</option>`).join("");
  setupChatRealtime();
  // Badge ist für den Start nicht kritisch und blockiert den Dashboard-Aufbau nicht mehr.
  updateChatUnreadBadge().catch(e=>console.warn("Chat-Badge",e));

  if (window.WalletLPEngine) {
    window.WalletLPEngine.configure(() => ({
      chainConfig: CHAIN_CONFIG,
      predefinedTokenSymbols, predefinedTokenNames, predefinedTokenDecimals,
      currentPrice: priceForToken,
      historicalPrice: taxHistoricalPrice,
      currentRpc: (chain, method, params) => evmRpcCall(configuredRpcUrl(chain), method, params),
      archiveRpc,
      sb, currentUser, wallets
    }));
  }

  if (window.WalletStakingEngine) {
    window.WalletStakingEngine.configure(() => ({ sb, currentUser }));
  }

  if (window.DAO1Project) {
    window.DAO1Project.configure({
      sb,
      getContext: () => ({
        currentUser,
        isAdmin,
        wallets,
        walletData,
        snapshots,
        chainMeta: CHAIN_META,
        chainConfig: CHAIN_CONFIG,
        predefinedTokenProject,
        predefinedTokenCategory,
        tokenFormat: window.WalletTokenFormat,
        normalizeAddress,
        dustThreshold: DUST_THRESHOLD,
        lpEngine: window.WalletLPEngine,
        priceForToken, taxHistoricalPrice, taxEvmBlockByTime,
        refreshApertumNftsForWallet
      })
    });
    // Cache-first/Lazy: DAO1 wird nur gemountet. DB-/Projekt-Caches werden erst beim Öffnen des DAO1-Tabs geladen.
    await window.DAO1Project.ensureMounted();
  }

  if (window.TLNVOWDiscovery?.configure) {
    window.TLNVOWDiscovery.configure({
      getContext: () => ({ currentUser, wallets, tokenFormat: window.WalletTokenFormat })
    });
  }

  activeChainFilter = new Set(Object.keys(CHAIN_META)); // Chain-Filter IMMER mit allen Chains starten
  renderChainFilter();
  renderWalletInputs();
  renderGlobalWalletPersonFilter();
  renderEvmWalletChainsNote();
  renderCustomChainSelect();
  renderCustomTokenList();
  renderSafeTokenTable();
  renderSnapshotManager();
  renderChartWalletSelect();
  renderChartChainSelect();
  renderAllocWalletSelect();
  renderResults();
  activeDiscoveryChains = new Set(discoveryChains());
  renderDiscoveryChainFilter();
  renderDiscoveryWalletSelect();
  await loadWalletRefreshStates();
  renderWalletDataFreshness();
  activeFeesChains = new Set(feeChains());
  renderFeesChainFilter();
  renderFeesWalletSelect();
  activeApprovalsChains = new Set(approvalsChains());
  renderApprovalsChainFilter();
  renderApprovalsWalletSelect();
  activeNftChains = new Set(nftChains());
  renderNftChainFilter();
  renderNftWalletSelect();

  // Zuerst den letzten automatisierten Snapshot sofort anzeigen. Seit Phase 5.75
  // startet ein normaler Login/Reload keinen allgemeinen Live-Grunddatenlauf mehr.
  // Der Refresh-State dient hier nur zur Anzeige, ob eine gezielte Aktualisierung sinnvoll ist.
  const cachedAt = await loadFromAutomatedCache();
  const autoRefreshNeeded = wallets.some(w => Object.keys(CHAIN_CONFIG).some(c => walletAddressForChain(w,c) && CHAIN_CONFIG[c]?.balanceProvider && !refreshedToday(w,c,'balances')) || (w.evm && !refreshedToday(w,'bsc','project:tln_vow')) || !refreshedToday(w,'','nft'));
  if (cachedAt) {
    renderResults();
    renderSafeTokenTable();
    renderCustomTokenList();
    renderAllocationChart();
    renderCacheStatusNote(
      autoRefreshNeeded
        ? "Bestände vom " + fmtSnapshotDateTime(cachedAt) + " – Aktualisierung verfügbar; kein automatischer On-Chain-Refresh beim Seitenstart."
        : "Bestände vom " + fmtSnapshotDateTime(cachedAt) + " – heute bereits live aktualisiert. Weitere Aktualisierungen nur manuell."
    );
  } else {
    renderCacheStatusNote(wallets.length > 0
      ? "Noch kein gespeicherter Stand – bitte „Daten aktualisieren“ starten."
      : "Noch kein gespeicherter Stand.");
  }

  // Cache-first: Beim Start ausschliesslich den gespeicherten Preisstand laden.
  // APIs, Pool-RPC und TLN-Infrastruktur werden nur durch die manuelle Preisaktualisierung gestartet.
  await loadCachedCurrentPricesAtStart().catch(e=>console.warn("Gespeicherter Preisstand:",e));
  // Zentrale NFT-Current-State-Registry beim App-Start aus Supabase restaurieren. Alle Verbraucher
  // (NFT-Tab, DAO-Team, Dashboard/Alerts) sehen damit denselben Bestand, ohne dass
  // der NFT-Tab zuerst geöffnet werden muss. Historische Ersterwerbs-/Kaufpreisarbeit bleibt getrennt.
  await ensureNftCacheLoaded().catch(e=>console.warn("NFT-Registry Start:",e));
  // Releasegebundene Datenmigrationen laufen genau einmal pro User/Datenversion.
  // Sie werden vor der Release-Mitteilung abgeschlossen, damit der User den effektiven Status sieht.
  await runPendingDataMigrations().catch(e=>console.warn("Release-Datenmigrationen",e));
  scheduleGlobalPriceRefresh();
  // Projekt-Grunddaten werden unabhängig vom Öffnen der Detail-Tabs aus ihren persistenten Caches restauriert.
  // Das Dashboard wartet nicht darauf; die Summary-Bridge rendert nach Abschluss erneut.
  if(wallets.length)setTimeout(()=>refreshDashboardProjectSummaries().catch(e=>console.warn("Dashboard Project-Summaries Start",e)),120);

  if(!userNavigationTouched) showTab("dashboard");
  const releaseNoticeShown=await maybeShowReleaseNotice();
  if(!releaseNoticeShown)maybeShowWelcomeModal();

  // Strikt cache-first: Ein Seiten-Reload startet KEIN loadAll() und damit keine breite
  // Balance-/NFT-/Projekt-On-Chain-Prüfung. Wir zeigen nur an, dass ein Refresh verfügbar ist.
  // Aktualisierung erfolgt über „Daten aktualisieren“ bzw. projektspezifische Refresh-Aktionen.
  if (autoRefreshNeeded && wallets.length > 0) {
    renderCacheStatusNote(cachedAt
      ? "Bestände vom " + fmtSnapshotDateTime(cachedAt) + " – Aktualisierung verfügbar; kein automatischer On-Chain-Refresh beim Seitenstart."
      : "Noch kein gespeicherter Stand – bitte „Daten aktualisieren“ starten.");
  }
  markRequestAudit("login-ready");
}


// ---- Bestandesaufnahme per 31.12: historische Bestände ----
let taxRows = [];
let taxCoverage = [];
const taxPriceCache = new Map();

let taxSnapshotLoaded = false;

function taxSnapshotWalletId(row){
  const w=wallets.find(x=>String(x.dbId||x.id)===String(row.wallet_id));
  return w?.dbId||w?.id||row.wallet_id||null;
}
async function loadTaxSnapshot(date,walletSel="__all"){
  if(!currentUser||!date)return false;
  let q=sb.from("year_end_positions").select("*").eq("snapshot_date",date).order("wallet_id").order("chain_key").order("symbol");
  if(walletSel!=="__all")q=q.eq("wallet_id",walletSel);
  const {data,error}=await q;
  if(error){if(error.code!=="PGRST205")console.warn("Gespeicherte Bestandesaufnahme:",error);return false;}
  if(!data?.length)return false;
  taxRows=data.map(r=>{
    const w=wallets.find(x=>String(x.dbId||x.id)===String(r.wallet_id));
    if(!w)return null;
    return {wallet:w.label,wallet_address:walletAddressForChain(w,r.chain_key),chain:r.chain_key,asset:r.asset_key,symbol:r.symbol,amount:r.amount==null?null:Number(r.amount),decimals:r.decimals,block:r.block_ref,price_usd:r.price_usd==null?null:Number(r.price_usd),value_usd:r.value_usd==null?null:Number(r.value_usd),price_source:r.price_source,status:r.status,balance_source:r.balance_source,error:r.error_message||null,wallet_id:r.wallet_id};
  }).filter(Boolean);
  let cq=sb.from("year_end_coverage").select("*").eq("snapshot_date",date);
  if(walletSel!=="__all")cq=cq.eq("wallet_scope",walletSel);
  else cq=cq.eq("wallet_scope","__all");
  const cr=await cq; taxCoverage=(cr.data||[]).map(c=>({chain:c.chain_key,status:c.status,scope:c.scope,detail:c.detail}));
  taxSnapshotLoaded=true;renderTaxResults(date,document.getElementById("taxTimezone")?.value||"Europe/Zurich");
  document.getElementById("taxExcelBtn").disabled=false;document.getElementById("taxPdfBtn").disabled=false;
  taxSetStatus("ready",`Gespeicherte Bestandesaufnahme vom ${date} geladen.`,`Keine Blockchain-Abfragen erforderlich. Mit „Neu berechnen“ kann der Stichtag vollständig aktualisiert werden.`);
  return true;
}
async function saveTaxSnapshot(date,tz,walletSel){
  if(!currentUser||!date)return;
  const selected=walletSel==="__all"?wallets:wallets.filter(w=>String(w.id)===String(walletSel));
  const ids=new Set(selected.map(w=>persistedWalletDbId(w)).filter(Boolean));
  if(ids.size)await sb.from("year_end_positions").delete().eq("snapshot_date",date).in("wallet_id",[...ids]);
  const payload=taxRows.filter(r=>{const w=selected.find(x=>x.label===r.wallet&&walletAddressForChain(x,r.chain)===r.wallet_address);return !!w?.dbId;}).map(r=>{
    const w=selected.find(x=>x.label===r.wallet&&walletAddressForChain(x,r.chain)===r.wallet_address);
    return {user_id:currentUser.id,snapshot_date:date,timezone:tz,wallet_id:w.dbId,chain_key:r.chain,asset_key:r.asset||"native",symbol:r.symbol||null,decimals:r.decimals??null,amount:r.amount??null,block_ref:r.block??null,price_usd:r.price_usd??null,value_usd:r.value_usd??null,balance_source:r.balance_source||null,price_source:r.price_source||null,status:r.status||"verifiziert",error_message:r.error||null,calculated_at:new Date().toISOString()};
  });
  if(payload.length){const {error}=await sb.from("year_end_positions").upsert(payload,{onConflict:"user_id,snapshot_date,wallet_id,chain_key,asset_key"});if(error)throw error;}
  const scope=walletSel==="__all"?"__all":String(walletSel);
  await sb.from("year_end_coverage").delete().eq("snapshot_date",date).eq("wallet_scope",scope);
  const cp=taxCoverage.map(c=>({user_id:currentUser.id,snapshot_date:date,wallet_scope:scope,chain_key:c.chain,status:c.status,scope:c.scope||null,detail:c.detail||null,calculated_at:new Date().toISOString()}));
  if(cp.length){const {error}=await sb.from("year_end_coverage").upsert(cp,{onConflict:"user_id,snapshot_date,wallet_scope,chain_key"});if(error)throw error;}
  taxSnapshotLoaded=true;
}
async function refreshTaxPricesOnly(){
  const date=document.getElementById("taxDate")?.value,walletSel=document.getElementById("taxWalletSelect")?.value||"__all";if(!date)return;
  if(!taxRows.length && !(await loadTaxSnapshot(date,walletSel)))return alert("Für diesen Stichtag ist noch keine gespeicherte Bestandesaufnahme vorhanden.");
  const btn=document.getElementById("taxPriceRefreshBtn");btn.disabled=true;btn.textContent="Kurse werden aktualisiert…";taxPriceCache.clear();
  try{for(let i=0;i<taxRows.length;i++){const r=taxRows[i];if(r.status!=="verifiziert"||!(Number(r.amount)>0))continue;const asset=r.asset==="native"?"native":{address:r.asset,symbol:r.symbol,decimals:r.decimals,coingeckoId:predefinedTokenCoinGeckoIds[r.chain+"|"+normalizeAddress(r.asset,r.chain)]||null};const hp=await taxHistoricalPrice(r.chain,asset,date,r.block);if(hp){r.price_usd=hp.price;r.value_usd=Number(r.amount)*hp.price;r.price_source=hp.source;}}
    await saveTaxSnapshot(date,document.getElementById("taxTimezone")?.value||"Europe/Zurich",walletSel);renderTaxResults(date,document.getElementById("taxTimezone")?.value||"");taxSetStatus("ready","Historische Kurse aktualisiert.","Gespeicherte Bestände wurden nicht erneut von der Blockchain geladen.");
  }catch(e){taxSetStatus("error",e.message||String(e));}finally{btn.disabled=false;btn.textContent="Nur Kurse aktualisieren";}
}

function taxEligibleChains(){
  return Object.keys(CHAIN_CONFIG).filter(c=>{
    const t=CHAIN_CONFIG[c]?.walletType;
    return t==="evm" || t==="btc" || t==="xrp" || t==="sol";
  });
}

function renderTaxWalletSelect(){
  const el=document.getElementById("taxWalletSelect");
  if(!el)return;
  const current=el.value;
  el.innerHTML='<option value="__all">Alle Wallets</option>'+wallets.map(w=>`<option value="${w.id}">${escapeAttr(w.label)}</option>`).join("");
  if(current==="__all" || wallets.some(w=>String(w.id)===String(current)))el.value=current;
  else el.value="__all";
  const date=document.getElementById("taxDate");
  if(date && !date.value){const y=new Date().getFullYear()-1;date.value=`${y}-12-31`;}
  if(date&&!date.dataset.snapshotBound){date.dataset.snapshotBound="1";date.addEventListener("change",()=>loadTaxSnapshot(date.value,el.value));el.addEventListener("change",()=>loadTaxSnapshot(date.value,el.value));setTimeout(()=>loadTaxSnapshot(date.value,el.value),0);}
}

function taxSetStatus(kind,text,detail=""){
  const el=document.getElementById("taxStatus");
  if(!el)return;
  const icon=kind==="ready"?"✅":kind==="error"?"❌":"⏳";
  el.innerHTML=`<strong>${icon} ${escapeAttr(text)}</strong>${detail?`<div class="meta" style="margin-top:4px">${escapeAttr(detail)}</div>`:""}`;
}

function zonedEndOfDayEpoch(dateStr,tz){
  const [y,m,d]=dateStr.split("-").map(Number);
  let guess=Date.UTC(y,m-1,d,23,59,59);
  if(tz==="UTC")return Math.floor(guess/1000);
  const fmt=new Intl.DateTimeFormat("en-CA",{timeZone:tz,year:"numeric",month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit",second:"2-digit",hourCycle:"h23"});
  for(let i=0;i<3;i++){
    const parts=Object.fromEntries(fmt.formatToParts(new Date(guess)).filter(p=>p.type!=="literal").map(p=>[p.type,p.value]));
    const represented=Date.UTC(Number(parts.year),Number(parts.month)-1,Number(parts.day),Number(parts.hour),Number(parts.minute),Number(parts.second));
    const target=Date.UTC(y,m-1,d,23,59,59);
    guess+=target-represented;
  }
  return Math.floor(guess/1000);
}

function taxChainWallets(selectedWallets,chain){
  return selectedWallets.filter(w=>walletAddressForChain(w,chain));
}

function taxCoverageSet(chain,status,detail="",scope=""){
  const existing=taxCoverage.find(x=>x.chain===chain);
  const row={chain,status,detail,scope};
  if(existing)Object.assign(existing,row); else taxCoverage.push(row);
}

let taxRoutescanLastCall=0;
async function taxRoutescanThrottle(){
  const wait=Math.max(0,525-(Date.now()-taxRoutescanLastCall));
  if(wait)await new Promise(r=>setTimeout(r,wait));
  taxRoutescanLastCall=Date.now();
}

function routescanBase(chain){
  const id=CHAIN_CONFIG[chain]?.evmChainId;
  if(!id)throw new Error("EVM Chain-ID fehlt in public.chains.");
  return `https://api.routescan.io/v2/network/mainnet/evm/${id}/etherscan/api`;
}

async function routescanCall(chain,params){
  await taxRoutescanThrottle();
  const qs=new URLSearchParams(params);
  const res=await fetch(`${routescanBase(chain)}?${qs.toString()}`,{headers:{"accept":"application/json"}});
  if(!res.ok)throw new Error(`Routescan HTTP ${res.status}`);
  const j=await res.json();
  if(String(j.status)==="0" && !/no transactions|no records/i.test(String(j.message||"")+" "+String(j.result||""))){
    throw new Error(`Routescan: ${typeof j.result==="string"?j.result:(j.message||"Abfrage fehlgeschlagen")}`);
  }
  return j.result;
}

const taxRoutescanUnavailable = new Set();

async function taxEvmBlockByTime(chain,targetEpoch){
  // Free source first. Unsupported Routescan networks are remembered for this page session.
  if (!taxRoutescanUnavailable.has(chain)) {
    try {
      const r = await routescanCall(chain,{
        module:"block",action:"getblocknobytime",
        timestamp:String(targetEpoch),closest:"before"
      });
      const n=Number(typeof r==="object"?(r.blockNumber??r.block_number??r.result):r);
      if(Number.isFinite(n)&&n>0)return {block:n,source:"Routescan getblocknobytime"};
      throw new Error("ungültige Blockantwort");
    } catch(e) {
      // "chain not supported" ist kein Laufzeitfehler der Anwendung, sondern eine
      // bekannte Provider-Grenze. Direkt auf Archive-RPC wechseln, ohne die Konsole
      // bei jedem Testlauf mit einer erwarteten Warnung zu befüllen.
      if (!/chain not supported/i.test(String(e?.message || e))) {
        console.warn(`${CHAIN_META[chain]?.label||chain}: kostenlose Stichtagsblock-Abfrage fehlgeschlagen; Archive-Fallback.`,e);
      }
      taxRoutescanUnavailable.add(chain);
    }
  }

  const latestHex=await archiveRpc(chain,"eth_blockNumber",[]);
  let low=0, high=Number(BigInt(latestHex)), best=0;
  while(low<=high){
    const mid=Math.floor((low+high)/2);
    const b=await archiveRpc(chain,"eth_getBlockByNumber",[taxBlockHex(mid),false]);
    if(!b){high=mid-1;continue;}
    const ts=Number(BigInt(b.timestamp));
    if(ts<=targetEpoch){best=mid;low=mid+1;} else high=mid-1;
  }
  if(!best)throw new Error("Historischer Stichtagsblock konnte nicht bestimmt werden.");
  return {block:best,source:"Alchemy Archive"};
}

async function taxEvmNativeBalance(chain,address,block){
  if(!taxRoutescanUnavailable.has(chain)){
    try{
      const r=await routescanCall(chain,{
        module:"account",action:"balancehistory",
        address,blockno:String(block)
      });
      const raw=typeof r==="object"?(r.balance??r.Balance??r.result):r;
      if(raw!=null && /^\d+$/.test(String(raw))){
        return {amount:Number(BigInt(String(raw)))/1e18,source:`Routescan balancehistory @ Block ${block}`};
      }
      throw new Error("Historischer Native-Bestand nicht lesbar.");
    }catch(e){
      console.warn(`${CHAIN_META[chain]?.label||chain}: kostenlose Native-Balance fehlgeschlagen; Archive-Fallback.`,e);
      taxRoutescanUnavailable.add(chain);
    }
  }
  const raw=await archiveRpc(chain,"eth_getBalance",[address,taxBlockHex(block)]);
  return {amount:Number(BigInt(raw||"0x0"))/1e18,source:`Alchemy eth_getBalance @ Block ${block}`};
}

async function taxEvmTokenBalance(chain,address,token,block){
  const decimals=await taxTokenDecimalsCurrent(chain,token);
  if(!taxRoutescanUnavailable.has(chain)){
    try{
      const r=await routescanCall(chain,{
        module:"account",action:"tokenbalancehistory",
        contractaddress:token.address,address,blockno:String(block)
      });
      const raw=typeof r==="object"?(r.balance??r.Balance??r.result):r;
      if(raw!=null && /^\d+$/.test(String(raw))){
        return {amount:Number(BigInt(String(raw)))/Math.pow(10,decimals),decimals,source:`Routescan tokenbalancehistory @ Block ${block}`};
      }
      throw new Error("Historischer Token-Bestand nicht lesbar.");
    }catch(e){
      console.warn(`${CHAIN_META[chain]?.label||chain}: kostenlose Token-Balance fehlgeschlagen; Archive-Fallback.`,e);
      taxRoutescanUnavailable.add(chain);
    }
  }
  const ownerArg=String(address).toLowerCase().replace(/^0x/,"").padStart(64,"0");
  const raw=await archiveRpc(chain,"eth_call",[{to:token.address,data:"0x70a08231"+ownerArg},taxBlockHex(block)]);
  // Ein historischer eth_call kann bei einem Contract, der am Zielblock noch nicht
  // existierte bzw. dort keinen decodierbaren Rückgabewert hatte, lediglich "0x"
  // liefern. Das bedeutet für balanceOf wirtschaftlich 0 und darf nicht an BigInt()
  // weitergegeben werden (BigInt("0x") wirft SyntaxError).
  const normalizedRaw = (!raw || raw === "0x") ? "0x0" : raw;
  return {amount:Number(BigInt(normalizedRaw))/Math.pow(10,decimals),decimals,source:`Alchemy ERC-20 balanceOf @ Block ${block}`};
}

async function historicalErc20Candidates(chain,address,targetBlock=null){
  // Nur EVM-Chains: Tron/Solana verwenden eigene Discovery-Wege.
  if (!CHAIN_CONFIG[chain]?.evmChainId) return [];
  const found=new Set();
  // Alchemy: Transferhistorie findet auch vollständig verkaufte Token/LPs.
  if(CHAIN_CONFIG[chain]?.discoveryProvider==="alchemy"){
    for(const direction of ["fromAddress","toAddress"]){
      let pageKey=null,pages=0;
      do{
        const q={fromBlock:"0x0",toBlock:targetBlock!=null?taxBlockHex(targetBlock):"latest",category:["erc20"],withMetadata:false,excludeZeroValue:false,maxCount:"0x3e8"};
        q[direction]=address;if(pageKey)q.pageKey=pageKey;
        const r=await alchemyRpc(chain,"alchemy_getAssetTransfers",[q],"discovery");
        for(const t of (r?.transfers||[])){const a=t.rawContract?.address;if(a&&/^0x[0-9a-f]{40}$/i.test(a))found.add(normalizeAddress(a,chain));}
        pageKey=r?.pageKey||null;pages++;
      }while(pageKey&&pages<100);
    }
  }
  // Blockscout-v2-kompatible Explorer (Apertum u.a.): Wallet-Token-Transfers paginieren.
  const base=String(CHAIN_CONFIG[chain]?.discoveryApiBase||CHAIN_CONFIG[chain]?.balanceApiBase||"").replace(/\/$/,"");
  if(base && CHAIN_CONFIG[chain]?.discoveryProvider!=="alchemy"){
    try{
      let url=`${base}/addresses/${address}/token-transfers?type=ERC-20`,pages=0;
      while(url&&pages++<200){const res=await fetch(url);if(!res.ok)break;const j=await res.json();for(const t of (j.items||[])){const a=t.token?.address;if(a&&/^0x[0-9a-f]{40}$/i.test(a)){if(targetBlock==null||Number(t.block_number||0)<=Number(targetBlock))found.add(normalizeAddress(a,chain));}}const np=j.next_page_params;url=np?`${base}/addresses/${address}/token-transfers?type=ERC-20&${new URLSearchParams(np)}`:null;}
    }catch(e){console.warn("Historische Token-Kandidaten",chain,e);}
  }
  return [...found];
}

function taxTokenUniverse(chain){
  const m=new Map();
  const add=(address,symbol,decimals,label)=>{
    if(!address)return;
    const a=normalizeAddress(address,chain);
    if(!/^0x[0-9a-f]{40}$/i.test(a))return;
    const old=m.get(a)||{};
    const key=chain+"|"+a;
    m.set(a,{
      address:a,
      symbol:symbol||old.symbol||predefinedTokenSymbols[key]||label||a.slice(0,8)+"…",
      decimals:Number.isFinite(Number(decimals))?Number(decimals):(Number.isFinite(Number(old.decimals))?Number(old.decimals):undefined),
      label:label||old.label||predefinedTokenLabels[key]||symbol||"",
      coingeckoId:predefinedTokenCoinGeckoIds[key]||old.coingeckoId||null
    });
  };
  (SAFE_ADDRESSES[chain]||[]).forEach(a=>{
    const k=chain+"|"+a;
    add(a,predefinedTokenSymbols[k],predefinedTokenDecimals[k],predefinedTokenLabels[k]);
  });
  customSafeTokens.filter(t=>t.chain===chain).forEach(t=>add(t.address,null,null,t.label));
  snapshots.forEach(s=>s.items.filter(it=>it.chain===chain && !it.is_native && it.address).forEach(it=>add(it.address,it.symbol,it.decimals,it.symbol)));
  return [...m.values()];
}

async function taxTokenDecimalsCurrent(chain,token){
  const known=Number(token?.decimals);
  if(Number.isFinite(known) && known>=0 && known<=255)return known;
  const key=chain+"|"+normalizeAddress(token?.address||"",chain);
  const predefined=Number(predefinedTokenDecimals[key]);
  if(Number.isFinite(predefined) && predefined>=0 && predefined<=255)return predefined;
  // Avoid Routescan proxy eth_call here: some Routescan chains return HTTP 500 for proxy calls.
  // Unknown decimals are explicitly a metadata limitation; ERC-20 default 18 is used only for
  // the raw-unit conversion and surfaced through the balance source.
  return 18;
}

function taxDateForCoinGecko(dateStr){
  const [y,m,d]=dateStr.split("-");
  return `${d}-${m}-${y}`;
}

async function taxCoinGeckoPrice(id,dateStr){
  if(!id)return null;
  const key=`${id}|${dateStr}`;
  if(taxPriceCache.has(key))return taxPriceCache.get(key);
  const url=`https://api.coingecko.com/api/v3/coins/${encodeURIComponent(id)}/history?date=${taxDateForCoinGecko(dateStr)}&localization=false`;
  for(let attempt=0;attempt<3;attempt++){
    try{
      if(attempt)await new Promise(r=>setTimeout(r,1200*attempt));
      const res=await fetch(url);
      if(!res.ok){
        if((res.status===429 || res.status>=500) && attempt<2)continue;
        throw new Error(`CoinGecko HTTP ${res.status}`);
      }
      const j=await res.json();
      const p=Number(j?.market_data?.current_price?.usd);
      const out=Number.isFinite(p)&&p>0?{price:p,source:`CoinGecko Tageskurs · ${dateStr}`} : null;
      taxPriceCache.set(key,out);
      return out;
    }catch(e){
      if(attempt===2){
        console.warn("Historischer CoinGecko-Preis:",id,e);
        taxPriceCache.set(key,null);
        return null;
      }
    }
  }
  return null;
}

function taxNativeCoinGeckoId(chain){
  if(CHAIN_META[chain]?.coingeckoId)return CHAIN_META[chain].coingeckoId;
  const cfg=CHAIN_CONFIG[chain]||{};
  const chainId=Number(cfg.evmChainId);
  const byEvmId={
    1:"ethereum",
    56:"binancecoin",
    137:"polygon-ecosystem-token",
    42161:"ethereum",
    8453:"ethereum",
    43114:"avalanche-2"
  };
  if(byEvmId[chainId])return byEvmId[chainId];
  if(cfg.walletType==="btc")return "bitcoin";
  if(cfg.walletType==="xrp")return "ripple";
  if(cfg.walletType==="sol")return "solana";
  return null;
}

const taxDexFactoryCache=new Map(),taxProjectReferenceCache=new Map();
const taxV2Iface=new ethers.Interface(["function getPair(address,address) view returns (address)","function token0() view returns (address)","function getReserves() view returns (uint112 reserve0,uint112 reserve1,uint32 blockTimestampLast)"]);
function taxPredefinedBySymbol(chain,symbol){
  const wanted=String(symbol||"").trim().toUpperCase();
  const prefix=chain+"|";
  const keys=new Set([
    ...Object.keys(predefinedTokenSymbols),
    ...Object.keys(predefinedTokenLabels),
    ...Object.keys(predefinedTokenNames),
    ...Object.keys(predefinedTokenDecimals)
  ].filter(k=>k.startsWith(prefix)));
  for(const k of keys){
    const sym=String(predefinedTokenSymbols[k]||"").trim();
    const label=String(predefinedTokenLabels[k]||"").trim();
    const name=String(predefinedTokenNames[k]||"").trim();
    if(![sym,label,name].some(v=>v.toUpperCase()===wanted))continue;
    const a=k.slice(prefix.length);
    return {address:a,symbol:sym||label||name||wanted,decimals:predefinedTokenDecimals[k],coingeckoId:predefinedTokenCoinGeckoIds[k]||null};
  }
  return null;
}
function predefinedTokenTicker(chain,address){
  const key=chain+"|"+normalizeAddress(address,chain);
  return String(predefinedTokenSymbols[key]||predefinedTokenLabels[key]||predefinedTokenNames[key]||"").trim();
}
async function taxDexFactory(chain){
  if(taxDexFactoryCache.has(chain))return taxDexFactoryCache.get(chain);
  const {data,error}=await sb.from("dex_configs").select("factory_address,version").eq("chain_key",chain).eq("enabled",true);
  const r=!error?(data||[]).find(x=>String(x.version||"").toLowerCase()==="v2"):null;
  let out=r?.factory_address?normalizeAddress(r.factory_address,chain):null;
  // Apertum hatte historisch noch keinen zwingenden dex_configs-Eintrag. Damit die bereits
  // validierte On-Chain-Preislogik trotzdem zuverlässig läuft, wird die V2-Factory bei
  // fehlender DB-Konfiguration direkt aus dem bekannten DAO1 wAPTM/wUSDT-Referenzpool
  // gelesen. Es wird nur die Factory on-chain ermittelt; Preise/Reserven bleiben live.
  if(!out&&chain==="apertum"){
    try{
      const pair=window.DAO1Project?.getAptmUsdtPairAddress?.()||null;
      if(pair){
        const fi=new ethers.Interface(["function factory() view returns (address)"]);
        const raw=await archiveRpc(chain,"eth_call",[{to:pair,data:fi.encodeFunctionData("factory",[])},"latest"]);
        const [factory]=fi.decodeFunctionResult("factory",raw);
        if(factory&&!/^0x0{40}$/i.test(factory))out=normalizeAddress(factory,chain);
      }
    }catch(e){console.warn("Apertum V2-Factory konnte nicht on-chain ermittelt werden",e);}
  }
  taxDexFactoryCache.set(chain,out);return out;
}
async function taxProjectReference(project,chain){
  const k=project+"|"+chain;if(taxProjectReferenceCache.has(k))return taxProjectReferenceCache.get(k);
  const {data,error}=await sb.from("defi_project_tokens").select("contract_address,role").eq("project_key",project).eq("chain_key",chain).eq("enabled",true);
  const r=!error?(data||[]).find(x=>String(x.role||"").toLowerCase()==="reference"):null,out=r?.contract_address?normalizeAddress(r.contract_address,chain):null;taxProjectReferenceCache.set(k,out);return out;
}
async function taxV2Pair(chain,a,b,block){
  const f=await taxDexFactory(chain);if(!f)return null;
  // Apertum: Factory/Pair-Metadaten werden aktuell gelesen; ob der Pool am Stichtag schon
  // existierte, entscheidet anschließend der letzte Sync <= Stichtagsblock. Das vermeidet
  // unzuverlässige historische eth_call-Zustände des öffentlichen Apertum-RPC.
  const callBlock=chain==="apertum"?"latest":taxBlockHex(block);
  const raw=await archiveRpc(chain,"eth_call",[{to:f,data:taxV2Iface.encodeFunctionData("getPair",[a,b])},callBlock]),[pair]=taxV2Iface.decodeFunctionResult("getPair",raw);
  return !pair||/^0x0{40}$/i.test(pair)?null:normalizeAddress(pair,chain);
}
const taxApertumSyncCache=new Map();
async function taxApertumLastSync(pair,block){
  const key=`${normalizeAddress(pair,"apertum")}|${Number(block)}`;if(taxApertumSyncCache.has(key))return taxApertumSyncCache.get(key);
  const syncTopic="0x1c411e9a96e071241c2f21f7726b17ae89e3cab4c78be50e062b03a9fffbbad1",step=50000;
  for(let to=Number(block);to>=0;to-=step){const from=Math.max(0,to-step+1);let logs=[];try{logs=await archiveRpc("apertum","eth_getLogs",[{address:pair,fromBlock:taxBlockHex(from),toBlock:taxBlockHex(to),topics:[syncTopic]}]);}catch(e){console.warn("Apertum Sync-Logs",pair,from,to,e);continue;}if(logs?.length){const l=logs[logs.length-1],x=String(l.data||"").replace(/^0x/,"");if(x.length>=128){const out={r0:BigInt("0x"+x.slice(0,64)),r1:BigInt("0x"+x.slice(64,128)),block:Number(BigInt(l.blockNumber))};taxApertumSyncCache.set(key,out);return out;}}}
  taxApertumSyncCache.set(key,null);return null;
}
async function taxDirectV2Price(chain,base,quote,block,bd,qd){
  const pair=await taxV2Pair(chain,base,quote,block);if(!pair)return null;
  const token0Block=chain==="apertum"?"latest":taxBlockHex(block);
  const t0raw=await archiveRpc(chain,"eth_call",[{to:pair,data:taxV2Iface.encodeFunctionData("token0",[])},token0Block]);
  let r0,r1,sourceBlock=block;
  if(chain==="apertum"&&Number.isFinite(Number(block))){const st=await taxApertumLastSync(pair,Number(block));if(!st)return null;r0=st.r0;r1=st.r1;sourceBlock=st.block;}
  else{const rr=await archiveRpc(chain,"eth_call",[{to:pair,data:taxV2Iface.encodeFunctionData("getReserves",[])},taxBlockHex(block)]);[r0,r1]=taxV2Iface.decodeFunctionResult("getReserves",rr);}
  const [t0]=taxV2Iface.decodeFunctionResult("token0",t0raw),is0=normalizeAddress(t0,chain)===normalizeAddress(base,chain);
  const rb=Number(is0?r0:r1)/10**Number(bd),rq=Number(is0?r1:r0)/10**Number(qd);return rb>0&&rq>0?{price:rq/rb,pair,sourceBlock}:null;
}
async function taxApertumLpStateFromEvents(pair,block){
  const syncTopic="0x1c411e9a96e071241c2f21f7726b17ae89e3cab4c78be50e062b03a9fffbbad1";
  const transferTopic="0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef";
  const zeroTopic="0x"+"0".repeat(64),step=50000;let sync=null,supply=0n;
  for(let from=0;from<=block;from+=step){const to=Math.min(block,from+step-1);let logs=[];try{logs=await archiveRpc("apertum","eth_getLogs",[{address:pair,fromBlock:taxBlockHex(from),toBlock:taxBlockHex(to),topics:[[syncTopic,transferTopic]]}]);}catch(e){console.warn("Apertum LP Logbereich",from,to,e);continue;}for(const l of logs||[]){const t0=String(l.topics?.[0]||"").toLowerCase();if(t0===syncTopic){const x=String(l.data||"").replace(/^0x/,"");if(x.length>=128)sync={r0:BigInt("0x"+x.slice(0,64)),r1:BigInt("0x"+x.slice(64,128)),block:Number(BigInt(l.blockNumber))};}else if(t0===transferTopic&&l.topics?.length>=3){const f=String(l.topics[1]).toLowerCase(),t=String(l.topics[2]).toLowerCase(),v=BigInt(l.data||"0x0");if(f===zeroTopic)supply+=v;if(t===zeroTopic)supply-=v;}}}
  return sync&&supply>0n?{...sync,supply}:null;
}
async function taxV2LpHistoricalPrice(chain,asset,block,dateStr){
  const pair=normalizeAddress(asset.address,chain),iface=new ethers.Interface(["function token0() view returns (address)","function token1() view returns (address)","function getReserves() view returns (uint112,uint112,uint32)","function totalSupply() view returns (uint256)"]);
  let a0,a1,r0,r1,supply;
  // Apertum: historische Reserven/LP-Supply eventbasiert, weil der öffentliche RPC bei alten
  // getReserves()-eth_calls unzuverlässige Nullzustände liefern kann.
  if(chain==="apertum"){
    [a0,a1]=await Promise.all(["token0","token1"].map(fn=>archiveRpc(chain,"eth_call",[{to:pair,data:iface.encodeFunctionData(fn,[])},"latest"])));
    const st=await taxApertumLpStateFromEvents(pair,block);if(!st)return null;r0=st.r0;r1=st.r1;supply=st.supply;
  }else{
    let rr,ts;[a0,a1,rr,ts]=await Promise.all(["token0","token1","getReserves","totalSupply"].map(fn=>archiveRpc(chain,"eth_call",[{to:pair,data:iface.encodeFunctionData(fn,[])},taxBlockHex(block)])));[r0,r1]=iface.decodeFunctionResult("getReserves",rr);[supply]=iface.decodeFunctionResult("totalSupply",ts);
  }
  const [t0]=iface.decodeFunctionResult("token0",a0),[t1]=iface.decodeFunctionResult("token1",a1);
  const mk=t=>{const a=normalizeAddress(t,chain),k=chain+"|"+a;return {address:a,symbol:predefinedTokenSymbols[k]||a.slice(0,8)+"…",decimals:predefinedTokenDecimals[k]??18,coingeckoId:predefinedTokenCoinGeckoIds[k]||null};};
  const x0=mk(t0),x1=mk(t1),d0=await taxTokenDecimalsCurrent(chain,x0),d1=await taxTokenDecimalsCurrent(chain,x1),lpd=await taxTokenDecimalsCurrent(chain,asset);
  const [p0,p1]=await Promise.all([taxHistoricalPrice(chain,x0,dateStr,block),taxHistoricalPrice(chain,x1,dateStr,block)]);if(!p0||!p1)return null;
  const q0=Number(r0)/10**d0,q1=Number(r1)/10**d1,lp=Number(supply)/10**lpd;if(!(lp>0))return null;
  return {price:(q0*p0.price+q1*p1.price)/lp,source:`V2 LP historisch · ${chain==="apertum"?"Sync/Transfer-Events":"Reserven + TotalSupply"} · ${pair} · Block ${block}`};
}

async function taxTlnVowHistoricalPriceLegacy(chain,asset,block,dateStr=""){
  if(!asset?.address)return null;const a=normalizeAddress(asset.address,chain),k=chain+"|"+a;if(predefinedTokenProject[k]!=="tln_vow")return null;
  const cat=String(predefinedTokenCategory[k]||""),vow=await taxProjectReference("tln_vow",chain),usdt=taxPredefinedBySymbol(chain,"USDT");if(!vow||!usdt)return null;
  if(["lp_token","lp"].includes(cat))return await taxV2LpHistoricalPrice(chain,asset,block,dateStr);
  const bd=await taxTokenDecimalsCurrent(chain,asset),vd=await taxTokenDecimalsCurrent(chain,{address:vow,decimals:predefinedTokenDecimals[chain+"|"+vow]??18}),ud=await taxTokenDecimalsCurrent(chain,usdt);
  const vu=await taxDirectV2Price(chain,vow,usdt.address,block,vd,ud);if(!vu)return null;
  if(a===vow)return {price:vu.price,source:`Uniswap V2 VOW/USDT · ${vu.pair} · Block ${block}`};
  if(["voucher_currency","v_currency"].includes(cat)){const leg=await taxDirectV2Price(chain,a,vow,block,bd,vd);return leg?{price:leg.price*vu.price,source:`TLN/VOW ${asset.symbol||"v-Währung"}/VOW → VOW/USDT · Pools ${leg.pair}, ${vu.pair} · Block ${block}`}:null;}
  if(["defi_token","tln_vow_token"].includes(cat)){const leg=await taxDirectV2Price(chain,a,vow,block,bd,vd);if(leg)return {price:leg.price*vu.price,source:`TLN/VOW ${asset.symbol||"Token"}/VOW → VOW/USDT · Pools ${leg.pair}, ${vu.pair} · Block ${block}`};const d=await taxDirectV2Price(chain,a,usdt.address,block,bd,ud);return d?{price:d.price,source:`TLN/VOW ${asset.symbol||"Token"}/USDT · ${d.pair} · Block ${block}`}:null;}
  return null;
}

async function taxWalletPriceEnginePairState(chain,address,block){
  const pair=normalizeAddress(address,chain),callBlock=block==="latest"?"latest":taxBlockHex(block);
  const iface=new ethers.Interface(["function token0() view returns (address)","function token1() view returns (address)","function getReserves() view returns (uint112,uint112,uint32)","function totalSupply() view returns (uint256)","function decimals() view returns (uint8)","function factory() view returns (address)"]);
  const [a0,a1,rr,ts,ld,fa]=await Promise.all(["token0","token1","getReserves","totalSupply","decimals","factory"].map(fn=>archiveRpc(chain,"eth_call",[{to:pair,data:iface.encodeFunctionData(fn,[])},callBlock])));
  const [t0]=iface.decodeFunctionResult("token0",a0),[t1]=iface.decodeFunctionResult("token1",a1),[r0,r1,blockTimestampLast]=iface.decodeFunctionResult("getReserves",rr),[supply]=iface.decodeFunctionResult("totalSupply",ts),[lpDecimalsRaw]=iface.decodeFunctionResult("decimals",ld),[factory]=iface.decodeFunctionResult("factory",fa);
  const mk=async t=>{const a=normalizeAddress(t,chain),k=chain+"|"+a,meta={address:a,symbol:predefinedTokenSymbols[k]||predefinedTokenLabels[k]||predefinedTokenNames[k]||a.slice(0,8)+"…",name:predefinedTokenNames[k]||predefinedTokenLabels[k]||predefinedTokenSymbols[k]||a.slice(0,8)+"…",decimals:predefinedTokenDecimals[k]??18};meta.decimals=await taxTokenDecimalsCurrent(chain,meta);return meta;};
  const [m0,m1]=await Promise.all([mk(t0),mk(t1)]),lpDecimals=Number(lpDecimalsRaw);
  return {token0:m0,token1:m1,reserve0:Number(ethers.formatUnits(r0,m0.decimals)),reserve1:Number(ethers.formatUnits(r1,m1.decimals)),totalSupply:Number(ethers.formatUnits(supply,lpDecimals)),lpDecimals,factory:normalizeAddress(factory,chain),blockTimestampLast:Number(blockTimestampLast)};
}
async function taxConfigureTlnVowPriceEngine(chain,block){
  if(!window.WalletPriceEngine)return null;
  const vow=await taxProjectReference("tln_vow",chain),usdt=taxPredefinedBySymbol(chain,"USDT"),usdc=taxPredefinedBySymbol(chain,"USDC"),busd=taxPredefinedBySymbol(chain,"BUSD");
  if(!vow||!usdt?.address)return null;
  const references={vow,usdt:usdt.address,usdc:usdc?.address||null,busd:busd?.address||null};
  window.WalletPriceEngine.configure(()=>({
    references:()=>references,
    tokenMeta:async(_chain,address)=>{const a=normalizeAddress(address,chain),k=chain+"|"+a,meta={address:a,symbol:predefinedTokenSymbols[k]||predefinedTokenLabels[k]||predefinedTokenNames[k]||a.slice(0,8)+"…",name:predefinedTokenNames[k]||predefinedTokenLabels[k]||predefinedTokenSymbols[k]||a.slice(0,8)+"…",decimals:predefinedTokenDecimals[k]??18};meta.decimals=await taxTokenDecimalsCurrent(chain,meta);return meta;},
    tokenCategory:(_chain,address)=>{const raw=String(predefinedTokenCategory[chain+"|"+normalizeAddress(address,chain)]||"").trim().toLowerCase();if(raw==="v_currency")return "voucher_currency";if(raw==="tln_vow_token")return "defi_token";return raw;},
    findPair:async(_chain,a,b)=>await taxV2Pair(chain,a,b,block),
    pairState:async(_chain,address,bl)=>await taxWalletPriceEnginePairState(chain,address,bl),
    poolType:async()=>"v2"
  }));
  return references;
}
async function taxTlnVowHistoricalPrice(chain,asset,block,dateStr=""){
  if(!asset?.address)return null;
  const a=normalizeAddress(asset.address,chain),k=chain+"|"+a;if(predefinedTokenProject[k]!=="tln_vow")return null;
  try{
    const refs=await taxConfigureTlnVowPriceEngine(chain,block);
    if(refs&&window.WalletPriceEngine){
      const raw=String(predefinedTokenCategory[k]||"").trim().toLowerCase();
      if(["lp_token","lp"].includes(raw)){
        const result=await window.WalletPriceEngine.getLpValuation({projectKey:"tln_vow",chain,lpAddress:a,amount:1,block:Number(block)});
        if(result?.priceUsd!=null)return {price:Number(result.priceUsd),source:`WalletPriceEngine · TLN/VOW LP historisch · Block ${block}`};
      }else{
        const meta={address:a,symbol:asset.symbol||predefinedTokenSymbols[k]||predefinedTokenLabels[k]||"Token",name:predefinedTokenNames[k]||asset.symbol||"Token",decimals:await taxTokenDecimalsCurrent(chain,asset)};
        const result=await window.WalletPriceEngine.getTokenPrice({projectKey:"tln_vow",chain,token:meta,block:Number(block)});
        if(result?.price!=null)return {price:Number(result.price),source:`WalletPriceEngine · ${result.route||result.source||"TLN/VOW"} · Block ${block}`};
      }
    }
  }catch(e){console.warn("WalletPriceEngine TLN/VOW Historie – Sicherheits-Fallback",chain,asset?.symbol,e);}
  // Übergangs-Fallback: bleibt bis die zentrale Engine auf Hauptseite und Discovery mit denselben Testfällen verifiziert ist.
  return await taxTlnVowHistoricalPriceLegacy(chain,asset,block,dateStr);
}

async function taxApertumWrappedPrice(chain,asset,block,dateStr=""){
  if(chain!=="apertum"||!asset?.address)return null;
  const a=normalizeAddress(asset.address,chain),sym=String(asset.symbol||predefinedTokenSymbols[chain+"|"+a]||"").toUpperCase(),metaName=String(predefinedTokenNames[chain+"|"+a]||predefinedTokenLabels[chain+"|"+a]||"").toUpperCase();
  if(sym==="WUSDT"||sym==="USDT"||sym==="WUSDC"||sym==="USDC"||metaName.includes("WUSDT")||metaName.includes("WRAPPED USDT")||metaName.includes("WUSDC")||metaName.includes("WRAPPED USDC"))return {price:1,source:"Apertum Stablecoin-Parität · 1 USD"};
  const aptm=await taxHistoricalPrice(chain,"native",dateStr,block,true);
  if((sym==="WAPTM"||metaName.includes("WAPTM")||metaName.includes("WRAPPED APTM"))&&aptm)return {price:aptm.price,source:`wAPTM/APTM 1:1 · ${aptm.source}`};
  const u=taxPredefinedBySymbol(chain,"WUSDT")||taxPredefinedBySymbol(chain,"USDT"),wa=taxPredefinedBySymbol(chain,"WAPTM");if(!u)return null;
  const bd=await taxTokenDecimalsCurrent(chain,asset),ud=await taxTokenDecimalsCurrent(chain,u),direct=await taxDirectV2Price(chain,a,u.address,block,bd,ud);if(direct)return {price:direct.price,source:`Apertum DEX ${sym||"Token"}/wUSDT · ${direct.pair} · Block ${block}`};
  if(wa&&aptm){const wd=await taxTokenDecimalsCurrent(chain,wa),via=await taxDirectV2Price(chain,a,wa.address,block,bd,wd);if(via)return {price:via.price*aptm.price,source:`Apertum DEX ${sym||"Token"}/wAPTM → APTM/USD · ${via.pair} · Block ${block}`};}
  return null;
}


async function taxHistoricalPrice(chain,asset,dateStr,block=null,skipWrapped=false){
  if(chain==="apertum"&&asset==="native"&&block!=null){
    try{
      const hp=await window.DAO1Project?.historicalAptmPriceAtBlock?.(Number(block));
      if(hp?.price!=null)return {price:Number(hp.price),source:hp.source||`DAO1 APTM Anchor · Block ${block}`};
      // Pre-Launch bzw. echte Preis-Lücke bleiben absichtlich ohne USD-Wert.
      return null;
    }catch(e){
      console.warn("DAO1 zentrale APTM-Historienpreis-Engine",e);
      return null;
    }
  }
  if(block!=null&&asset!=="native"){try{const t=await taxTlnVowHistoricalPrice(chain,asset,block,dateStr);if(t)return t;if(!skipWrapped){const a=await taxApertumWrappedPrice(chain,asset,block,dateStr);if(a)return a;}if(asset?.address&&window.WalletLPEngine){const pi=await window.WalletLPEngine.pairInfo(chain,asset.address);if(pi){const lp=await taxV2LpHistoricalPrice(chain,{...asset,decimals:pi.decimals},block,dateStr);if(lp)return lp;}}}catch(e){console.warn("Historischer DEX-/LP-Preis:",chain,asset?.symbol,e);}}
  if(chain==="apertum")return null; // Apertum wird bewusst vollständig on-chain bewertet; kein CoinGecko-Fallback.
  const id=asset==="native"?taxNativeCoinGeckoId(chain):(asset?.coingeckoId||null);return dateStr?taxCoinGeckoPrice(id,dateStr):null;
}


async function taxCachedStakedLp(projectKey,chain,walletAddress,pairAddress,cutoffIso){
  if(!window.WalletLPEngine||!window.WalletStakingEngine)return 0;
  try{
    const events=await window.WalletLPEngine.loadHistory(projectKey,chain,walletAddress);
    return window.WalletStakingEngine.stakeBalanceAt(events,pairAddress,cutoffIso);
  }catch(e){
    console.warn("Staking-Stichtagsbestand aus Cache",chain,pairAddress,e);
    return 0;
  }
}

async function taxEvmChain(chain,selectedWallets,targetEpoch,dateStr){
  const ws=taxChainWallets(selectedWallets,chain);
  if(!ws.length)return;
  taxSetStatus("loading",`${CHAIN_META[chain]?.label||chain}: historischer Block via Routescan…`);
  let bi;
  try{bi=await taxEvmBlockByTime(chain,targetEpoch);}
  catch(e){taxCoverageSet(chain,"fehlgeschlagen",e.message,"EVM");return;}

  let tokens=taxTokenUniverse(chain);
  // Zusätzlich alle bis zum Stichtag jemals transferierten ERC-20-Contracts aufnehmen.
  // So erscheinen auch vollständig verkaufte Token und entfernte LP-Positionen.
  const histMap=new Map(tokens.map(t=>[normalizeAddress(t.address,chain),t]));
  for(const w of ws){
    const wa=walletAddressForChain(w,chain);
    for(const a of await historicalErc20Candidates(chain,wa,bi.block)){if(!histMap.has(a)){const k=chain+"|"+a;histMap.set(a,{address:a,symbol:predefinedTokenSymbols[k]||a.slice(0,8)+"…",decimals:predefinedTokenDecimals[k],label:predefinedTokenLabels[k]||"",coingeckoId:predefinedTokenCoinGeckoIds[k]||null});}}
  }
  tokens=[...histMap.values()];
  let verified=0,errors=0,priceMissing=0;
  for(let wi=0;wi<ws.length;wi++){
    const w=ws[wi],address=walletAddressForChain(w,chain);
    // Für BSC/TLN/VOW gelten auch per Legacy-Discovery bestätigte historische LPs
    // als Projekt-LPs. Sie müssen am Steuerstichtag um gestakte LP-Mengen ergänzt werden,
    // selbst wenn die LP-Adresse heute nicht mehr als lp_token in predefined_tokens steht.
    let tlnBscHistoryPairs=new Set();
    if(chain==="bsc"&&window.WalletLPEngine){
      try{const ev=await window.WalletLPEngine.loadHistory("tln_vow",chain,address);tlnBscHistoryPairs=new Set((ev||[]).map(e=>normalizeAddress(e.pair_address,chain)).filter(Boolean));}catch{}
    }
    taxSetStatus("loading",`${CHAIN_META[chain]?.label||chain}: ${w.label}…`,`Block ${bi.block} · Wallet ${wi+1}/${ws.length}`);
    try{
      const nativeBalance=await taxEvmNativeBalance(chain,address,bi.block);
        const amount=nativeBalance.amount;
      if(amount>0){
        const hp=await taxHistoricalPrice(chain,"native",dateStr,bi.block);
        if(!hp)priceMissing++;
        taxRows.push({wallet:w.label,wallet_address:address,chain,block:bi.block,block_timestamp:targetEpoch,asset:"native",
          symbol:NATIVE_SYMBOL[chain]||chain.toUpperCase(),amount,price_usd:hp?.price??null,value_usd:hp?amount*hp.price:null,
          price_source:hp?.source||null,status:"verifiziert",balance_source:nativeBalance.source});
        verified++;
      }
    }catch(e){errors++;taxRows.push({wallet:w.label,wallet_address:address,chain,block:bi.block,asset:"native",symbol:NATIVE_SYMBOL[chain]||chain.toUpperCase(),status:"nicht verifizierbar",error:e.message,balance_source:"Routescan balancehistory"});}
    for(const token of tokens){
      try{
        const b=await taxEvmTokenBalance(chain,address,token,bi.block);
        const tk=chain+"|"+normalizeAddress(token.address,chain);
        const isTlnBscLp=chain==="bsc"&&((predefinedTokenProject[tk]==="tln_vow"&&predefinedTokenCategory[tk]==="lp_token")||tlnBscHistoryPairs.has(normalizeAddress(token.address,chain)));
        const stakedLp=isTlnBscLp?await taxCachedStakedLp("tln_vow",chain,address,token.address,new Date(targetEpoch*1000).toISOString()):0;
        const economicAmount=Number(b.amount||0)+Number(stakedLp||0);
        if(economicAmount>0){
          const hp=await taxHistoricalPrice(chain,token,dateStr,bi.block);
          if(!hp)priceMissing++;
          taxRows.push({wallet:w.label,wallet_address:address,chain,block:bi.block,block_timestamp:targetEpoch,asset:token.address,
            symbol:token.symbol,amount:economicAmount,decimals:b.decimals,price_usd:hp?.price??null,value_usd:hp?economicAmount*hp.price:null,
            price_source:hp?.source||null,status:"verifiziert",balance_source:isTlnBscLp&&stakedLp>0?`${b.source} + TLN/VOW Staking-Cache (${stakedLp} LP gestakt)`:b.source});
          verified++;
        }
      }catch(e){
        // Unknown/deployed-later token can be skipped; true Routescan/history errors are surfaced once in coverage.
        if(/rate|limit|histor|unsupported|not available|error/i.test(String(e.message||"")))errors++;
      }
    }
  }
  const detail=`${ws.length} Wallet(s) geprüft · ${verified} positive Position(en) am Stichtag${priceMissing?` · ${priceMissing} ohne historischen Kurs`:""}${errors?` · ${errors} Abfragefehler`:""} · Preise: APTM-Pool bzw. CoinGecko-Tageshistorie, soweit ID vorhanden`;
  taxCoverageSet(chain,errors?"teilweise":"berücksichtigt",detail,"EVM exakt · kostenlose Quelle → Alchemy Archive-Fallback");
}

async function taxBitcoinWallet(chain,w,targetEpoch,dateStr){
  const address=walletAddressForChain(w,chain);
  if(!address)return null;
  let url=`https://blockstream.info/api/address/${encodeURIComponent(address)}/txs`;
  let balanceSat=0,lastSeen=null,pages=0;
  while(url && pages<2000){
    pages++;
    const res=await fetch(url);
    if(!res.ok)throw new Error(`Blockstream HTTP ${res.status}`);
    const txs=await res.json();
    if(!Array.isArray(txs)||!txs.length)break;
    for(const tx of txs){
      const ts=Number(tx?.status?.block_time||0);
      if(!tx?.status?.confirmed || !ts || ts>targetEpoch)continue;
      for(const v of tx.vout||[])if(v?.scriptpubkey_address===address)balanceSat+=Number(v.value||0);
      for(const vin of tx.vin||[])if(vin?.prevout?.scriptpubkey_address===address)balanceSat-=Number(vin.prevout.value||0);
    }
    lastSeen=txs[txs.length-1]?.txid;
    if(txs.length<25||!lastSeen)break;
    url=`https://blockstream.info/api/address/${encodeURIComponent(address)}/txs/chain/${lastSeen}`;
  }
  const amount=balanceSat/1e8;
  const hp=amount>0?await taxHistoricalPrice(chain,"native",dateStr):null;
  return {amount,hp,pages,source:`Blockstream komplette bestätigte Tx-Historie bis Stichtag (${pages} Seite(n))`};
}

async function taxBitcoinChain(chain,selectedWallets,targetEpoch,dateStr){
  const ws=taxChainWallets(selectedWallets,chain);
  if(!ws.length)return;
  let verified=0,errors=0,priceMissing=0;
  for(let i=0;i<ws.length;i++){
    const w=ws[i],address=walletAddressForChain(w,chain);
    taxSetStatus("loading",`${CHAIN_META[chain]?.label||"Bitcoin"}: ${w.label} wird rekonstruiert…`,`Wallet ${i+1}/${ws.length} · vollständige bestätigte Transaktionshistorie`);
    try{
      const r=await taxBitcoinWallet(chain,w,targetEpoch,dateStr);
      if(r?.amount>0){
        if(!r.hp)priceMissing++;
        taxRows.push({wallet:w.label,wallet_address:address,chain,asset:"native",symbol:NATIVE_SYMBOL[chain]||"BTC",
          amount:r.amount,price_usd:r.hp?.price??null,value_usd:r.hp?r.amount*r.hp.price:null,price_source:r.hp?.source||null,
          status:"verifiziert",balance_source:r.source});
        verified++;
      }
    }catch(e){errors++;taxRows.push({wallet:w.label,wallet_address:address,chain,asset:"native",symbol:NATIVE_SYMBOL[chain]||"BTC",status:"nicht verifizierbar",error:e.message,balance_source:"Blockstream Tx-Rekonstruktion"});}
  }
  taxCoverageSet(chain,errors?"teilweise":"berücksichtigt",`${ws.length} Wallet(s) geprüft · ${verified} positive BTC-Bestände${priceMissing?` · ${priceMissing} ohne Kurs`:""}${errors?` · ${errors} Fehler`:""}`,"BTC exakt · bestätigte Blockstream-Transaktionshistorie");
}

const XRP_EPOCH_OFFSET=946684800;
async function xrplCall(method,params){
  const res=await fetch("https://s2.ripple.com/",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({method,params:[params]})});
  if(!res.ok)throw new Error(`XRPL HTTP ${res.status}`);
  const j=await res.json();
  const r=j?.result;
  if(!r)throw new Error("XRPL: leere Antwort");
  if(r.status==="error")throw new Error(r.error_message||r.error||"XRPL-Fehler");
  return r;
}
async function xrplLedgerByTime(targetEpoch){
  const cur=await xrplCall("ledger",{ledger_index:"validated",transactions:false,expand:false});
  let hi=Number(cur.ledger_index||cur.ledger?.ledger_index),lo=32570,best=lo;
  if(!Number.isFinite(hi))throw new Error("XRPL letzter Ledger nicht lesbar");
  while(lo<=hi){
    const mid=Math.floor((lo+hi)/2);
    const r=await xrplCall("ledger",{ledger_index:mid,transactions:false,expand:false});
    const close=Number(r.ledger?.close_time??r.close_time)+XRP_EPOCH_OFFSET;
    if(!Number.isFinite(close))throw new Error("XRPL Ledger-Zeit nicht lesbar");
    if(close<=targetEpoch){best=mid;lo=mid+1;} else hi=mid-1;
  }
  return best;
}
async function taxXrpChain(chain,selectedWallets,targetEpoch,dateStr){
  const ws=taxChainWallets(selectedWallets,chain);
  if(!ws.length)return;
  taxSetStatus("loading",`${CHAIN_META[chain]?.label||"XRP"}: Stichtags-Ledger wird bestimmt…`,"Ripple Full-History Server s2.ripple.com");
  let ledger;
  try{ledger=await xrplLedgerByTime(targetEpoch);}catch(e){taxCoverageSet(chain,"fehlgeschlagen",e.message,"XRP nativ");return;}
  let verified=0,errors=0,priceMissing=0;
  for(const w of ws){
    const address=walletAddressForChain(w,chain);
    try{
      const r=await xrplCall("account_info",{account:address,ledger_index:ledger,strict:true});
      const amount=Number(r.account_data?.Balance||0)/1e6;
      if(amount>0){
        const hp=await taxHistoricalPrice(chain,"native",dateStr);
        if(!hp)priceMissing++;
        taxRows.push({wallet:w.label,wallet_address:address,chain,asset:"native",symbol:NATIVE_SYMBOL[chain]||"XRP",amount,
          block:ledger,price_usd:hp?.price??null,value_usd:hp?amount*hp.price:null,price_source:hp?.source||null,status:"verifiziert",
          balance_source:`XRPL account_info @ Ledger ${ledger}`});
        verified++;
      }
    }catch(e){
      if(/actNotFound|Account not found/i.test(e.message||""))continue;
      errors++;taxRows.push({wallet:w.label,wallet_address:address,chain,asset:"native",symbol:NATIVE_SYMBOL[chain]||"XRP",block:ledger,status:"nicht verifizierbar",error:e.message,balance_source:`XRPL account_info @ Ledger ${ledger}`});
    }
  }
  taxCoverageSet(chain,errors?"teilweise":"berücksichtigt",`${ws.length} Wallet(s) geprüft · ${verified} positive XRP-Bestände${priceMissing?` · ${priceMissing} ohne Kurs`:""}${errors?` · ${errors} Fehler`:""}`,"XRP nativ exakt · Full-History Ledger");
}

async function solRpcTax(chain,method,params){
  return solanaRpc(chain,method,params);
}
async function taxSolTargetSlot(chain,address,targetEpoch){
  const cur=await solRpcTax(chain,"getSlot",[{commitment:"finalized"}]);let lo=0,hi=Number(cur),best=0,guard=0;
  while(lo<=hi&&guard++<64){const mid=Math.floor((lo+hi)/2);let bt=null;try{bt=await solRpcTax(chain,"getBlockTime",[mid]);}catch{}
    if(bt==null){lo=mid+1;continue;}
    if(Number(bt)<=targetEpoch){best=mid;lo=mid+1;}else hi=mid-1;
  }
  if(!best)throw new Error("Solana Stichtags-Slot konnte nicht bestimmt werden.");
  return {slot:best,accountDidNotExist:false};
}
async function taxSolNativeWallet(chain,w,targetEpoch,dateStr){
  const address=walletAddressForChain(w,chain);if(!address)return null;const t=await taxSolTargetSlot(chain,address,targetEpoch);if(t.accountDidNotExist)return {chain,address,amount:0,slot:null,source:"Alchemy Solana History · vor Stichtag keine Wallet-Aktivität"};
  const r=await solRpcTax(chain,"getBalance",[address,{commitment:"finalized",slot:t.slot}]),amount=Number(r?.value||0)/1e9,hp=amount>0?await taxHistoricalPrice(chain,"native",dateStr):null;return {chain,address,amount,hp,slot:t.slot,source:`Alchemy Solana Account Archive · getBalance @ Slot ${t.slot}`};
}
async function taxSolanaChains(selectedWallets,targetEpoch,dateStr){
  const chains=Object.keys(CHAIN_CONFIG).filter(c=>CHAIN_CONFIG[c]?.walletType==="sol");
  for(const chain of chains){const ws=taxChainWallets(selectedWallets,chain);if(!ws.length)continue;let verified=0,errors=0,priceMissing=0;
    for(const w of ws){const address=walletAddressForChain(w,chain);try{taxSetStatus("loading",`Solana: ${w.label} · historischer Slot und Bestände…`);const r=await taxSolNativeWallet(chain,w,targetEpoch,dateStr);
      if(r?.amount>0){if(!r.hp)priceMissing++;taxRows.push({wallet:w.label,wallet_address:r.address,chain,asset:"native",symbol:NATIVE_SYMBOL[chain]||"SOL",amount:r.amount,block:r.slot,price_usd:r.hp?.price??null,value_usd:r.hp?r.amount*r.hp.price:null,price_source:r.hp?.source||null,status:"verifiziert",balance_source:r.source});verified++;}
      if(r?.slot!=null){let pageKey=null;do{const cfg={slot:r.slot,pageLimit:1000};if(pageKey)cfg.pageKey=pageKey;const tr=await solRpcTax(chain,"getTokenAccountsByOwnerAtSlot",[address,{},cfg]),vals=tr?.value||tr?.accounts||[];
        for(const x of vals){const info=x?.account?.data?.parsed?.info||x?.data?.parsed?.info||{},mint=info.mint||x?.mint,ta=info.tokenAmount||x?.tokenAmount||{},amount=Number(ta.uiAmountString??ta.uiAmount??0);if(!mint||!(amount>0))continue;const k=chain+"|"+normalizeAddress(mint,chain),tok={address:mint,symbol:predefinedTokenSymbols[k]||x?.symbol||String(mint).slice(0,6)+"…",decimals:Number(ta.decimals??predefinedTokenDecimals[k]??0),coingeckoId:predefinedTokenCoinGeckoIds[k]||null},hp=await taxHistoricalPrice(chain,tok,dateStr,r.slot);if(!hp)priceMissing++;taxRows.push({wallet:w.label,wallet_address:address,chain,asset:mint,symbol:tok.symbol,amount,decimals:tok.decimals,block:r.slot,price_usd:hp?.price??null,value_usd:hp?amount*hp.price:null,price_source:hp?.source||null,status:"verifiziert",balance_source:`Alchemy getTokenAccountsByOwnerAtSlot @ Slot ${r.slot}`});verified++;}pageKey=tr?.pageKey||null;}while(pageKey);}
    }catch(e){errors++;taxRows.push({wallet:w.label,wallet_address:address,chain,asset:"native",symbol:NATIVE_SYMBOL[chain]||"SOL",status:"nicht verifizierbar",error:e.message,balance_source:"Alchemy Solana Account Archive"});}}
    taxCoverageSet(chain,errors?"teilweise":"berücksichtigt",`${ws.length} Wallet(s) geprüft · ${verified} positive SOL/SPL-Position(en)${priceMissing?` · ${priceMissing} ohne Kurs`:""}${errors?` · ${errors} Fehler`:""}`,"SOL + SPL/Token-2022 · Alchemy historischer Slot");
  }
}


function renderTaxCoverage(){
  const rows=[...taxCoverage].sort((a,b)=>(CHAIN_CONFIG[a.chain]?.sortOrder||999)-(CHAIN_CONFIG[b.chain]?.sortOrder||999));
  if(!rows.length)return "";
  const cls=s=>s==="berücksichtigt"?"safe":s==="teilweise"?"":"unsafe";
  return `<div class="custom-token-card" style="margin-top:12px"><div class="chain-title">Berücksichtigte Chains / Abdeckung</div>
    <div class="chain-table-wrap"><table class="chain-admin-table"><thead><tr><th>Chain</th><th>Status</th><th>Abdeckung</th><th>Details</th></tr></thead><tbody>
      ${rows.map(r=>`<tr><td><strong>${escapeAttr(CHAIN_META[r.chain]?.label||r.chain)}</strong></td><td><span class="badge ${cls(r.status)}">${escapeAttr(r.status)}</span></td><td>${escapeAttr(r.scope||"–")}</td><td>${escapeAttr(r.detail||"–")}</td></tr>`).join("")}
    </tbody></table></div></div>`;
}

async function runTaxSnapshot(){
  const btn=document.getElementById("taxRunBtn");
  const date=document.getElementById("taxDate")?.value;
  const tz=document.getElementById("taxTimezone")?.value||"Europe/Zurich";
  const walletSel=document.getElementById("taxWalletSelect")?.value||"__all";
  if(!date)return alert("Bitte Stichtag wählen.");
  const targetEpoch=zonedEndOfDayEpoch(date,tz);
  const selectedWallets=walletSel==="__all"?wallets:wallets.filter(w=>String(w.id)===String(walletSel));
  taxRows=[];taxCoverage=[];taxPriceCache.clear();
  btn.disabled=true;btn.textContent="Stichtagsbestand wird ermittelt…";
  document.getElementById("taxExcelBtn").disabled=true;
  document.getElementById("taxPdfBtn").disabled=true;
  try{
    const configured=Object.keys(CHAIN_CONFIG);
    // Declare every chain that is relevant to the selected wallet(s).
    for(const chain of configured){
      if(!taxChainWallets(selectedWallets,chain).length)continue;
      const type=CHAIN_CONFIG[chain]?.walletType;
      if(!["evm","btc","xrp","sol"].includes(type)){
        taxCoverageSet(chain,"nicht unterstützt","Für diese Chain ist noch keine exakte historische Stichtagslogik implementiert.",type||"–");
      }
    }
    for(const chain of configured.filter(c=>CHAIN_CONFIG[c]?.walletType==="evm" && taxChainWallets(selectedWallets,c).length)){
      await taxEvmChain(chain,selectedWallets,targetEpoch,date);
    }
    for(const chain of configured.filter(c=>CHAIN_CONFIG[c]?.walletType==="btc" && taxChainWallets(selectedWallets,c).length)){
      await taxBitcoinChain(chain,selectedWallets,targetEpoch,date);
    }
    for(const chain of configured.filter(c=>CHAIN_CONFIG[c]?.walletType==="xrp" && taxChainWallets(selectedWallets,c).length)){
      await taxXrpChain(chain,selectedWallets,targetEpoch,date);
    }
    await taxSolanaChains(selectedWallets,targetEpoch,date);

    renderTaxResults(date,tz);
    await saveTaxSnapshot(date,tz,walletSel);
    document.getElementById("taxExcelBtn").disabled=taxRows.length===0;
    document.getElementById("taxPdfBtn").disabled=taxRows.length===0;
    const ok=taxRows.filter(r=>r.status==="verifiziert").length,bad=taxRows.filter(r=>r.status!=="verifiziert").length;
    const covered=taxCoverage.filter(r=>r.status==="berücksichtigt").length,partial=taxCoverage.filter(r=>r.status==="teilweise").length;
    const omitted=taxCoverage.length-covered-partial;
    taxSetStatus("ready",`Bereit – ${ok} verifizierte Position(en)${bad?`, ${bad} nicht verifizierbar`:""}.`,
      `${covered}/${taxCoverage.length} relevante Chain(s) vollständig berücksichtigt · ${partial} teilweise · ${omitted} nicht berücksichtigt. Keine Bestände wurden geschätzt.`);
  }catch(e){
    console.error("Bestandesaufnahme per 31.12:",e);taxSetStatus("error",e.message||String(e));
  }finally{btn.disabled=false;btn.textContent="Exakten Stichtagsbestand ermitteln";}
}

function renderTaxResults(date="",tz=""){
  const summary=document.getElementById("taxSummary"),out=document.getElementById("taxResults");
  if(!summary||!out)return;
  const ok=taxRows.filter(r=>r.status==="verifiziert"),bad=taxRows.filter(r=>r.status!=="verifiziert");
  const priced=ok.filter(r=>r.price_usd!=null),unpriced=ok.filter(r=>r.price_usd==null);
  const usdTotal=priced.reduce((a,r)=>a+Number(r.value_usd||0),0);
  const covered=taxCoverage.filter(r=>r.status==="berücksichtigt").map(r=>CHAIN_META[r.chain]?.label||r.chain);
  const partial=taxCoverage.filter(r=>r.status==="teilweise").map(r=>CHAIN_META[r.chain]?.label||r.chain);
  const failed=taxCoverage.filter(r=>!["berücksichtigt","teilweise"].includes(r.status)).map(r=>CHAIN_META[r.chain]?.label||r.chain);
  summary.innerHTML=`<div class="project-summary">
    <div class="custom-token-card project-summary-box"><span class="field-label">Verifizierte Positionen</span><strong>${ok.length}</strong></div>
    <div class="custom-token-card project-summary-box"><span class="field-label">Historischer Kurs vorhanden</span><strong>${priced.length}</strong><div class="meta">${unpriced.length} ohne Kurs</div></div>
    <div class="custom-token-card project-summary-box"><span class="field-label">USD-Wert soweit verifiziert</span><strong>${usdTotal?fmtUsd(usdTotal):"–"}</strong></div>
    <div class="custom-token-card project-summary-box"><span class="field-label">Chains berücksichtigt</span><strong>${covered.length}</strong><div class="meta">${escapeAttr(covered.join(", ")||"–")}</div></div>
    <div class="custom-token-card project-summary-box"><span class="field-label">Chains teilweise</span><strong>${partial.length}</strong><div class="meta">${escapeAttr(partial.join(", ")||"–")}</div></div>
    <div class="custom-token-card project-summary-box"><span class="field-label">Chains nicht berücksichtigt</span><strong>${failed.length}</strong><div class="meta">${escapeAttr(failed.join(", ")||"–")}</div></div>
    <div class="custom-token-card project-summary-box"><span class="field-label">Positionen nicht verifizierbar</span><strong>${bad.length}</strong></div>
  </div>${renderTaxCoverage()}`;
  if(!taxRows.length){out.innerHTML='<div class="empty">Keine Positionen gefunden oder keine Chain konnte verifiziert werden.</div>';return;}
  const debugCols=!!(isAdmin&&adminDebugMode);
  out.innerHTML=`<div class="chain-table-wrap project-data-table tax-position-table"><table><thead><tr><th>Wallet</th><th>Chain</th><th>Asset</th><th class="num">Bestand</th><th class="num">Preis USD</th><th class="num">Wert USD</th>${debugCols?'<th>Block / Ledger</th><th>Status / Quelle</th>':''}</tr></thead><tbody>
    ${taxRows.map(r=>`<tr><td>${escapeAttr(r.wallet)}<div class="meta">${escapeAttr(r.wallet_address||"")}</div></td><td>${escapeAttr(CHAIN_META[r.chain]?.label||r.chain)}</td><td><strong>${escapeAttr(r.symbol||"–")}</strong><div class="meta">${r.asset&&r.asset!=="native"?escapeAttr(r.asset):"nativ"}</div></td><td class="num">${r.amount==null?"–":fmt(r.amount,{chain:r.chain,address:r.asset&&r.asset!=="native"?r.asset:null,symbol:r.symbol})}</td><td class="num">${r.price_usd==null?"–":fmtUsd(r.price_usd)}</td><td class="num">${r.value_usd==null?"–":fmtUsd(r.value_usd)}</td>${debugCols?`<td>${r.block||"–"}</td><td>${r.status==="verifiziert"?'<span class="badge safe">verifiziert</span>':'<span class="badge unsafe">nicht verifizierbar</span>'}<div class="meta">${escapeAttr(r.error||r.balance_source||"")}${r.price_source?` · Preis: ${escapeAttr(r.price_source)}`:""}</div></td>`:''}</tr>`).join("")}
    </tbody></table></div>`;
}

function taxXmlCell(v){
  const num=typeof v==="number"&&Number.isFinite(v);
  const esc=String(v??"").replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;");
  return `<Cell><Data ss:Type="${num?"Number":"String"}">${esc}</Data></Cell>`;
}

function exportTaxExcel(){
  const date=document.getElementById("taxDate")?.value||"";
  const tz=document.getElementById("taxTimezone")?.value||"";
  let body=`<Row>${taxXmlCell("Wallet Tracking – Bestandesaufnahme per 31.12")}</Row><Row>${taxXmlCell("Stichtag")}${taxXmlCell(date)}</Row><Row>${taxXmlCell("Zeitzone")}${taxXmlCell(tz)}</Row><Row>${taxXmlCell("Qualitätsregel")}${taxXmlCell("Keine Bestände geschätzt; Coverage je Chain separat ausgewiesen.")}</Row><Row></Row>`;
  body+=`<Row>${["CHAIN COVERAGE","STATUS","ABDECKUNG","DETAIL"].map(taxXmlCell).join("")}</Row>`;
  for(const c of taxCoverage)body+=`<Row>${[CHAIN_META[c.chain]?.label||c.chain,c.status,c.scope,c.detail].map(taxXmlCell).join("")}</Row>`;
  body+=`<Row></Row>`;
  const heads=["Wallet","Wallet-Adresse","Chain","Symbol","Asset/Contract","Bestand","Preis USD","Wert USD","Block/Ledger","Bestandsquelle","Preisquelle","Status","Fehler"];
  body+=`<Row>${heads.map(taxXmlCell).join("")}</Row>`;
  for(const r of taxRows)body+=`<Row>${[r.wallet,r.wallet_address,r.chain,r.symbol,r.asset,r.amount??"",r.price_usd??"",r.value_usd??"",r.block??"",r.balance_source||"",r.price_source||"",r.status,r.error||""].map(taxXmlCell).join("")}</Row>`;
  const xml=`<?xml version="1.0"?><?mso-application progid="Excel.Sheet"?><Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"><Worksheet ss:Name="Stichtag"><Table>${body}</Table></Worksheet></Workbook>`;
  const blob=new Blob([xml],{type:"application/vnd.ms-excel"}),a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=`bestandesaufnahme-31-12-${date}.xls`;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);
}

function exportTaxPdf(){
  const date=document.getElementById("taxDate")?.value||"",tz=document.getElementById("taxTimezone")?.value||"",w=window.open("","_blank");if(!w)return alert("Popup wurde blockiert.");
  const ok=taxRows.filter(r=>r.status==="verifiziert"),priced=ok.filter(r=>r.price_usd!=null&&r.value_usd!=null),total=priced.reduce((s,r)=>s+Number(r.value_usd||0),0);
  const walletNames=[...new Set(taxRows.map(r=>r.wallet))].sort((a,b)=>a.localeCompare(b,"de"));
  const grouped=new Map();for(const r of ok){const k=r.chain+"|"+(r.asset||r.symbol),x=grouped.get(k)||{chain:r.chain,symbol:r.symbol,asset:r.asset,amount:0,value:0,priced:true,price:r.price_usd};x.amount+=Number(r.amount||0);if(r.value_usd==null)x.priced=false;else x.value+=Number(r.value_usd||0);if(x.price==null&&r.price_usd!=null)x.price=r.price_usd;grouped.set(k,x);}
  const chainKeys=[...new Set([...grouped.values()].map(x=>x.chain))].sort((a,b)=>(CHAIN_CONFIG[a]?.sortOrder||999)-(CHAIN_CONFIG[b]?.sortOrder||999));
  const chainSummary=chainKeys.map(chain=>{const ar=[...grouped.values()].filter(x=>x.chain===chain),sum=ar.filter(x=>x.priced).reduce((q,x)=>q+x.value,0),rows=ar.map(x=>`<tr><td><b>${escapeAttr(x.symbol||"–")}</b><small>${x.asset&&x.asset!=="native"?escapeAttr(x.asset):"nativ"}</small></td><td class="n">${fmt(x.amount,{chain:x.chain,address:x.asset&&x.asset!=="native"?x.asset:null,symbol:x.symbol},{summary:true})}</td><td class="n">${x.price==null?"–":fmtUsd(x.price)}</td><td class="n">${x.priced?fmtUsd(x.value):"–"}</td></tr>`).join("");return `<h2>${escapeAttr(CHAIN_META[chain]?.label||chain)}</h2><table><thead><tr><th>Token</th><th class="n">Gesamtbestand</th><th class="n">Kurs USD</th><th class="n">Wert USD</th></tr></thead><tbody>${rows}</tbody><tfoot><tr><td colspan="3">SUBTOTAL ${escapeAttr(CHAIN_META[chain]?.label||chain)}</td><td class="n">${fmtUsd(sum)}</td></tr></tfoot></table>`}).join("");
  w.document.write(`<!doctype html><html><head><meta charset="utf-8"><title>Bestandesaufnahme ${date}</title><style>@page{size:A4 landscape;margin:15mm}body{font:9px Arial;color:#18202a;margin:0}h1{font-size:22px;margin:0 0 5px}h2{margin:14px 0 5px}.head{border-bottom:2px solid #ccd2d9;padding-bottom:9px}.cards{display:flex;gap:8px;margin:12px 0}.card{border:1px solid #ccd2d9;border-radius:6px;padding:8px;min-width:150px}.card b{display:block;font-size:14px}table{border-collapse:collapse;width:100%;margin:8px 0}thead{display:table-header-group}tr{page-break-inside:avoid}th,td{border:1px solid #c8ced5;padding:4px;vertical-align:top}th,tfoot td{background:#eef1f4;font-weight:bold}.n{text-align:right;white-space:nowrap}th.n{text-align:right}small{display:block;color:#666;font-size:7px;word-break:break-all}tfoot td{border-top:2px solid #18202a;font-size:10px}</style></head><body><div class="head"><h1>Bestandesaufnahme per 31.12</h1><p><b>Stichtag:</b> ${escapeAttr(date)} · ${escapeAttr(tz)} &nbsp; <b>Erstellt:</b> ${new Date().toLocaleString("de-CH")}</p></div><div class="cards"><div class="card">Wallets<b>${walletNames.length}</b></div><div class="card">Verifizierte Positionen<b>${ok.length}</b></div><div class="card">Historisch bewertet<b>${priced.length}/${ok.length}</b></div><div class="card">Gesamtwert<b>${fmtUsd(total)}</b></div></div><h1>Summary nach Chain</h1><p>Tokenbestände sind über alle ausgewählten Wallets je Chain zusammengefasst.</p>${chainSummary}<table><tfoot><tr><td>GESAMTSUMME – bewertete Positionen</td><td class="n">${fmtUsd(total)}</td></tr></tfoot></table><script>window.onload=()=>window.print();<\/script></body></html>`);w.document.close();
}



// Phase 4.95 · zentrale Datenstands-Metadaten für Tabs + Systemübersicht
const WT_DATA_STATUS = window.WT_DATA_STATUS || (window.WT_DATA_STATUS = {});
function wtFormatDataStamp(v){if(!v)return null;const d=new Date(v);if(Number.isNaN(d.getTime()))return null;return d.toLocaleString("de-CH",{day:"2-digit",month:"2-digit",year:"numeric",hour:"2-digit",minute:"2-digit",hour12:false});}
function setWtDataStatus(key,{updatedAt=null,cacheAt=null,source=null,label=null}={}){const prev=WT_DATA_STATUS[key]||{},next={...prev,updatedAt,cacheAt,source,label};if(JSON.stringify(prev)===JSON.stringify(next))return;WT_DATA_STATUS[key]=next;document.dispatchEvent(new CustomEvent("wallettracking:data-status",{detail:{key,...next}}));}
function wtDataStatusText(key){const x=WT_DATA_STATUS[key];if(!x)return "Aktualisierungszeitpunkt noch nicht verfügbar";const u=wtFormatDataStamp(x.updatedAt),c=wtFormatDataStamp(x.cacheAt);if(c&&x.source==="cache")return `aus Cache vom ${c}`;if(u)return `Daten aktualisiert am ${u}`;if(c)return `aus Cache vom ${c}`;return "Aktualisierungszeitpunkt noch nicht verfügbar";}
function ensureTabDataStatus(panel,name){if(!panel||name==="admin")return;let el=panel.querySelector(":scope > .wt-tab-data-status");if(!el){el=document.createElement("div");el.className="wt-tab-data-status";panel.insertBefore(el,panel.firstChild);}const key=name==="tlnvow"?"tln":name==="dao1"?"dao":name;el.innerHTML=`<strong>Datenstand:</strong> ${escapeAttr(wtDataStatusText(key).replace(/^Datenstand:\s*/,""))}`;}
function toggleSidebarCollapsed(force){const shell=document.querySelector(".app-shell");if(!shell)return;const next=typeof force==="boolean"?force:!shell.classList.contains("sidebar-collapsed");shell.classList.toggle("sidebar-collapsed",next);try{localStorage.setItem("wt-sidebar-collapsed",next?"1":"0")}catch{};const b=document.getElementById("sidebarCollapseBtn");if(b)b.setAttribute("aria-expanded",next?"false":"true");}
window.setWtDataStatus=setWtDataStatus;window.toggleSidebarCollapsed=toggleSidebarCollapsed;
document.addEventListener("DOMContentLoaded",()=>{try{toggleSidebarCollapsed(localStorage.getItem("wt-sidebar-collapsed")==="1")}catch{}
  const syncGlobal=()=>{const ds=document.getElementById("cacheStatusNote"),ps=document.getElementById("currentPriceStatus"),gd=document.getElementById("globalDataStatusText"),gp=document.getElementById("globalPriceStatusText");if(gd&&ds?.textContent)gd.textContent=ds.textContent.trim();if(gp&&ps?.textContent)gp.textContent=ps.textContent.replace(/^Preisstand:\s*/,"").trim()};syncGlobal();const obs=new MutationObserver(syncGlobal);const ds=document.getElementById("cacheStatusNote"),ps=document.getElementById("currentPriceStatus");if(ds)obs.observe(ds,{childList:true,subtree:true,characterData:true});if(ps)obs.observe(ps,{childList:true,subtree:true,characterData:true});
});
document.addEventListener("wallettracking:data-status",()=>{const p=document.querySelector(".tab-panel.active");if(p)ensureTabDataStatus(p,p.id.replace(/^tab-/,""));if(document.getElementById("admintab-system")?.classList.contains("active"))renderAdminSystemOverview();});

function showTab(name) {
  if(window.isDataJobActive?.()) return;
  markRequestAudit(`tab:${name}`);
  // TLN/VOW ist nur erreichbar, wenn ein passender Projekt-Token im Summary-Bestand liegt.
  if (name === "tlnvow" && !hasTlnVowTokenInSummary()) name = "tracking";
  updateContextNavigation(name);

  document.querySelectorAll(".tab-panel").forEach(p => p.classList.remove("active"));
  document.querySelectorAll(".tab-btn[data-tab]").forEach(b => b.classList.toggle("active", b.dataset.tab === name));
  const panel = document.getElementById("tab-" + name);
  if (panel) { panel.classList.add("active"); ensureTabDataStatus(panel,name); }
  if (name === "dashboard") renderDashboard();
  if (name === "predefined") { ensurePredefinedNames(); renderSafeTokenTable(); }
  if (name === "admin" && !document.querySelector(".admin-tab-panel.active")) showAdminTab("customtokens");
  if (name === "chat") {
    const userView = document.getElementById("userChatView");
    const adminView = document.getElementById("adminChatView");
    if (userView) userView.style.display = isAdmin ? "none" : "block";
    if (adminView) adminView.style.display = isAdmin ? "block" : "none";
    if (isAdmin) renderAdminChatUserSelect(); else loadOwnChat();
  }
  if (name === "tracking") ensureSnapshotsLoaded().then(()=>{renderSnapshotManager();renderResults();renderChartWalletSelect();}).catch(e=>console.warn("Manuelle Snapshots:",e));
  if (name === "tax") ensureSnapshotsLoaded().then(()=>renderTaxWalletSelect()).catch(e=>console.warn("Steuer-Snapshots:",e));
  if (name === "help") {
    if (typeof window.renderGeneralHelp === "function") window.renderGeneralHelp();
    renderHelpChainCoverage();
  }
  if (name === "nfts") ensureNftCacheLoaded().then(()=>{
    // Current State sofort aus RAM anzeigen. Historische Ersterwerbs-/Kaufpreis-Aufbereitung
    // läuft erst im NFT-Bereich und blockiert den aktuellen Bestand nicht.
    onNftWalletChange();
    ensureNftGlobalFirstOwnedLoaded().then(()=>{
      onNftWalletChange();
      // Phase 6.12: Fresh-Build/letzte Aktualisierung persistiert auch bewusst offene
      // Resolver-v3-Ergebnisse. Nur wenn sich die Erwerbs-Evidenz geändert hat oder ein
      // alter Resolverstand vorliegt, muss beim Tab-Einstieg nochmals nachgeladen werden.
      if(centralNftPurchaseEvidenceNeedsRefresh()) enrichCentralNftPurchaseEvidence().then(()=>onNftWalletChange()).catch(e=>console.warn("NFT Kaufpreis-Cache:",e));
    }).catch(e=>console.warn("NFT Besitzhistorie:",e));
  }).catch(e=>console.warn("NFT-Cache:",e));
  if (name === "fees") { renderFeesSummary(); onFeesWalletChange(); }
  if (name === "discovery") {
    ensureDiscoveryCacheLoaded().then(()=>{
      renderDiscoveryCacheState();
      if (lastDiscoveryFindings.length > 0) renderDiscoveryResults(lastDiscoveryFindings);
    }).catch(e=>console.warn("Discovery-Cache:",e));
  }
  if (name === "tlnvow" && window.TLNVOWProject) {
    Promise.resolve(window.TLNVOWDiscovery?.ensureInitialized?.())
      .then(()=>window.TLNVOWDiscovery?.loadDashboardSummary?.())
      // Phase 5.78: Der normale Projekt-Einstieg braucht nur den bereits gespeicherten
      // Preis-Snapshot. DEX-Konfiguration/Provider und Live-Preislogik werden erst beim
      // expliziten Untertab „Kurse und Pools“ initialisiert.
      .then(()=>window.TLNVOWProject.loadCachedPrices?.())
      .then(()=>{
        const tlnSubtabs = document.querySelectorAll("#tab-tlnvow .tln-vow-main-subtabs .tab-btn");
        const hasActiveTlnSubtab = [...tlnSubtabs].some(b => b.classList.contains("active"));
        if (!hasActiveTlnSubtab) {
          const overviewBtn = [...tlnSubtabs].find(b => /Übersicht/.test(b.textContent || ""));
          if (overviewBtn) openTlnDiscoveryTab("overview", overviewBtn);
        }
        // Phase 5.77: Der reine TLN/VOW-Einstieg darf keine LP-Historie/Scan-States
        // für alle Wallets laden. LP-Caches werden erst im LP-/Kurse-und-Pools-Kontext gelesen.
        return null;
      })
      .catch(e=>console.warn('TLN/VOW Projekt-Autoload:',e));
  }
  if (name === "dao1" && window.DAO1Project) {
    window.DAO1Project.ensureLoaded();
  }
}

function showAdminTab(name) {
  markRequestAudit(`admin-tab:${name}`);
  document.querySelectorAll(".admin-tab-panel").forEach(p => p.classList.remove("active"));
  document.querySelectorAll("[data-admin-tab]").forEach(b => b.classList.toggle("active", b.dataset.adminTab === name));
  document.querySelectorAll("[data-open-admin]").forEach(b => b.classList.toggle("active", b.dataset.openAdmin === name));
  const panel = document.getElementById("admintab-" + name);
  if (panel) panel.classList.add("active");
  if (name === "customtokens") renderAdminCustomTokens();
  if (name === "chains") loadAdminChains();
  if (name === "coverage") renderAdminChainCoverage();
  if (name === "defiprojects") loadAdminDefiProjects();
  if (name === "dex") loadAdminDexConfigs();
  if (name === "hardcoding") renderHardcodingAudit();
  if (name === "system") renderAdminSystemOverview();
  if (name === "ideas" && typeof window.renderAdminIdeas === "function") window.renderAdminIdeas();
  if (name === "documentation") renderAdminDocumentation();
}



const ADMIN_SYSTEM_TREE = [
  {id:"support",level:0,label:"💬 Support & Info",status:"planning",start:"DB Basis",daily:"–",open:"–",manual:"–",details:[]},
  {id:"chat",level:1,label:"Chat",status:"planning",start:"DB + Realtime",daily:"–",open:"DB",manual:"DB",details:[
    ["Nachrichten","–","Supabase · Chat-Tabellen","–","Login/Tab öffnen/Realtime"],["Ungelesen-Zähler","–","Supabase","–","App-Start"]]},
  {id:"help",level:1,label:"Hilfe",status:"planning",start:"Datei/DOM",daily:"–",open:"lokal",manual:"–",details:[["Allgemeine Hilfe","JS-Modul","–","–","Tab öffnen"]]},
  {id:"support-data",level:1,label:"🗑️ Daten & Konto",status:"done",idea:"Vollständige userbezogene Datenlöschung",start:"–",daily:"–",open:"cache-only",manual:"User bestätigt Löschung",details:[["Alle WalletTracking-Daten löschen","–","wallettracking_delete_all_user_data() + wallet-private","keine externe API","Phase 5.97: löscht transaktional alle public-Tabellenzeilen mit user_id des angemeldeten Users, anonymisiert created_by/updated_by in globalen Caches und leert lokale Browserdaten. Normale User werden danach abgemeldet; Admin-User behalten für wiederholte Lifecycle-Tests ausschließlich ihre Supabase-Auth-Session und starten leer neu. Globale öffentliche Blockchain-/Registry-/Token-/Contract-Fakten und das Auth-Login bleiben erhalten."]]},

  {id:"walletsgrp",level:0,label:"🧰 Wallets & Token",status:"planning",start:"DB",daily:"–",open:"Cache/DB",manual:"je Funktion",details:[]},
  {id:"wallets",level:1,label:"Meine Wallets",status:"done",start:"Edge · 1 Liste",daily:"–",open:"bereits geladen",manual:"gezielt speichern / vollständig löschen",details:[["Wallet-Konfiguration + Besitzer","RAM nach Login","wallet-private · verschlüsselte Wallet-Felder; is_own_wallet","–","App-Start: eine wallet_list-Abfrage; Besitzerfilter arbeitet danach nur im RAM"],["Neue/gespeicherte Wallet · Erstaufbau","nur diese Wallet","Current-State je konfigurierter Chain + NFT/DAO-Target-Refresh; TLN/VOW lazy bzw. Session-Refresh","RPC/API nur für diese Wallet","Phase 5.82: Speichern startet kein breites loadAll() über alle Wallets mehr. Bestehende Wallets bleiben unangetastet; Current State wird gezielt aufgebaut, DAO1/APTMDAO aktualisiert nur diese Wallet und TLN/VOW übernimmt sie sofort, falls das Modul bereits initialisiert ist – sonst beim ersten Öffnen."],["Wallet vollständig löschen","RAM wird nach Erfolg verworfen","wallet-private → transaktionale RPC; walletbezogene Tabellen + Snapshot-/31.12.-Daten + abgeleitete User-Caches","keine globalen Registry-/On-Chain-Fakten","Löschen in Meine Wallets; danach Reload und Neuaufbau aller Summen aus verbleibenden Daten"]]},
  {id:"predefined",level:1,label:"Vordefinierte Token",status:"in_progress",start:"DB",daily:"–",open:"RAM",manual:"DB neu",details:[["Vordefinierte Token + Dashboard-Flag","RAM","Supabase · predefined_tokens.dashboard_visible","–","App-Start; Flag bedeutet „immer anzeigen“. Positive Bestände > USD 1 erscheinen automatisch; Flag-Änderung nur Admin, danach Dashboard aus RAM neu rendern"]]},
  {id:"custom",level:1,label:"Eigene sichere Token",status:"planning",start:"DB",daily:"–",open:"RAM",manual:"DB",details:[["User-Token","RAM","Supabase · userbezogene Token","–","App-Start"]]},
  {id:"discovery",level:1,label:"🔍 Entdecken",status:"planning",start:"–",daily:"–",open:"DB-Cache",manual:"On-chain/API",details:[["Discovery-Ergebnis","RAM nach Lazy Load","Supabase Discovery-Cache","Alchemy/EVM + freie Quellen","Erst beim Öffnen des Tabs; Scan nur manuell"]]},

  {id:"analysis",level:0,label:"📊 Übersicht & Analyse",status:"in_progress",start:"Dashboard sofort + Caches",daily:"kein allgemeiner Auto-Refresh",open:"Cache lazy",manual:"je Funktion",details:[["App-Start-Inventar","RAM/Automated Cache","Chain-/Token-/Wallet-Basis · Refresh-State · automatisierter Bestand · Preis-Snapshot","keine allgemeine Preis-/On-chain-Aktualisierung beim Start","Phase 5.75: Der normale Login zeigt persistierte Current-State-Caches und startet kein loadAll() mehr. Projekt- und Historienjobs laufen nur über ihren jeweiligen Tab bzw. eine explizite Aktion; eine neue Wallet behält ihren gezielten Erstaufbau."]]},
  {id:"dashboard",level:1,label:"Dashboard · Startseite",status:"in_progress",idea:"Project-Summary-Cache",start:"sofort + Cache",daily:"Grunddaten + Preise",open:"RAM",manual:"Daten/Preise",details:[
    ["Vermögenskennzahlen","RAM aus Automated Snapshot","bereits geladener Bestands-Cache","kein allgemeiner Start-RPC","Dashboard sofort aus Cache. Phase 5.75: Ein normaler Seitenreload startet keinen allgemeinen Grunddatenlauf; Aktualisierung erfolgt gezielt manuell, beim Erstaufbau einer neuen Wallet oder über projektspezifische Tab-Logik."],
    ["Project-Summary","localStorage Anzeige-Cache + Projektcaches","TLN/DAO Projektcaches","keine eigene Discovery","Projektmodule schreiben bestätigte Summary-Werte zurück; Phase 6.00: TLN cache-only DB-Summaries verwenden ausschließlich persistierte UUID-wallet_id-Werte; transiente Client-IDs wie local1 werden bis zur DB-Zuordnung übersprungen. TLN Team nutzt denselben Forest/Lifecycle. TLN Staking-/Referral-/Bonus-Rewards und DAO Rewards/Referral Rewards sind in Originaltoken angeschlossen; DAO1/APTMDAO-Bezüge stammen aus getrennten Tree-Caches; die übergreifende Partnerzahl wird wallet-zentriert dedupliziert (1 Wallet = 1 Partner), während die beiden Einzelzahlen separat sichtbar bleiben. DAO-Aktivstatus bleibt bis zum Bot-Target-Proof offen."],
    ["Erststart ohne Wallet","lokale UI","–","–","Dashboard bleibt Startseite und erklärt den Ablauf; Ein-Klick-Aktion legt eine neue Wallet-Zeile an. Nach Speichern startet automatisch der Grunddaten-Erstaufbau."],
    ["Dashboard-Kurse","RAM","wallet_global_current_price_snapshot + predefined_tokens.dashboard_visible + TLN/VOW Projekt-PriceEngine","global alle 15 Min. bei aktivem Client + manuell","App-Start lädt den globalen Snapshot. Pro :00/:15/:30/:45 claimt genau ein aktiver Client den globalen Refresh-Slot. TLN/VOW: BSC PancakeSwap / ETH Uniswap; kein CoinGecko-/GeckoTerminal-Fallback."],
    ["Projekt-Kacheln","RAM + Project-Summary","predefined_tokens + persistente Projektcaches","keine eigene Discovery","Breite Karten; Projektwert wird zusätzlich in frei verfügbar / aktuell gebunden / gesamt aufgesplittet. LP-Staking wird nur einmal gezählt, auch wenn walletData und lp_position_cache dieselbe Position enthalten. Kursliste automatisch bei Bestand > USD 1; „immer anzeigen“ erlaubt Bestand 0; Projekt-Token nur bei belegter Projektbeteiligung. Reward-Summaries nutzen Summary-Kommastellen (leer = Anzeige übernehmen, 0 = keine Nachkommastellen). Fehlende Summary-Werte bleiben – bis ein fachlicher Cache sie bestätigt."],
    ["Personenfilter","RAM","verschlüsselte Wallet-Besitzer aus wallet-private","–","Eigene Wallets / alle Personen / bestimmte Person; keine Zusatzabfrage"]]},
  {id:"tracking",level:1,label:"Wallet-Tracking · Token-Übersicht",status:"in_progress",idea:"Browser-Cache + DATA_VERSIONS",start:"gespeicherter Stand",daily:"Preise frisch",open:"Cache",manual:"Bestände + Projekte + NFTs",details:[
    ["Wallet-Bestände","Automated Cache / RAM","Supabase Refresh-State","RPC je Chain nur bei gezieltem Refresh","Start zeigt Cache sofort und startet keinen allgemeinen Auto-Refresh. Neue Wallet: gezielter Erstaufbau nur für diese Wallet direkt nach Speichern; kein loadAll() über bestehende Wallets. Der zentrale Ladebalken bleibt bis zum Abschluss von Beständen, Projekt-/NFT-/Reward-Daten, Summaries und erfolgreichem Snapshot sichtbar. DAO1/APTMDAO baut für relevante Wallets die ERC-20 Asset-Flows inkrementell mit auf. Historische NFT-Ownership wird aus Wallet-Transferhistorien reproduziert; bei nur belegtem Abgang bleibt der Erwerbsbeginn bewusst unbekannt statt geschätzt. Projekte aktualisieren nur ihren relevanten Wallet-Scope bzw. bleiben lazy."],
    ["Aktuelle Kurse","Globaler 15-Minuten-Snapshot/RAM","wallet_global_current_price_snapshot","Preis-APIs + DEX/Pool RPC","Global :00/:15/:30/:45 nur bei aktivem Client; ein atomarer Slot-Claim verhindert Doppeljobs. Phase 5.41: stale-while-refresh – der letzte gültige Snapshot bleibt während Refresh/Teilfehler aktiv; tatsächlich neu geladene Assetpreise tragen zusätzlich refreshedAt. Alte Einzelpreise werden dadurch nicht als im aktuellen Lauf erneuert interpretiert. Keine Historisierung dieses aktuellen Snapshots."],
    ["TLN/VOW LP & Staking im Bestand","RAM/DB-Cache","Supabase Projekt-/Staking-Caches","BSC RPC","Im fälligen Grunddaten-Hintergrundlauf; vollständige Projekt-Discovery bleibt separat"]]},
  {id:"tax",level:1,label:"🧾 Bestandesaufnahme per 31.12",status:"planning",start:"–",daily:"–",open:"DB-Snapshots",manual:"historisch",details:[["Snapshots","RAM nach Lazy Load","Supabase Snapshots","–","Manuelle Snapshots und Jahresbestand erst beim Öffnen des Tabs"],["Historische Bewertung","Cache","Supabase Preis-/LP-Historie","Archive RPC/API bei Bedarf","Stichtagsberechnung"]]},
  {id:"fees",level:1,label:"💸 Gebühren",status:"planning",start:"–",daily:"–",open:"DB-Summary",manual:"Delta/API",details:[["Gebühren-Summary","RAM nach Lazy Load","Supabase Fee Cache/Summary","–","Gespeicherten Gebührenstand erst beim Öffnen des Tabs lesen"],["Gebührenhistorie","RAM","Supabase Fee Cache","Routescan/NodeReal/Blockscout etc.","On-chain/API erst bei Aktualisierung"]]},
  {id:"nfts",level:1,label:"🖼️ NFTs",status:"in_progress",start:"Current-State DB-Registry",daily:"kein Blind-Refresh",open:"RAM zuerst · History danach",manual:"On-chain/API",details:[["NFT-Bestand","RAM ab App-Start","Supabase NFT Cache + project_nft_ownership","Chain-spezifische NFT Quellen/RPC","Phase 5.58: Kaufpreis-Resolver v2 prüft ERC-20, nativen APTM-Tx-Value und Internal Transactions; reine Transfers/Mints werden von ungeklärten Käufen getrennt. Historische NFT-Entry-Txs bleiben auch ohne bereits verifizierten Kauf erhalten, damit fehlende DAO1-Kaufpreise zentral nachanalysiert werden können. Negative Preisbefunde werden nur mit konkreter geprüfter Erwerbs-Tx persistent abgeschlossen. Phase 5.75: zentrale NFT-Registry lädt beim App-Start nur den für Current State nötigen Bestand/Ownership. Globale Ersterwerbs- und Kaufpreis-Historie wird erst beim Öffnen des NFT-Tabs nachgeladen. NFT-Tab, DAO-Team und weitere Verbraucher verwenden dieselbe zentrale Datenbasis. Manuelle/gezielte Chain-Refreshs bleiben inkrementell. Phase 5.54: Phase 5.54: Kauf/Mint-Wallet und aktuelles Wallet werden gekürzt mit dem transparenten Standard-Copy-Icon gezeigt. Der früheste on-chain Besitzzeitpunkt bleibt auch ohne Kaufnachweis sichtbar; Kauf/Mint-Verifikation wird weiterhin separat gekennzeichnet. Phase 6.29 startet Audit P6: nft_cache (aktueller Wallet-NFT-Bestand) und project_nft_ownership (Besitzhistorie) sind die persistenten Wahrheiten; DAO1-Session-Sichten werden nach ihrer Initialisierung gegen diese zentralen Read-Models geprüft und als „DAO1 NFT Read-Model Audit“ protokolliert."],["NFT-Freshness","RAM","wallet_refresh_state","–","App-Start prüft nur, ob Aktualisierung verfügbar ist"]]},
  {id:"approvals",level:1,label:"🔓 Freigaben",status:"planning",start:"–",daily:"–",open:"bei Auswahl",manual:"On-chain/API",details:[["Token-Freigaben","–","–","Alchemy/RPC je unterstützter Chain","Spezialfunktion; nicht beim App-Start"]]},

  {id:"projects",level:0,label:"🏦 DeFi-Projekte",status:"in_progress",start:"Konfig DB",daily:"Preise",open:"Übersicht · keine Projektdaten",manual:"projektbezogen",details:[]},
  {id:"projects-overview",level:1,label:"Übersicht",status:"in_progress",start:"–",daily:"–",open:"nur lokale UI",manual:"–",details:[["DeFi-Projektübersicht","lokale UI","–","–","Öffnen lädt keine TLN/VOW- oder DAO1-Projektdaten; Inhalt noch zu definieren"]]},
  {id:"tln",level:1,label:"TLN / VOW",status:"in_progress",start:"Summary-Cache",daily:"Grunddaten + zentrale Preise",open:"Lazy Current-State",manual:"projektbezogen",details:[]},
  {id:"tln-overview",level:2,label:"Übersicht",status:"in_progress",start:"–",daily:"global 15 Min.",open:"DB-Batch + Preis-Snapshot",manual:"–",details:[["Projekt-Wallets + Discovery-Snapshots","Session/RAM","Supabase Projektgrunddaten + verified-discovery-results als Batch","ein Multicall nur für Wallets ohne bekannten Projektbezug","TLN/VOW erstmals öffnen; gleiche technische Cache-Reads danach Session-Hit"],["Aktueller Preisstand","globaler 15-Min.-Snapshot","Supabase Current Price Snapshot","–","Übersicht liest nur gespeicherten Snapshot; keine DEX-/Provider-Initialisierung"]]},
  {id:"tln-prices",level:2,label:"Kurse und Pools",status:"in_progress",start:"–",daily:"Preise",open:"Preis-/DEX-Infrastruktur lazy",manual:"RPC",details:[["LP/Pool-Daten + Preisrouten","Projektcache","Supabase DeFi-/DEX-Konfiguration + Current Price Snapshot","BSC/ETH Pool-RPC","Erst beim Öffnen dieses Untertabs werden DEX-Konfiguration und RPC-Provider initialisiert; statische Chain-IDs vermeiden Provider-Netzwerk-Erkennung"]]},
  {id:"tln-staking",level:2,label:"Staking/Rewards",status:"in_progress",start:"–",daily:"–",open:"Discovery-Cache",manual:"Discovery/RPC",details:[["Staking-Positionen/Rewards","Browser/DB Cache je Teilbereich","Supabase TLN/VOW Caches","BSC/ETH RPC","Lazy beim Projekt; Aktualisierung/Discovery gezielt"]]},
  {id:"tln-loans",level:2,label:"Loans",status:"in_progress",start:"–",daily:"–",open:"Discovery-Cache",manual:"Discovery/RPC",details:[["Loans/Rebounds","Cache","Supabase/Discovery-Daten","BSC RPC","Nicht Teil des normalen App-Starts"]]},
  {id:"tln-rewards",level:2,label:"Rewards Summary",status:"in_progress",start:"–",daily:"–",open:"Cache",manual:"Discovery",details:[["Reward Summary","Cache","Supabase/Discovery Cache","BSC/ETH bei Discovery","Projekt-Tab"]]},
  {id:"tln-referral",level:2,label:"Referral Rewards",status:"in_progress",start:"–",daily:"–",open:"Cache",manual:"Discovery",details:[["Referral Rewards","Cache","Supabase/Discovery Cache","BSC/ETH bei Discovery","Projekt-Tab"]]},
  {id:"tln-bonus",level:2,label:"Bonus-Rewards",status:"in_progress",start:"–",daily:"–",open:"Cache",manual:"Discovery",details:[["Bonus Rewards","Cache","Supabase/Discovery Cache","BSC/ETH bei Discovery","Projekt-Tab"]]},
  {id:"tln-team",level:2,label:"Team",status:"in_progress",idea:"Browser-Cache + DATA_VERSIONS",start:"–",daily:"–",open:"🟡 IDB + Version",manual:"Delta/RPC",details:[["SmartNode Team-Graph","IndexedDB · tln-vow/smartnode-global-graph","Supabase globaler TLN Graph + cache_data_versions","BSC Registry/RPC nur Discovery/Update","Phase 6.44: Realtest 6.43 erreichte Step 7, erzeugte bei fehlendem verifiziertem Globalgraph jedoch >3500 Requests durch den historischen SmartNode-Fallback ab Block 0. Normaler Team-Tab startet deshalb bei Slice-MISS keinen Full-Cold-Scan mehr. Vor dem Slice werden eigene Wallets gezielt per Identity-Cache/RPC auf verifizierte TLN-ID reduziert; reine Projekt-/Token-Wallets erweitern den Root-Scope nicht. Bei HIT bleibt der Egress-first-Pfad: nur relevante Downline/Upline per DB-RPC bzw. IDB + DATA_VERSIONS. Ein vollständiger historischer Globalgraph-Neuaufbau ist nur noch explizit über manuellen Step 7/DEV zulässig. Der lokale Slice trägt weiterhin die Root-Signatur der aktuellen eigenen Wallets; Änderungen auf einem anderen Gerät erzwingen daher einen neuen relevanten Slice statt eines falschen Cache-Hits. Migration 059 erforderlich. Lifecycle separat: verifizierte Ergebnisse pro Wallet persistent; v8/v9-verifizierte Cache-Ergebnisse werden releaseübergreifend wiederverwendet. Phase 6.45: Realtest 6.44 zeigte >1400 einzelne eth_getTransactionByHash-Aufrufe aus automatischer Lifecycle-Nachverifikation nach Team-Restore. Der normale Team-Tab startet deshalb keine Lifecycle-History mehr. Phase 6.46: Realtest 6.45 zeigte dennoch >1000 eth_getTransactionByHash-Aufrufe. Ursache war teamRestoreAdditionalRegistryGraph(): fehlte fuer eine Zusatzregistry ein persistenter Graph-Cache, baute der normale Restore deren komplette Join-Historie automatisch auf und lud jede Transfer-Tx einzeln. Das ist nun getrennt: normaler Team-Restore liest Zusatzregistries nur aus persistentem Cache; historischer Zusatzregistry-Aufbau ist ausschliesslich im expliziten Step-7-Pfad erlaubt. Ein Release-/UI-Wechsel invalidiert keine fachlich weiterhin gültigen verifizierten Lifecycles."]]},
  {id:"tln-admin",level:2,label:"Admin · Contracts",status:"planning",start:"–",daily:"–",open:"DB/Cache",manual:"Discovery",details:[["Contract Registry/Prüffälle","–","Supabase","BSC/ETH RPC bei Discovery","Nur Admin"]]},
  {id:"tln-help",level:2,label:"Hilfe",status:"planning",start:"–",daily:"–",open:"lokal",manual:"–",details:[["TLN/VOW Hilfe","JS-Modul","–","–","Tab öffnen"]]},
  {id:"tln-lpold",level:2,label:"Liquidity Pools_old",status:"planning",start:"–",daily:"–",open:"Cache/DB",manual:"RPC",details:[["Legacy LP-Ansicht","Cache","Supabase LP Cache","BSC/ETH RPC","Legacy-Bereich"]]},

  {id:"dao",level:1,label:"DAO1",status:"in_progress",idea:"Browser-Cache + DATA_VERSIONS",start:"Summary-Cache",daily:"Grunddaten",open:"Lazy DB",manual:"projektbezogen",details:[["Projekt-Basis","DOM Mount + Dashboard-Summary","Supabase gezielte Summary-/Tree-Caches","–","App-Start zeigt Summary cache-first; vollständiges refreshConfig erst beim Öffnen"]]},
  {id:"dao-overview",level:2,label:"Übersicht",status:"in_progress",start:"–",daily:"–",open:"DB/RAM",manual:"Projektrefresh",details:[["DAO1 Übersicht/Bot-Summen","RAM nach Lazy Load","Supabase DAO1 Caches","Apertum bei Aktualisierung","Current State; eindeutige aktuelle Bots, Historie separat"]]},
  {id:"dao-prices",level:2,label:"Kurse und Pools",status:"in_progress",start:"–",daily:"–",open:"vorhandener Preis-Cache",manual:"zentrale Preisaktualisierung",details:[["DAO1 aktuelle Kurse/Preisrouten","RAM/zentraler Preiscache","bestehende DAO1/Apertum Preislogik","Apertum DEX nur bei zentraler Preisaktualisierung","Tab zeigt ausschließlich bereits ermittelte Preise, Routen und Pools; keine eigene Preisermittlung"]]},
  {id:"dao-tx",level:2,label:"Transaktionen",status:"in_progress",start:"–",daily:"–",open:"DB-Cache",manual:"Delta/On-chain",details:[["Apertum Transaktionshistorie","RAM","Supabase zentrale Historie/Asset-Flows","Apertum RPC/Explorer","Wallet-Wechsel Cache; Daten aktualisieren lädt neue Chain-Daten"]]},
  {id:"dao-claims",level:2,label:"Bot-Claims",status:"in_progress",start:"Summary aus DB-Cache",daily:"–",open:"DB-Cache",manual:"Delta/On-chain",details:[["Bot Claims","P5: zentrale asset-flow-first Payout-Leseschicht; Claim→NFT-Marker aus Transaktion/Claim-Cache","Supabase project_transaction_asset_flows (Asset/Menge/USD kanonisch) + project_transactions/project_nft_claims nur Claim-/NFT-Zuordnung und Kompatibilitätsdaten","Apertum nur bei manueller Aktualisierung","Phase 6.20 persistiert auch native APTM-Claims als Asset-Flows. Phase 6.21 entfernt den Legacy-Read-Fallback aus sichtbaren Claim-/Transaktions-/Exportpfaden; Asset-Flows sind dort alleinige Quelle für Asset, Menge und USD-Wert. Phase 6.22 ergänzt die historische APTM/USD-Bewertung direkt auf den nativen Claim-Flows; vorhandene TX-Preise werden wiederverwendet, nur offene Blöcke gehen über exact-v13 Price-Anchors. Der erste 6.22-Realtest scheiterte korrekt offen mit PGRST204, weil loadAssetFlowRows das private Runtime-Feld wallet_address hydratisiert und der Preis-Backfill diese Zeilen unverändert zurückschreiben wollte. Phase 6.23 entfernt dieses Nicht-Schemafeld zentral vor jedem Asset-Flow-Upsert; die fehlgeschlagene v1-Migration wird ohne SQL/Wallet-Neuaufbau erneut ausgeführt. Der 6.23-Realtest bewertete 257 von 267 nativen APTM-Flows und zeigte $1’452.40 historischen Gesamtwert; Phase 6.24 führt zusätzlich die sichtbare Spalte „APTM-Preis USD historisch“ direkt aus dem kanonischen Flow-Preis statt aus dem Legacy-Feld aptm_usd. Phase 6.25 diagnostiziert die offenen Preisfälle mit exaktem Anchor-Cache, nächstem gültigem Zielanker davor/danach und Legacy-Predecessor. Phase 6.26 verschiebt Repricing und Diagnose aus dem Claim-Tab in den App-Start-/DAO1-Aktualisierungspfad: nur offene Nicht-Prelaunch-Flows werden erneut geprüft; echte Prelaunch-Fälle werden dauerhaft markiert. Der 6.26-Realtest reduzierte 10 offene Flows auf 4 echte Prelaunch-Fälle und 6 Post-Launch-Missing-Fälle; die Diagnose blieb jedoch wegen noch nicht hydriertem Adminstatus beim App-Start bei 0. Phase 6.27 lässt die Diagnose deshalb im eigenen User-Kontext bereits mit aktiver Session laufen. Phase 6.28 behebt die Ursache der sechs verbleibenden Post-Launch-Lücken: Admin-Läufe synchronisieren die globale APTM-Poolhistorie bis zum höchsten offenen Claim-Block; alle User dürfen fehlende Exact-Zielblöcke read-only lokal aus Pool-State/Sync-Logs auflösen, ohne globale Cache-Schreibrechte. Prelaunch ist global und wallet-unabhängig als Block < 88356 (erster verlässlicher wAPTM/wUSDT-Marktpreis) definiert."]]},
  {id:"dao-ref",level:2,label:"Referral Rewards",status:"in_progress",start:"Summary aus DB-Cache",daily:"–",open:"DB-Cache",manual:"Delta/On-chain",details:[["Referral Rewards","Dashboard: aggregierter Tx-/Asset-Flow-Cache; Detail: RAM","Supabase Tx/Flow Cache","Apertum nur bei manueller Aktualisierung","Dashboard und Detail verwenden dieselben Referral-Regeln; nur relevantes DAO1 Referral-Wallet"]]},
  {id:"dao-team",level:2,label:"Team",status:"in_progress",start:"–",daily:"–",open:"🟢 IDB + Version",manual:"🟡 On-chain Update",details:[
    ["Legacy Team-Kanten","IndexedDB · dao1/legacy-tree","Supabase dao1_old_tree_*","Apertum RPC nur bei manueller Aktualisierung","Normaler Tab-Aufruf 🟢: IDB + DATA_VERSIONS → Root + Downline + Upline der aktuell eigenen DIDs lokal lesen, DB 0 / RPC 0 bei HIT; manueller Update-Pfad inkrementell mit 24-Block-Overlap"],
    ["APTMDAO Team-Kanten","IndexedDB · dao1/aptmdao-tree","Supabase aptmdao_tree_*","Apertum NFT-Mint-Event; RPC nur bei Update/Erstaufbau","Phase 5.39: child/parent/wallet on-chain verifiziert; eigener Graph, max. 20 Ebenen; Migration 063. DAO1/APTMDAO sind eigenständige DID-/Alias-Systeme. Normaler Cache-HIT ohne RPC, Update mit 24-Block-Overlap."],
    ["DAO Wallet-Team + Partner-Bot-Lifecycle","RAM + Dashboard-Summary","dao1_old_tree_* + aptmdao_tree_* + dao_partner_bot_lifecycle_cache","Apertum RPC/Explorer nur bei Tree-Update bzw. gezielten Partnerdetails","Phase 5.62: Partner-Bots fremder Team-Wallets werden nach Entdeckung zentral in kleinen Batches aktualisiert, per userbezogenem SHA-256-Scan-State max. täglich erneut geprüft und in den bestehenden Lifecycle für Dashboard/Team persistiert. Direkte Uplines bleiben reine Upline-Knoten und werden weder als Downline noch als Partner gezählt. Phase 5.55: DAO1-alt und APTMDAO werden als getrennte vollständige Graphquellen in einen Walletgraph überführt; zentrale aktuelle NFT-/Ownership-Zuordnung hat bei DID→Wallet Vorrang vor historischen Tree-Event-Adressen. Mehrere externe Uplines eines eigenen Wallets werden getrennt nach DAO1/APTMDAO parallel oberhalb des Einstiegsknotens gezeigt. Belegte Upline-Ketten oberhalb eigener DIDs werden als echte Knoten gezeigt; eigene Wallets folgen ihrer DID-Parent-Kante (z. B. #25924 unter #21043) und zählen nicht als Partner. DAO1-only-Partner benötigen keine APTMDAO-DID. Für eigene Wallets ist der zentrale NFT-/Ownership-Bestand die Single Source of Truth; der Team-Baum startet keine parallele NFT-Discovery. Phase 5.93: Der Apertum-RPC-Proxy erlaubt ausschließlich die benötigten APTMDAO-DID eth_call-Selectoren; DATA_MIGRATIONS kann partial persistent speichern (SQL 072), und NFT-Migration v4 läuft automatisch erneut. Phase 5.92: CORS-gesperrte APTMDAO-Metadaten (api.aptmdao.io/nft/<ID>) werden serverseitig über wallet-private mit enger Allowlist geladen; Migrationsjobs unterscheiden complete/partial/failed und partial erhöht die Datenversion nicht. APTMDAO-DID ownerOf/Parent darf eth_call über den bestehenden RPC-Proxy nutzen. Phase 5.91: NFT-Metadatenabrufe verwenden nur echte Metadata-/Token-URIs; Explorer-Webseiten und external_url-UI-Links werden CORS-sicher übersprungen. Die Migration wird per Datenversion einmalig erneut ausgeführt. Phase 5.90: Apertum-Botnamen werden zusätzlich aus Store-/Metadata-Attributen sowie vorhandenen project_nfts-Bezeichnungen aufgelöst; generische MineBot-#-Namen bleiben letzter Fallback. Die automatische Datenmigration prüft bestehende Apertum-NFT-Caches einmalig erneut. Phase 5.88: Der NFT-Tab bietet einen Typfilter (DID, MineBot, Hearts NFT, TradeBot); Apertum-Bots bevorzugen echte Store-/Metadata-Namen vor generischen MineBot-Fallbacks und vervollständigen Bild + Name + ID. Ein manueller NFT-Refresh repariert anschließend nur offene/invollständige DAO-Ownership-Historien. APTMDAO-Identitäts-NFTs werden fachlich als DID gezählt. Phase 5.87 gleicht vor 5.82 hinzugefügte Wallets gegen den zentralen Current-State ab und rekonstruiert fehlende/invollständige Ownership-Historien; bekannte DAO1-DID-Contracts benötigen keine manuelle Typklassifikation. Aktueller Owner und historische Erwerbs-/Kaufdaten bleiben getrennte Eigenschaften desselben NFT-Datensatzes. Root-Erkennung bleibt von aktuellen Projekt-Balances entkoppelt; Ownership wird vor Dashboard-/Tree-Cache geladen. User-Oberfläche: ausschließlich ein wallet-zentrierter DAO-Team-Baum (1 Wallet = 1 Knoten/Partner); separate DAO1-alt/APTMDAO-neu Ansichten sind aus der normalen Navigation entfernt und bleiben nur intern/DEV als getrennte Nachweisgraphen. Standardansicht ist wallet-zentriert. Eigene Wallets werden anhand ihrer belegten DAO1-/APTMDAO-Upline ebenfalls in denselben Baum eingehängt statt künstlich als separate Roots dargestellt; sie zählen nicht als Partner. DAO1-/APTMDAO-DIDs desselben Wallets bleiben on-chain getrennt und werden im Knoten visuell getrennt gezeigt. APTMDAO bestimmt bei zwei belegten Downline-Beziehungen die grafische Position. Bot-Details trennen aktuellen Owner-Bestand von früher auf diesem Wallet gekauften/übertragenen Bots; historische Kaufdaten bleiben am Bot. Neue MinerBot-Käufe lesen die verwendete APTMDAO-DID direkt aus dem Kaufaufruf (Referenz #31722: DID #7315, Parent #23); historische Ownership bleibt Fallback. Eigene Wallets sind aus Letzte Partneraktivitäten ausgeschlossen. Migration 065."],
    ["DATA_VERSION","IndexedDB Meta","Supabase cache_data_versions","–","Legacy: Migration 057; APTMDAO: Migration 063. Kleine Registry-Gates statt Graph-Vollread bei Cache-HIT."],
    ["Partner-Botdetails","RAM + 24h IndexedDB Current-State","Supabase NFT/Ownership/Lifecycle Caches","Apertum nur bei abgelaufenem/fehlendem Current-State-Cache","Phase 5.78: fremde Partner-Wallet+Contract-Holdings werden 24h browserseitig wiederverwendet; historische Erwerbs-/DID-/Kaufpreislogik bleibt separat und blockgenau"]]},
  {id:"dao-lp",level:2,label:"Liquidity Pools",status:"in_progress",start:"–",daily:"–",open:"DB/Cache",manual:"RPC",details:[["DAO1 LP-Positionen","LP Cache","Supabase LP Cache","Apertum RPC","Beim Untertab öffnen renderProjectLpTab"]]},
  {id:"dao-config",level:2,label:"Konfiguration",status:"planning",start:"–",daily:"–",open:"bereits Lazy geladen",manual:"DB",details:[["Miner/Projekt-NFT/Konfiguration","RAM","Supabase DAO1 Tabellen","–","DAO1 ensureLoaded/refreshConfig"]]},
  {id:"dao-help",level:2,label:"Hilfe",status:"done",start:"–",daily:"–",open:"lokal",manual:"–",details:[["DAO1 Hilfe","JS-Modul","–","–","Tab öffnen"]]},

  {id:"cache-audit",level:0,label:"⚡ Cache-/Request-Audit",status:"done",idea:"Cache-/Request-Audit und Startoptimierung",start:"🟢 Session-Audit + kein Auto-loadAll",daily:"kein Blind-Refresh",open:"Tab-Marker + Messung",manual:"gezielte Vergleichsläufe",details:[
    ["Request-Inventar","Session/RAM","Supabase Tabellen + cache_data_versions","RPC/API je tatsächlich ausgeführtem Call","Phase 5.80 Abschlussstand: TLN/VOW bündelt die Wallet-Token-Prüfung projektweit in einem Multicall, lädt Discovery-Snapshots aller eigenen Wallets in einem DB-Batch und memoisiert technische Cache-Reads pro Session. Der normale TLN-Haupttab initialisiert DEX/Provider nicht mehr; Kurse/Pools tun dies erst beim Untertab. DAO-Partner-Current-Holdings werden 24h im zentralen IndexedDB-Cache wiederverwendet. DATA_VERSIONS bleibt in-flight dedupliziert und 30 s gecacht; Start-/Tab-/Refresh-Marker segmentieren den Lauf"],
    ["Shared Loads","RAM pro App-Lauf","globale/öffentliche Cache-Tabellen","–","Identische DB-Reads/Graph-Paginierungen innerhalb eines Laufs einmal laden und teilen"],
    ["Delta-Invalidierung","IndexedDB/local cache","DATA_VERSIONS + rootsKey + sync_cursor/last_scanned_block","Chain Head + kleiner Overlap","Nur bei Versions-/Scope-/Cursor-Abweichung nachziehen; kein Blind-Rebuild"],
    ["Current State vs History","zentraler Current-State-Cache","NFT/Ownership/Projektcaches","historische Reads nur bei Bedarf","Aktuelle Bestände nie auf Kaufpreis/Lifecycle/historische DID-Auflösung warten lassen"],
    ["Historisches ownerOf@Block","persistenter Ergebnis-Cache","DAO Lifecycle/History Cache","gezielter eth_call über geeigneten RPC","Separat reparieren; darf aktuelle Bot-Anzahl nicht beeinflussen"]]},
  {id:"admin",level:0,label:"⚙️ Admin-Bereich",status:"in_progress",start:"Admin-Prüfung",daily:"–",open:"on demand",manual:"DB",details:[]},
  {id:"admin-token",level:1,label:"Eigene sichere Token",status:"planning",start:"–",daily:"–",open:"DB",manual:"DB",details:[]},
  {id:"admin-chains",level:1,label:"⛓️ Chains",status:"planning",start:"Chain-Konfig DB",daily:"–",open:"DB",manual:"DB",details:[["Chain-Konfiguration","RAM","Supabase public.chains","–","Grundkonfiguration wird beim Login geladen; Editor on demand"]]},
  {id:"admin-defi",level:1,label:"🏦 DeFi-Projekte",status:"planning",start:"Projekt-Konfig DB",daily:"–",open:"DB",manual:"DB",details:[]},
  {id:"admin-dex",level:1,label:"🔄 DEX",status:"planning",start:"–",daily:"–",open:"DB",manual:"DB",details:[]},
  {id:"admin-hard",level:1,label:"🧪 Hardcoding-Audit",status:"planning",start:"–",daily:"–",open:"lokal",manual:"–",details:[]},
  {id:"admin-system",level:1,label:"🗺️ Systemübersicht",status:"done",idea:"Systemübersicht · Funktionsbaum",start:"Release-/Migrationscheck",daily:"–",open:"lokal",manual:"–",details:[["Funktions-/Ladebaum","JS Definition","–","–","Admin-Tab öffnen; Status mit Ideen/TODOs verknüpft"],["Release-Management / DATA_MIGRATIONS","userbezogener Versionsstand","Supabase user_data_migrations + user_release_acknowledgements","gezielte API/RPC nur wenn ein registrierter Migrationsjob dies fachlich verlangt","Phase 5.93: SQL 072 erweitert den DB-Status-Constraint um partial; der Apertum-RPC-Proxy wird mit enger eth_call-Allowlist versioniert/deployed. Phase 5.92: complete/partial/failed wird persistent unterschieden; partial/failed erhöht die Datenversion nicht und wird erneut versucht. Phase 5.89: beim Login nur fehlende Datenmigrationen ausführen; Abschluss erst nach Erfolg persistieren. Relevante Release-Mitteilungen erscheinen pro User einmal als quittierungspflichtiges Popup."]]},
  {id:"admin-ideas",level:1,label:"💡 Ideen / Umbau",status:"in_progress",start:"JS geladen",daily:"–",open:"lokal",manual:"–",details:[["Projekt-TODOs","admin/ideas.js","–","–","Datei wird mit Cache-Buster geladen"]]},
  {id:"admin-testing",level:1,label:"🧪 Zu testen",status:"in_progress",idea:"Zu testen · Wallet- und Datenlöschungs-Flows",start:"–",daily:"–",open:"lokal",manual:"praktischer Test",details:[["Wallet hinzufügen","–","Wallet-/Projekt-Daten + Caches","projektbezogene Initialisierung","Neue Wallet erfassen; sichtbaren Ladebalken bis Job-Ende, DAO1 Claim-Auszahlungen/Asset-Flows, Projekt-Erkennung und Dashboard-Summen prüfen"],["Wallet löschen","–","walletbezogene DB-Daten + Caches","–","Einzel-Wallet-Löschung vollständig prüfen; Summen aus verbleibenden Wallets neu validieren"],["Sämtliche Daten löschen","–","wallettracking_delete_all_user_data() + Browsercache","–","Zweistufige Bestätigung, vollständige serverseitige + lokale Löschung prüfen; normale User: Logout/Re-Login, Admin-Testuser: Session bleibt erhalten und leerer Neustart ohne neuen Magic Link"]]},
  {id:"admin-doc",level:1,label:"📚 Dokumentation",status:"done",start:"–",daily:"–",open:"lokal",manual:"–",details:[]}
];

let adminSystemSelectedId="dao-team";
const WT_SYSTEM_TREE_STATE_KEY="wt-system-tree-expanded-v1";
let wtSystemExpanded=new Set();
try{const a=JSON.parse(localStorage.getItem(WT_SYSTEM_TREE_STATE_KEY)||"[]");if(Array.isArray(a))wtSystemExpanded=new Set(a)}catch{}
function wtSystemChildrenMap(){const m=new Map();const stack=[];for(const r of ADMIN_SYSTEM_TREE){while(stack.length&&stack[stack.length-1].level>=r.level)stack.pop();const parent=stack.length?stack[stack.length-1]:null;if(parent){if(!m.has(parent.id))m.set(parent.id,[]);m.get(parent.id).push(r.id)}stack.push(r)}return m}
function wtSystemParentMap(){const m=new Map(),stack=[];for(const r of ADMIN_SYSTEM_TREE){while(stack.length&&stack[stack.length-1].level>=r.level)stack.pop();m.set(r.id,stack.length?stack[stack.length-1].id:null);stack.push(r)}return m}
function wtSystemVisible(row,parentMap){let p=parentMap.get(row.id);while(p){if(!wtSystemExpanded.has(p))return false;p=parentMap.get(p)}return true}
function wtSaveSystemTree(){try{localStorage.setItem(WT_SYSTEM_TREE_STATE_KEY,JSON.stringify([...wtSystemExpanded]))}catch{}}
function toggleAdminSystemNode(id,event){event?.stopPropagation?.();if(wtSystemExpanded.has(id))wtSystemExpanded.delete(id);else wtSystemExpanded.add(id);wtSaveSystemTree();renderAdminSystemOverview()}
function setAdminSystemTreeExpanded(expand){const cm=wtSystemChildrenMap();wtSystemExpanded=expand?new Set(cm.keys()):new Set();wtSaveSystemTree();renderAdminSystemOverview()}
window.toggleAdminSystemNode=toggleAdminSystemNode;window.setAdminSystemTreeExpanded=setAdminSystemTreeExpanded;
function adminSystemIdeaStatus(row){
  if(!row.idea||!Array.isArray(window.ADMIN_IDEAS)&&typeof ADMIN_IDEAS==="undefined")return row.status||"planning";
  const list=(typeof ADMIN_IDEAS!=="undefined"?ADMIN_IDEAS:[]).filter(x=>`${x.title} ${x.desc}`.toLowerCase().includes(String(row.idea).toLowerCase()));
  if(!list.length)return row.status||"planning";if(list.some(x=>x.status==="error"))return "error";if(list.some(x=>["in_progress","clarifying","paused"].includes(x.status)))return "in_progress";if(list.every(x=>x.status==="done"))return "done";return "planning";
}
function adminSystemStatusMeta(status){return ({done:["🟢","Erledigt"],in_progress:["🟡","In Arbeit"],error:["🔴","Fehlerhaft"],planning:["⚪","In Planung"]})[status]||["⚪","In Planung"]}
function wtSystemDataKey(row){if(row.id==="tracking")return "tracking";if(row.id==="dao-team")return "dao-team";if(row.id==="tln-team")return "tln-team";if(row.id.startsWith("dao"))return "dao";if(row.id.startsWith("tln"))return "tln";return row.id}
function wtSystemCurrentText(row,childrenMap){if(childrenMap.has(row.id))return "–";const own=WT_DATA_STATUS[wtSystemDataKey(row)];return own?wtDataStatusText(wtSystemDataKey(row)):"Aktualisierungszeitpunkt noch nicht verfügbar"}
let adminSystemDataVersionsPromise=null;
let adminSystemDataVersionsLoadedAt=0;
async function refreshAdminSystemDataVersions({force=false}={}){
  if(!sb||!isAdmin)return;
  const now=Date.now();
  if(!force&&adminSystemDataVersionsLoadedAt&&now-adminSystemDataVersionsLoadedAt<30000)return;
  if(adminSystemDataVersionsPromise)return adminSystemDataVersionsPromise;
  adminSystemDataVersionsPromise=(async()=>{
    try{
      const {data,error}=await sb.from("cache_data_versions").select("namespace,cache_key,data_version,sync_cursor,updated_at").in("namespace",["dao1","tln-vow"]);
      if(error)throw error;
      const rows=Array.isArray(data)?data:[];
      const newest=(items)=>items.slice().sort((a,b)=>new Date(b.updated_at||0)-new Date(a.updated_at||0))[0]||null;
      const dao=newest(rows.filter(r=>r.namespace==="dao1"&&["legacy-tree","aptmdao-tree"].includes(r.cache_key)));
      const tln=newest(rows.filter(r=>r.namespace==="tln-vow"&&r.cache_key==="smartnode-global-graph"));
      if(dao)setWtDataStatus("dao-team",{updatedAt:dao.sync_cursor||dao.updated_at,cacheAt:dao.updated_at,source:"cache"});
      if(tln)setWtDataStatus("tln-team",{updatedAt:tln.sync_cursor||tln.updated_at,cacheAt:tln.updated_at,source:"cache"});
      adminSystemDataVersionsLoadedAt=Date.now();
    }catch(e){console.warn("Systemübersicht DATA_VERSIONS",e)}
    finally{adminSystemDataVersionsPromise=null;}
  })();
  return adminSystemDataVersionsPromise;
}
function requestAuditAggregateRows(){
  const groups=new Map();
  for(const e of WT_REQUEST_AUDIT.entries){
    const key=[e.kind,e.method,e.resource,e.scope||""].join("|");
    const g=groups.get(key)||{...e,count:0,totalMs:0,maxMs:0,lastCaller:""};
    g.count++;g.totalMs+=Number(e.durationMs||0);g.maxMs=Math.max(g.maxMs,Number(e.durationMs||0));if(e.caller)g.lastCaller=e.caller;groups.set(key,g);
  }
  return [...groups.values()].sort((a,b)=>b.count-a.count||b.totalMs-a.totalMs);
}
function requestAuditPanelHtml(){
  const rows=requestAuditAggregateRows(),total=WT_REQUEST_AUDIT.entries.length,totalMs=WT_REQUEST_AUDIT.entries.reduce((s,e)=>s+Number(e.durationMs||0),0),duplicates=rows.filter(r=>r.count>1).length;
  const body=rows.slice(0,80).map(r=>`<tr><td>${escapeAttr(r.kind)}</td><td><strong>${escapeAttr(`${r.method} ${r.resource}`)}</strong></td><td class="meta">${escapeAttr(r.scope||"–")}</td><td class="num">${r.count}</td><td class="num">${(r.totalMs/r.count).toFixed(1)} ms</td><td class="num">${r.maxMs.toFixed(1)} ms</td><td class="meta">${escapeAttr(r.lastCaller||"–")}</td></tr>`).join("");
  return `<div class="custom-token-card" style="margin-top:14px"><div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap"><h3 style="margin:0">⚡ Laufender Request-Audit</h3><button type="button" class="secondary" onclick="renderAdminSystemOverview()">Neu anzeigen</button><button type="button" class="secondary" onclick="exportRequestAudit()">Audit exportieren</button><button type="button" class="secondary" onclick="resetRequestAudit()">Audit zurücksetzen</button></div><div class="meta" style="margin-top:7px">Seit ${escapeAttr(wtFormatDataStamp(WT_REQUEST_AUDIT.startedAt)||WT_REQUEST_AUDIT.startedAt)} · ${total} Requests · ${rows.length} eindeutige Signaturen · ${duplicates} mehrfach aufgerufene Signaturen · kumuliert ${Math.round(totalMs)} ms. Filterwerte werden gekürzt/anonymisiert; Auth-Header und Bodies werden nicht gespeichert.</div><div class="chain-table-wrap" style="margin-top:10px"><table class="chain-admin-table" style="min-width:1250px"><thead><tr><th>Typ</th><th>Request</th><th>Scope / Filter</th><th class="num">Anzahl</th><th class="num">Ø</th><th class="num">Max</th><th>letzter Aufrufer</th></tr></thead><tbody>${body||'<tr><td colspan="7">Noch keine Requests gemessen.</td></tr>'}</tbody></table></div></div>`;
}
function renderAdminSystemOverview(){
  const host=document.getElementById("adminSystemOverview");if(!host||!isAdmin)return;const cm=wtSystemChildrenMap(),pm=wtSystemParentMap();try{if(localStorage.getItem(WT_SYSTEM_TREE_STATE_KEY)===null)wtSystemExpanded=new Set(cm.keys())}catch{};
  const rows=ADMIN_SYSTEM_TREE.filter(r=>wtSystemVisible(r,pm)).map(r=>{const st=adminSystemIdeaStatus(r),m=adminSystemStatusMeta(st),hasKids=cm.has(r.id),toggle=hasKids?`<button class="wt-system-tree-toggle" onclick="toggleAdminSystemNode('${escapeAttr(r.id)}',event)" title="${wtSystemExpanded.has(r.id)?'Zuklappen':'Aufklappen'}">${wtSystemExpanded.has(r.id)?'▼':'▶'}</button>`:'<span style="display:inline-block;width:30px"></span>';const leaf=!hasKids;return `<tr class="wt-system-row" onclick="selectAdminSystemRow('${escapeAttr(r.id)}')"><td style="padding-left:${8+r.level*20}px;white-space:nowrap">${toggle}<strong>${escapeAttr(r.label)}</strong></td><td style="white-space:nowrap" title="${m[1]}">${m[0]} ${m[1]}</td><td>${escapeAttr(leaf?wtSystemCurrentText(r,cm):'–')}</td><td>${escapeAttr(leaf?(r.start||'–'):'–')}</td><td>${escapeAttr(leaf?(r.daily||'–'):'–')}</td><td>${escapeAttr(leaf?(r.open||'–'):'–')}</td><td>${escapeAttr(leaf?(r.manual||'–'):'–')}</td></tr>`}).join("");
  host.innerHTML=`<div class="custom-token-card" style="margin-bottom:14px"><div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap"><button type="button" class="secondary" onclick="setAdminSystemTreeExpanded(true)">Alle aufklappen</button><button type="button" class="secondary" onclick="setAdminSystemTreeExpanded(false)">Alle zuklappen</button><span>🟢 erledigt</span><span>🟡 in Arbeit</span><span>🔴 fehlerhaft</span><span>⚪ in Planung</span></div><div class="meta" style="margin-top:7px">Aktueller Datenstand und Tabs verwenden dieselben zentralen Metadaten. Knotenpfeil = Ast auf/zu; Zeile = Datenquellen-Popup.</div></div><div class="chain-table-wrap"><table class="chain-admin-table" style="min-width:1320px"><thead><tr><th>Bereich / Baum</th><th>Status</th><th>Aktueller Datenstand</th><th>Normaler App-Start</th><th>1. Start am Tag</th><th>Tab / Bereich öffnen</th><th>Manuell aktualisieren</th></tr></thead><tbody>${rows}</tbody></table></div>${requestAuditPanelHtml()}`;
  refreshAdminSystemDataVersions();
}
function ensureAdminSystemDetailModal(){
  let modal=document.getElementById("adminSystemDetailModal");if(modal)return modal;
  modal=document.createElement("div");modal.id="adminSystemDetailModal";modal.className="wt-system-detail-modal";modal.setAttribute("aria-hidden","true");
  modal.innerHTML=`<div class="wt-system-detail-dialog" role="dialog" aria-modal="true" aria-labelledby="adminSystemDetailTitle"><div class="wt-system-detail-head"><h3 id="adminSystemDetailTitle">Datenquellen</h3><button type="button" class="secondary wt-system-detail-close" onclick="closeAdminSystemDetailModal()" aria-label="Schließen">×</button></div><div id="adminSystemDetailBody" class="wt-system-detail-body"></div></div>`;
  modal.addEventListener("click",e=>{if(e.target===modal)closeAdminSystemDetailModal();});document.body.appendChild(modal);return modal;
}
function openAdminSystemDetailModal(row){
  const modal=ensureAdminSystemDetailModal(),title=document.getElementById("adminSystemDetailTitle"),body=document.getElementById("adminSystemDetailBody");
  if(title)title.textContent=`Datenquellen · ${row?.label||'–'}`;
  const detailRows=(row?.details||[]).map(d=>`<tr><td><strong>${escapeAttr(d[0])}</strong></td><td>${escapeAttr(d[1]||'–')}</td><td>${escapeAttr(d[2]||'–')}</td><td>${escapeAttr(d[3]||'–')}</td><td>${escapeAttr(d[4]||'–')}</td></tr>`).join("");
  if(body)body.innerHTML=detailRows?`<div class="chain-table-wrap"><table class="chain-admin-table" style="min-width:1050px"><thead><tr><th>Datenbestand</th><th>Browser / lokaler Cache</th><th>Supabase / DB</th><th>On-chain / API</th><th>Ladezeitpunkt / Auslöser</th></tr></thead><tbody>${detailRows}</tbody></table></div>`:`<div class="note">Für diesen Gruppeneintrag gibt es keine eigenen Daten. Wähle einen Tab oder Untertab.</div>`;
  modal.classList.add("open");modal.setAttribute("aria-hidden","false");document.body.classList.add("wt-modal-open");
}
function closeAdminSystemDetailModal(){const modal=document.getElementById("adminSystemDetailModal");if(!modal)return;modal.classList.remove("open");modal.setAttribute("aria-hidden","true");document.body.classList.remove("wt-modal-open");}
function selectAdminSystemRow(id){adminSystemSelectedId=id;const row=ADMIN_SYSTEM_TREE.find(x=>x.id===id);if(row)openAdminSystemDetailModal(row);}
window.renderAdminSystemOverview=renderAdminSystemOverview;
window.selectAdminSystemRow=selectAdminSystemRow;
window.closeAdminSystemDetailModal=closeAdminSystemDetailModal;
document.addEventListener("keydown",e=>{if(e.key==="Escape"&&document.getElementById("adminSystemDetailModal")?.classList.contains("open"))closeAdminSystemDetailModal();});


function renderAdminDocumentation(){
  const el=document.getElementById("adminDocumentation"); if(!el)return;
  el.innerHTML=`
  <div class="custom-token-card"><h3 style="margin-top:0">Cache-/Request-Audit · Phase 5.80</h3><div class="note"><p><strong>Aktiv:</strong> Der Admin-Systemtab misst im laufenden Browser-Tab Supabase-/RPC-/API-Requests mit Signatur, Filter/Scope, Aufrufer, Dauer und Status. Login, Tab-Wechsel und manuelle Refreshs werden als Marker erfasst.</p><p><strong>Abschlussmessung:</strong> TLN/VOW-Haupttab wurde von 143 auf 42 und danach auf ca. 16 Requests reduziert. DAO-Team sank im Warm-Run von ca. 130 auf 16 Requests; Bot-Claims → Referral-Rewards verursacht in derselben Session keine zusätzlichen History-Reads. Weitere Optimierungen erfolgen nur noch bei konkretem Messbeleg.</p><p><strong>Startoptimierung:</strong> Seitenreload startet kein <code>loadAll()</code> mehr. TLN/VOW lädt beim Projekt-Einstieg weder LP-Historie/Team/31.12.-Historie noch DEX-/Provider-Infrastruktur; Kurse/Pools initialisieren diese Preis-Infrastruktur erst beim eigenen Untertab. Discovery-Snapshots werden gebündelt und technische Cache-Reads innerhalb der Session wiederverwendet. NFT-Current-State wird sofort aus der zentralen Registry gezeigt.</p><p><strong>DAO:</strong> Bot-Claims und Referral-Rewards teilen sich denselben Session-History-Cache; Partner-Scan-State wird gebündelt gelesen und identische laufende Partner-Jobs werden dedupliziert. Der aktuelle NFT-/Bot-Bestand fremder Partner wird als öffentlicher abgeleiteter Chain-Cache 24 Stunden in IndexedDB wiederverwendet; historische DID-/Kaufpreislogik bleibt blockgenau getrennt.</p><p><strong>Regel:</strong> Current State (Wallet/NFT/Bot/aktuelle Positionen) bleibt von History (Kaufpreis, Lifecycle, historischer DID-Besitz) getrennt.</p><p><strong>Regression DAO:</strong> Monica 0x568281…fe4940 muss DAO1 #21044, APTMDAO #7803, 9 Mining-Bots und 1 Trading-Bot liefern.</p></div></div>
  <div class="custom-token-card"><h3 style="margin-top:0">1. Architekturregeln</h3><div class="note">
  <p><strong>Neuester Stand:</strong> Änderungen immer auf dem zuletzt ausgelieferten Stand aufbauen.</p>
  <p><strong>Supabase als Konfigurationsquelle:</strong> Chain-, Provider-, Projekt- und Token-Konfiguration möglichst datenbankgesteuert; keine neue fachliche Chain-Hardcodierung.</p>
  <p><strong>Cache ist versioniert:</strong> „Cache vorhanden“ bedeutet nicht „Cache fachlich aktuell“. Vor Tageslimit und Activity-Check wird die Datenversion geprüft.</p>
  <p><strong>Invalidieren statt blind löschen:</strong> Alte Daten bleiben als Fallback erhalten, bis ein notwendiger Neuaufbau erfolgreich abgeschlossen ist.</p></div></div>

  <div class="custom-token-card"><h3 style="margin-top:0">2. Ladeprozess</h3><div class="note">
  <p><strong>Start:</strong> Dashboard sofort anzeigen → vorhandene Current-State-Caches/Summaries lesen. Ein normaler Login/Reload startet seit Phase 5.75 keinen allgemeinen <code>loadAll()</code>-Hintergrundlauf mehr.</p><p><strong>Zentraler Grunddatenlauf:</strong> bleibt für gezielte Aktualisierung und den Erstaufbau neuer Wallets erhalten: pro Wallet sequentiell Wallet-/Tokenbestände → Projektpositionen inkl. LP/Staking → NFTs. Projekt-Detail-Discovery bleibt getrennt.</p>
  <p><strong>Automatisch:</strong> Eine neu gespeicherte Wallet startet ihren Grunddaten-Erstaufbau. Bestehende Wallets werden beim normalen Login nicht blind täglich aktualisiert; projektspezifische Tabs dürfen ihre eigene versionierte Freshness-Prüfung ausführen.</p>
  <p><strong>Manuell:</strong> jederzeit möglich; die Tagesbegrenzung gilt nur für automatische Läufe.</p>
  <p><strong>Entscheidungsreihenfolge:</strong> Datenversion prüfen → nötigen Neuaufbau erzwingen → Tagesstatus prüfen → Activity-Check → inkrementell aktualisieren.</p>
  <p><strong>Activity-Check:</strong> bei aktuellem Cache zuerst relevante Blockchain-Aktivität prüfen. Nur vom User bestätigter Spam darf ignoriert werden.</p>
  <p><strong>Leeres Ergebnis = erfolgreich:</strong> 0 NFTs, 0 LP-/Staking-Positionen, 0 Gebühren oder 0 relevante Aktivitäten dürfen niemals als „noch nie geprüft“ erscheinen, wenn der Prozess erfolgreich abgeschlossen wurde.</p>
  <p><strong>Entdecken / Gebühren:</strong> ausschließlich manuell. Projekt-Detail-Discovery bleibt projektbezogen; Dashboard-Grunddaten dürfen unabhängig vom Tab aus vorhandenen Caches bzw. dem zentralen Tageslauf nachgeführt werden.</p></div></div>

  <div class="custom-token-card"><h3 style="margin-top:0">3. Cache-/Scan-Versionierung</h3><div class="note">
  <p>Version nur erhöhen, wenn eine fachliche Änderung vorhandene Daten unvollständig/falsch macht. UI-/Layout-/Textänderungen benötigen keine neue Datenversion.</p>
  <p><strong>Discovery-Version:</strong> erhöhen, wenn bisher relevante Blockchain-Ereignisse gar nicht gefunden wurden → Nach-/Fullscan erforderlich.</p>
  <p><strong>Klassifikation:</strong> wenn Rohereignisse vorhanden sind, aber anders interpretiert werden müssen, soll langfristig nur neu klassifiziert werden.</p>
  <p><strong>Aktuell:</strong> Balances v${DATA_VERSIONS.balances}; NFTs v${DATA_VERSIONS.nft}; TLN/VOW BSC LP/Staking v${DATA_VERSIONS["project:tln_vow:bsc"]}; Scan-Typ <code>lp_history_v7_legacy_discovery</code>.</p></div></div>

  <div class="custom-token-card"><h3 style="margin-top:0">4. TLN/VOW LP & Staking</h3><div class="note">
  <p>Ein LP gehört zum Projekt, wenn mindestens eines seiner Underlyings ein TLN/VOW-Projekt-Token ist. Historische LPs dürfen nicht nur von heute aktiven <code>lp_token</code>-Adressen abhängen.</p>
  <p>BSC Legacy-Discovery: Wallet-ERC20-Historie → Contract-Kandidat → token0/token1 → Projektzugehörigkeit → LP-Identität → Staking-Klassifikation. <strong>Aktuelle getReserves()/totalSupply()-Reads sind keine Voraussetzung für historische Discovery</strong>; sie werden nur für die aktuelle Bewertung benötigt.</p>
  <p>Stake/Unstake nur gegen bestätigte Staking-Contracts; „Gegenadresse ist Smart Contract“ reicht nicht.</p>
  <p>LP/Staking zählt wirtschaftlich zur Token-Übersicht und zum 31.12.-Bestand. Nach Projekt-Refresh wird die Token-Übersicht neu berechnet.</p>
  <p>Historische LP-/Staking-Wallets bleiben auch bei aktuellem Bestand 0 sichtbar und im Walletfilter auswählbar.</p></div></div>

  <div class="custom-token-card"><h3 style="margin-top:0">5. Spam / Entdecken</h3><div class="note">
  <p>Das System erkennt nur <strong>Spamverdacht</strong>. Die endgültige Entscheidung <strong>Sicher</strong> oder <strong>Spam</strong> trifft der User.</p>
  <p>Nur bestätigter Spam wird standardmäßig ausgeblendet und darf beim Activity-Check ignoriert werden. Die Sammelaktion „Alle Spam-Verdachte als Spam markieren“ ist eine ausdrückliche Useraktion.</p></div></div>

  <div class="custom-token-card"><h3 style="margin-top:0">6. Release-/Fehlerbehebungsregel</h3><div class="note">
  <p>Bei jeder fachlichen Korrektur prüfen: betroffener Datenbereich, Re-Klassifikation vs. inkrementeller Nachscan vs. Fullscan, nötige <code>data_version</code>, nötiger neuer <code>scan_type</code>.</p>
  <p><strong>Dokumentation ist Definition of Done:</strong> Systemübersicht, Admin-Dokumentation, Ideen/TODO, Hilfe-/Erklärungstexte sowie technische Angaben zu Datenquellen, Caches, Jobs und Ladezeitpunkten bei jeder Änderung mitprüfen. README/Migrationsstatus aktualisieren, falls im gelieferten Projekt vorhanden; sichtbaren Versions-Timestamp auf tatsächliche Schweizer Zeit setzen; JS-Syntax, doppelte DOM-IDs und Regressionen prüfen.</p></div></div>

  <div class="custom-token-card"><h3 style="margin-top:0">7. Vorgesehene Architekturverbesserungen</h3><div class="note">
  <p><strong>Raw Events / Interpretation trennen:</strong> Blockchain-Rohdaten langfristig separat von Add/Remove/Send/Receive/Stake/Unstake halten, damit Klassifikationsfehler ohne Fullscan korrigiert werden können.</p>
  <p><strong>Admin-Neuaufbau:</strong> gezielte Wartungsaktion für einzelnes Wallet / alle Wallets eines Users und auswählbare Datenbereiche vorsehen.</p>
  <p><strong>ETH TLN/VOW Liquidity Pools:</strong> weiterhin offen; BSC ist aktuell funktional weiter ausgebaut.</p></div></div>`;
}


function coverageCell(enabled, provider, implementedProviders, notApplicable=false) {
  if (notApplicable) return `<span class="badge">— nicht vorgesehen</span>`;
  if (!enabled) return `<span class="badge danger">❌ deaktiviert</span>${provider ? `<div class="note">${escapeAttr(provider)}</div>` : ""}`;
  const ok = !!provider && implementedProviders.includes(provider);
  return `${ok ? '<span class="badge safe">✅ aktiv</span>' : '<span class="badge warn">⚠️ prüfen</span>'}<div class="note">${escapeAttr(provider || "kein Provider")}</div>`;
}

function renderAdminChainCoverage(){
  if(!isAdmin)return;
  const el=document.getElementById("adminChainCoverageList");
  if(!el)return;
  const balanceProviders=["rpc","evm_rpc","blockstream","mempool","xrpscan","solana_rpc","solana_publicnode","trongrid","akash_rest","apertum_explorer","blockscout"];
  const feeProviders=["routescan","nodereal","blockscout","xrpscan","solana_publicnode","apertum_explorer","mempool","tronscan"];
  const discoveryProviders=["alchemy","wallet_data"];
  const approvalProviders=["goplus","blockscout"];
  const nftProviders=["alchemy","blockscout"];
  const rows=Object.keys(CHAIN_CONFIG).sort((a,b)=>(CHAIN_CONFIG[a]?.sortOrder||100)-(CHAIN_CONFIG[b]?.sortOrder||100)).map(chain=>{
    const c=CHAIN_CONFIG[chain]||{}, meta=CHAIN_META[chain]||{};
    const wt=c.walletType||"";
    const approvalsNA=["btc","bitcoin","xrp","solana","tron","akash"].includes(wt);
    const nftNA=["btc","bitcoin","akash"].includes(wt);
    return `<tr>
      <td class="sticky-col-1"><strong>${escapeAttr(chain)}</strong></td>
      <td class="sticky-col-2">${escapeAttr(meta.label||chain)}</td>
      <td>${coverageCell(true,c.balanceProvider,balanceProviders)}</td>
      <td>${coverageCell(c.feesEnabled,c.feeProvider,feeProviders)}</td>
      <td>${coverageCell(c.discoveryEnabled,c.discoveryProvider,discoveryProviders,wt==="btc"||wt==="bitcoin")}</td>
      <td>${coverageCell(c.approvalsEnabled,c.approvalsProvider,approvalProviders,approvalsNA)}</td>
      <td>${coverageCell(c.nftEnabled,c.nftProvider,nftProviders,nftNA)}</td>
    </tr>`;
  }).join("");
  el.innerHTML=`<div class="chain-table-wrap"><table class="chain-admin-table" style="min-width:1150px"><thead><tr>
    <th class="sticky-col-1">Chain-Key</th><th class="sticky-col-2">Anzeigename</th><th>Bestände</th><th>Gebühren</th><th>Entdecken</th><th>Freigaben</th><th>NFTs</th>
  </tr></thead><tbody>${rows}</tbody></table></div>`;
}

function yearEndCoverageLabel(chain,c){const wt=c.walletType||"";if(wt==="evm")return "✓ exakt · historischer Block";if(wt==="btc")return "✓ exakt · UTXO-Stichtag";if(wt==="xrp")return "✓ XRP nativ · Full-History Ledger";if(wt==="sol")return "✓ SOL + SPL/Token-2022 · historischer Slot";if(wt==="tron")return "Noch nicht unterstützt";return "Noch nicht unterstützt";}
function renderHelpChainCoverage(){const el=document.getElementById("helpChainCoverage");if(!el)return;const balanceProviders=["rpc","evm_rpc","blockstream","mempool","xrpscan","solana_rpc","solana_publicnode","trongrid","akash_rest","apertum_explorer","blockscout"],feeProviders=["routescan","nodereal","blockscout","xrpscan","solana_publicnode","apertum_explorer","mempool","tronscan"];const rows=Object.keys(CHAIN_CONFIG).sort((a,b)=>(CHAIN_CONFIG[a]?.sortOrder||100)-(CHAIN_CONFIG[b]?.sortOrder||100)).map(chain=>{const c=CHAIN_CONFIG[chain]||{},m=CHAIN_META[chain]||{};return `<tr><td><strong>${escapeAttr(m.label||chain)}</strong></td><td>${coverageCell(true,c.balanceProvider,balanceProviders)}</td><td>${coverageCell(c.feesEnabled,c.feeProvider,feeProviders)}</td><td>${escapeAttr(yearEndCoverageLabel(chain,c))}</td></tr>`}).join("");el.innerHTML=`<div class="chain-table-wrap help-chain-coverage-wrap"><table class="chain-admin-table help-chain-coverage-table"><thead><tr><th>Chain</th><th>Aktueller Bestand</th><th>Gebühren</th><th>Bestand per 31.12.</th></tr></thead><tbody>${rows}</tbody></table></div>`;}
function switchProjectSubtab(project,name,button){document.querySelectorAll(`#tab-${project} .project-subtab-panel`).forEach(x=>x.style.display="none");const p=document.getElementById(`${project}-subtab-${name}`);if(p)p.style.display="block";document.querySelectorAll(`#tab-${project} .project-subtabs .tab-btn`).forEach(x=>x.classList.remove("active"));button?.classList.add("active");}

function openTlnDiscoveryTab(panel,button){
  switchProjectSubtab('tlnvow','discovery',button);
  const api=window.TLNVOWDiscovery;
  if(api?.switchProjectUserTab)api.switchProjectUserTab(panel||'overview');
}
window.openTlnDiscoveryTab=openTlnDiscoveryTab;
function openTlnPoolsTab(button){
  switchProjectSubtab('tlnvow','overview',button);
  Promise.resolve(window.TLNVOWProject?.ensureLoaded?.()).catch(e=>console.warn('TLN/VOW Kurse/Pools:',e));
}
window.openTlnPoolsTab=openTlnPoolsTab;

function adminSimpleInput(value,key,type="text",extra=""){
  if(type==="checkbox") return `<input data-field="${key}" type="checkbox" ${value!==false?"checked":""}>`;
  return `<input data-field="${key}" type="${type}" value="${escapeAttr(value??"")}" ${extra}>`;
}
function adminSelect(value,key,options){
  return `<select data-field="${key}">${options.map(([v,l])=>`<option value="${escapeAttr(v)}" ${String(value??"")===v?"selected":""}>${escapeAttr(l)}</option>`).join("")}</select>`;
}
function readAdminRow(root,fields){
  const out={};
  fields.forEach(([k,type])=>{
    const el=root.querySelector(`[data-field="${k}"]`);
    if(!el)return;
    if(type==="checkbox")out[k]=el.checked;
    else if(type==="number")out[k]=el.value===""?null:Number(el.value);
    else out[k]=el.value.trim()||null;
  });
  return out;
}

async function loadAdminDefiProjects(){
  if(!isAdmin)return;
  await loadDefiProjectsCache();
  const [{data:projects,error:pErr},{data:tokens,error:tErr}]=await Promise.all([
    sb.from("defi_projects").select("*").order("sort_order",{ascending:true}),
    sb.from("defi_project_tokens").select("*").order("project_key").order("chain_key")
  ]);
  const pEl=document.getElementById("adminDefiProjectsList");
  const tEl=document.getElementById("adminDefiProjectTokensList");
  if(pErr){pEl.innerHTML=`<div class="error">${escapeAttr(pErr.message)}</div>`;return;}
  if(tErr){tEl.innerHTML=`<div class="error">${escapeAttr(tErr.message)}</div>`;return;}

  pEl.innerHTML=`<div class="chain-table-wrap"><table class="chain-admin-table" style="min-width:900px"><thead><tr>
    <th>Projekt-Key</th><th>Name</th><th>Beschreibung</th><th>Sortierung</th><th>Aktiv</th><th>Aktion</th>
  </tr></thead><tbody>${(projects||[]).map(p=>`<tr data-defi-project="${escapeAttr(p.project_key)}">
    <td>${adminSimpleInput(p.project_key,"project_key","text","disabled")}</td>
    <td>${adminSimpleInput(p.name,"name")}</td>
    <td>${adminSimpleInput(p.description,"description")}</td>
    <td>${adminSimpleInput(p.sort_order,"sort_order","number")}</td>
    <td>${adminSimpleInput(p.enabled,"enabled","checkbox")}</td>
    <td><button onclick="saveDefiProject('${escapeAttr(p.project_key)}')">💾</button> <button class="remove" onclick="deleteDefiProject('${escapeAttr(p.project_key)}')">Löschen</button></td>
  </tr>`).join("")}</tbody></table></div>`;

  const projectOpts=(projects||[]).map(p=>[p.project_key,p.name]);
  const chainOpts=Object.keys(CHAIN_META).map(c=>[c,CHAIN_META[c].label]);
  tEl.innerHTML=`<div class="chain-table-wrap"><table class="chain-admin-table" style="min-width:1200px"><thead><tr>
    <th>Projekt</th><th>Chain</th><th>Rolle</th><th>Symbol</th><th>Contract</th><th>Aktiv</th><th>Aktion</th>
  </tr></thead><tbody>${(tokens||[]).map(t=>`<tr data-defi-token="${t.id}">
    <td>${adminSelect(t.project_key,"project_key",projectOpts)}</td>
    <td>${adminSelect(t.chain_key,"chain_key",chainOpts)}</td>
    <td>${adminSimpleInput(t.role,"role")}</td>
    <td>${adminSimpleInput(t.symbol,"symbol")}</td>
    <td>${adminSimpleInput(t.contract_address,"contract_address")}</td>
    <td>${adminSimpleInput(t.enabled,"enabled","checkbox")}</td>
    <td><button onclick="saveDefiProjectToken('${t.id}')">💾</button> <button class="remove" onclick="deleteDefiProjectToken('${t.id}')">Löschen</button></td>
  </tr>`).join("")}</tbody></table></div>`;
}
function addDefiProjectRow(){
  const key=prompt("Projekt-Key (z.B. projekt_xyz):");
  if(!key)return;
  const name=prompt("Anzeigename:",key)||key;
  sb.from("defi_projects").insert({project_key:key.trim().toLowerCase(),name,enabled:true,sort_order:100}).then(({error})=>{
    if(error)alert(error.message);else loadAdminDefiProjects();
  });
}
async function saveDefiProject(key){
  const root=document.querySelector(`[data-defi-project="${CSS.escape(key)}"]`);
  const row=readAdminRow(root,[["name","text"],["description","text"],["sort_order","number"],["enabled","checkbox"]]);
  const {error}=await sb.from("defi_projects").update(row).eq("project_key",key);
  if(error)alert(error.message);else{await loadDefiProjectsCache();await loadAdminDefiProjects();renderSafeTokenTable();}
}
async function deleteDefiProject(key){
  if(!confirm(`Projekt "${key}" inkl. Projekt-Referenzen wirklich löschen?`))return;
  const {error}=await sb.from("defi_projects").delete().eq("project_key",key);
  if(error)alert(error.message);else loadAdminDefiProjects();
}
async function addDefiProjectTokenRow(){
  await loadDefiProjectsCache();
  if(!defiProjectsCache.length){alert("Bitte zuerst ein DeFi-Projekt anlegen.");return;}
  const project_key=defiProjectsCache[0].project_key;
  const chain_key=Object.keys(CHAIN_META)[0];
  const {error}=await sb.from("defi_project_tokens").insert({project_key,chain_key,role:"reference",symbol:"",contract_address:"",enabled:true});
  if(error)alert(error.message);else loadAdminDefiProjects();
}
async function saveDefiProjectToken(id){
  const root=document.querySelector(`[data-defi-token="${CSS.escape(String(id))}"]`);
  const row=readAdminRow(root,[["project_key","text"],["chain_key","text"],["role","text"],["symbol","text"],["contract_address","text"],["enabled","checkbox"]]);
  const {error}=await sb.from("defi_project_tokens").update(row).eq("id",id);
  if(error)alert(error.message);else loadAdminDefiProjects();
}
async function deleteDefiProjectToken(id){
  if(!confirm("Projekt-Token/Referenz löschen?"))return;
  const {error}=await sb.from("defi_project_tokens").delete().eq("id",id);
  if(error)alert(error.message);else loadAdminDefiProjects();
}

async function loadAdminDexConfigs(){
  if(!isAdmin)return;
  const {data,error}=await sb.from("dex_configs").select("*").order("chain_key").order("dex_key");
  const el=document.getElementById("adminDexConfigsList");
  if(error){el.innerHTML=`<div class="error">${escapeAttr(error.message)}</div>`;return;}
  const chainOpts=Object.keys(CHAIN_META).map(c=>[c,CHAIN_META[c].label]);
  el.innerHTML=`<div class="chain-table-wrap"><table class="chain-admin-table" style="min-width:1500px"><thead><tr>
    <th>Chain</th><th>DEX-Key</th><th>Name</th><th>Protokoll</th><th>Version</th><th>Factory</th><th>Router optional</th><th>Aktiv</th><th>Aktion</th>
  </tr></thead><tbody>${(data||[]).map(d=>`<tr data-dex="${d.id}">
    <td>${adminSelect(d.chain_key,"chain_key",chainOpts)}</td>
    <td>${adminSimpleInput(d.dex_key,"dex_key")}</td>
    <td>${adminSimpleInput(d.name,"name")}</td>
    <td>${adminSimpleInput(d.protocol,"protocol")}</td>
    <td>${adminSelect(d.version,"version",[["v2","V2"],["v3","V3"]])}</td>
    <td>${adminSimpleInput(d.factory_address,"factory_address")}</td>
    <td>${adminSimpleInput(d.router_address,"router_address")}</td>
    <td>${adminSimpleInput(d.enabled,"enabled","checkbox")}</td>
    <td><button onclick="saveDexConfig('${d.id}')">💾</button> <button class="remove" onclick="deleteDexConfig('${d.id}')">Löschen</button></td>
  </tr>`).join("")}</tbody></table></div>`;
}
async function addDexConfigRow(){
  const chain_key=Object.keys(CHAIN_META)[0];
  const {error}=await sb.from("dex_configs").insert({chain_key,dex_key:"new_dex",name:"Neue DEX",protocol:"",version:"v2",factory_address:"",enabled:true});
  if(error)alert(error.message);else loadAdminDexConfigs();
}
async function saveDexConfig(id){
  const root=document.querySelector(`[data-dex="${CSS.escape(String(id))}"]`);
  const row=readAdminRow(root,[["chain_key","text"],["dex_key","text"],["name","text"],["protocol","text"],["version","text"],["factory_address","text"],["router_address","text"],["enabled","checkbox"]]);
  const {error}=await sb.from("dex_configs").update(row).eq("id",id);
  if(error)alert(error.message);else loadAdminDexConfigs();
}
async function deleteDexConfig(id){
  if(!confirm("DEX-Konfiguration löschen?"))return;
  const {error}=await sb.from("dex_configs").delete().eq("id",id);
  if(error)alert(error.message);else loadAdminDexConfigs();
}


const HARDCODING_AUDIT_ITEMS = [
  {severity:"open", area:"Routescan", item:"fee_api_base Fallback", detail:"Routescan darf keine Chain-URL mehr selbst konstruieren. Fehlende fee_api_base soll als Konfigurationsfehler sichtbar werden."},
  {severity:"open", area:"Tron", item:"TRC20 Decimals", detail:"TRON_TOKEN_DECIMALS_DEFAULT=6 ist chain-/token-spezifischer Fallback. Decimals sollen aus predefined_tokens bzw. Token-Metadaten kommen."},
  {severity:"review", area:"Wallet-Maske", item:"EVM-Chain-Hinweis", detail:"Der sichtbare Hilfetext nennt Ethereum/BSC/Polygon/Arbitrum/Base/Avalanche/Apertum statisch. Darstellung sollte aus wallet_type=evm generiert werden."},
  {severity:"review", area:"Eigene sichere Token", item:"Chain-Auswahl", detail:"Die Auswahl enthält noch feste Chain-Optionen. Sie sollte aus public.chains erzeugt werden."},
  {severity:"review", area:"DeFi-Projekt UI", item:"Projektmodule", detail:"DAO1 und TLN/VOW besitzen jetzt eigene Unter-Tabs inklusive projektspezifischer Hilfe. Daten bleiben generisch in Supabase; die Modulnamen DAO1Project/TLNVOWProject sind bewusst projektspezifische Implementierung und können bei weiteren Projekten in ein gemeinsames Framework überführt werden."},
  {severity:"keep", area:"Liquidity Pools", item:"Generischer DB-Cache", detail:"lp_history_events speichert unveränderliche Add-/Remove-Historie projekt- und chainübergreifend; project_scan_state hält den inkrementellen Wallet-Scanstand. Seit Phase 2am speichert lp_position_cache zusätzlich den bewusst aktualisierten Positions-, Underlying-, Pool-Anteil-, USD- und 31.12.-Stand. Projekt-Tabs lesen grundsätzlich den Cache; höchstens 1x täglich pro Wallet kann beim Öffnen ein automatischer Projekt-Refresh erfolgen."},
  {severity:"keep", area:"Services", item:"Globale API-/App-URLs", detail:"CoinGecko, GeckoTerminal, GoPlus, Supabase-App-URL, CDN, revoke.cash und IPFS sind globale Services und keine Chain-Stammdaten."},
  {severity:"keep", area:"Credentials", item:"Frontend-Keys", detail:"Alchemy/PublicNode/NodeReal nicht in public.chains verschieben. Später separat über Proxy/Secret-Strategie lösen."}
];

const LIFECYCLE_ARCH_AUDIT_ITEMS = [
  {priority:"P1", workStatus:"erledigt", severity:"critical", area:"DAO1 Lifecycle-Abschluss", finding:"Teilpfade konnten intern partial/leer bleiben, während der übergeordnete Wallet-Job trotzdem als vollständig aufgebaut erschien.", action:"Phase 6.02: Einheitlicher Statusvertrag complete / partial / failed / deferred ist in DAO1 eingeführt und wird bis zum zentralen Wallet-Abschlussstatus propagiert; apertureHandled ist davon getrennt."},
  {priority:"P2", workStatus:"erledigt", severity:"high", area:"Snapshot-Gate", finding:"Snapshots dürfen fachlich erst entstehen, wenn alle dafür erforderlichen Teiljobs vollständig sind.", action:"Phase 6.03: Automatischer Fresh-Build-Snapshot ist an den Lifecycle-Statusvertrag gekoppelt; nur complete ist zugelassen, partial/deferred/failed blockieren den finalen Snapshot und werden im Snapshot-Gate protokolliert."},
  {priority:"P3", workStatus:"erledigt", severity:"critical", area:"Fresh-Build-Parität", finding:"6.11-Realtest: Fresh-Build reproduziert den bekannten Entwicklungs-Testuser einschließlich Ownership/Erwerbsdaten und historischer Kaufpreise. Kontrollfall #38483 findet wieder exakt 10’000 wUSDT in Tx 0x31cd…1de2; weitere bekannte Preise (u. a. #31722, #90227, #90289, #37174) sind deckungsgleich. Bewusst nicht deterministisch verknüpfbare Käufe bleiben offen statt geraten zu werden.", action:"Phase 6.12 schließt P3 ab und macht den finalen Resolver-v3-Stand cache-first: auch bewusst offene Ergebnisse werden mit ihrer Erwerbs-Evidenz persistiert und beim ersten NFT-Tab-Öffnen nicht nochmals neu gerechnet, solange sich die zugrunde liegende Ownership-/Erwerbs-Evidenz nicht geändert hat."},
  {priority:"P4", workStatus:"erledigt", severity:"high", area:"Performance Fresh-Import", finding:"6.18-Realtest bestätigt die Konsolidierung: Wallet-Erstimport 25'783 ms, DAO1 16'788 ms. Asset-Flows 1'056 ms, Claims 2'241 ms, Transactions 3'354 ms, NFT-Ownership 8'135 ms. Gegenüber dem 6.11-Stand mit rund 17 Minuten wurde der blockierende Fresh-Build um rund 97,5 % reduziert; weitere Ownership-Mikrooptimierungen sind aktuell nicht verhältnismässig.", action:"P4 abgeschlossen. 6.18 bleibt Referenz: Owner-/Collections-Endpoint parallel, Asset-Flow-Fresh-Build ohne Vollbewertung, Claim-Patches im Batch. Weitere Optimierung nur bei neu gemessenem Hotspot."},
  {priority:"P5", workStatus:"erledigt", severity:"critical", area:"DAO1 Claims / Payouts", finding:"Die früher überlappenden Claim-/Payout-Modelle sind konsolidiert. Asset, Menge und historischer USD-Wert werden kanonisch in project_transaction_asset_flows geführt; project_nft_claims bleibt Claim↔NFT/Evidenz, project_transactions Transaktions-/Klassifikationsbasis. Legacy reward_aptm/USD sind keine aktive sichtbare Quelle mehr.", action:"P5 abgeschlossen. Realtests: 263 eindeutige native APTM-Flows / 263 TX / 1’829.869891 APTM; nach 6.28 sind alle Post-Launch-Claimpreise bewertet (6/6 nachgezogen, missing=0). Vier Claims vor dem globalen On-Chain-Marktstart Block 88356 bleiben korrekt als Prelaunch ohne erfundenen USD-Wert. Weitere Änderungen nur bei Regression."},
  {priority:"P6", workStatus:"erledigt", severity:"high", area:"NFT / Bot Current State", finding:"6.30-Realtest: zentrale und DAO1-lokale Read-Sichten sind vollständig deckungsgleich: 19/19 aktuelle NFTs, 36/36 Ownership-Zeilen, keine onlyLocal/onlyCentral-Abweichung, Status complete. Der unabhängige Claim-Lifecycle-Blocker ist ebenfalls behoben.", action:"P6 abgeschlossen. Persistente Wahrheit bleibt nft_cache + project_nft_ownership; DAO1-Sessiondaten sind abgeleitete Runtime-Sicht. Read-Model-Audit bleibt als Regressiondiagnose bestehen."},
  {priority:"P7", workStatus:"erledigt", severity:"high", area:"Wallet-ID Lifecycle", finding:"P7-Codeaudit 6.31 fand mehrere DB-Grenzen mit dbId||id-Fallback. Der Fresh-Wallet-Realtest bestätigte danach ausschließlich persistierte UUIDs in wallet_id-Requests, keine 400/422/22P02-Fehler und lifecycleStatus complete bei leerer failures-Liste.", action:"Phase 6.31/6.32: DB-wallet_id akzeptiert nur w.dbId im UUID-Format; lokale Client-ID bleibt UI/Runtime. NFT-/Discovery-Schreibpfade, Dashboard-LP, 31.12.-Delete und DAO1-Walletauflösung sind UUID-strikt. P7 = erledigt."},
  {priority:"P8", workStatus:"erledigt", severity:"medium", area:"Fehlerbehandlung", finding:"Der 6.34-Realtest bestätigt die zentrale Auth-Fehlergrenze: nach manuellem Entfernen des Supabase-Auth-Tokens wird Session-Verlust erkannt, Cache-Daten bleiben sichtbar, Re-Login wird gefordert und private DAO1-/Edge-Requests werden vor dem Request blockiert; keine 401-Kaskade mehr.", action:"Phase 6.36 schließt P8 nach Rest-Catch-Audit ab. Leere Catches wurden kontextbezogen geprüft: optionale Parser-/Storage-/Metadata-Fallbacks bleiben bewusst tolerant; fachlich relevante Async-Pfade nutzen den zentralen optional/retryable/partial/fatal-Statusvertrag. Keine pauschale Log-Eskalation, da dies optionale Fallbacks verfälschen würde."},
  {priority:"P9", workStatus:"erledigt", severity:"medium", area:"Cache-Ownership / Invalidierung", finding:"Phase 6.36/6.37: Ownership- und Invalidierungs-Audit abgeschlossen. Browser-/IndexedDB-Graphen werden über DATA_VERSIONS, Payload-/Storage-Schema und Root-Scope gegated; private Refresh-States prüfen data_version vor Tageslimit; Partial-Lifecycle darf einen verifizierten TLN-Team-Lifecycle nicht degradieren. Konkrete Restlücke: block-versionierte TLN/VOW-Staking-/Technical-Caches konnten von einem älteren offenen Browser-Tab mit kleinerem last_scanned_block zurückgeschrieben werden.", action:"Phase 6.37 schließt die belegte Lücke: vor Writes block-versionierter Staking-/Technical-Caches wird der persistente Blockstand geprüft; ein kleinerer lokaler Block darf einen neueren DB-Stand nicht ersetzen. lastBlock=0 bleibt bewusst unversioniert. Scanner-/DATA_VERSION-Wechsel erzwingen weiterhin fachlichen Neuaufbau. P9 = erledigt; kein pauschaler Cache-Refactor nötig."},
  {priority:"P10", workStatus:"in Arbeit", severity:"high", area:"Security / Supabase / RLS / Data API", finding:"DB-/Codeaudit: alle WalletTracking-public-Tabellen haben RLS; private Userdaten sind über auth.uid() getrennt, no_plain_wallet-Policies sind RESTRICTIVE. Kein bestätigter anon- oder Cross-User-Zugriff auf private Walletdaten. Shared DAO/APTMDAO-/TLN-/Preis-Caches werden bewusst vom authentifizierten Browser beschrieben; manipulierter Client könnte globale Ableitungen verfälschen.", action:"Shared-Cache-Write-Architektur derzeit bewusst nicht umbauen: Regressionsrisiko ist höher als das aktuell nachgewiesene Integritätsrisiko; als akzeptiertes Restrisiko dokumentiert. RPC-Hardening 6.39: direkte EXECUTE-Rechte für anon/authenticated auf vier reine Triggerfunktionen und wallettracking_cleanup_price_refresh_slots entzogen; produktiv bereits ausgeführt und in SQL 074 nachgeführt. Offen vor P10-Abschluss: gezielter Cross-User-Negativtest (Testkonten werden noch vorbereitet) und Restprüfung der RPC-/Admin-Grenzen. 6.39-Regression: DAO/APTMDAO-Tree und Chat-RPC PASS. TLN-Team-Realtest zeigte bei neu importiertem bekanntem TLN-Wallet auch nach Hard-Refresh keinen Baum. 6.41 ergänzte einen Slice-MISS-Trigger, 6.42 korrigierte dessen Script-Cache-Buster, 6.43 beseitigte die Init-Race-Condition. Realtest 6.43 erreichte Step 7 tatsächlich, löste bei fehlendem verifiziertem Globalgraph jedoch den historischen Full-Cold-Fallback ab Block 0 aus und lag bereits bei >3500 Requests ohne Abschluss. Korrektur 6.44: normaler Team-Tab darf bei Slice-MISS keinen Full-History-Scan mehr starten; eigene Roots werden vor dem DB-Slice auf verifizierte TLN-IDs reduziert. Realtest 6.44 zeigte dennoch >1400 einzelne eth_getTransactionByHash-Requests. Ursache: nach einem erfolgreichen Cache-Restore wurden offene Partner-Lifecycles automatisch über teamVerifyMissingLifecycles nachverifiziert. Korrektur 6.45: automatische Lifecycle-Rekonstruktion entfernt. Realtest 6.45 zeigte trotzdem >1000 eth_getTransactionByHash-Aufrufe. Ursache: fehlender Zusatzregistry-Graph-Cache startete im Restore noch teamRestoreAdditionalRegistryGraph() mit kompletter History. Korrektur 6.46: normaler Restore ist auch fuer Zusatzregistries strikt cache-only; weder History-Aufbau noch Evidence-Tx-Parent-Hydrierung laufen automatisch, beides nur noch explizit Step 7. Cross-User-Negativtest bleibt vorbereitet/offen."},
  {priority:"P11", workStatus:"offen", severity:"high", area:"Wallet-/Datenlöschung End-to-End", finding:"Nach P10 folgt der reale End-to-End-Regressionsaudit für Einzelwallet- und vollständige Userdaten-Löschung einschließlich Snapshots, 31.12., NFTs, Claims/Rewards, Caches und Alias-Provenienz.", action:"Erst nach Abschluss P10 starten; bestehende produktive Delete-RPCs nicht vorzeitig umbauen."},
  {priority:"P12", workStatus:"offen", severity:"medium", area:"Admin-/Berechtigungsmodell", finding:"Admin-Erkennung verwendet teilweise weiterhin E-Mail-Zuordnung; Google-Login/Account-Linking ist separat geplant.", action:"Admin-Berechtigung langfristig an stabile User-UUID koppeln und bestehende Admin-UUID beim kontrollierten Google-Linking erhalten."},
  {priority:"P13", workStatus:"offen", severity:"medium", area:"Data-API / Schema-Trennung", finding:"Viele Browser-Tabellen liegen historisch in public; neue interne Job-/Admin-/Backend-Tabellen sollen nicht automatisch exponiert werden.", action:"Neue Tabellen vor Anlage als Browser/API oder intern klassifizieren; exponierte Tabellen mit expliziten GRANTs/RLS, interne Tabellen möglichst in nicht exponiertem Schema."},
  {priority:"P14", workStatus:"offen", severity:"medium", area:"Secrets / Provider-Grenzen", finding:"Frontend-Providerkeys und verbleibende direkte Providerzugriffe sind bekannte Hardening-Themen, aber kein Befund dieses P10-RLS-Audits.", action:"Später getrennt prüfen; keine Credentials in public.chains verschieben."},
  {priority:"P15", workStatus:"offen", severity:"medium", area:"Abschluss-Regressionsaudit", finding:"Nach P10–P14 fehlt ein kompakter Gesamt-Regressionstest der Sicherheits-, Lifecycle- und Fresh-Build-Grenzen.", action:"Zum Abschluss definierte Realtests erneut ausführen und Auditstatus dokumentieren."},
  {priority:"—", workStatus:"beobachten", severity:"good", area:"Komplette Userdaten-Löschung", finding:"Transaktionale DB-Löschung plus Abschlussprüfung ist architektonisch robust aufgebaut.", action:"Beibehalten; nur Regressionstests und Scope-Dokumentation ergänzen."},
  {priority:"—", workStatus:"beobachten", severity:"good", area:"Projekttrennung", finding:"TLN/VOW und DAO1/APTM sind fachlich getrennte Projektmodule mit gemeinsamer Infrastruktur.", action:"Beibehalten; gemeinsame Infrastruktur konsolidieren, ohne projektspezifische Fachlogik zu vermischen."}
];
function lifecycleAuditBadge(i){
  if(i.severity==="critical")return '<span class="badge unsafe">kritisch</span>';
  if(i.severity==="high")return '<span class="badge" style="background:rgba(220,80,50,.15);color:#dc5032">hoch</span>';
  if(i.severity==="medium")return '<span class="badge" style="background:rgba(240,185,11,.15);color:#f0b90b">mittel</span>';
  return '<span class="badge safe">stabil</span>';
}
function lifecycleWorkStatusBadge(i){
  if(i.workStatus==="in Arbeit")return '<span class="badge" style="background:rgba(70,130,220,.15);color:#4682dc">in Arbeit</span>';
  if(i.workStatus==="erledigt")return '<span class="badge safe">erledigt</span>';
  if(i.workStatus==="beobachten")return '<span class="badge" style="background:rgba(120,120,120,.14);color:var(--muted)">beobachten</span>';
  return '<span class="badge unsafe">offen</span>';
}
function renderHardcodingAudit(){
  const el=document.getElementById("adminHardcodingAudit");
  if(!el || !isAdmin)return;
  const badge=i=>i.severity==="open"
    ? '<span class="badge unsafe">offen</span>'
    : i.severity==="review"
      ? '<span class="badge" style="background:rgba(240,185,11,.15);color:#f0b90b">prüfen</span>'
      : '<span class="badge safe">bewusst belassen</span>';
  const lifecycleRows=LIFECYCLE_ARCH_AUDIT_ITEMS.map(i=>`<tr><td><strong>${escapeAttr(i.priority)}</strong></td><td>${lifecycleWorkStatusBadge(i)}</td><td>${lifecycleAuditBadge(i)}</td><td>${escapeAttr(i.area)}</td><td>${escapeAttr(i.finding)}</td><td>${escapeAttr(i.action)}</td></tr>`).join("");
  const hardcodingRows=HARDCODING_AUDIT_ITEMS.map(i=>`<tr><td>${badge(i)}</td><td>${escapeAttr(i.area)}</td><td>${escapeAttr(i.item)}</td><td>${escapeAttr(i.detail)}</td></tr>`).join("");
  el.innerHTML=`
    <div class="custom-token-card" style="margin-bottom:16px">
      <h3 style="margin-top:0">Lifecycle-/Architektur-Audit · Phase 6.39</h3>
      <div class="note" style="margin-bottom:10px"><strong>Entscheidung:</strong> Kein Rewrite. Feature-Freeze für neue große Funktionen, bis die offenen Lifecycle-Punkte konsolidiert sind. <strong>Steuerungsregel:</strong> Die Tabelle ist die führende Quelle. Bearbeitet wird jeweils die höchste offene Arbeitspriorität P1–P15. <strong>Arbeitspriorität</strong> bestimmt die Reihenfolge; <strong>Risiko</strong> beschreibt unabhängig davon die fachliche/technische Auswirkung. Abgeschlossene Punkte auf „erledigt“ setzen; stabile Punkte ohne Umbau bleiben auf „beobachten“.</div>
      <div class="chain-table-wrap"><table class="chain-admin-table" style="min-width:1450px"><thead><tr><th>Prio</th><th>Arbeitsstatus</th><th>Risiko</th><th>Bereich</th><th>Audit-Befund</th><th>Ziel / nächster Schritt</th></tr></thead><tbody>${lifecycleRows}</tbody></table></div>
    </div>
    <div class="custom-token-card">
      <h3 style="margin-top:0">Hardcoding-Rest-Audit</h3>
      <div class="note" style="margin-bottom:10px">Chain-/Provider-/Projekt-Konfiguration soll möglichst datenbankgesteuert bleiben. Bewusst globale Service-Konfigurationen sind kein automatischer Fehler.</div>
      <div class="chain-table-wrap"><table class="chain-admin-table" style="min-width:1100px"><thead><tr><th>Status</th><th>Bereich</th><th>Fund</th><th>Bewertung / nächster Schritt</th></tr></thead><tbody>${hardcodingRows}</tbody></table></div>
    </div>`;
}

const ADMIN_CHAIN_FIELDS = [
  {k:"chain_key", l:"Chain-Key", critical:true, type:"text", sticky:1},
  {k:"label", l:"Anzeigename", type:"text", sticky:2},
  {k:"native_symbol", l:"Natives Symbol", type:"text", sticky:3},
  {k:"coingecko_id", l:"CoinGecko-ID", type:"text"},
  {k:"wallet_type", l:"Wallet-Typ", critical:true, type:"select", options:["evm","btc","xrp","sol","tron","akash"]},
  {k:"evm_chain_id", l:"EVM Chain-ID", critical:true, type:"number"},
  {k:"explorer_url_template", l:"Explorer-URL ({address})", critical:true, type:"text", cls:"xwide-input"},
  {k:"geckoterminal_network", l:"GeckoTerminal Network", type:"text"},
  {k:"display_color", l:"Anzeigefarbe", critical:false, type:"color"},
  {k:"icon_path", l:"Chain-Logo (Pfad)", critical:false, type:"text", cls:"xwide-input"},
  {k:"rpc_url", l:"RPC-/REST-Endpunkt", critical:true, type:"text", cls:"xwide-input"},
  {k:"archive_rpc_provider", l:"Historie-Provider", critical:false, type:"text"},
  {k:"archive_rpc_url", l:"Historie-/Archive-RPC", critical:false, type:"text", cls:"xwide-input"},
  {k:"balance_provider", l:"Balance-Provider", critical:true, type:"text"},
  {k:"balance_api_base", l:"Balance API-Basis", critical:true, type:"text", cls:"xwide-input"},
  {k:"fees_enabled", l:"Gebühren aktiv", critical:true, type:"checkbox"},
  {k:"discovery_enabled", l:"Discovery aktiv", critical:false, type:"checkbox"},
  {k:"approvals_enabled", l:"Freigaben aktiv", critical:false, type:"checkbox"},
  {k:"nft_enabled", l:"NFT aktiv", critical:false, type:"checkbox"},
  {k:"discovery_provider", l:"Discovery-Provider", critical:true, type:"text"},
  {k:"discovery_api_base", l:"Discovery API-Basis", critical:true, type:"text", cls:"xwide-input"},
  {k:"approvals_provider", l:"Freigaben-Provider", critical:true, type:"text"},
  {k:"approvals_api_base", l:"Freigaben API-Basis", critical:true, type:"text", cls:"xwide-input"},
  {k:"nft_provider", l:"NFT-Provider", critical:true, type:"text"},
  {k:"nft_api_base", l:"NFT API-Basis", critical:true, type:"text", cls:"xwide-input"},
  {k:"fee_provider", l:"Gebühren-Provider", critical:true, type:"text"},
  {k:"fee_api_base", l:"Gebühren API-Basis", critical:true, type:"text", cls:"xwide-input"},
  {k:"fee_finality_blocks", l:"Fee Finality", critical:true, type:"number"},
  {k:"fee_overlap_blocks", l:"Fee Overlap", critical:true, type:"number"},
  {k:"sort_order", l:"Sortierung", type:"number"},
  {k:"enabled", l:"Aktiv", critical:true, type:"checkbox"}
];

function chainStickyClass(field) {
  return field.sticky ? ` sticky-col-${field.sticky}` : "";
}

function chainCellControl(field, row, isNew=false) {
  const val = row?.[field.k];
  const disabled = (!isNew && field.k === "chain_key") ? "disabled" : "";
  if (field.type === "checkbox") {
    return `<input data-chain-field="${field.k}" type="checkbox" ${val !== false ? "checked" : ""}>`;
  }
  if (field.type === "select") {
    return `<select data-chain-field="${field.k}" ${disabled}>${field.options.map(o =>
      `<option value="${escapeAttr(o)}" ${String(val||"")===o?"selected":""}>${escapeAttr(o)}</option>`).join("")}</select>`;
  }
  const colorStyle = field.type === "color" ? 'style="min-width:54px;width:54px;height:34px;padding:2px"' : "";
  return `<input data-chain-field="${field.k}" class="${field.cls||""}" type="${field.type}" value="${escapeAttr(val ?? (field.type==="color" ? "#6b7280" : ""))}" ${colorStyle} ${disabled}>`;
}

function chainTableHeader() {
  return `<thead><tr>${ADMIN_CHAIN_FIELDS.map(f =>
    `<th class="${f.critical?"critical-cell ":""}${chainStickyClass(f)}">${escapeAttr(f.l)}${f.critical?' ⚠':''}</th>`
  ).join("")}<th>Aktion</th></tr></thead>`;
}

function chainTableRow(row={}, isNew=false) {
  const id = isNew ? "new" : String(row.chain_key);
  return `<tr data-chain-editor="${escapeAttr(id)}">
    ${ADMIN_CHAIN_FIELDS.map(f => `<td class="${f.critical?"critical-cell ":""}${chainStickyClass(f)}">${chainCellControl(f,row,isNew)}</td>`).join("")}
    <td><div class="chain-admin-save">
      <button onclick="saveAdminChain('${escapeAttr(id)}', ${isNew})">💾 Speichern</button>
      ${isNew?'<button class="secondary" onclick="closeNewChainEditor()">✕</button>':""}
    </div></td>
  </tr>`;
}

async function loadAdminChains() {
  const el = document.getElementById("adminChainsList");
  if (!el || !isAdmin) return;
  el.innerHTML = '<div class="note">Chains werden geladen…</div>';
  const {data,error} = await sb.from("chains").select("*").order("sort_order",{ascending:true});
  if (error) { el.innerHTML = `<div class="error">${escapeAttr(error.message)}</div>`; return; }

  el.innerHTML = `<div class="chain-table-wrap">
    <table class="chain-admin-table">
      ${chainTableHeader()}
      <tbody>${(data||[]).map(r=>chainTableRow(r,false)).join("")}</tbody>
    </table>
  </div>`;
}

function openNewChainEditor() {
  const el=document.getElementById("adminChainEditor");
  if (!el) return;
  el.style.display="block";
  el.innerHTML=`<div class="chain-table-wrap">
    <table class="chain-admin-table">
      ${chainTableHeader()}
      <tbody>${chainTableRow({enabled:true,sort_order:100},true)}</tbody>
    </table>
  </div>`;
}
function closeNewChainEditor() {
  const el=document.getElementById("adminChainEditor");
  if (el) { el.style.display="none"; el.innerHTML=""; }
}

function readChainEditor(id) {
  const root=document.querySelector(`[data-chain-editor="${CSS.escape(String(id))}"]`);
  if (!root) throw new Error("Chain-Editor nicht gefunden.");
  const out={};
  ADMIN_CHAIN_FIELDS.forEach(f=>{
    const input=root.querySelector(`[data-chain-field="${f.k}"]`);
    if (!input) return;
    if (f.type==="checkbox") out[f.k]=input.checked;
    else if (f.type==="number") out[f.k]=input.value===""?null:Number(input.value);
    else out[f.k]=input.value.trim() || null;
  });
  return out;
}

function inferNativeTechnicalDecimals(walletType,chainKey){
  const t=String(walletType||"").toLowerCase();
  if(t==="evm") return 18;
  if(t==="sol") return 9;
  if(t==="tron") return 6;
  if(t==="btc") return 8;
  if(t==="xrp") return 6;
  return null;
}

async function syncNativeAssetForChain(chainKey,chainRow={}){
  const chain=String(chainKey||chainRow.chain_key||"").trim();
  if(!chain) return;
  const symbol=String(chainRow.native_symbol||NATIVE_SYMBOL[chain]||chain.toUpperCase()).trim();
  const payload={
    chain,address:"native",is_native:true,label:`${symbol} (nativ)`,symbol,
    name:chainRow.label||CHAIN_META[chain]?.label||symbol,
    coingecko_id:chainRow.coingecko_id||CHAIN_META[chain]?.coingeckoId||null,
    decimals:inferNativeTechnicalDecimals(chainRow.wallet_type||CHAIN_CONFIG[chain]?.walletType,chain),enabled:true
  };
  const {data,error}=await sb.from("predefined_tokens").select("chain,address").eq("chain",chain).eq("address","native").maybeSingle();
  if(error) throw error;
  if(data){
    const {error:updateError}=await sb.from("predefined_tokens").update(payload).eq("chain",chain).eq("address","native");
    if(updateError) throw updateError;
  }else{
    const {error:insertError}=await sb.from("predefined_tokens").insert(payload);
    if(insertError) throw insertError;
  }
}

async function saveAdminChain(id,isNew=false) {
  if (!isAdmin) return;
  try {
    const row=readChainEditor(id);
    if (isNew && !row.chain_key) throw new Error("Chain-Key ist erforderlich.");
    if (!row.label) throw new Error("Anzeigename ist erforderlich.");
    if (!row.native_symbol) throw new Error("Natives Symbol ist erforderlich.");
    const savedChainKey=isNew?row.chain_key:id;
    const nativeSyncRow={...row,chain_key:savedChainKey};
    let q;
    if (isNew) q=sb.from("chains").insert(row);
    else {
      delete row.chain_key;
      q=sb.from("chains").update(row).eq("chain_key",id);
    }
    const {error}=await q;
    if (error) throw error;
    await syncNativeAssetForChain(savedChainKey,nativeSyncRow);
    closeNewChainEditor();
    await loadChainConfigFromDb();
    await loadPredefinedTokensFromDb();
    activeChainFilter = new Set(Object.keys(CHAIN_META));
    await loadAdminChains();
    alert("Chain-Konfiguration gespeichert.");
  } catch(e) {
    alert("Speichern fehlgeschlagen: "+(e.message||e));
  }
}

// Rein statische Übersicht, keine DB-Anbindung nötig - hier einfach die Liste pflegen.




// ---- Admin: eigene sichere Token aller User einsehen/übernehmen/ignorieren ----
let adminAllCustomTokens = []; // rohe Zeilen aus der DB (alle User)

async function loadAdminCustomTokens() {
  const { data, error } = await sb.from("safe_tokens").select("*").order("created_at", { ascending: false });
  if (error) { console.error(error); adminAllCustomTokens = []; return; }
  adminAllCustomTokens = data || [];
}

async function renderAdminCustomTokens() {
  const el = document.getElementById("adminCustomTokensList");
  el.innerHTML = `<div class="status">Lade...</div>`;
  await loadAdminCustomTokens();

  const statusFilter = document.getElementById("adminTokenStatusFilter").value;
  let rows = adminAllCustomTokens;
  if (statusFilter !== "all") {
    rows = rows.filter(r => (r.admin_status || "pending") === statusFilter);
  }

  if (rows.length === 0) {
    el.innerHTML = `<div class="empty">Keine Einträge mit diesem Status.</div>`;
    return;
  }

  el.innerHTML = rows.map(r => {
    const chainMeta = CHAIN_META[r.chain];
    const alreadyPredefined = (SAFE_ADDRESSES[r.chain] || []).includes(normalizeAddress(r.address, r.chain));
    const status = r.admin_status || "pending";
    const statusBadge = status === "promoted" ? '<span class="badge safe">übernommen</span>'
      : status === "ignored" ? '<span class="badge unsafe">ignoriert</span>'
      : '<span class="badge unsafe" style="background:rgba(240,185,11,0.15);color:#f0b90b">ausstehend</span>';

    return `<div class="custom-token-row" style="align-items:flex-start;flex-wrap:wrap">
      <div style="flex:1;min-width:220px">
        <div><span class="dot ${chainMeta ? chainMeta.dot : ''}" style="margin-right:6px"></span>${chainMeta ? chainMeta.label : r.chain} ${statusBadge} ${alreadyPredefined ? '<span class="note" style="display:inline">(bereits vordefiniert)</span>' : ''}</div>
        <div class="meta">User-Label: "${escapeAttr(r.label)}" · ${r.address}</div>
      </div>
      ${status === "pending" ? `
        <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
          <input type="text" id="admin-label-${r.id}" value="${escapeAttr(r.label)}" style="width:160px" placeholder="Label für vordefinierte Liste" />
          <button onclick="adminPromoteToken('${r.id}','${r.chain}','${r.address}')">Als vordefiniert übernehmen</button>
          <button class="remove" onclick="adminIgnoreToken('${r.id}')">Ignorieren</button>
        </div>
      ` : ''}
    </div>`;
  }).join("");
}

async function adminIgnoreToken(id) {
  const { error } = await sb.from("safe_tokens").update({ admin_status: "ignored" }).eq("id", id);
  if (error) { alert("Fehler: " + error.message); return; }
  renderAdminCustomTokens();
}

async function adminPromoteToken(id, chain, address) {
  const labelInput = document.getElementById("admin-label-" + id);
  const label = labelInput ? labelInput.value.trim() : "";
  if (!label) { alert("Bitte ein Label eingeben."); return; }

  const { error: insertError } = await sb.from("predefined_tokens")
    .upsert({ chain, address: address.toLowerCase(), label }, { onConflict: "chain,address" });
  if (insertError) { alert("Fehler beim Übernehmen: " + insertError.message); return; }

  const { error: updateError } = await sb.from("safe_tokens").update({ admin_status: "promoted" }).eq("id", id);
  if (updateError) { alert("Fehler beim Markieren: " + updateError.message); return; }

  await loadPredefinedTokensFromDb(); // damit die neue Liste sofort überall greift
  renderSafeTokenTable();
  renderAdminCustomTokens();
}

// ---- Alchemy: EVM-Daten (ersetzt Moralis) ----
// WICHTIG: Hier den API-Key deiner Alchemy-App eintragen.
// Da diese Seite statisch auf GitHub Pages läuft, ist ein Frontend-Key grundsätzlich sichtbar.
// Testversion: API-Key wird im Request-Pfad verwendet. Deshalb die Domain-Allowlist in Alchemy auf deine Website beschränken.
const ALCHEMY_API_KEY = "alch_UMCNBKNtoimHNHHPBk7kV";

function configuredAlchemyBase(chain, purpose="discovery") {
  const cfg = CHAIN_CONFIG[chain] || {};
  const base = purpose === "approvals" ? cfg.approvalsApiBase : cfg.discoveryApiBase;
  const provider = purpose === "approvals" ? cfg.approvalsProvider : cfg.discoveryProvider;
  if (provider !== "alchemy" || !base) {
    throw new Error(`${CHAIN_META[chain]?.label || chain}: ${purpose}-Provider/API-Basis ist in public.chains nicht als Alchemy konfiguriert`);
  }
  return base.replace(/\/+$/, "");
}

function configuredNftBase(chain) {
  const cfg = CHAIN_CONFIG[chain] || {};
  if (!cfg.nftProvider || !cfg.nftApiBase) {
    throw new Error(`${CHAIN_META[chain]?.label || chain}: NFT-Provider/API-Basis fehlt in public.chains`);
  }
  return cfg.nftApiBase.replace(/\/+$/, "");
}

function assertAlchemyConfigured() {
  if (!ALCHEMY_API_KEY || ALCHEMY_API_KEY.startsWith("HIER_")) {
    throw new Error("Alchemy API-Key fehlt – bitte ALCHEMY_API_KEY im HTML eintragen.");
  }
}

let archiveRpcQueue = Promise.resolve();
let archiveRpcLastCall = 0;

function configuredArchiveRpcUrl(chain) {
  const cfg = CHAIN_CONFIG[chain] || {};
  // archive_rpc_url ist optional. Gemäß DB-Schema fällt die Historien-/On-Chain-Abfrage
  // auf rpc_url zurück, wenn kein eigener Archive-RPC hinterlegt ist. Das ist u.a. für
  // Apertum wichtig, dessen öffentlicher RPC auch für aktuelle DEX-Abfragen genutzt wird.
  const rawBase = cfg.archiveRpcUrl || cfg.rpcUrl;
  if (!rawBase) {
    throw new Error(`${CHAIN_META[chain]?.label || chain}: weder Historie-/Archive-RPC noch RPC konfiguriert`);
  }
  const base = rawBase.replace(/\/+$/, "");
  if (cfg.archiveRpcUrl && String(cfg.archiveRpcProvider || "").toLowerCase() === "alchemy") {
    assertAlchemyConfigured();
    return `${base}/${encodeURIComponent(ALCHEMY_API_KEY)}`;
  }
  return base;
}

function archiveRpc(chain, method, params) {
  const run = async () => {
    // Free-Alchemy has a low throughput ceiling. Historical requests are intentionally serialized.
    const wait = Math.max(0, 220 - (Date.now() - archiveRpcLastCall));
    if (wait) await new Promise(resolve => setTimeout(resolve, wait));
    archiveRpcLastCall = Date.now();

    const url = configuredArchiveRpcUrl(chain);
    const delays = [0, 800, 1800, 3500];
    let lastError = null;

    for (let attempt = 0; attempt < delays.length; attempt++) {
      if (delays[attempt]) await new Promise(resolve => setTimeout(resolve, delays[attempt]));
      try {
        const res = await fetch(url, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ jsonrpc:"2.0", id:1, method, params })
        });
        if (!res.ok) {
          let detail = "";
          try { detail = await res.text(); } catch (_) {}
          if ((res.status === 429 || res.status >= 500) && attempt < delays.length - 1) continue;
          throw new Error(`${CHAIN_META[chain]?.label || chain}: Archive-RPC HTTP ${res.status}${detail ? " – " + detail.slice(0,180) : ""}`);
        }
        const data = await res.json();
        if (data.error) throw new Error(`${CHAIN_META[chain]?.label || chain}: ${data.error.message || "Archive-RPC Fehler"}`);
        return data.result;
      } catch (e) {
        lastError = e;
        if (attempt === delays.length - 1) throw e;
      }
    }
    throw lastError || new Error("Archive-RPC fehlgeschlagen");
  };
  archiveRpcQueue = archiveRpcQueue.then(run, run);
  return archiveRpcQueue;
}

function taxBlockHex(block) {
  return "0x" + Number(block).toString(16);
}

async function alchemyRpc(chain, method, params, purpose="discovery") {
  assertAlchemyConfigured();
  const base = configuredAlchemyBase(chain, purpose);
  const url = `${base}/${encodeURIComponent(ALCHEMY_API_KEY)}`;
  const delays = [0, 600, 1500];
  let lastNetworkError = null;

  for (let attempt = 0; attempt < delays.length; attempt++) {
    if (delays[attempt]) await new Promise(resolve => setTimeout(resolve, delays[attempt]));
    let res;
    try {
      res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ jsonrpc: "2.0", id: 1, method, params })
      });
    } catch (e) {
      lastNetworkError = e;
      continue;
    }
    if (!res.ok) {
      let detail = "";
      try { detail = await res.text(); } catch (_) {}
      if ((res.status === 429 || res.status >= 500) && attempt < delays.length - 1) continue;
      throw new Error(`${CHAIN_META[chain]?.label || chain}: Alchemy HTTP ${res.status}${detail ? " – " + detail.slice(0, 180) : ""}`);
    }
    const data = await res.json();
    if (data.error) throw new Error(`${CHAIN_META[chain]?.label || chain}: ${method}: ${data.error.message || "Alchemy RPC-Fehler"}`);
    return data.result;
  }
  throw new Error(`${CHAIN_META[chain]?.label || chain}: Netzwerkfehler bei ${method} nach 3 Versuchen (${lastNetworkError?.message || lastNetworkError || "Load failed"})`);
}

async function alchemyRpcBatch(chain, calls, purpose="discovery") {
  if (!calls.length) return [];
  assertAlchemyConfigured();

  // Große Wallet-Historien erzeugen sehr viele Receipt-/TX-Abfragen.
  // Browser (insb. Safari/iOS) können bei großen JSON-RPC-Batches mit "Load failed"
  // abbrechen. Deshalb intern immer in kleine Pakete aufteilen.
  const MAX_CALLS_PER_HTTP_BATCH = 10;
  if (calls.length > MAX_CALLS_PER_HTTP_BATCH) {
    const allRows = [];
    for (let offset = 0; offset < calls.length; offset += MAX_CALLS_PER_HTTP_BATCH) {
      if (offset > 0) await new Promise(resolve => setTimeout(resolve, 200));
      const part = calls.slice(offset, offset + MAX_CALLS_PER_HTTP_BATCH);
      const rows = await alchemyRpcBatch(chain, part, purpose);
      allRows.push(...rows);
    }
    return allRows;
  }

  const base = configuredAlchemyBase(chain, purpose);
  const url = `${base}/${encodeURIComponent(ALCHEMY_API_KEY)}`;
  const payload = calls.map((c, i) => ({
    jsonrpc: "2.0",
    id: i + 1,
    method: c.method,
    params: c.params
  }));

  // Bei älteren/aktiven Wallets laufen viele Requests nacheinander.
  // Kurzzeitige Browser-/Netzwerkabbrüche automatisch bis zu 3x wiederholen.
  const delays = [0, 500, 1200];
  let lastNetworkError = null;

  for (let attempt = 0; attempt < delays.length; attempt++) {
    if (delays[attempt]) await new Promise(resolve => setTimeout(resolve, delays[attempt]));

    let res;
    try {
      res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
    } catch (e) {
      lastNetworkError = e;
      continue;
    }

    if (!res.ok) {
      let detail = "";
      try { detail = await res.text(); } catch (_) {}

      // Rate-Limit / temporäre Serverfehler ebenfalls nochmals versuchen.
      if ((res.status === 429 || res.status >= 500) && attempt < delays.length - 1) {
        continue;
      }

      throw new Error(`${CHAIN_META[chain]?.label || chain}: Alchemy Batch HTTP ${res.status}${detail ? " – " + detail.slice(0, 180) : ""}`);
    }

    const data = await res.json();
    if (!Array.isArray(data)) {
      throw new Error(`${CHAIN_META[chain]?.label || chain}: Unerwartete Alchemy-Batch-Antwort`);
    }

    const byId = new Map(data.map(x => [x.id, x]));
    return payload.map(p => {
      const x = byId.get(p.id);
      if (!x) return null;
      if (x.error) return { __error: x.error.message || "RPC-Fehler" };
      return x.result;
    });
  }

  throw new Error(
    `${CHAIN_META[chain]?.label || chain}: Netzwerkfehler bei RPC-Batch nach 3 Versuchen (${lastNetworkError?.message || lastNetworkError || "Load failed"})`
  );
}

async function fetchAlchemyOutgoingTxHashes(chain, address, onProgress) {
  const hashes = new Set();
  let pageKey = null;
  let page = 0;
  let truncated = false;

  do {
    page++;
    if (onProgress) onProgress(page);
    const filter = {
      fromBlock: "0x0",
      toBlock: "latest",
      fromAddress: address,
      category: ["external", "erc20", "erc721", "erc1155"],
      excludeZeroValue: false,
      maxCount: "0x64" // 100 statt 1000: kleinere Antworten für alte/aktive Wallets
    };
    if (pageKey) filter.pageKey = pageKey;
    let result;
    try {
      result = await alchemyRpc(chain, "alchemy_getAssetTransfers", [filter], "approvals");
    } catch (e) {
      // Einige Netzwerke unterstützen nicht jede NFT-Kategorie. Für Gebühren/Approvals
      // reicht als Fallback die externe + ERC20-Historie.
      filter.category = ["external", "erc20"];
      result = await alchemyRpc(chain, "alchemy_getAssetTransfers", [filter], "approvals");
    }
    (result.transfers || []).forEach(t => { if (t.hash) hashes.add(t.hash); });
    pageKey = result.pageKey || null;
    if (pageKey) await new Promise(resolve => setTimeout(resolve, 150));
  } while (pageKey && page < FEES_MAX_PAGES);

  if (pageKey) truncated = true;
  return { hashes: [...hashes], truncated };
}

// Zentrale Chain-Konfiguration.
// Single Source of Truth: public.chains in Supabase.
// Im HTML gibt es absichtlich KEINE Chain-Metadaten als Fallback mehr.
const CHAIN_META = {};
const CHAIN_CONFIG = {};
const NATIVE_SYMBOL = {};
const GECKOTERMINAL_NETWORK = {};
let chainConfigStatus = { source: "nicht geladen", count: 0, loadedAt: null };

async function loadChainConfigFromDb() {
  const chainFields="chain_key,label,native_symbol,coingecko_id,wallet_type,explorer_url_template,geckoterminal_network,icon_path,sort_order,enabled,evm_chain_id,rpc_url,archive_rpc_url,archive_rpc_provider,balance_provider,fee_provider,fee_api_base,fee_finality_blocks,fee_overlap_blocks,fees_enabled,discovery_enabled,approvals_enabled,nft_enabled,discovery_provider,discovery_api_base,approvals_provider,approvals_api_base,nft_provider,nft_api_base,balance_api_base,display_color";
  let q=await sb.from("chains").select(chainFields).eq("enabled", true).order("sort_order", { ascending: true });
  // Rollout-tolerant: Website darf zwischen Deploy und SQL-Migration nicht ausfallen.
  // Fehlt icon_path noch, lädt die App die bisherige Chain-Konfiguration weiter ohne Logos.
  if(q.error && /icon_path/i.test(String(q.error.message||q.error.details||""))){
    q=await sb.from("chains")
      .select(chainFields.replace(",icon_path",""))
      .eq("enabled", true)
      .order("sort_order", { ascending: true });
  }
  const {data,error}=q;

  if (error) {
    chainConfigStatus = { source: "FEHLER", count: 0, loadedAt: new Date().toISOString(), error: error.message };
    throw new Error("Chain-Konfiguration konnte nicht aus Supabase geladen werden: " + error.message);
  }
  if (!Array.isArray(data) || data.length === 0) {
    chainConfigStatus = { source: "FEHLER", count: 0, loadedAt: new Date().toISOString(), error: "Keine aktiven Chains" };
    throw new Error("Chain-Konfiguration aus Supabase ist leer. Bitte Tabelle public.chains prüfen.");
  }

  for (const obj of [CHAIN_META, CHAIN_CONFIG, NATIVE_SYMBOL, GECKOTERMINAL_NETWORK]) {
    Object.keys(obj).forEach(k => delete obj[k]);
  }

  data.forEach(row => {
    const key = String(row.chain_key || "").trim();
    if (!key) return;

    CHAIN_META[key] = {
      label: row.label || key,
      dot: key, // reine Darstellungs-Klasse; keine Chain-Daten im HTML nötig
      coingeckoId: row.coingecko_id || null,
      nativeSymbol: row.native_symbol || key.toUpperCase(),
      iconPath: row.icon_path || null
    };
    CHAIN_CONFIG[key] = {
      walletType: row.wallet_type || null,
      explorerUrlTemplate: row.explorer_url_template || null,
      sortOrder: Number(row.sort_order || 100),
      evmChainId: row.evm_chain_id == null ? null : Number(row.evm_chain_id),
      rpcUrl: row.rpc_url || null,
      archiveRpcUrl: row.archive_rpc_url || null,
      archiveRpcProvider: row.archive_rpc_provider || null,
      balanceProvider: row.balance_provider || null,
      balanceApiBase: row.balance_api_base || null,
      displayColor: row.display_color || "#6b7280",
      feeProvider: row.fee_provider || null,
      feeApiBase: row.fee_api_base || null,
      feeFinalityBlocks: row.fee_finality_blocks == null ? null : Number(row.fee_finality_blocks),
      feeOverlapBlocks: row.fee_overlap_blocks == null ? null : Number(row.fee_overlap_blocks),
      feesEnabled: row.fees_enabled === true,
      discoveryEnabled: row.discovery_enabled === true,
      approvalsEnabled: row.approvals_enabled === true,
      nftEnabled: row.nft_enabled === true,
      discoveryProvider: row.discovery_provider || null,
      discoveryApiBase: row.discovery_api_base || null,
      approvalsProvider: row.approvals_provider || null,
      approvalsApiBase: row.approvals_api_base || null,
      nftProvider: row.nft_provider || null,
      nftApiBase: row.nft_api_base || null
    };
    NATIVE_SYMBOL[key] = row.native_symbol || key.toUpperCase();
    if (row.geckoterminal_network) {
      GECKOTERMINAL_NETWORK[key] = row.geckoterminal_network;
    }
  });

  chainConfigStatus = {
    source: "Supabase public.chains",
    count: Object.keys(CHAIN_META).length,
    loadedAt: new Date().toISOString()
  };
  return true;
}


// ---- Chain-Filter (Wallet-Tracking-Tab) - standardmässig sind alle Chains aktiv ----
let activeChainFilter = new Set();

function renderChainFilter() {
  const el = document.getElementById("chainFilterContainer");
  if (!el) return;
  el.innerHTML = Object.keys(CHAIN_META).map(chain => {
    const meta = CHAIN_META[chain];
    const checked = activeChainFilter.has(chain) ? "checked" : "";
    return `<label style="display:flex;align-items:center;gap:6px;font-size:0.85rem;cursor:pointer">
      <input type="checkbox" ${checked} onchange="toggleChainFilter('${chain}', this.checked)" style="width:auto" />
      <span class="dot" style="background:${escapeAttr(CHAIN_CONFIG[meta.dot]?.displayColor || "#6b7280")}"></span> ${meta.label}
    </label>`;
  }).join("");
}

function toggleChainFilter(chain, isChecked) {
  if (isChecked) activeChainFilter.add(chain);
  else activeChainFilter.delete(chain);
  renderResults();
}

function setAllChainFilter(selectAll) {
  activeChainFilter = selectAll ? new Set(Object.keys(CHAIN_META)) : new Set();
  renderChainFilter();
  renderResults();
}

// ---- Navigation "Gehe zu Wallet" ----
function renderWalletNav() {
  const el = document.getElementById("walletNav");
  if (el) {
    const visibleWallets=walletsForCurrentView();
    const current = el.value;
    el.innerHTML = `<option value="">– auswählen –</option>` +
      visibleWallets.map(w => `<option value="${w.id}">${escapeAttr(w.label)}</option>`).join("");
    if (visibleWallets.some(w => w.id === current)) el.value = current;
  }
  renderDiscoveryWalletSelect();
  renderChartWalletSelect();
  renderAllocWalletSelect();
  renderFeesWalletSelect();
  renderApprovalsWalletSelect();
  renderNftWalletSelect();
}

function goToWallet(id) {
  if (!id) return;
  const el = document.getElementById("wallet-block-" + id);
  if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
}


// RPC-Endpunkt (PublicNode, kein Key nötig) pro EVM-Chain - für native Balance und Token-Checks
// Kostenloser PublicNode/Allnodes-Token - hebt die Archiv-Sperre auf (nötig für den
// Discovery-Scan über weiter zurückliegende Blöcke) und erhöht generell die Rate-Limits.
// Kostenloser PublicNode/Allnodes-Token - hebt die Archiv-Sperre auf (nötig für den
// Discovery-Scan über weiter zurückliegende Blöcke) und erhöht generell die Rate-Limits.
// PublicNode scheint pro Chain einen eigenen Token zu vergeben statt eines einzigen
// chain-übergreifenden Tokens - darum eine Map statt einer einzelnen Konstante.
// Kostenloser PublicNode/Allnodes-Token - hebt die Archiv-Sperre auf (nötig für den
// Discovery-Scan über weiter zurückliegende Blöcke) und erhöht generell die Rate-Limits.
// Ein einziger Token gilt chain-übergreifend (bestätigt: ETH und BSC haben denselben Wert geliefert).
const PUBLICNODE_TOKEN = "a39e5bb34dbfbaa3dbd07f8e2d5292c769941030dc99ca5b8776b76e3df78b36";
function publicnodeToken(chain) {
  return PUBLICNODE_TOKEN;
}

function configuredRpcUrl(chain) {
  const base = CHAIN_CONFIG[chain]?.rpcUrl;
  if (!base) throw new Error(`${CHAIN_META[chain]?.label || chain}: RPC-/REST-Endpunkt fehlt in public.chains`);
  // PublicNode-Zugangstoken ist ein Credential, keine Chain-Konfiguration.
  // Ist in rpc_url bereits ein individueller Pfad hinterlegt, bleibt er unverändert.
  if (base.includes("publicnode.com") && PUBLICNODE_TOKEN && !base.endsWith(PUBLICNODE_TOKEN)) {
    return base.replace(/\/+$/, "") + "/" + publicnodeToken(chain);
  }
  return base;
}


// Holt Name/Dezimalstellen direkt vom Contract für vordefinierte Token, die noch nie
// eine Wallet mit Bestand hatten (darum bisher nicht im Cache) - unabhängig vom Bestand.
async function ensurePredefinedNames() {
  for (const chain of Object.keys(CHAIN_CONFIG).filter(c => CHAIN_CONFIG[c]?.walletType === "evm" && CHAIN_CONFIG[c]?.rpcUrl)) {
    const missing = (SAFE_ADDRESSES[chain] || []).filter(a =>
      !tokenMetaCache[chain + "|" + a] && !predefinedTokenLabels[chain + "|" + a]
    );
    if (missing.length === 0) continue;

    const calls = [];
    const plan = [];
    missing.forEach((addr, idx) => {
      calls.push({ to: addr, data: "0x313ce567" }); plan.push({ idx, type: "decimals" });
      calls.push({ to: addr, data: "0x95d89b41" }); plan.push({ idx, type: "symbol" });
    });

    let results;
    try {
      results = await evmRpcBatch(configuredRpcUrl(chain), calls);
    } catch (e) {
      continue; // Netzwerkfehler - Namen bleiben unbekannt, nächster Tab-Aufruf versucht's erneut
    }

    const perToken = missing.map(() => ({}));
    results.forEach((hex, i) => {
      const { idx, type } = plan[i];
      perToken[idx][type] = hex;
    });

    missing.forEach((addr, idx) => {
      const decHex = perToken[idx].decimals;
      const decimals = decHex && decHex !== "0x" ? parseInt(decHex, 16) : 18;
      const symbol = decodeAbiString(perToken[idx].symbol) || (addr.slice(0, 8) + "…");
      tokenMetaCache[chain + "|" + addr] = { decimals, symbol };
    });
  }
  saveTokenMetaCache();
  renderSafeTokenTable();
}


// Vordefinierte sichere Token kommen jetzt aus Supabase (Tabelle predefined_tokens),
// nicht mehr fest im Code - siehe loadPredefinedTokensFromDb().
let SAFE_ADDRESSES = {};
let predefinedTokenLabels = {}; // Key "chain|adresse" -> Label
let predefinedTokenCategory = {}; // Key "chain|adresse" -> "v_currency" | "lp_token" | "tln_vow_token" | null

// Adressen case-sensitiv normalisieren - EVM/Apertum-Adressen sind Hex (Gross-/Klein-
// schreibung egal), Tron-Adressen sind Base58 und GROSS-/KLEINSCHREIBUNG IST RELEVANT.
function normalizeAddress(address, chain) {
  const value = address.trim();
  return CHAIN_CONFIG[chain]?.walletType === "evm" ? value.toLowerCase() : value;
}

async function ensureNativeAssetsConfigured(){
  if(!isAdmin)return false;
  let changed=false;
  for(const chain of Object.keys(CHAIN_META)){
    if(predefinedNativeAssets[chain])continue;
    await syncNativeAssetForChain(chain,{
      chain_key:chain,
      native_symbol:NATIVE_SYMBOL[chain]||chain.toUpperCase(),
      label:CHAIN_META[chain]?.label||chain,
      wallet_type:CHAIN_CONFIG[chain]?.walletType||null,
      coingecko_id:CHAIN_META[chain]?.coingeckoId||null
    });
    changed=true;
  }
  return changed;
}

async function refreshPredefinedTokens() {
  await loadPredefinedTokensFromDb();
  renderSafeTokenTable();
  loadAll(); // neue/geänderte vordefinierte Token sollen sofort im Wallet-Tracking berücksichtigt werden
}

async function loadDefiProjectsCache(){
  const {data,error}=await sb.from("defi_projects").select("*").eq("enabled",true).order("sort_order",{ascending:true});
  if(error){ console.error(error); defiProjectsCache=[]; return; }
  defiProjectsCache=data||[];
  const sel=document.getElementById("newPredefDefiProject");
  if(sel){
    const current=sel.value;
    sel.innerHTML='<option value="">– keines –</option>'+defiProjectsCache.map(p=>`<option value="${escapeAttr(p.project_key)}">${escapeAttr(p.name)}</option>`).join("");
    if(defiProjectsCache.some(p=>p.project_key===current)) sel.value=current;
  }
}

async function addPredefinedToken() {
  if (!isAdmin) { alert("Nur Admins können vordefinierte Token ändern."); return; }
  const chain = document.getElementById("newPredefChain").value;
  const addressRaw = document.getElementById("newPredefAddress").value.trim();
  const label = document.getElementById("newPredefLabel").value.trim();
  const defiProjectKey = document.getElementById("newPredefDefiProject").value || null;
  const defiCategory = document.getElementById("newPredefDefiCategory").value || null;

  if (!addressRaw || !label) { alert("Bitte Adresse und Label ausfüllen."); return; }
  const address = normalizeAddress(addressRaw, chain);

  const { error } = await sb.from("predefined_tokens").insert({
    chain, address, label,
    defi_project_key: defiProjectKey,
    defi_category: defiCategory
  });
  if (error) { alert("Fehler beim Hinzufügen: " + error.message); return; }

  document.getElementById("newPredefAddress").value = "";
  document.getElementById("newPredefLabel").value = "";
  document.getElementById("newPredefDefiProject").value = "";
  document.getElementById("newPredefDefiCategory").value = "";
  await refreshPredefinedTokens();
}

// Case-insensitiver Adress-Abgleich für UPDATE/DELETE-Abfragen (ausser Tron, dort ist
// Gross-/Kleinschreibung bewusst relevant) - die Adresse im Code ist normalisiert
// (kleingeschrieben), in der DB steht teils noch die Original-Schreibweise, darum darf
// hier kein exaktes .eq() auf die Adresse verwendet werden, sonst wird still nichts gefunden.
function matchAddressQuery(query, chain, address) {
  return chain === "tron" ? query.eq("address", address) : query.ilike("address", address);
}

async function updatePredefinedTokenLabel(chain, address, newLabel) {
  if (!isAdmin) return;
  newLabel = newLabel.trim();
  if (!newLabel) return;
  const { error } = await matchAddressQuery(sb.from("predefined_tokens").update({ label: newLabel }).eq("chain", chain), chain, address);
  if (error) { alert("Fehler beim Speichern: " + error.message); return; }
  predefinedTokenLabels[chain + "|" + address] = newLabel;
}

async function updatePredefinedTokenDisplayDecimals(chain,address,field,value){
  if (!isAdmin) return;
  const allowNull=field==="summary_decimals";
  const raw=String(value??"").trim();
  const dbValue=allowNull&&raw===""?null:Number(raw);
  if(dbValue!==null && (!Number.isInteger(dbValue)||dbValue<0||dbValue>18)){
    alert("Kommastellen müssen eine ganze Zahl zwischen 0 und 18 sein.");
    renderSafeTokenTable();
    return;
  }
  const {error}=await matchAddressQuery(sb.from("predefined_tokens").update({[field]:dbValue}).eq("chain",chain),chain,address);
  if(error){alert("Fehler beim Speichern: "+error.message);renderSafeTokenTable();return;}
  await loadPredefinedTokensFromDb();
  renderSafeTokenTable();
  renderResults();
  window.dispatchEvent(new CustomEvent("wallettracking:token-display-settings-changed",{detail:{chain,address,field,value:dbValue}}));
}

async function deletePredefinedToken(chain, address, label) {
  if (!isAdmin) return;
  if (!confirm(`"${label}" (${chain}) wirklich aus der vordefinierten Liste löschen? Betrifft ALLE User.`)) return;
  const { error } = await matchAddressQuery(sb.from("predefined_tokens").delete().eq("chain", chain), chain, address);
  if (error) { alert("Fehler beim Löschen: " + error.message); return; }
  await refreshPredefinedTokens();
}

async function loadPredefinedTokensFromDb() {
  const { data, error } = await sb.from("predefined_tokens").select("*");
  if (error) { console.error(error); return; }
  const addresses = {};
  const labels = {};
  const categories = {}; // "chain|adresse" -> generische DeFi-Kategorie
  const projects = {}; // "chain|adresse" -> project_key
  const coinGeckoIds = {};
  const symbols = {};
  const names = {};
  const decimals = {};
  const displayDecimals = {};
  const summaryDecimals = {};
  const dashboardVisible = {};
  const byChainSymbol = {};
  const nativeAssets = {};
  const seen = new Set(); // Dedupe für den Fall, dass dieselbe Adresse mit unterschiedlicher
                           // Gross-/Kleinschreibung mehrfach in der DB steht (case-sensitiver PK)
  data.forEach(row => {
    if (row.enabled === false) return;
    const chain = row.chain;
    const isNative = row.is_native === true || String(row.address||"").toLowerCase() === "native";
    const address = isNative ? "native" : normalizeAddress(row.address, chain);
    const dedupeKey = chain + "|" + address;
    if (seen.has(dedupeKey)) return;
    seen.add(dedupeKey);
    if (!isNative) {
      addresses[chain] = addresses[chain] || [];
      addresses[chain].push(address);
    } else {
      nativeAssets[chain] = {
        chain, address:"native", label:row.label || `${row.symbol||NATIVE_SYMBOL[chain]||chain.toUpperCase()} (nativ)`,
        symbol:row.symbol || NATIVE_SYMBOL[chain] || chain.toUpperCase(), name:row.name || CHAIN_META[chain]?.label || chain,
        technicalDecimals:row.decimals == null ? null : Number(row.decimals),
        displayDecimals:Number.isInteger(Number(row.display_decimals)) ? Number(row.display_decimals) : 6,
        summaryDecimals:row.summary_decimals == null || row.summary_decimals === "" ? null : Number(row.summary_decimals),
        dashboardVisible:row.dashboard_visible === true
      };
    }
    if (row.label) labels[dedupeKey] = row.label;
    categories[dedupeKey] = row.defi_category || null;
    projects[dedupeKey] = row.defi_project_key || null;
    if (row.coingecko_id) coinGeckoIds[dedupeKey] = row.coingecko_id;
    if (row.symbol) symbols[dedupeKey] = row.symbol;
    if (row.name) names[dedupeKey] = row.name;
    if (row.decimals !== null && row.decimals !== undefined) decimals[dedupeKey] = Number(row.decimals);
    const display = Number.isInteger(Number(row.display_decimals)) ? Number(row.display_decimals) : 6;
    const summary = row.summary_decimals === null || row.summary_decimals === undefined || row.summary_decimals === "" ? null : Number(row.summary_decimals);
    displayDecimals[dedupeKey] = display;
    summaryDecimals[dedupeKey] = Number.isInteger(summary) ? summary : null;
    dashboardVisible[dedupeKey] = row.dashboard_visible === true;
    const symbolKey=String(row.symbol||row.label||"").trim().toUpperCase();
    if(symbolKey) byChainSymbol[`${chain}|${symbolKey}`]={display,summary:summaryDecimals[dedupeKey]};
  });
  SAFE_ADDRESSES = addresses;
  predefinedTokenLabels = labels;
  predefinedTokenCategory = categories;
  predefinedTokenProject = projects;
  predefinedTokenCoinGeckoIds = coinGeckoIds;
  predefinedTokenSymbols = symbols;
  predefinedTokenNames = names;
  predefinedTokenDecimals = decimals;
  predefinedTokenDisplayDecimals = displayDecimals;
  predefinedTokenSummaryDecimals = summaryDecimals;
  predefinedTokenDashboardVisible = dashboardVisible;
  predefinedTokenDisplayByChainSymbol = byChainSymbol;
  predefinedNativeAssets = nativeAssets;
}

// Apertum: Balance-Abfrage über die öffentliche Blockscout-Explorer-API (CORS-freundlich für Browser-Zugriffe)
function isSafeTokenAddress(address, chain) {
  if (!address) return false;
  const a = normalizeAddress(address, chain);
  if ((SAFE_ADDRESSES[chain] || []).includes(a)) return true;
  return customSafeTokens.some(t => t.chain === chain && t.address === a);
}

// ---- Eigene sichere Token (Supabase-gestützt, an den Account gebunden) ----
let customSafeTokens = [];

async function loadCustomSafeTokensFromDb() {
  const { data, error } = await sb.from("safe_tokens").select("*").order("created_at");
  if (error) { console.error(error); customSafeTokens = []; return; }
  customSafeTokens = data.map(row => ({ dbId: row.id, chain: row.chain, address: row.address, label: row.label }));
}

async function addCustomSafeToken() {
  const chain = document.getElementById("customChain").value;
  const rawAddress = document.getElementById("customAddress").value.trim();
  const address = normalizeAddress(rawAddress, chain);
  const label = document.getElementById("customLabel").value.trim();

  const walletType = CHAIN_CONFIG[chain]?.walletType;
  const isValidEvm = walletType === "evm" && /^0x[0-9a-fA-F]{40}$/.test(address);
  const isValidTron = walletType === "tron" && /^T[1-9A-HJ-NP-Za-km-z]{33}$/.test(address);
  const isValidSolana = walletType === "sol" && /^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(address);
  if (!address || (!isValidEvm && !isValidTron && !isValidSolana)) {
    alert(walletType === "tron"
      ? "Bitte eine gültige Tron-Token-Adresse eingeben."
      : walletType === "sol"
        ? "Bitte eine gültige Solana Mint-Adresse eingeben."
        : "Bitte eine gültige EVM-Contract-Adresse eingeben (0x... mit 40 Hex-Zeichen).");
    return;
  }
  if (customSafeTokens.some(t => t.chain === chain && t.address === address)) {
    alert("Dieser Token ist für diese Chain bereits erfasst.");
    return;
  }

  const { data, error } = await sb.from("safe_tokens").insert({
    user_id: currentUser.id,
    chain,
    address,
    label: label || address
  }).select().single();

  if (error) {
    alert("Fehler beim Speichern: " + error.message);
    return;
  }

  customSafeTokens.push({ dbId: data.id, chain, address, label: label || address });
  document.getElementById("customAddress").value = "";
  document.getElementById("customLabel").value = "";
  renderCustomTokenList();
  renderSafeTokenTable();
  loadAll(); // neuer Token soll sofort im Wallet-Tracking berücksichtigt werden, nicht erst nach manuellem Neuladen
  renderResults();
}

async function removeCustomSafeToken(chain, address) {
  const t = customSafeTokens.find(t => t.chain === chain && t.address === address);
  const label = t?.label || address;
  if (!confirm(`Token "${label}" (${String(chain || "").toUpperCase()}) wirklich aus deiner sicheren Token-Liste entfernen?`)) return;
  if (t && t.dbId) {
    const { error } = await sb.from("safe_tokens").delete().eq("id", t.dbId);
    if (error) { alert("Token konnte nicht gelöscht werden: " + error.message); return; }
  }
  customSafeTokens = customSafeTokens.filter(t => !(t.chain === chain && t.address === address));
  renderCustomTokenList();
  renderSafeTokenTable();
  loadAll(); // Entfernter Token soll sofort aus dem Wallet-Tracking verschwinden, falls dort ein Bestand angezeigt war
}

function renderCustomChainSelect(){
  const el=document.getElementById("customChain");
  if(!el)return;
  const current=el.value;
  const chains=Object.keys(CHAIN_CONFIG).filter(c=>{
    const type=CHAIN_CONFIG[c]?.walletType;
    return type==="evm" || type==="tron" || type==="sol";
  });
  el.innerHTML=chains.map(c=>`<option value="${escapeAttr(c)}">${escapeAttr(CHAIN_META[c]?.label||c)}</option>`).join("");
  if(chains.includes(current))el.value=current;
}

function renderCustomTokenList() {
  const el = document.getElementById("customTokenList");
  if (customSafeTokens.length === 0) {
    el.innerHTML = `<div class="empty">Noch keine eigenen Token erfasst.</div>`;
    return;
  }
  el.innerHTML = customSafeTokens.map(t => {
    const p = priceForToken(t.chain, t.address);
    const priceHtml = p
      ? `<div style="margin-top:4px">${fmtPrice(p.price)}<span class="price-source">${p.source}</span></div>`
      : `<div style="margin-top:4px;color:var(--muted);font-size:0.78rem">Kein Kurs gefunden</div>`;
    return `
    <div class="custom-token-row">
      <div>
        <div>${escapeAttr(t.label)} <span class="badge safe">sicher</span></div>
        <div class="meta">${t.chain.toUpperCase()} · ${t.address}</div>
        ${priceHtml}
      </div>
      <button class="remove" onclick="removeCustomSafeToken('${t.chain}','${t.address}')">Entfernen</button>
    </div>
  `;
  }).join("");
}

function renderSafeTokenTable() {
  const el = document.getElementById("safeTokenTable");
  const rows = [];

  // Native Coins zuerst – als echte Stammdaten aus predefined_tokens.
  // Falls Migration/Datensatz bei einer neuen Chain noch fehlt, bleibt die Zeile sichtbar,
  // ist aber als nicht konfiguriert erkennbar und wird NICHT still als Token-Contract behandelt.
  Object.keys(CHAIN_META).forEach(chain => {
    const native=predefinedNativeAssets[chain];
    rows.push(native ? { ...native, isNative:true } : {
      chain, address:"native", label:(NATIVE_SYMBOL[chain] || chain.toUpperCase()) + " (nativ)", isNative:true, nativeMissing:true,
      technicalDecimals:null, displayDecimals:null, summaryDecimals:null, dashboardVisible:false
    });
  });

  Object.keys(SAFE_ADDRESSES).forEach(chain => {
    (SAFE_ADDRESSES[chain] || []).forEach(address => {
      let label = predefinedTokenLabels[chain + "|" + address] || null;
      if (!label) {
        const cached = tokenMetaCache[chain + "|" + address];
        label = cached ? cached.symbol : null;
      }
      const key=chain+"|"+address;
      rows.push({ chain, address, label,
        technicalDecimals:predefinedTokenDecimals[key],
        displayDecimals:predefinedTokenDisplayDecimals[key],
        summaryDecimals:predefinedTokenSummaryDecimals[key],
        dashboardVisible:predefinedTokenDashboardVisible[key]===true
      });
    });
  });

  // Filter-Dropdowns befüllen (Auswahl dabei erhalten)
  populateSelectPreserving("predefChainFilter", Object.keys(CHAIN_META).sort(), c => c.toUpperCase(), "Alle Chains");
  const distinctLabels = [...new Set(rows.map(r => r.label).filter(Boolean))].sort((a, b) => a.localeCompare(b));
  populateSelectPreserving("predefTokenFilter", distinctLabels, l => l, "Alle Token");

  // Filter anwenden
  const chainFilter = document.getElementById("predefChainFilter").value;
  const tokenFilter = document.getElementById("predefTokenFilter").value;
  const textFilter = document.getElementById("predefTextFilter").value.trim().toLowerCase();

  let filtered = rows;
  if (chainFilter) filtered = filtered.filter(r => r.chain === chainFilter);
  if (tokenFilter) filtered = filtered.filter(r => r.label === tokenFilter);
  if (textFilter) {
    filtered = filtered.filter(r =>
      (r.label || "").toLowerCase().includes(textFilter) ||
      (r.address || "").toLowerCase().includes(textFilter)
    );
  }

  if (rows.length === 0) {
    el.innerHTML = `<div class="empty">Keine vordefinierten Token hinterlegt.</div>`;
    return;
  }
  if (filtered.length === 0) {
    el.innerHTML = `<div class="empty">Keine Token gefunden, die zu den Filtern passen.</div>`;
    return;
  }

  filtered.sort((a, b) => {
    const chainCompare = a.chain.localeCompare(b.chain);
    if (chainCompare !== 0) return chainCompare;
    return (a.label || "").localeCompare(b.label || "");
  });

  const DEFI_CATEGORY_LABELS = { voucher_currency:"Voucher-Währung", lp_token:"LP Token", defi_token:"DeFi-Token" };

  const tableHeader = isAdmin
    ? `<tr><th>Chain</th><th>Token</th><th>Adresse</th><th style="text-align:center">Decimals<br><span class="meta">technisch</span></th><th style="text-align:center">Kommastellen<br><span class="meta">Anzeige</span></th><th style="text-align:center">Kommastellen<br><span class="meta">Summary</span></th><th style="text-align:center">Im Dashboard<br>immer anzeigen</th><th style="text-align:right">Kurs (USD)</th><th>DeFi-Projekt</th><th>Projekt-Kategorie</th><th></th></tr>`
    : `<tr><th>Chain</th><th>Token</th><th>Adresse</th><th style="text-align:right">Kurs (USD)</th></tr>`;
  el.innerHTML = `<table class="project-data-table"><thead>${tableHeader}</thead><tbody>
    ${filtered.map(r => {
      let p;
      if (r.isNative) {
        const np = nativePrices[r.chain];
        p = np ? { price: np.price, source: np.source || "CoinGecko" } : null;
      } else {
        p = priceForToken(r.chain, r.address);
      }
      const priceCell = p
        ? `${fmtPrice(p.price)}<span class="price-source">${p.source}</span>`
        : '<span style="color:var(--muted)">–</span>';

      if (!isAdmin) {
        const readonlyLabel = r.label ? escapeAttr(r.label) : '<span style="color:var(--muted)">unbekannt</span>';
        const readonlyAddress = r.isNative ? '<span style="color:var(--muted)">native</span>' : r.address;
        return `<tr>
          <td><span class="dot" style="margin-right:6px;background:${escapeAttr(CHAIN_CONFIG[r.chain]?.displayColor || "#6b7280")}"></span>${r.chain.toUpperCase()}</td>
          <td>${readonlyLabel}</td>
          <td style="font-size:0.78rem;word-break:break-all">${readonlyAddress}</td>
          <td style="text-align:right">${priceCell}</td>
        </tr>`;
      }

      const categoryKey = r.chain + "|" + (r.address || "");
      const category = predefinedTokenCategory[categoryKey] || "";
      const projectKey = predefinedTokenProject[categoryKey] || "";
      const projectName = defiProjectsCache.find(p=>p.project_key===projectKey)?.name || projectKey;
      const projectCell = r.isNative ? '<span style="color:var(--muted)">–</span>' :
        (isAdmin
          ? `<select onchange="setPredefinedTokenDefi('${r.chain}','${r.address}','defi_project_key',this.value)">
              <option value="" ${projectKey===""?"selected":""}>– keines –</option>
              ${defiProjectsCache.map(p=>`<option value="${escapeAttr(p.project_key)}" ${projectKey===p.project_key?"selected":""}>${escapeAttr(p.name)}</option>`).join("")}
            </select>`
          : (projectKey ? escapeAttr(projectName) : '<span style="color:var(--muted)">–</span>'));
      const categoryCell = r.isNative ? '<span style="color:var(--muted)">–</span>' :
        (isAdmin
          ? `<select onchange="setPredefinedTokenDefi('${r.chain}','${r.address}','defi_category',this.value)">
              <option value="" ${category===""?"selected":""}>– keine –</option>
              <option value="voucher_currency" ${category==="voucher_currency"?"selected":""}>Voucher-Währung</option>
              <option value="lp_token" ${category==="lp_token"?"selected":""}>LP Token</option>
              <option value="defi_token" ${category==="defi_token"?"selected":""}>DeFi-Token</option>
            </select>`
          : (category ? escapeAttr(DEFI_CATEGORY_LABELS[category] || category) : '<span style="color:var(--muted)">–</span>'));

      const labelCell = (isAdmin && !r.isNative)
        ? `<input type="text" value="${escapeAttr(r.label || "")}" style="font-size:0.85rem;padding:4px 6px" onblur="updatePredefinedTokenLabel('${r.chain}','${r.address}', this.value)" onkeydown="if(event.key==='Enter') this.blur()" />`
        : (r.label ? escapeAttr(r.label) : '<span style="color:var(--muted)">unbekannt (noch kein Bestand gefunden)</span>');

      const deleteCell = (isAdmin && !r.isNative)
        ? `<button class="remove" onclick="deletePredefinedToken('${r.chain}','${r.address}','${escapeAttr(r.label || r.address)}')">Löschen</button>`
        : "";

      return `<tr>
      <td><span class="dot" style="margin-right:6px;background:${escapeAttr(CHAIN_CONFIG[r.chain]?.displayColor || "#6b7280")}"></span>${r.chain.toUpperCase()}</td>
      <td>${labelCell}</td>
      <td style="font-size:0.78rem;word-break:break-all">${r.isNative ? '<span style="color:var(--muted)">native</span>' : r.address}</td>
      <td style="text-align:center">${r.technicalDecimals??'<span style="color:var(--muted)">–</span>'}</td>
      <td style="text-align:center">${r.nativeMissing?'<span style="color:var(--danger,#ef4444)">nicht konfiguriert</span>':(isAdmin?`<input type="number" min="0" max="18" step="1" value="${Number.isInteger(Number(r.displayDecimals))?Number(r.displayDecimals):6}" style="width:68px;text-align:center" onchange="updatePredefinedTokenDisplayDecimals('${r.chain}','${r.address}','display_decimals',this.value)">`:(Number.isInteger(Number(r.displayDecimals))?Number(r.displayDecimals):6))}</td>
      <td style="text-align:center">${r.nativeMissing?'<span style="color:var(--muted)">–</span>':(isAdmin?`<input type="number" min="0" max="18" step="1" value="${r.summaryDecimals!==null&&r.summaryDecimals!==undefined&&r.summaryDecimals!==''&&Number.isInteger(Number(r.summaryDecimals))?Number(r.summaryDecimals):''}" placeholder="wie Anzeige" title="Leer = Kommastellen Anzeige übernehmen" style="width:92px;text-align:center" onchange="updatePredefinedTokenDisplayDecimals('${r.chain}','${r.address}','summary_decimals',this.value)">`:(r.summaryDecimals!==null&&r.summaryDecimals!==undefined&&r.summaryDecimals!==''&&Number.isInteger(Number(r.summaryDecimals))?Number(r.summaryDecimals):'<span style="color:var(--muted)">wie Anzeige</span>'))}</td>
      <td style="text-align:center"><input type="checkbox" style="width:auto" ${r.dashboardVisible?"checked":""} ${r.nativeMissing?"disabled":""} onchange="setPredefinedTokenDashboardVisible('${r.chain}','${r.address}',this.checked)"></td>
      <td style="text-align:right">${priceCell}</td>
      <td>${projectCell}</td>
      <td>${categoryCell}</td>
      ${isAdmin ? `<td>${deleteCell}</td>` : ""}
    </tr>`;
    }).join("")}
  </tbody></table>`;
}

async function setPredefinedTokenDashboardVisible(chain,address,visible){
  if(!isAdmin)return;
  const normalized=address==="native"?"native":normalizeAddress(address,chain);
  const {error}=await matchAddressQuery(sb.from("predefined_tokens").update({dashboard_visible:!!visible}).eq("chain",chain),chain,normalized);
  if(error){alert("Dashboard-Auswahl konnte nicht gespeichert werden: "+error.message);renderSafeTokenTable();return;}
  predefinedTokenDashboardVisible[chain+"|"+normalized]=!!visible;
  if(predefinedNativeAssets[chain]&&normalized==="native")predefinedNativeAssets[chain].dashboardVisible=!!visible;
  renderSafeTokenTable();renderDashboard();
}
window.setPredefinedTokenDashboardVisible=setPredefinedTokenDashboardVisible;

async function setPredefinedTokenDefi(chain,address,field,value){
  if (!isAdmin) return;
  const dbValue=value||null;
  const {error}=await matchAddressQuery(sb.from("predefined_tokens").update({[field]:dbValue}).eq("chain",chain),chain,address);
  if(error){ alert("Fehler beim Speichern: "+error.message); return; }
  const key=chain+"|"+address;
  if(field==="defi_project_key") predefinedTokenProject[key]=dbValue;
  if(field==="defi_category") predefinedTokenCategory[key]=dbValue;
  updateTlnVowTabVisibility();
  window.DAO1Project?.updateVisibility?.();
}

// Befüllt ein <select> mit Optionen und behält die bisherige Auswahl bei, falls sie noch existiert
function populateSelectPreserving(selectId, values, labelFn, placeholderLabel) {
  const el = document.getElementById(selectId);
  if (!el) return;
  const current = el.value;
  el.innerHTML = `<option value="">${placeholderLabel}</option>` +
    values.map(v => `<option value="${escapeAttr(v)}">${escapeAttr(labelFn(v))}</option>`).join("");
  if (values.includes(current)) el.value = current;
}

// ---- Live-Kurse: native Coins + möglichst viele Token ----
let nativePrices = {}; // chainKey -> {price, change24h}
let tokenPrices = {}; // "chain|adresse" -> {price, change24h, source}

// Globaler, nicht personenbezogener Snapshot für aktuelle Preise.
// Keine Historisierung: pro Refresh wird genau der aktuelle Stand überschrieben.
// TLN/VOW hält seinen globalen Projekt-Snapshot parallel, damit Route/Poolzustand erhalten bleiben.
const CURRENT_PRICE_GLOBAL_CACHE_TABLE = "wallet_global_current_price_snapshot";
const CURRENT_PRICE_GLOBAL_CACHE_VERSION = "wallettracking-current-prices-v2";
const CURRENT_PRICE_TIMEZONE = "Europe/Zurich";
const CURRENT_PRICE_SLOT_MINUTES = 15;
let currentPriceCacheState = { capturedAt:null, source:"none" };
let allCurrentPricesPromise = null;
let globalPriceTimer = null;

function priceSlotKey(value=new Date()){
  const d=value instanceof Date?value:new Date(value);
  if(Number.isNaN(d.getTime()))return "";
  const parts=new Intl.DateTimeFormat("en-CA",{timeZone:CURRENT_PRICE_TIMEZONE,year:"numeric",month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit",hourCycle:"h23"}).formatToParts(d);
  const x=Object.fromEntries(parts.filter(p=>p.type!=="literal").map(p=>[p.type,p.value]));
  const minute=Math.floor(Number(x.minute||0)/CURRENT_PRICE_SLOT_MINUTES)*CURRENT_PRICE_SLOT_MINUTES;
  return `${x.year}-${x.month}-${x.day}T${x.hour}:${String(minute).padStart(2,"0")}`;
}
function nextPriceSlotDelayMs(){
  const now=Date.now(),d=new Date(now),m=d.getMinutes(),next=(Math.floor(m/CURRENT_PRICE_SLOT_MINUTES)+1)*CURRENT_PRICE_SLOT_MINUTES;
  const n=new Date(d);n.setSeconds(2,0);if(next>=60){n.setHours(d.getHours()+1,0,2,0);}else n.setMinutes(next,2,0);
  return Math.max(1000,n.getTime()-now);
}
function formatCurrentPriceTimestamp(value){
  const d=value instanceof Date?value:new Date(value);
  return Number.isNaN(d.getTime())?"–":new Intl.DateTimeFormat("de-CH",{timeZone:CURRENT_PRICE_TIMEZONE,day:"2-digit",month:"2-digit",year:"numeric",hour:"2-digit",minute:"2-digit",second:"2-digit"}).format(d);
}
function setCentralPriceBusy(busy){const b=document.getElementById("currentPriceRefreshBtn");if(b){b.disabled=!!busy;b.textContent=busy?"Preise werden aktualisiert…":"Preise aktualisieren";}}
function setCentralPriceStatus(text,kind="note"){const el=document.getElementById("currentPriceStatus");if(!el)return;const cls=kind==="success"?"success":kind==="warning"?"warning":kind==="error"?"error":"note";el.className=cls+" wt-data-status-line";const clean=String(text||"").replace(/^Preisstand:\s*/,"");el.innerHTML=`<strong>Preisstand:</strong> ${escapeAttr(clean)}`;}
async function loadGlobalCurrentPriceSnapshot(){
  try{
    const {data,error}=await sb.from(CURRENT_PRICE_GLOBAL_CACHE_TABLE).select("captured_at,payload,slot_key").eq("snapshot_key","current").eq("valuation_version",CURRENT_PRICE_GLOBAL_CACHE_VERSION).maybeSingle();
    if(error)throw error;if(!data?.payload)return null;
    return {capturedAt:data.captured_at,payload:data.payload,slotKey:data.slot_key,currentSlot:data.slot_key===priceSlotKey()};
  }catch(e){console.warn("Globaler Preiscache konnte nicht aus Supabase geladen werden",e);return null;}
}
function hydrateGlobalCurrentPriceSnapshot(payload){
  if(!payload||typeof payload!=="object")return false;
  nativePrices=payload.nativePrices&&typeof payload.nativePrices==="object"?payload.nativePrices:{};
  tokenPrices=payload.tokenPrices&&typeof payload.tokenPrices==="object"?payload.tokenPrices:{};
  return true;
}
async function saveGlobalCurrentPriceSnapshot(slotKey=priceSlotKey()){
  const capturedAt=new Date().toISOString(),payload={nativePrices,tokenPrices};
  try{
    const {error}=await sb.from(CURRENT_PRICE_GLOBAL_CACHE_TABLE).upsert({snapshot_key:"current",valuation_version:CURRENT_PRICE_GLOBAL_CACHE_VERSION,slot_key:slotKey,captured_at:capturedAt,payload,updated_at:capturedAt},{onConflict:"snapshot_key,valuation_version"});
    if(error)throw error;currentPriceCacheState={capturedAt,source:"live",slotKey};return true;
  }catch(e){console.warn("Globaler Preiscache konnte nicht gespeichert werden",e);currentPriceCacheState={capturedAt,source:"live-unsaved",slotKey};return false;}
}
async function claimGlobalPriceSlot(slotKey=priceSlotKey()){
  try{
    const {data,error}=await sb.rpc("wallettracking_claim_price_refresh_slot",{p_slot_key:slotKey,p_valuation_version:CURRENT_PRICE_GLOBAL_CACHE_VERSION});
    if(error)throw error;return data===true;
  }catch(e){console.warn("Globaler Preis-Slot konnte nicht reserviert werden",e);return false;}
}
async function loadCachedCurrentPricesAtStart(){
  const [cached]=await Promise.all([
    loadGlobalCurrentPriceSnapshot(),
    window.TLNVOWProject?.loadCachedPrices?.().catch?.(e=>{console.warn("TLN/VOW Preissnapshot",e);return null;}) || Promise.resolve(null)
  ]);
  if(cached?.payload&&hydrateGlobalCurrentPriceSnapshot(cached.payload)){
    currentPriceCacheState={capturedAt:cached.capturedAt,source:"supabase",slotKey:cached.slotKey};
    setCentralPriceStatus(`${formatCurrentPriceTimestamp(cached.capturedAt)} · global gespeichert${cached.currentSlot?" · aktueller 15-Min.-Slot":""}.`,cached.currentSlot?"success":"warning");
    setWtDataStatus("dashboard",{updatedAt:cached.capturedAt,cacheAt:cached.capturedAt,source:"cache",label:"Dashboard"});
    rerenderAllCurrentPriceViews();renderDashboard();return currentPriceCacheState;
  }
  setCentralPriceStatus("Noch kein global gespeicherter Preisstand vorhanden.","warning");renderDashboard();return null;
}
function rerenderAllCurrentPriceViews(){renderResults();renderSafeTokenTable();renderCustomTokenList();renderAllocationChart();renderDashboard();if(document.getElementById("tab-predefined")?.classList.contains("active"))renderSafeTokenTable();}
async function runGlobalPriceRefresh({manual=false,slotKey=priceSlotKey()}={}){
  setCentralPriceBusy(true);setCentralPriceStatus(manual?"Alle aktuellen Preise werden neu ermittelt…":"Globaler 15-Minuten-Preisstand wird aktualisiert…","note");
  await loadNativePrices();
  let tlnState=null;
  if(window.TLNVOWProject){await window.TLNVOWProject.refreshPrices();tlnState=window.TLNVOWProject.getPriceState?.()||null;}
  const saved=await saveGlobalCurrentPriceSnapshot(slotKey);
  rerenderAllCurrentPriceViews();await refreshFeePriceViews().catch(e=>console.warn("Gebühren-Kursansicht aktualisieren:",e));
  const stamp=formatCurrentPriceTimestamp(currentPriceCacheState.capturedAt);
  setCentralPriceStatus(`${stamp} · globaler Preisstand${saved?" gespeichert":" (Speichern fehlgeschlagen)"}.`,saved?"success":"warning");
  setWtDataStatus("tracking",{updatedAt:currentPriceCacheState.capturedAt,cacheAt:saved?currentPriceCacheState.capturedAt:null,source:saved?"cache":"live",label:"Wallet-Tracking"});
  window.dispatchEvent(new CustomEvent("wallettracking:all-prices-updated",{detail:{manual,general:currentPriceCacheState,tln:tlnState}}));
  return {general:currentPriceCacheState,tln:tlnState};
}
async function refreshAllCurrentPrices({manual=false}={}){
  if(allCurrentPricesPromise)return allCurrentPricesPromise;
  allCurrentPricesPromise=(async()=>{
    const slotKey=priceSlotKey();
    if(!manual){
      const cached=await loadGlobalCurrentPriceSnapshot();
      if(cached?.currentSlot&&hydrateGlobalCurrentPriceSnapshot(cached.payload)){
        currentPriceCacheState={capturedAt:cached.capturedAt,source:"supabase",slotKey:cached.slotKey};
        await window.TLNVOWProject?.loadCachedPrices?.();rerenderAllCurrentPriceViews();
        setCentralPriceStatus(`${formatCurrentPriceTimestamp(cached.capturedAt)} · global gespeichert · aktueller 15-Min.-Slot.`,`success`);return {general:currentPriceCacheState,tln:window.TLNVOWProject?.getPriceState?.()||null};
      }
      const claimed=await claimGlobalPriceSlot(slotKey);
      if(!claimed){
        // Ein anderer aktiver Client aktualisiert gerade. Kurz darauf den globalen Snapshot übernehmen.
        await new Promise(r=>setTimeout(r,2500));const after=await loadGlobalCurrentPriceSnapshot();
        if(after?.payload&&hydrateGlobalCurrentPriceSnapshot(after.payload)){currentPriceCacheState={capturedAt:after.capturedAt,source:"supabase",slotKey:after.slotKey};await window.TLNVOWProject?.loadCachedPrices?.();rerenderAllCurrentPriceViews();setCentralPriceStatus(`${formatCurrentPriceTimestamp(after.capturedAt)} · global gespeichert.`,`success`);return {general:currentPriceCacheState,tln:window.TLNVOWProject?.getPriceState?.()||null};}
        return null;
      }
    }
    return await runGlobalPriceRefresh({manual,slotKey});
  })().catch(e=>{setCentralPriceStatus(`Preisaktualisierung fehlgeschlagen: ${e.message||e}`,"error");throw e;}).finally(()=>{setCentralPriceBusy(false);allCurrentPricesPromise=null;});
  return allCurrentPricesPromise;
}
function scheduleGlobalPriceRefresh(){
  if(globalPriceTimer)clearTimeout(globalPriceTimer);
  const tick=async()=>{if(currentUser)await refreshAllCurrentPrices({manual:false}).catch(e=>console.warn("Globaler 15-Minuten-Preisjob",e));globalPriceTimer=setTimeout(tick,nextPriceSlotDelayMs());};
  // Beim Login aktuellen Slot prüfen; danach an :00/:15/:30/:45 (mit 2 s Sicherheitsabstand).
  setTimeout(()=>{if(currentUser)refreshAllCurrentPrices({manual:false}).catch(e=>console.warn("Globaler Preisstart",e));},300);
  globalPriceTimer=setTimeout(tick,nextPriceSlotDelayMs());
}
document.addEventListener("visibilitychange",()=>{if(!document.hidden&&currentUser)refreshAllCurrentPrices({manual:false}).catch(e=>console.warn("Preisstand nach Rückkehr",e));});
window.refreshAllCurrentPrices=refreshAllCurrentPrices;

// Preis-/Token-Metadaten der vordefinierten Token kommen ab Phase 1 aus Supabase.
// Schlüssel ist immer "chain|contract", nie nur das Kürzel – dadurch bleiben gleichnamige
// Token auf unterschiedlichen Chains eindeutig.
let predefinedTokenCoinGeckoIds = {}; // "chain|adresse" -> CoinGecko-ID
let predefinedTokenSymbols = {};      // "chain|adresse" -> Symbol
let predefinedTokenNames = {};        // "chain|adresse" -> Name
let predefinedTokenDecimals = {};     // "chain|adresse" -> technische Blockchain-decimals
let predefinedTokenDisplayDecimals = {}; // "chain|adresse" -> UI-Nachkommastellen
let predefinedTokenSummaryDecimals = {}; // "chain|adresse" -> Summary-Nachkommastellen (null = Anzeige übernehmen)
let predefinedTokenDisplayByChainSymbol = {}; // "chain|SYMBOL" -> Anzeige-Metadaten
let predefinedNativeAssets = {}; // chain -> echter predefined_tokens-Datensatz mit is_native=true

function tokenDisplayMeta({chain,address,symbol}={}){
  const c=String(chain||"").trim().toLowerCase();
  const rawAddress=String(address||"").trim();
  const a=rawAddress.toLowerCase()==="native"?"native":(rawAddress?normalizeAddress(rawAddress,c):"");
  const direct=a?`${c}|${a}`:"";
  if(direct && Object.prototype.hasOwnProperty.call(predefinedTokenDisplayDecimals,direct)){
    return {display:predefinedTokenDisplayDecimals[direct],summary:predefinedTokenSummaryDecimals[direct]};
  }
  const sym=String(symbol||"").replace(/\s*\(nativ\)\s*$/i,"").trim().toUpperCase();
  return predefinedTokenDisplayByChainSymbol[`${c}|${sym}`] || null;
}
function tokenDisplayDigits(meta={},summary=false){
  const hit=tokenDisplayMeta(meta);
  const display=Number.isInteger(Number(hit?.display))?Number(hit.display):6;
  if(summary && hit?.summary !== null && hit?.summary !== undefined && hit?.summary !== "" && Number.isInteger(Number(hit.summary))) return Number(hit.summary);
  return display;
}
function formatTokenAmountGlobal(value,meta={},options={}){
  const n=Number(value);
  if(!Number.isFinite(n)) return "–";
  const digits=tokenDisplayDigits(meta,!!options.summary);
  return n.toLocaleString("de-CH",{minimumFractionDigits:digits,maximumFractionDigits:digits});
}
window.WalletTokenFormat={
  amount:formatTokenAmountGlobal,
  digits:tokenDisplayDigits,
  meta:tokenDisplayMeta
};

// GeckoTerminal (dieselbe Firma wie CoinGecko, DEX-basierte Kurse) als Ergänzung für alle
// anderen sicheren Token - deckt auch kleinere/eigene Token ab, sofern sie irgendwo auf
// einer DEX gehandelt werden. Kein API-Key nötig, kostenlos. LP-Token und Token ohne
// eigenen Handelsplatz liefern hier bewusst keinen Kurs (kein Rätselraten).

async function apertumCurrentDirectPrice(base,quote,bd,qd,explicitPair=null){
  const chain="apertum",pair=explicitPair?normalizeAddress(explicitPair,chain):await taxV2Pair(chain,base,quote,null);if(!pair)return null;
  const iface=new ethers.Interface(["function token0() view returns (address)","function getReserves() view returns (uint112,uint112,uint32)"]);
  const [t0raw,rr]=await Promise.all([
    archiveRpc(chain,"eth_call",[{to:pair,data:iface.encodeFunctionData("token0",[])},"latest"]),
    archiveRpc(chain,"eth_call",[{to:pair,data:iface.encodeFunctionData("getReserves",[])},"latest"])
  ]);
  const [t0]=iface.decodeFunctionResult("token0",t0raw),[r0,r1]=iface.decodeFunctionResult("getReserves",rr),is0=normalizeAddress(t0,chain)===normalizeAddress(base,chain);
  const rb=Number(is0?r0:r1)/10**Number(bd),rq=Number(is0?r1:r0)/10**Number(qd);
  return rb>0&&rq>0?{price:rq/rb,pair,baseReserve:rb,quoteReserve:rq}:null;
}
async function loadApertumCurrentPrices(){
  const refreshedAt=new Date().toISOString();
  const chain="apertum",u=taxPredefinedBySymbol(chain,"WUSDT")||taxPredefinedBySymbol(chain,"USDT"),wa=taxPredefinedBySymbol(chain,"WAPTM");
  if(!u||!wa){console.warn("Apertum Live-Kurse: wAPTM oder wUSDT nicht in predefined_tokens gefunden");return;}
  const ud=await taxTokenDecimalsCurrent(chain,u),wd=await taxTokenDecimalsCurrent(chain,wa);
  // Gleiche Referenz wie im DAO1-Projekt: der validierte wAPTM/wUSDT-Pool wird direkt
  // verwendet. Damit hängt der Basispreis nicht von Symbolfeldern oder der Factory-Suche ab.
  const referencePair=window.DAO1Project?.getAptmUsdtPairAddress?.()||null;
  let aptmLeg=null;
  try{aptmLeg=await apertumCurrentDirectPrice(wa.address,u.address,wd,ud,referencePair);}catch(e){console.warn("Apertum Referenzpool direkt",e);}
  if(!aptmLeg){
    try{aptmLeg=await apertumCurrentDirectPrice(wa.address,u.address,wd,ud);}catch(e){console.warn("Apertum Referenzpool via Factory",e);}
  }
  const aptm=aptmLeg?.price;if(!(aptm>0)){console.warn("Apertum Live-Kurse: kein wAPTM/wUSDT-Preis ermittelbar");return;}
  nativePrices[chain]={price:aptm,change24h:undefined,source:`Apertum DEX wAPTM/wUSDT · ${aptmLeg.pair}`,refreshedAt};
  tokenPrices[chain+"|"+normalizeAddress(u.address,chain)]={price:1,source:"Apertum DEX · Stablecoin 1 USD",refreshedAt};
  tokenPrices[chain+"|"+normalizeAddress(wa.address,chain)]={price:aptm,source:`Apertum DEX wAPTM/wUSDT · ${aptmLeg.pair}`,refreshedAt};
  const prefix=chain+"|";
  const addresses=[...new Set([...(SAFE_ADDRESSES[chain]||[]),...Object.keys(predefinedTokenLabels).filter(k=>k.startsWith(prefix)).map(k=>k.slice(prefix.length)),...Object.keys(predefinedTokenSymbols).filter(k=>k.startsWith(prefix)).map(k=>k.slice(prefix.length))])];
  for(const rawAddr of addresses){
    // "native" ist ein interner Asset-Key und keine EVM-Adresse. Native APTM wird
    // bereits über nativePrices gesetzt und darf nie in ethers ABI-Address-Encoding gelangen.
    if(String(rawAddr||"").toLowerCase()==="native")continue;
    const addr=normalizeAddress(rawAddr,chain);
    if(!ethers.isAddress(addr))continue;
    const key=chain+"|"+addr,sym=predefinedTokenTicker(chain,addr).toUpperCase();
    if(["WUSDT","USDT","WUSDC","USDC"].includes(sym)){tokenPrices[key]={price:1,source:"Apertum DEX · Stablecoin 1 USD",refreshedAt};continue;}
    if(sym==="WAPTM"){tokenPrices[key]={price:aptm,source:`Apertum DEX wAPTM/wUSDT · ${aptmLeg.pair}`,refreshedAt};continue;}
    const asset={address:addr,symbol:sym,decimals:predefinedTokenDecimals[key]};const bd=await taxTokenDecimalsCurrent(chain,asset);
    try{
      const direct=await apertumCurrentDirectPrice(addr,u.address,bd,ud);
      const via=await apertumCurrentDirectPrice(addr,wa.address,bd,wd);
      const directLiquidity=direct?direct.quoteReserve:0,viaLiquidity=via?via.quoteReserve*aptm:0;
      if(direct&&directLiquidity>=viaLiquidity)tokenPrices[key]={price:direct.price,source:`Apertum DEX ${sym||"Token"}/wUSDT · ${direct.pair}`,refreshedAt};
      else if(via)tokenPrices[key]={price:via.price*aptm,source:`Apertum DEX ${sym||"Token"}/wAPTM → wUSDT · ${via.pair} · ${aptmLeg.pair}`,refreshedAt};
    }catch(e){console.warn("Apertum Live-Kurs",sym||addr,e);}
  }
}

async function loadNativePrices() {
  const refreshedAt=new Date().toISOString();
  const ids = [...new Set(
    Object.entries(CHAIN_META).filter(([chain])=>chain!=="apertum").map(([,m]) => m.coingeckoId)
      .concat(Object.entries(predefinedTokenCoinGeckoIds).filter(([key])=>!key.startsWith("apertum|")).map(([,id])=>id))
      .filter(Boolean)
  )].join(",");

  const alreadyPriced = {}; // "chain|adresse" -> true, deckt USDT/USDC ab (kein Doppel-Fetch via GeckoTerminal)

  try {
    const res = await fetch(`https://api.coingecko.com/api/v3/simple/price?ids=${ids}&vs_currencies=usd&include_24hr_change=true`);
    if (!res.ok) throw new Error("HTTP " + res.status);
    const data = await res.json();

    const prices = {};
    Object.keys(CHAIN_META).forEach(chain => {
      if(chain === "apertum") return; // Apertum: ausschließlich On-Chain-Kurse
      const id = CHAIN_META[chain].coingeckoId;
      if (data[id] && typeof data[id].usd === "number") {
        prices[chain] = {
          price: data[id].usd,
          change24h: typeof data[id].usd_24h_change === "number" ? data[id].usd_24h_change : undefined,
          source: "CoinGecko",
          refreshedAt
        };
      }
    });
    // Phase 5.40: stale-while-refresh. Der letzte gültige Preisstand bleibt sichtbar,
    // bis für ein Asset tatsächlich ein neuer gültiger Kurs vorliegt.
    nativePrices = {...nativePrices,...prices};

    const tPrices = {};
    Object.keys(SAFE_ADDRESSES).forEach(chain => {
      if(chain === "apertum") return; // Apertum: kein CoinGecko-Fallback
      (SAFE_ADDRESSES[chain] || []).forEach(address => {
        if(isTlnVowManagedToken(chain,address)) return;
        const tokenKey = chain + "|" + address;
        const cgId = predefinedTokenCoinGeckoIds[tokenKey];
        if (cgId && data[cgId] && typeof data[cgId].usd === "number") {
          const key = chain + "|" + address;
          tPrices[key] = {
            price: data[cgId].usd,
            change24h: typeof data[cgId].usd_24h_change === "number" ? data[cgId].usd_24h_change : undefined,
            source: "CoinGecko",
            refreshedAt
          };
          alreadyPriced[key] = true;
        }
      });
    });
    tokenPrices = {...tokenPrices,...tPrices};
  } catch (e) {
    // Phase 5.40: bei einem Refresh-Fehler niemals den letzten gültigen Snapshot leeren.
    console.warn("Aktuelle Preise: bestehender Snapshot bleibt aktiv",e);
  }

  await loadTokenPricesViaGeckoTerminal(alreadyPriced);
  await loadApertumCurrentPrices();
  if(document.getElementById("tab-predefined")?.classList.contains("active")) renderSafeTokenTable();

  // Gebühren-Ansichten können bereits sichtbar sein, während die Kursabfrage noch
  // im Hintergrund läuft. Nach Abschluss nur die betroffenen Ansichten neu rendern
  // (kein Browser-Reload, damit keine neue Lade-Schleife/API-Abfragen entstehen).
  refreshFeePriceViews().catch(e => console.warn("Gebühren-Kursansicht aktualisieren:", e));
}

async function refreshFeePriceViews() {
  if (!currentUser) return;
  await renderFeesSummary();
  const select = document.getElementById("feesWalletSelect");
  const walletId = select ? select.value : "";
  if (!walletId) return;
  const w = wallets.find(x => String(x.id) === String(walletId));
  if (!w) return;
  const rows = await loadFeeCacheForWallet(walletId);
  if (!rows.length) return;
  const results = rows.map(r => ({
    chain:r.chain, totalFee:Number(r.total_fee_native || 0), txCount:Number(r.tx_count || 0),
    cached:true, cachedAt:r.last_scanned_at, source:r.data_source
  }));
  renderFeesResults(w, results);
}

async function loadTokenPricesViaGeckoTerminal(alreadyPriced) {
  // Alle Chains parallel abfragen statt nacheinander - das war der Haupt-Geschwindigkeitsverlust.
  const chainJobs = Object.keys(GECKOTERMINAL_NETWORK).filter(chain=>chain!=="apertum").map(async chain => {
    const network = GECKOTERMINAL_NETWORK[chain];
    const list = (SAFE_ADDRESSES[chain] || [])
      .filter((addr, idx, arr) => arr.indexOf(addr) === idx) // Duplikate raus
      .filter(addr => !isTlnVowManagedToken(chain,addr)) // TLN/VOW ausschließlich über zentrale Projekt-PriceEngine
      .filter(addr => !alreadyPriced[chain + "|" + addr]);

    if (list.length === 0) return;

    // Innerhalb einer Chain bleiben Batches sequenziell (kommt praktisch nie vor,
    // da selten >30 Token pro Chain), aber die Chains selbst laufen jetzt parallel.
    for (let i = 0; i < list.length; i += 30) {
      const batch = list.slice(i, i + 30);
      try {
        const res = await fetch(`https://api.geckoterminal.com/api/v2/simple/networks/${network}/token_price/${batch.join(",")}`);
        if (!res.ok) continue;
        const data = await res.json();
        const attrs = data && data.data && data.data.attributes;
        if (!attrs || !attrs.token_prices) continue;
        Object.keys(attrs.token_prices).forEach(addr => {
          const price = parseFloat(attrs.token_prices[addr]);
          if (!isFinite(price)) return;
          const changeRaw = attrs.h24_price_change_percentage ? attrs.h24_price_change_percentage[addr] : undefined;
          const change = changeRaw !== undefined ? parseFloat(changeRaw) : undefined;
          const key = chain + "|" + normalizeAddress(addr, chain);
          tokenPrices[key] = {
            price,
            change24h: isFinite(change) ? change : undefined,
            source: "GeckoTerminal (DEX)",
            refreshedAt:new Date().toISOString()
          };
        });
      } catch (e) {
        // Fehler bei einer Chain sollen die anderen nicht blockieren
      }
    }
  });
  await Promise.all(chainJobs);
}



function fmtUsd(n) {
  return "$" + Number(n).toLocaleString('de-CH', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function fmtPrice(n) {
  return "$" + Number(n).toLocaleString('de-CH', { minimumFractionDigits: 5, maximumFractionDigits: 5 });
}

// ---- Wallet-Verwaltung (Supabase-gestützt) ----
let walletCounter = 0;
let wallets = [];
let walletData = {}; // id -> { eth:{native, tokens}|{error}, bsc:{...}, matic:{...}, btc:{...}, xrp:{...}, sol:{...} }
let globalWalletPersonFilter = "__own";

function newWallet(label, evm, btc, xrp, sol, tron, akash, dbId, isOwnWallet=true, ownerName="") {
  walletCounter++;
  return {
    id: dbId || ("local" + walletCounter), dbId: dbId || null,
    label: label || ("Wallet " + walletCounter),
    evm: evm || "", btc: btc || "", xrp: xrp || "", sol: sol || "", tron: tron || "", akash: akash || "",
    isOwnWallet:isOwnWallet !== false,
    ownerName:String(ownerName||"").trim()
  };
}

function walletOwnerLabel(w){return w?.isOwnWallet!==false?"Eigenes Wallet":(String(w?.ownerName||"").trim()||"Nicht zugeordnet");}
function walletsForCurrentView(){
  if(globalWalletPersonFilter==="__all")return wallets.slice();
  if(globalWalletPersonFilter==="__own")return wallets.filter(w=>w.isOwnWallet!==false);
  if(globalWalletPersonFilter.startsWith("owner:")){
    const name=globalWalletPersonFilter.slice(6);
    return wallets.filter(w=>w.isOwnWallet===false&&String(w.ownerName||"")===name);
  }
  return wallets.slice();
}
function renderGlobalWalletPersonFilter(){
  const el=document.getElementById("globalWalletPersonFilter");if(!el)return;
  const names=[...new Set(wallets.filter(w=>w.isOwnWallet===false&&w.ownerName).map(w=>w.ownerName))].sort((a,b)=>a.localeCompare(b,"de"));
  const valid=globalWalletPersonFilter==="__all"||globalWalletPersonFilter==="__own"||(globalWalletPersonFilter.startsWith("owner:")&&names.includes(globalWalletPersonFilter.slice(6)));
  if(!valid)globalWalletPersonFilter="__own";
  el.innerHTML=`<option value="__all">Wallets aller Personen</option><option value="__own">Eigene Wallets</option>${names.map(n=>`<option value="owner:${escapeAttr(n)}">${escapeAttr(n)}</option>`).join("")}`;
  el.value=globalWalletPersonFilter;
}
function setGlobalWalletPersonFilter(value){
  globalWalletPersonFilter=String(value||"__own");
  renderDashboard();renderResults();renderWalletNav();renderChartWalletSelect();renderAllocWalletSelect();renderAllocationChart();
  if(document.getElementById("tab-tax")?.classList.contains("active"))renderTaxWalletSelect();
}
window.setGlobalWalletPersonFilter=setGlobalWalletPersonFilter;

// Zentrale Sortierung nach Wallet-Bezeichnung (alphabetisch) - nach jeder Änderung
// aufgerufen, damit ALLE Stellen (Liste, "Gehe zu Wallet", Details je Wallet,
// Discovery-Dropdown) automatisch konsistent sortiert bleiben.
function sortWalletsByLabel() {
  wallets.sort((a, b) => a.label.localeCompare(b.label, "de"));
}

async function walletPrivateSessionReady(forceRefresh=false) {
  const {data,error}=await sb.auth.getSession();
  if(error)throw error;
  let session=data?.session||null;
  if(!session)throw new Error("Sitzung abgelaufen. Bitte neu anmelden.");
  const expiresMs=Number(session.expires_at||0)*1000;
  if(forceRefresh||(expiresMs&&expiresMs-Date.now()<90000)){
    const refreshed=await sb.auth.refreshSession();
    if(refreshed.error||!refreshed.data?.session)throw (refreshed.error||new Error("Sitzung konnte nicht erneuert werden."));
    session=refreshed.data.session;
    if(session.user)currentUser=session.user;
  }
  return session;
}
function walletPrivateAuthStatus(error){
  const status=Number(error?.context?.status||error?.status||0);
  return status===401||status===403;
}
async function invokeWalletPrivate(action, body = {}) {
  await walletPrivateSessionReady(false);
  let lastError=null;
  for(let attempt=0;attempt<2;attempt++){
    const { data, error } = await sb.functions.invoke("wallet-private", {body: { action, ...body }});
    if(!error){
      if (!data?.ok) throw new Error(data?.error || `wallet-private/${action} fehlgeschlagen.`);
      return data;
    }
    lastError=error;
    if(attempt===0&&walletPrivateAuthStatus(error)){
      await walletPrivateSessionReady(true);
      continue;
    }
    break;
  }
  let detail = lastError?.message || String(lastError||"wallet-private fehlgeschlagen");
  try {
    const response = lastError?.context?.clone?.();
    const payload = response ? await response.json() : null;
    if (payload?.error) detail = payload.error;
  } catch (_) {}
  throw new Error(detail);
}
window.walletPrivateSessionReady=walletPrivateSessionReady;
window.invokeWalletPrivate=invokeWalletPrivate;

async function loadWalletsFromDb() {
  try {
    const data = await invokeWalletPrivate("wallet_list");
    wallets = (data.wallets || []).map(row => newWallet(
      row.label,
      row.evm_address,
      row.btc_address,
      row.xrp_address,
      row.sol_address,
      row.tron_address,
      row.akash_address,
      row.id,
      row.is_own_wallet,
      row.owner_name
    ));
    sortWalletsByLabel();
  } catch (error) {
    console.error("Wallets sicher laden:", error);
    wallets = [];
  }
}

function addWallet() {
  wallets.push(newWallet());
  sortWalletsByLabel();
  renderWalletInputs();
}

async function deleteWalletCompletely(w) {
  if (!currentUser || !w?.dbId) throw new Error("Gespeicherte Wallet-ID fehlt.");
  return invokeWalletPrivate("wallet_delete", {wallet_id:String(w.dbId)});
}

function isSupabaseAuthStorageKey(key) {
  const k=String(key||"");
  return /^sb-[^-]+-auth-token$/i.test(k) || /supabase.*auth.*token/i.test(k);
}
function clearWebStorageExceptAuth(storage,preserveAuthSession=false){
  try{
    if(!preserveAuthSession){storage.clear();return;}
    const keep=new Map();
    for(let i=0;i<storage.length;i++){
      const key=storage.key(i);
      if(key && isSupabaseAuthStorageKey(key))keep.set(key,storage.getItem(key));
    }
    storage.clear();
    for(const [key,value] of keep)if(value!=null)storage.setItem(key,value);
  }catch(_){}
}
async function clearWalletTrackingLocalUserData({preserveAuthSession=false}={}) {
  try {
    if (window.WalletTrackingBrowserCache?.destroy) {
      await window.WalletTrackingBrowserCache.destroy();
    } else if ("indexedDB" in window) {
      await new Promise(resolve => {
        const req = indexedDB.deleteDatabase("wallet_tracking_cache");
        req.onsuccess = req.onerror = req.onblocked = () => resolve();
      });
    }
  } catch (e) {
    console.warn("Lokalen WalletTracking-IndexedDB-Cache löschen", e);
  }
  clearWebStorageExceptAuth(localStorage,preserveAuthSession);
  clearWebStorageExceptAuth(sessionStorage,preserveAuthSession);
}

async function deleteAllWalletTrackingUserData() {
  if (!currentUser?.id) {
    alert("Bitte zuerst anmelden.");
    return;
  }

  const typed = prompt(
    "Alle deine in WalletTracking gespeicherten Daten werden unwiderruflich gelöscht.\n\n" +
    "Dazu gehören Wallets, Bestände, Snapshots, 31.12.-Daten, persönliche Token, NFTs, Projekt-/Reward-/Staking-/LP-/Loan-Caches, Partner-Aliase, Support-Nachrichten, UI-Einstellungen sowie Release-/Migrationsstände.\n\n" +
    "Globale öffentliche Blockchain-/Token-/Contract-/Registry-Daten bleiben erhalten. Dein Login-Konto bleibt bestehen.\n\n" +
    "Tippe LÖSCHEN, um fortzufahren:"
  );
  if (typed !== "LÖSCHEN") return;
  if (!confirm("Sind Sie sicher?\n\nAlle WalletTracking-Daten dieses Users werden vollständig gelöscht. Dieser Vorgang kann nicht rückgängig gemacht werden.")) return;

  const btn=document.getElementById("deleteAllUserDataBtn");
  const status=document.getElementById("deleteAllUserDataStatus");
  if(btn){btn.disabled=true;btn.textContent="Daten werden gelöscht…";}
  if(status)status.textContent="Vollständige Löschung läuft…";

  try {
    const result = await invokeWalletPrivate("user_data_delete");
    if(status)status.textContent=`Serverseitig gelöscht${Number(result?.result?.deleted_rows||0)?`: ${Number(result.result.deleted_rows)} Datensätze`: ""}. Lokale Daten werden entfernt…`;

    const keepAdminSession=!!isAdmin;
    if(!keepAdminSession){
      try { await sb.auth.signOut(); } catch (e) { console.warn("Abmelden nach vollständiger Datenlöschung", e); }
    }
    await clearWalletTrackingLocalUserData({preserveAuthSession:keepAdminSession});

    if(keepAdminSession){
      alert("Alle gespeicherten WalletTracking-Daten wurden vollständig gelöscht. Admin-Testmodus: Du bleibst angemeldet und startest jetzt mit leerem WalletTracking neu.");
      location.reload();
    }else{
      alert("Alle gespeicherten WalletTracking-Daten wurden vollständig gelöscht. Dein Login-Konto bleibt bestehen. Du wirst jetzt zur leeren Anwendung zurückgeführt.");
      location.href = REDIRECT_URL;
    }
  } catch (e) {
    console.error("Alle WalletTracking-Userdaten löschen", e);
    if(status)status.textContent="Löschung fehlgeschlagen – es wurde kein erfolgreicher Abschluss bestätigt.";
    alert("Die vollständige Datenlöschung konnte nicht abgeschlossen werden.\n\n" + (e?.message || e));
    if(btn){btn.disabled=false;btn.textContent="Alle WalletTracking-Daten löschen";}
  }
}
window.deleteAllWalletTrackingUserData=deleteAllWalletTrackingUserData;

function clearWalletRelatedMemory(w) {
  const walletId = String(w?.dbId || w?.id || "");
  const localId = String(w?.id || "");
  if (localId) delete walletData[localId];

  nftCaches?.delete?.(walletId);
  discoveryCaches?.delete?.(walletId);
  if (String(currentDiscoveryWalletId?.() || "") === walletId) {
    discoveryCache = null;
    lastDiscoveryFindings = [];
  }

  if (typeof feeCaches !== "undefined" && feeCaches?.keys) {
    for (const key of [...feeCaches.keys()]) if (String(key).startsWith(walletId + "|")) feeCaches.delete(key);
  }
  if (typeof walletRefreshStates !== "undefined" && walletRefreshStates?.keys) {
    for (const key of [...walletRefreshStates.keys()]) if (String(key).startsWith(walletId + "|")) walletRefreshStates.delete(key);
  }

  // Historische/aggregierte Ansichten dürfen nach einer vollständigen Wallet-Löschung
  // keine bereits geladenen Werte der gelöschten Wallet im RAM behalten.
  if (Array.isArray(taxRows)) {
    taxRows = taxRows.filter(r => String(r.wallet_id || "") !== walletId && !(w?.label && r.wallet === w.label));
  }
  taxCoverage = [];
  taxSnapshotLoaded = false;
  taxPriceCache?.clear?.();

  if (Array.isArray(snapshots)) {
    snapshots = snapshots
      .map(s => ({...s,items:(s.items||[]).filter(it=>String(it.wallet_id||"")!==walletId)}))
      .filter(s => (s.items||[]).length > 0);
  }
  snapshotsLoaded = false;
  snapshotsLoadPromise = null;

  // Projekt-Summaries enthalten aggregierte Werte über mehrere Wallets. Die lokale
  // Persistenz wird invalidiert; nach dem folgenden Reload wird sie ausschließlich
  // aus den verbleibenden Wallets/DB-Daten neu aufgebaut.
  try {
    const key = dashboardProjectSummaryStorageKey?.();
    if (key) localStorage.removeItem(key);
  } catch (_) {}
}

async function removeWallet(id) {
  const w = wallets.find(w => w.id === id);
  if (!w) return;

  const persistedText = w.dbId
    ? "Dabei wird diese Wallet vollständig aus WalletTracking gelöscht – inklusive Beständen, manuellen und automatischen Snapshots, Bestand per 31.12., Gebühren, NFTs, Claims/Rewards, Projekt-Transaktionen, LP-/Staking-/Discovery-Daten, Refresh-/Scan-States und allen daraus berechneten userbezogenen Summen/Caches. Globale Blockchain-/Registry-Fakten bleiben erhalten."
    : "Die Wallet ist noch nicht gespeichert und wird nur aus der aktuellen Liste entfernt.";
  if (!confirm(`Wallet "${w.label}" wirklich VOLLSTÄNDIG löschen?\n\n${persistedText}\n\nDieser Vorgang kann nicht rückgängig gemacht werden.`)) return;

  try {
    if (w.dbId) await deleteWalletCompletely(w);
  } catch (e) {
    console.error("Wallet vollständig löschen:", e);
    alert("Die Wallet wurde NICHT vollständig gelöscht.\n\n" + (e.message || e));
    return;
  }

  clearWalletRelatedMemory(w);
  wallets = wallets.filter(x => x.id !== id);

  // Ein kompletter Reload ist hier Absicht: sämtliche userbezogenen Aggregationen,
  // Projekt-Summaries und Caches werden danach aus dem bereinigten DB-Stand neu
  // aufgebaut. So kann keine alte Summe der gelöschten Wallet im RAM stehen bleiben.
  if (w.dbId) {
    alert(`Wallet "${w.label}" wurde vollständig gelöscht. WalletTracking wird neu geladen, damit alle Summen und historischen Ansichten aus den verbleibenden Daten neu aufgebaut werden.`);
    location.reload();
    return;
  }

  renderWalletInputs();
  renderGlobalWalletPersonFilter();
  renderDashboard();
  renderResults();
  renderTaxWalletSelect?.();
  onNftWalletChange?.();
  onDiscoveryWalletChange?.();
  renderFeesSummary?.();
}

function updateWalletField(id, field, value) {
  const w = wallets.find(w => w.id === id);
  if (w) w[field] = value;
  updateAllValidationIcons();
}
function setWalletOwnership(id,isOwn){
  const w=wallets.find(w=>w.id===id);if(!w)return;
  w.isOwnWallet=!!isOwn;
  renderWalletInputs();renderGlobalWalletPersonFilter();renderDashboard();
}
window.setWalletOwnership=setWalletOwnership;

async function initializeSavedWalletTargeted(w,{isNew=false}={}) {
  if(!w||!currentUser)return {skipped:true};
  const started=performance.now(),failures=[],timings={};
  const timed=async(name,fn)=>{
    const t0=performance.now();
    try{return await fn();}
    finally{timings[name]=Math.round(performance.now()-t0);}
  };
  // Nur diese Wallet neu aufbauen. Bestehende Wallets und deren Caches werden nicht breit aktualisiert.
  walletData[w.id]={};
  const chains=Object.keys(CHAIN_CONFIG).filter(c=>CHAIN_CONFIG[c]?.balanceProvider&&walletAddressForChain(w,c));
  await timed("Bestände",async()=>{
    for(const chain of chains){
      try{
        const r=await loadWalletChain(w,chain,false);
        if(r?.ok===false)throw new Error(r.error||"Bestand konnte nicht geladen werden");
        await saveWalletRefreshState(w,chain,'balances',{last_checked_at:new Date().toISOString(),last_refreshed_at:new Date().toISOString(),last_result:'refreshed'});
      }catch(e){failures.push(`${CHAIN_META[chain]?.label||chain}: ${e.message||e}`);}
    }
  });

  // DAO1 besitzt bereits einen gezielten Wallet-Erstaufbau inkl. Apertum-NFT/Ownership/Tx.
  // Audit P1: Der DAO1-Teilstatus wird unverändert bis zum zentralen Abschlussstatus
  // propagiert. apertureHandled ist davon getrennt, damit ein partieller DAO1-Lauf
  // keinen zweiten allgemeinen Apertum-NFT-Scan auslöst.
  let daoHandledApertum=false,daoLifecycle=null;
  await timed("DAO1",async()=>{
    if(w.evm&&window.DAO1Project?.refreshWalletAfterSave){
      try{
        const r=await window.DAO1Project.refreshWalletAfterSave(w.dbId||w.id,{isNew});
        daoHandledApertum=!!(r?.apertureHandled??r?.ok);
        const status=["complete","partial","failed","deferred"].includes(r?.status)?r.status:(r?.ok?"complete":"failed");
        daoLifecycle={status,parts:r?.parts||{},result:r};
        if(status==="failed")failures.push("DAO1/APTMDAO: Lifecycle fehlgeschlagen");
        if(status==="complete")window.setWtDataStatus?.("dao",{updatedAt:new Date().toISOString(),source:"fresh-build",label:"DAO1 Wallet-Erstaufbau"});
      }catch(e){
        daoLifecycle={status:"failed",parts:{},error:e?.message||String(e)};
        failures.push(`DAO1/APTMDAO: ${e.message||e}`);
      }
    }
  });

  // Andere NFT-Chains current-state aktualisieren; Apertum nicht doppelt laden, wenn DAO es bereits erledigt hat.
  await timed("NFTs",async()=>{
    try{
      const nr=await refreshNftsForWallet(w,null,{skipChains:daoHandledApertum?["apertum"]:[]});
      if(nr?.errors?.length)failures.push(...nr.errors.map(x=>`NFT: ${x}`));
      await saveWalletRefreshState(w,'','nft',{last_checked_at:new Date().toISOString(),last_refreshed_at:new Date().toISOString(),last_result:Number(nr?.count||0)===0?'no_nfts':'refreshed'});
    }catch(e){failures.push(`NFTs: ${e.message||e}`);}
  });

  // P3 Fresh-Build-Finalisierung: DAO1 hat Ownership bereits persistent aufgebaut.
  // Der zentrale NFT-Tab muss denselben finalen DB-Stand noch im selben Lauf übernehmen,
  // statt bis zum nächsten Hard-Refresh mit dem Startzustand weiterzurendern. Gleichzeitig
  // wird die Kaufpreis-Evidenz für genau diese neue Wallet aus der frühesten eigenen
  // Erwerbs-Tx nachgezogen.
  await timed("NFT-Finalisierung",async()=>{
    try{
      await loadNftOwnershipCacheFromDb();
      await ensureNftGlobalFirstOwnedLoaded();
      await enrichCentralNftPurchaseEvidence({walletIds:[String(w.dbId||w.id)]});
      lastNftFindings=cachedNftsForSelection();
      renderNftResults(lastNftFindings,[]);
      onNftWalletChange();
    }catch(e){
      console.warn("NFT Fresh-Build Finalisierung",e);
      failures.push(`NFT-Finalisierung: ${e.message||e}`);
    }
  });

  // TLN/VOW aktualisiert nur seine Wallet-Auswahl/Current-State-Verknüpfung, falls das Modul bereits offen war.
  // War es noch nie geöffnet, bleibt der Erstaufbau bewusst lazy und verwendet beim ersten Öffnen die neue DB-Wallet.
  await timed("TLN/VOW",async()=>{
    try{await window.TLNVOWDiscovery?.refreshWalletAfterSave?.(w.dbId||w.id);}catch(e){failures.push(`TLN/VOW: ${e.message||e}`);}
  });

  await timed("Summen",async()=>{
    await mergeTlnBscStakingCacheIntoWalletData().catch(e=>wtReportAsyncIssue("partial","TLN/BSC Staking-Cache Merge",e,{context:"fresh-wallet-sums"}));
    renderResults();renderSafeTokenTable();renderCustomTokenList();renderAllocationChart();renderDashboard();renderWalletDataFreshness();
  });
  // Audit P2 / Snapshot-Gate: Ein automatischer Fresh-Build-Snapshot ist ein
  // finaler Referenzstand. Er darf deshalb nur entstehen, wenn alle erforderlichen
  // Teiljobs vollständig abgeschlossen sind. Der in P1 eingeführte DAO1-Statusvertrag
  // ist dafür die führende Information; partial / deferred / failed werden nicht
  // durch einen Snapshot als scheinbar vollständig konserviert.
  const preSnapshotLifecycleStatus=failures.length?"failed":(daoLifecycle?.status&&daoLifecycle.status!=="complete"?daoLifecycle.status:"complete");
  const snapshotGate={
    status:"deferred",
    eligible:failures.length===0&&preSnapshotLifecycleStatus==="complete",
    reason:failures.length?"Teiljob-Fehler vorhanden":(preSnapshotLifecycleStatus!=="complete"?`Lifecycle ${preSnapshotLifecycleStatus}`:"")
  };
  if(snapshotGate.eligible){
    await timed("Snapshot",async()=>{
      try{
        await createSnapshot(true);
        snapshotGate.status="complete";
        snapshotGate.reason="";
      }catch(e){
        snapshotGate.status="failed";
        snapshotGate.reason=e?.message||String(e);
        failures.push(`Snapshot: ${e.message||e}`);
      }
    });
  }else{
    timings["Snapshot"]=0;
    console.info("Wallet Fresh-Build Snapshot-Gate",{wallet:w.label||w.id,lifecycleStatus:preSnapshotLifecycleStatus,daoLifecycleStatus:daoLifecycle?.status||null,failures:[...failures],snapshotGate});
  }
  await timed("Projekt-Summaries",()=>refreshDashboardProjectSummaries().catch(e=>wtReportAsyncIssue("optional","Projekt-Summaries nach Fresh-Build",e)));
  const durationMs=Math.round(performance.now()-started);
  const detail=Object.entries(timings).map(([name,ms])=>`${name} ${Math.round(ms/100)/10}s`).join(" · ");
  const lifecycleStatus=failures.length?"failed":preSnapshotLifecycleStatus;
  console.info("Wallet-Erstimport Laufzeit",{wallet:w.label||w.id,isNew,durationMs,timings,lifecycleStatus,daoLifecycle,snapshotGate,failures:[...failures]});
  return {ok:lifecycleStatus==="complete",status:lifecycleStatus,parts:{dao1:daoLifecycle,snapshot:snapshotGate},failures,isNew,durationMs,timings,durationText:formatWalletImportDuration(durationMs),detail};
}

function formatWalletImportDuration(ms){
  const sec=Math.max(0,Math.round(Number(ms||0)/1000));
  if(sec<60)return `${sec} Sek.`;
  const min=Math.floor(sec/60),rest=sec%60;
  return `${min} Min. ${String(rest).padStart(2,"0")} Sek.`;
}

async function saveWallet(id) {
  const w = wallets.find(w => w.id === id);
  if (!w) return;
  const isNewWallet = !w.dbId;
  const statusEl = document.getElementById("saveStatus-" + id);

  const invalidFields = ["evm", "btc", "xrp", "sol", "tron", "akash"].filter(f => w[f] && !isValidAddressFormat(f, w[f]));
  if (invalidFields.length > 0) {
    alert("Ungültiges Adressformat bei: " + invalidFields.join(", ") + ". Bitte korrigieren, bevor du speicherst.");
    return;
  }

  const dupeFields = ["evm", "btc", "xrp", "sol", "tron", "akash"].filter(f => findDuplicateWalletLabels(f, w[f], id).length > 0);
  if (dupeFields.length > 0) {
    if (!confirm("Diese Wallet hat dieselbe Adresse wie eine andere erfasste Wallet (" + dupeFields.join(", ") + "). Trotzdem speichern?")) {
      return;
    }
  }
  if(w.isOwnWallet===false&&!String(w.ownerName||"").trim()){
    alert("Bitte den Namen des Besitzers eingeben oder «Eigenes Wallet» aktivieren.");
    return;
  }

  if (statusEl) statusEl.textContent = "Speichere...";

  const walletPayload = {
    id: w.dbId || undefined,
    label: w.label,
    is_own_wallet:w.isOwnWallet!==false,
    owner_name:w.isOwnWallet===false?String(w.ownerName||"").trim():"",
    evm_address: w.evm,
    btc_address: w.btc,
    xrp_address: w.xrp,
    sol_address: w.sol,
    tron_address: w.tron,
    akash_address: w.akash
  };

  try {
    const result = await invokeWalletPrivate("wallet_save", { wallet: walletPayload });
    if (!w.dbId) {
      w.dbId = result.id;
      w.id = result.id;
    }
    if (statusEl) statusEl.textContent = "Gespeichert.";
  } catch (error) {
    console.error("Wallet sicher speichern:", error);
    if (statusEl) statusEl.textContent = "Fehler: " + (error.message || error);
    return;
  }

  sortWalletsByLabel();
  renderWalletInputs();
  renderGlobalWalletPersonFilter();
  renderDashboard();

  // Der Wallet-Aufbau ist fachlich Teil des Speichervorgangs und darf nicht als
  // unsichtbares Promise im Hintergrund weiterlaufen. Der zentrale Datenjob hält
  // „Daten werden geladen …“ sichtbar und sperrt die Navigation bis Bestände,
  // Projekt-/NFT-/Reward-Daten, Summaries und (bei Erfolg) Snapshot fertig sind.
  try{
    const r=await runDataJob(isNewWallet?"Neue Wallet · Daten werden geladen …":"Wallet · Daten werden aktualisiert …",
      ()=>initializeSavedWalletTargeted(w,{isNew:isNewWallet}));
    const freshStatus=document.getElementById("saveStatus-"+w.id);
    const duration=r?.durationText?` · ${r.durationText}`:"";
    if(r?.failures?.length){
      console.warn("Gezielter Wallet-Erstaufbau mit Hinweisen",r.failures,r?.timings||{});
      if(freshStatus)freshStatus.textContent=`Gespeichert · Daten aufgebaut – ${r.failures.length} Teilbereich${r.failures.length===1?"":"e"} mit Fehler${duration}.`;
      renderCacheStatusNote(`Wallet gespeichert · Daten aufgebaut – ${r.failures.length} Teilbereich${r.failures.length===1?"":"e"} mit Fehler${duration}.`);
    }else if(r?.status==="partial"){
      if(freshStatus)freshStatus.textContent=`Gespeichert · Daten teilweise aufgebaut${duration}.`;
      renderCacheStatusNote(`Wallet gespeichert · Lifecycle teilweise abgeschlossen${duration}.`);
    }else if(r?.status==="deferred"){
      if(freshStatus)freshStatus.textContent=`Gespeichert · Datenaufbau teilweise zurückgestellt${duration}.`;
      renderCacheStatusNote(`Wallet gespeichert · Lifecycle teilweise zurückgestellt${duration}.`);
    }else{
      if(freshStatus)freshStatus.textContent=`Gespeichert · Daten vollständig aufgebaut${duration}.`;
      renderCacheStatusNote((isNewWallet?"Neue Wallet vollständig aufgebaut":"Wallet-Daten aktualisiert")+duration+".");
    }
  }catch(e){
    console.warn("Gezielter Erstaufbau nach Wallet-Speicherung",e);
    const freshStatus=document.getElementById("saveStatus-"+w.id);
    if(freshStatus)freshStatus.textContent="Gespeichert · Datenaufbau fehlgeschlagen.";
    renderCacheStatusNote(`Wallet gespeichert · Datenaufbau teilweise fehlgeschlagen: ${e?.message||e}`);
  }
}

// Format-Validierung pro Chain (Länge/Präfix/Zeichensatz) - rein strukturell, keine
// Checksum-Prüfung, aber fängt Tippfehler und falsch eingefügte Adressen zuverlässig ab.
function isValidAddressFormat(field, value) {
  if (!value) return true; // leer = nichts zu prüfen
  const v = value.trim();
  switch (field) {
    case "evm":
      return /^0x[0-9a-fA-F]{40}$/.test(v);
    case "tron":
      return /^T[1-9A-HJ-NP-Za-km-z]{33}$/.test(v);
    case "sol":
      return /^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(v);
    case "xrp":
      return /^r[1-9A-HJ-NP-Za-km-z]{24,34}$/.test(v);
    case "btc":
      return /^(bc1[0-9a-z]{25,62}|[13][1-9A-HJ-NP-Za-km-z]{25,34})$/i.test(v);
    case "akash":
      return /^akash1[02-9ac-hj-np-z]{38}$/.test(v);
    default:
      return true;
  }
}

// Prüft, ob eine Wallet-Adresse in einem anderen Wallet-Eintrag doppelt vorkommt.
// EVM-Adressen werden gross-/kleinschreibungsunabhängig verglichen (Standard bei EVM),
// alle anderen (Tron, Bitcoin, XRP, Solana) exakt - dort ist Gross-/Kleinschreibung relevant.
function walletFieldsMatch(field, a, b) {
  if (!a || !b) return false;
  if (field === "evm") return a.trim().toLowerCase() === b.trim().toLowerCase();
  return a.trim() === b.trim();
}

function findDuplicateWalletLabels(field, value, excludeId) {
  if (!value) return [];
  return wallets.filter(w => w.id !== excludeId && walletFieldsMatch(field, w[field], value)).map(w => w.label);
}

function renderValidationIconInner(field, value, walletId) {
  if (!value) return "";
  if (!isValidAddressFormat(field, value)) {
    return `<span style="color:var(--danger);font-size:0.75rem;display:block;margin-top:3px">✗ Ungültiges Adressformat</span>`;
  }
  const dupes = findDuplicateWalletLabels(field, value, walletId);
  if (dupes.length > 0) {
    return `<span style="color:var(--danger);font-size:0.75rem;display:block;margin-top:3px">✗ Doppelt (auch bei: ${escapeAttr(dupes.join(", "))})</span>`;
  }
  return `<span style="color:#46c878;font-size:0.75rem;display:block;margin-top:3px">✓ eindeutig</span>`;
}

// Leichte Update-Funktion (nur die Icon-Spans, nicht die ganzen Eingabefelder neu rendern) -
// sonst würde bei jedem Tastenanschlag der Fokus aus dem Eingabefeld springen.
function updateAllValidationIcons() {
  ["evm", "btc", "xrp", "sol", "tron", "akash"].forEach(field => {
    wallets.forEach(w => {
      const el = document.getElementById(`dup-${w.id}-${field}`);
      if (el) el.innerHTML = renderValidationIconInner(field, w[field], w.id);
    });
  });
}

function renderEvmWalletChainsNote(){
  const el=document.getElementById("evmWalletChainsNote");
  if(!el)return;
  const labels=Object.keys(CHAIN_CONFIG)
    .filter(c=>CHAIN_CONFIG[c]?.walletType==="evm")
    .map(c=>CHAIN_META[c]?.label||c);
  el.textContent=labels.length
    ? `EVM-Adresse gilt für: ${labels.join(", ")} – sie ist bei allen diesen EVM-Chains dieselbe Adresse.`
    : "Aktuell sind keine EVM-Chains konfiguriert.";
}

function renderWalletInputs() {
  const container = document.getElementById("walletInputsContainer");
  container.innerHTML = wallets.map(w => `
    <div class="wallet-input-card">
      <div class="wallet-input-head">
        <input type="text" value="${escapeAttr(w.label)}" oninput="updateWalletField('${w.id}','label',this.value)" />
        <button class="remove" onclick="removeWallet('${w.id}')">Entfernen</button>
      </div>
      <div class="field-grid">
        <div class="wallet-owner-fields">
          <label class="wallet-own-check"><input type="checkbox" ${w.isOwnWallet!==false?"checked":""} onchange="setWalletOwnership('${w.id}',this.checked)"> <span>Eigenes Wallet</span></label>
          <div>
            <span class="field-label">Besitzer${w.isOwnWallet!==false?" (bei eigenem Wallet nicht erforderlich)":""}</span>
            <input type="text" value="${escapeAttr(w.ownerName)}" ${w.isOwnWallet!==false?"disabled":""} oninput="updateWalletField('${w.id}','ownerName',this.value)" placeholder="Name der Person" />
          </div>
        </div>
        <div>
          <span class="field-label">EVM-Adresse</span>
          <input type="text" value="${escapeAttr(w.evm)}" oninput="updateWalletField('${w.id}','evm',this.value)" placeholder="0x..." />
          <div id="dup-${w.id}-evm">${renderValidationIconInner("evm", w.evm, w.id)}</div>
        </div>
        <div>
          <span class="field-label">Bitcoin-Adresse</span>
          <input type="text" value="${escapeAttr(w.btc)}" oninput="updateWalletField('${w.id}','btc',this.value)" placeholder="bc1... / 1... / 3..." />
          <div id="dup-${w.id}-btc">${renderValidationIconInner("btc", w.btc, w.id)}</div>
        </div>
        <div>
          <span class="field-label">XRP-Adresse</span>
          <input type="text" value="${escapeAttr(w.xrp)}" oninput="updateWalletField('${w.id}','xrp',this.value)" placeholder="r..." />
          <div id="dup-${w.id}-xrp">${renderValidationIconInner("xrp", w.xrp, w.id)}</div>
        </div>
        <div>
          <span class="field-label">Solana-Adresse</span>
          <input type="text" value="${escapeAttr(w.sol)}" oninput="updateWalletField('${w.id}','sol',this.value)" placeholder="Base58-Adresse" />
          <div id="dup-${w.id}-sol">${renderValidationIconInner("sol", w.sol, w.id)}</div>
        </div>
        <div>
          <span class="field-label">Tron-Adresse</span>
          <input type="text" value="${escapeAttr(w.tron)}" oninput="updateWalletField('${w.id}','tron',this.value)" placeholder="T..." />
          <div id="dup-${w.id}-tron">${renderValidationIconInner("tron", w.tron, w.id)}</div>
        </div>
        <div>
          <span class="field-label">Akash-Adresse</span>
          <input type="text" value="${escapeAttr(w.akash)}" oninput="updateWalletField('${w.id}','akash',this.value)" placeholder="akash1..." />
          <div id="dup-${w.id}-akash">${renderValidationIconInner("akash", w.akash, w.id)}</div>
        </div>
      </div>
      <div class="action-row" style="margin:10px 0 0;align-items:center">
        <button onclick="saveWallet('${w.id}')">Speichern</button>
        <span id="saveStatus-${w.id}" class="note" style="margin:0"></span>
      </div>
    </div>
  `).join("");
}

function escapeAttr(s) {
  return String(s || "").replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;");
}

// ---- Datenabruf ----

// EVM-Bestände werden in Phase 1 vollständig über kostenlose öffentliche RPCs geladen.
// Kein Etherscan/Moralis/Alchemy wird für das normale Wallet-Tracking benötigt.

// Generische EVM-RPC-Hilfsfunktionen (für gezielte Balance-Abfrage bekannter Token-Adressen)
async function evmRpcCall(rpcUrl, method, params) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15000);
  try {
    const res = await fetch(rpcUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ jsonrpc: "2.0", id: 1, method, params }),
      signal: controller.signal
    });
    if (!res.ok) throw new Error("RPC HTTP " + res.status);
    const data = await res.json();
    if (data.error) throw new Error(data.error.message);
    return data.result;
  } catch (e) {
    if (e && e.name === "AbortError") throw new Error("RPC Timeout");
    throw e;
  } finally {
    clearTimeout(timeout);
  }
}

function decodeAbiString(hex) {
  if (!hex || hex === "0x") return "";
  try {
    const data = hex.slice(2);
    const lengthHex = data.slice(64, 128);
    const length = parseInt(lengthHex, 16);
    const strHex = data.slice(128, 128 + length * 2);
    const bytes = new Uint8Array(strHex.length / 2);
    for (let i = 0; i < strHex.length; i += 2) {
      bytes[i / 2] = parseInt(strHex.substr(i, 2), 16);
    }
    const str = new TextDecoder("utf-8").decode(bytes);
    return str.replace(/\0/g, "").trim();
  } catch (e) {
    return "";
  }
}

async function fetchNativeViaRpc(rpcUrl, address) {
  const result = await evmRpcCall(rpcUrl, "eth_getBalance", [address, "latest"]);
  return Number(BigInt(result)) / 1e18;
}

// Bündelt mehrere eth_call-Anfragen in einer einzigen HTTP-Anfrage (JSON-RPC Batch),
// statt für jeden Token einzeln zum Server zu gehen - das ist der Haupt-Geschwindigkeitshebel.
async function evmRpcBatch(rpcUrl, calls) {
  if (calls.length === 0) return [];

  // Kleine Batches sind bei öffentlichen RPCs stabiler als ein sehr großer Request.
  const MAX_CALLS = 40;
  if (calls.length > MAX_CALLS) {
    const all = [];
    for (let i = 0; i < calls.length; i += MAX_CALLS) {
      const part = await evmRpcBatch(rpcUrl, calls.slice(i, i + MAX_CALLS));
      all.push(...part);
      if (i + MAX_CALLS < calls.length) await new Promise(r => setTimeout(r, 80));
    }
    return all;
  }

  const body = calls.map((c, i) => ({
    jsonrpc: "2.0",
    id: i,
    method: "eth_call",
    params: [{ to: c.to, data: c.data }, "latest"]
  }));
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 20000);
  try {
    const res = await fetch(rpcUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
      signal: controller.signal
    });
    if (!res.ok) throw new Error("RPC HTTP " + res.status);
    const data = await res.json();
    const arr = Array.isArray(data) ? data : [data];
    const byId = {};
    arr.forEach(d => { byId[d.id] = d; });
    return calls.map((c, i) => {
      const d = byId[i];
      if (!d || d.error) return null;
      return d.result;
    });
  } catch (e) {
    if (e && e.name === "AbortError") throw new Error("RPC Timeout");
    throw e;
  } finally {
    clearTimeout(timeout);
  }
}

// Cache für Dezimalstellen/Symbol pro Chain+Adresse - diese ändern sich nie,
// darum werden sie nur einmal abgefragt statt für jede Wallet neu. Wird dauerhaft
// in localStorage gespeichert: nach dem allerersten Laden entfällt dieser Abruf
// bei jedem weiteren Seitenaufruf komplett, auch nach einem Browser-Neustart.
const TOKEN_META_CACHE_KEY = "tokenMetaCache";
const TOKEN_META_CACHE_VERSION_KEY = "tokenMetaCacheVersion";
const TOKEN_META_CACHE_VERSION = 3; // hochzählen, wenn sich das Cache-Format/die Dekodierung ändert
let tokenMetaCache = {};

function loadTokenMetaCache() {
  try {
    const storedVersion = localStorage.getItem(TOKEN_META_CACHE_VERSION_KEY);
    if (storedVersion !== String(TOKEN_META_CACHE_VERSION)) {
      // Alter/fehlerhafter Cache (z.B. falsch dekodierte Sonderzeichen) - verwerfen und neu aufbauen
      localStorage.removeItem(TOKEN_META_CACHE_KEY);
      localStorage.setItem(TOKEN_META_CACHE_VERSION_KEY, String(TOKEN_META_CACHE_VERSION));
      tokenMetaCache = {};
      return;
    }
    const raw = localStorage.getItem(TOKEN_META_CACHE_KEY);
    tokenMetaCache = raw ? JSON.parse(raw) : {};
  } catch (e) {
    tokenMetaCache = {};
  }
}

function saveTokenMetaCache() {
  try {
    localStorage.setItem(TOKEN_META_CACHE_KEY, JSON.stringify(tokenMetaCache));
  } catch (e) {
    // localStorage evtl. nicht verfügbar - dann gilt der Cache nur für diese Sitzung
  }
}

// Lädt ERC-20-Metadaten auch für historisch gefundene Token ohne aktuellen Bestand.
// Dadurch zeigt Discovery nicht nur die Contract-Adresse, sondern Symbol/Name/Decimals.
async function fetchEvmTokenMetadata(chain, addresses) {
  const unique=[...new Set((addresses||[]).map(a=>normalizeAddress(a,chain)).filter(a=>/^0x[0-9a-f]{40}$/i.test(a)))];
  const out={};
  for(let start=0;start<unique.length;start+=30){
    const chunk=unique.slice(start,start+30),calls=[],plan=[];
    chunk.forEach((a,idx)=>{
      const k=chain+"|"+a,cached=tokenMetaCache[k]||{};
      if(cached.symbol&&cached.name&&Number.isFinite(Number(cached.decimals))){out[a]=cached;return;}
      calls.push({to:a,data:"0x313ce567"});plan.push({idx,type:"decimals"});
      calls.push({to:a,data:"0x95d89b41"});plan.push({idx,type:"symbol"});
      calls.push({to:a,data:"0x06fdde03"});plan.push({idx,type:"name"});
    });
    if(!calls.length)continue;
    try{
      const results=await evmRpcBatch(configuredRpcUrl(chain),calls),per=chunk.map(()=>({}));
      results.forEach((hex,i)=>{const x=plan[i];per[x.idx][x.type]=hex;});
      chunk.forEach((a,idx)=>{
        const k=chain+"|"+a,old=tokenMetaCache[k]||{},x=per[idx];
        const dec=x.decimals&&x.decimals!=="0x"?parseInt(x.decimals,16):Number(old.decimals);
        const meta={decimals:Number.isFinite(dec)?dec:(predefinedTokenDecimals[k]??18),symbol:decodeAbiString(x.symbol)||old.symbol||predefinedTokenSymbols[k]||a.slice(0,8)+"…",name:decodeAbiString(x.name)||old.name||predefinedTokenNames[k]||null};
        tokenMetaCache[k]=meta;out[a]=meta;
      });
      saveTokenMetaCache();
    }catch(e){console.warn("Token-Metadaten",chain,e);}
  }
  unique.forEach(a=>{if(!out[a]&&tokenMetaCache[chain+"|"+a])out[a]=tokenMetaCache[chain+"|"+a];});
  return out;
}

// Prüft gezielt die Balance der sicheren + selbst erfassten Token für eine Chain,
// gebündelt in möglichst wenigen Anfragen (kein Auto-Discovery unbekannter Token,
// siehe Erklärung im Chat).
async function fetchKnownTokenBalances(rpcUrl, address, chain) {
  const list = (SAFE_ADDRESSES[chain] || []).map(a => ({ address: a, label: null }))
    .concat(customSafeTokens.filter(t => t.chain === chain).map(t => ({ address: t.address, label: t.label })));

  const seen = new Set();
  const unique = list.filter(t => {
    if (seen.has(t.address)) return false;
    seen.add(t.address);
    return true;
  });
  if (unique.length === 0) return [];

  // Balance IMMER abfragen, Dezimalstellen/Symbol nur für noch nicht gecachte Token -
  // alles zusammen in einer einzigen Anfrage (ein Netzwerk-Umlauf statt zwei).
  const balanceData = "0x70a08231" + address.toLowerCase().replace("0x", "").padStart(64, "0");
  const calls = [];
  const plan = []; // parallel zu calls: was die jeweilige Antwort bedeutet

  unique.forEach((t, idx) => {
    calls.push({ to: t.address, data: balanceData });
    plan.push({ idx, type: "balance" });

    const cacheKey = chain + "|" + t.address;
    if (!tokenMetaCache[cacheKey]) {
      calls.push({ to: t.address, data: "0x313ce567" });
      plan.push({ idx, type: "decimals" });
      calls.push({ to: t.address, data: "0x95d89b41" });
      plan.push({ idx, type: "symbol" });
    }
  });

  const results = await evmRpcBatch(rpcUrl, calls);

  const perToken = unique.map(() => ({}));
  results.forEach((hex, i) => {
    const { idx, type } = plan[i];
    perToken[idx][type] = hex;
  });

  const withBalance = [];
  let cacheChanged = false;
  unique.forEach((t, idx) => {
    const hex = perToken[idx].balance;
    if (!hex || hex === "0x") return;
    const raw = BigInt(hex);
    if (raw <= 0n) return;

    const cacheKey = chain + "|" + t.address;
    if (!tokenMetaCache[cacheKey]) {
      const decHex = perToken[idx].decimals;
      const decimals = decHex && decHex !== "0x" ? parseInt(decHex, 16) : 18;
      const symbol = t.label || decodeAbiString(perToken[idx].symbol) || (t.address.slice(0, 8) + "…");
      tokenMetaCache[cacheKey] = { decimals, symbol };
      cacheChanged = true;
    }
    const meta = tokenMetaCache[cacheKey];
    withBalance.push({
      symbol: meta.symbol,
      address: t.address,
      amount: Number(raw) / Math.pow(10, meta.decimals)
    });
  });
  if (cacheChanged) saveTokenMetaCache();

  return withBalance;
}

async function fetchEvmAddressInfo(chain, rpcUrl, address) {
  // Nativer Coin + ausschließlich vordefinierte/eigene sichere Token.
  const [native, tokens] = await Promise.all([
    fetchNativeViaRpc(rpcUrl, address),
    fetchKnownTokenBalances(rpcUrl, address, chain)
  ]);
  return { native, tokens };
}

function configuredBalanceBase(chain) {
  const cfg = CHAIN_CONFIG[chain] || {};
  const base = cfg.balanceApiBase || cfg.rpcUrl;
  if (!cfg.balanceProvider || !base) {
    throw new Error(`${CHAIN_META[chain]?.label || chain}: Balance-Provider/API-Basis fehlt in public.chains`);
  }
  return base.replace(/\/+$/, "");
}

async function fetchBitcoinBalance(chain, address) {
  const base = configuredBalanceBase(chain);
  const res = await fetch(`${base}/address/${address}`);
  if (!res.ok) throw new Error("HTTP " + res.status);
  const data = await res.json();
  const funded = data.chain_stats.funded_txo_sum + data.mempool_stats.funded_txo_sum;
  const spent = data.chain_stats.spent_txo_sum + data.mempool_stats.spent_txo_sum;
  return (funded - spent) / 1e8;
}

async function fetchXrpBalance(chain, address) {
  const base = configuredBalanceBase(chain);
  const res = await fetch(`${base}/account/${address}`);
  if (!res.ok) throw new Error("HTTP " + res.status);
  const data = await res.json();
  if (data.xrpBalance === undefined) throw new Error("Keine Balance gefunden");
  return parseFloat(data.xrpBalance);
}

const SOLANA_TOKEN_PROGRAMS = [
  "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA",
  "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
];

async function solanaRpc(chain,method,params){
  const cfg=CHAIN_CONFIG[chain]||{};
  if(String(cfg.archiveRpcProvider||"").toLowerCase()!=="alchemy"||!cfg.archiveRpcUrl)throw new Error(`${CHAIN_META[chain]?.label||chain}: Alchemy-Solana-RPC ist in public.chains nicht konfiguriert.`);
  return archiveRpc(chain,method,params);
}


async function fetchSolanaAddressInfo(chain, address) {
  const [balanceResult, ...tokenResults] = await Promise.all([
    solanaRpc(chain, "getBalance", [address]),
    ...SOLANA_TOKEN_PROGRAMS.map(programId =>
      solanaRpc(chain, "getTokenAccountsByOwner", [
        address,
        { programId },
        { encoding:"jsonParsed", commitment:"confirmed" }
      ]).catch(e => {
        console.warn("Solana Token-Programm konnte nicht gelesen werden:", programId, e);
        return { value:[] };
      })
    )
  ]);

  const native = Number(balanceResult?.value || 0) / 1e9;
  const byMint = new Map();

  tokenResults.forEach(result => {
    (result?.value || []).forEach(row => {
      const info = row?.account?.data?.parsed?.info;
      const mint = info?.mint;
      const ta = info?.tokenAmount;
      if (!mint || !ta) return;

      const amount = ta.uiAmount !== null && ta.uiAmount !== undefined
        ? Number(ta.uiAmount)
        : Number(ta.uiAmountString || 0);
      if (!Number.isFinite(amount) || amount <= 0) return;

      const previous = byMint.get(mint);
      if (previous) {
        previous.amount += amount;
      } else {
        byMint.set(mint, {
          address: mint,
          symbol: mint.slice(0, 6) + "…" + mint.slice(-4),
          name: null,
          decimals: Number(ta.decimals || 0),
          amount
        });
      }
    });
  });

  return { native, tokens:[...byMint.values()] };
}

async function fetchSolanaBalance(chain, address) {
  const result = await solanaRpc(chain, "getBalance", [address]);
  return Number(result?.value || 0) / 1e9;
}

// ---- Tron (native TRX, vorerst ohne TRC20-Token) ----
// ---- Tron: nativer TRX-Bestand + sichere TRC20-Token (z.B. USDT-TRC20) ----
// Bekannte TRC20-Dezimalstellen - TronGrid liefert nur den rohen Betrag, keine Dezimalstellen.
// Deckt aktuell die grossen Stablecoins ab (alle 6 Dezimalstellen, Branchenstandard).
const TRON_TOKEN_DECIMALS_DEFAULT = 6;


async function fetchAkashBalance(chain, address) {
  // Akash Mainnet REST/LCD (Cosmos SDK Bank-Modul). AKT ist on-chain als uakt
  // mit 6 Dezimalstellen denominiert.
  const base = configuredBalanceBase(chain);
  const res = await fetch(`${base}/cosmos/bank/v1beta1/balances/${encodeURIComponent(address)}`);
  if (!res.ok) throw new Error("HTTP " + res.status);
  const data = await res.json();
  const balance = (data.balances || []).find(b => b.denom === "uakt");
  return balance ? Number(balance.amount || 0) / 1e6 : 0;
}

async function fetchTronAddressInfo(chain, address) {
  const base = configuredBalanceBase(chain);
  const res = await fetch(`${base}/v1/accounts/${address}`);
  if (!res.ok) throw new Error("HTTP " + res.status);
  const data = await res.json();
  if (!data.success) throw new Error(data.error || "Unbekannter Fehler");
  const account = (data.data || [])[0];
  const native = account && account.balance ? account.balance / 1e6 : 0;

  // Volle Liste (nicht vorab gefiltert) - so kann sowohl die normale Ansicht (nur sichere
  // Token, siehe chainRows) als auch die "Entdecken"-Funktion (auch unsichere Token) darauf zugreifen.
  const tokens = [];
  const trc20List = (account && account.trc20) || [];
  trc20List.forEach(entry => {
    const contractAddress = Object.keys(entry)[0];
    const rawStr = entry[contractAddress];
    if (!contractAddress || !rawStr) return;

    const raw = BigInt(rawStr);
    if (raw <= 0n) return;

    const normalizedContract = normalizeAddress(contractAddress, "tron");
    if (!isSafeTokenAddress(normalizedContract, "tron")) return;
    const custom = customSafeTokens.find(t => t.chain === "tron" && t.address === normalizedContract);
    const label = predefinedTokenLabels["tron|" + normalizedContract] || (custom ? custom.label : null) || (contractAddress.slice(0, 8) + "…");
    tokens.push({
      symbol: label,
      address: normalizedContract,
      amount: Number(raw) / Math.pow(10, TRON_TOKEN_DECIMALS_DEFAULT)
    });
  });

  return { native, tokens };
}

// ---- Apertum (EVM, chain-id 2786) ----
// Der kostenlose Blockscout-Explorer liefert die Wallet-Tokenliste; fürs normale
// Tracking übernehmen wir daraus ausschließlich vordefinierte/eigene sichere Token.
async function fetchApertumAddressInfo(chain, address) {
  const base = configuredBalanceBase(chain);
  const [balRes, tokRes] = await Promise.all([
    fetch(`${base}/addresses/${address}`),
    fetch(`${base}/addresses/${address}/tokens?type=ERC-20`)
  ]);
  if (!balRes.ok) throw new Error("HTTP " + balRes.status + " (Balance)");
  const balData = await balRes.json();
  const native = balData.coin_balance ? Number(BigInt(balData.coin_balance)) / 1e18 : 0;

  let tokens = [];
  if (tokRes.ok) {
    const tokData = await tokRes.json();
    tokens = (tokData.items || [])
      .filter(item => item.token)
      .map(item => {
        const decimals = parseInt(item.token.decimals || "18", 10);
        const raw = BigInt(item.value || "0");
        return {
          symbol: item.token.symbol || item.token.name || "?",
          address: (item.token.address || "").toLowerCase(),
          amount: Number(raw) / Math.pow(10, decimals)
        };
      })
      .filter(t => t.amount >= DUST_THRESHOLD && isSafeTokenAddress(t.address, chain));
  }
  return { native, tokens };
}

function walletAddressForChain(wallet, chain) {
  const type = CHAIN_CONFIG[chain]?.walletType;
  const fields = { evm:"evm", btc:"btc", xrp:"xrp", sol:"sol", tron:"tron", akash:"akash" };
  const field = fields[type];
  return field ? wallet?.[field] : null;
}

async function loadWalletChain(wallet, chain, preserveCachedOnError = false) {
  walletData[wallet.id] = walletData[wallet.id] || {};
  const previous = walletData[wallet.id][chain];
  const cfg = CHAIN_CONFIG[chain] || {};
  const address = walletAddressForChain(wallet, chain);

  if (!address) {
    delete walletData[wallet.id][chain];
    return { ok:true, skipped:true };
  }

  try {
    let native = 0;
    let tokens = [];

    switch (cfg.balanceProvider) {
      case "evm_rpc": {
        const r = await fetchEvmAddressInfo(chain, configuredRpcUrl(chain), address);
        native = r.native; tokens = r.tokens || [];
        break;
      }
      case "blockscout": {
        const r = await fetchApertumAddressInfo(chain, address);
        native = r.native; tokens = r.tokens || [];
        break;
      }
      case "blockstream":
        native = await fetchBitcoinBalance(chain, address);
        break;
      case "xrpscan":
        native = await fetchXrpBalance(chain, address);
        break;
      case "solana_rpc": {
        const r = await fetchSolanaAddressInfo(chain, address);
        native = r.native; tokens = r.tokens || [];
        break;
      }
      case "trongrid": {
        const r = await fetchTronAddressInfo(chain, address);
        native = r.native; tokens = r.tokens || [];
        break;
      }
      case "akash_rest":
        native = await fetchAkashBalance(chain, address);
        break;
      default:
        throw new Error(`Balance-Provider "${cfg.balanceProvider || "–"}" ist nicht implementiert`);
    }

    walletData[wallet.id][chain] = {
      native,
      nativeSymbol: NATIVE_SYMBOL[chain] || chain.toUpperCase(),
      tokens
    };
    return { ok:true };
  } catch (err) {
    if (preserveCachedOnError && previous && !previous.error) {
      walletData[wallet.id][chain] = previous;
    } else {
      walletData[wallet.id][chain] = { error:err.message };
    }
    return { ok:false, error:err.message };
  }
}

async function mergeTlnBscStakingCacheIntoWalletData(){
  if(!window.WalletLPEngine)return;
  const chain="bsc",projectKey="tln_vow";
  const targets=wallets.map(w=>({w,wa:walletAddressForChain(w,chain)})).filter(x=>x.wa);
  let batchByWallet=null;
  if(window.WalletLPEngine.loadPositionCacheBatch){
    try{batchByWallet=await window.WalletLPEngine.loadPositionCacheBatch(projectKey,chain,targets.map(x=>x.wa));}
    catch(e){console.warn("TLN/VOW Staking-Cache Batch",e);}
  }
  for(const {w,wa} of targets){
    let cached=[];
    try{cached=batchByWallet?.get(normalizeAddress(wa,chain))||(!batchByWallet?await window.WalletLPEngine.loadPositionCache(projectKey,chain,wa):[]);}
    catch(e){console.warn("TLN/VOW Staking-Cache",w.label,e);continue;}
    if(!walletData[w.id]?.[chain])walletData[w.id][chain]={native:null,nativeSymbol:CHAIN_META[chain]?.nativeSymbol||"BNB",tokens:[]};
    const cd=walletData[w.id][chain];if(cd.error)continue;cd.tokens=cd.tokens||[];
    for(const c of cached||[]){
      const staked=Number(c.current_staked_lp||0);if(staked<=DUST_THRESHOLD)continue;
      const addr=normalizeAddress(c.pair_address,chain),key=chain+"|"+addr;
      let t=cd.tokens.find(x=>normalizeAddress(x.address,chain)===addr);
      if(!t){t={symbol:predefinedTokenSymbols[key]||c.lp_label||"PCLP",address:addr,amount:0};cd.tokens.push(t);}
      const walletOnly=Number(t._walletOnlyAmount??t.amount??0);t._walletOnlyAmount=walletOnly;t.stakingAmount=staked;t.amount=walletOnly+staked;
      t.lpInfo={lpLabel:c.lp_label||"PCLP",t0:{address:c.token0_address,symbol:c.token0_symbol||"Token0",decimals:Number(c.token0_decimals||18)},t1:{address:c.token1_address,symbol:c.token1_symbol||"Token1",decimals:Number(c.token1_decimals||18)},balance:t.amount,walletBalance:walletOnly,stakedBalance:staked,amount0:Number(c.current_amount0||0),amount1:Number(c.current_amount1||0),share:Number(c.current_share||0),usd:c.current_usd==null?null:Number(c.current_usd)};
    }
  }
}


// ---- Zentraler Refresh-/Activity-Status (Phase 2au) ----
// Supabase ist bewusst die Quelle: 1x täglich gilt damit pro Wallet auch geräteübergreifend.
let walletRefreshStates = new Map();

// Fachliche Cache-/Algorithmus-Versionen.
// Nur erhöhen, wenn vorhandene Cache-Daten fachlich neu aufgebaut werden müssen.
// Die Versionsprüfung steht IMMER vor Tageslimit und Activity-Check.
const DATA_VERSIONS = Object.freeze({
  balances: 1,
  nft: 1,
  "project:tln_vow:bsc": 7
});
function requiredDataVersion(chain,dataType){
  return Number(DATA_VERSIONS[`${dataType}:${chain}`] ?? DATA_VERSIONS[dataType] ?? 1);
}
const refreshStateKey=(walletId,chain,dataType)=>`${String(walletId)}|${chain||''}|${dataType}`;
function refreshStateCurrent(w,chain,dataType){
  const r=walletRefreshStates.get(refreshStateKey(walletDbId(w),chain,dataType));
  return !!r && Number(r.data_version||0) >= requiredDataVersion(chain,dataType);
}
function needsDataRebuild(w,chain,dataType){ return !refreshStateCurrent(w,chain,dataType); }
function walletDbId(w){return String(w?.dbId||w?.id||'');}
function localDayKey(v){const d=v instanceof Date?v:new Date(v);if(isNaN(d.getTime()))return '';return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;}
function refreshedToday(w,chain,dataType){const r=walletRefreshStates.get(refreshStateKey(walletDbId(w),chain,dataType));return refreshStateCurrent(w,chain,dataType)&&!!r?.last_checked_at&&localDayKey(r.last_checked_at)===localDayKey(new Date());}
async function loadWalletRefreshStates(){
  walletRefreshStates=new Map();if(!currentUser)return;
  const {data,error}=await sb.from('wallet_refresh_state').select('*').eq('user_id',currentUser.id);
  if(error){console.warn('wallet_refresh_state:',error);return;}
  for(const r of data||[])walletRefreshStates.set(refreshStateKey(r.wallet_id,r.chain_key,r.data_type),r);
}
async function saveWalletRefreshState(w,chain,dataType,patch={}){
  const payload={user_id:currentUser.id,wallet_id:walletDbId(w),chain_key:chain||'',data_type:dataType,data_version:requiredDataVersion(chain,dataType),updated_at:new Date().toISOString(),...patch};
  const {data,error}=await sb.from('wallet_refresh_state').upsert(payload,{onConflict:'user_id,wallet_id,chain_key,data_type'}).select().single();
  if(error){console.warn('Refresh-Status speichern:',error);return null;}
  walletRefreshStates.set(refreshStateKey(payload.wallet_id,payload.chain_key,payload.data_type),data);return data;
}
function confirmedSpamAddressesForWallet(w,chain){
  const cache=discoveryCaches.get(walletDbId(w));const out=new Set();
  for(const f of (cache?.findings||[]))if(f?.userMarkedScam&&f.chain===chain&&f.address)out.add(normalizeAddress(f.address,chain));
  return out;
}
async function evmRelevantActivitySince(w,chain,state){
  // Nur ein vom User bestätigtes Spam-Token wird ignoriert. System-Verdacht allein reicht nicht.
  const address=walletAddressForChain(w,chain);if(!address)return {changed:false,latestBlock:null,reason:'keine Adresse'};
  const latestBlock=await window.WalletLPEngine?.latestBlock?.(chain).catch(()=>null);
  const fromBlock=Math.max(0,Number(state?.last_checked_block||0)+1);
  if(!state?.last_checked_at||!Number(state?.last_checked_block||0))return {changed:true,latestBlock,reason:'Erstprüfung'};
  // Der zuverlässigste vorhandene EVM-Activity-Pfad ist Alchemy Asset Transfers: native + ERC20, ein/ausgehend.
  if(CHAIN_CONFIG[chain]?.discoveryProvider==='alchemy'){
    const spam=confirmedSpamAddressesForWallet(w,chain);
    for(const direction of ['fromAddress','toAddress']){
      let pageKey=null,pages=0;
      do{
        const q={fromBlock:taxBlockHex(fromBlock),toBlock:'latest',category:['external','erc20','erc721','erc1155'],withMetadata:false,excludeZeroValue:false,maxCount:'0x3e8'};q[direction]=address;if(pageKey)q.pageKey=pageKey;
        const r=await alchemyRpc(chain,'alchemy_getAssetTransfers',[q],'discovery');
        for(const t of (r?.transfers||[])){
          const contract=t.rawContract?.address?normalizeAddress(t.rawContract.address,chain):null;
          if(contract&&spam.has(contract))continue;
          return {changed:true,latestBlock,reason:contract?'relevanter Token-Transfer':'native Aktivität'};
        }
        pageKey=r?.pageKey||null;pages++;
      }while(pageKey&&pages<20);
    }
    return {changed:false,latestBlock,reason:'keine relevante Aktivität'};
  }
  // Ohne geeigneten Activity-Indexer wird aus Sicherheitsgründen aktualisiert statt Aktivität zu übersehen.
  return {changed:true,latestBlock,reason:'kein sicherer Activity-Indexer'};
}
function renderCentralRefreshProgress(lines=[],options={}){
  const el=document.getElementById('centralRefreshProgress');if(!el)return;
  if(!lines.length){el.innerHTML='';return;}
  const collapsed=options.collapsed===true;
  const finished=options.finished===true;
  const summary=finished?'Datenaktualisierung · abgeschlossen':'Datenaktualisierung · läuft…';
  el.innerHTML=`<details class="custom-token-card" ${collapsed?'':'open'}>
    <summary style="cursor:pointer;font-weight:700;user-select:none">${summary}</summary>
    <div class="note" style="margin-top:9px">${lines.map(x=>escapeAttr(x)).join('<br>')}</div>
  </details>`;
}
async function refreshNftsForWallet(w,onProgress=null,options={}){
  const allChains=nftChains(),skipChains=new Set((options?.skipChains||[]).map(String));
  const onlyChains=Array.isArray(options?.onlyChains)?new Set(options.onlyChains.map(String)):null;
  const chains=allChains.filter(c=>(!onlyChains||onlyChains.has(c))&&!skipChains.has(c));
  const refreshSet=new Set(chains);
  const old=nftCaches.get(walletDbId(w));
  let walletNfts=((old?.nfts)||[]).filter(n=>!refreshSet.has(String(n?.chain||""))),errors=[];
  for(const chain of chains){
    if(!walletAddressForChain(w,chain))continue;
    try{
      onProgress?.(chain);
      const provider=CHAIN_CONFIG[chain]?.nftProvider;let found=[];
      if(provider==='blockscout')found=await fetchApertumNfts(chain,walletAddressForChain(w,chain));
      else if(provider==='alchemy')found=await fetchNftsForChain(chain,walletAddressForChain(w,chain));
      else continue;
      found.forEach(n=>{n.walletLabel=w.label;n.walletId=walletDbId(w);});
      const oldMap=new Map(((old?.nfts)||[]).map(n=>[nftKey(n),{
        spam:!!n.userMarkedSpam,safe:!!n.userMarkedSafe,
        acquiredAt:n.acquiredAt||null,acquiredBlock:n.acquiredBlock||null,acquisitionTxHash:n.acquisitionTxHash||null,acquisitionSource:n.acquisitionSource||null,
        image:n.image||null,imageSource:n.imageSource||null,metadataUri:n.metadataUri||null,metadataMethod:n.metadataMethod||null,
        name:n.name||null,nameSource:n.nameSource||null,collectionName:n.collectionName||null,purchaseEvidence:n.purchaseEvidence||null
      }]));
      found.forEach(n=>{
        const f=oldMap.get(nftKey(n));if(!f)return;
        if(f.spam)n.userMarkedSpam=true;if(f.safe)n.userMarkedSafe=true;
        if(!n.acquiredAt&&f.acquiredAt)n.acquiredAt=f.acquiredAt;if(!n.acquiredBlock&&f.acquiredBlock)n.acquiredBlock=f.acquiredBlock;
        if(!n.acquisitionTxHash&&f.acquisitionTxHash)n.acquisitionTxHash=f.acquisitionTxHash;if(!n.acquisitionSource&&f.acquisitionSource)n.acquisitionSource=f.acquisitionSource;
        if(!n.image&&f.image)n.image=f.image;if(!n.imageSource&&f.imageSource)n.imageSource=f.imageSource;
        if(!n.metadataUri&&f.metadataUri)n.metadataUri=f.metadataUri;if(!n.metadataMethod&&f.metadataMethod)n.metadataMethod=f.metadataMethod;
        if(f.name)n.name=bestNftName(n.tokenId,n.collectionName||f.collectionName,n.name,f.name);if(!n.nameSource&&f.nameSource)n.nameSource=f.nameSource;if(!n.collectionName&&f.collectionName)n.collectionName=f.collectionName;
        if(!n.purchaseEvidence&&f.purchaseEvidence)n.purchaseEvidence=f.purchaseEvidence;
      });
      walletNfts.push(...found);
    }catch(e){
      errors.push(`${CHAIN_META[chain]?.label||chain}: ${e.message}`);
      // Bei Teilfehlern niemals den zuletzt bestätigten Bestand dieser Chain wegwerfen.
      walletNfts.push(...((old?.nfts)||[]).filter(n=>String(n?.chain||"")===chain));
    }
  }
  await saveNftCacheForWallet(w,walletNfts,[...new Set([...(old?.selected_chains||[]),...chains])]);return {errors,count:walletNfts.length};
}
async function refreshProjectWallet(w,projectKey='tln_vow',chain='bsc'){
  if(!walletAddressForChain(w,chain))return {skipped:true};
  const scratch=document.getElementById('centralProjectRefreshScratch');
  if(!scratch)return {skipped:true};
  const rr=await renderProjectLpTab(projectKey,[chain],'centralProjectRefreshScratch','2025-12-31',true,{walletId:walletDbId(w),silent:true});
  if(rr?.errors?.length)throw new Error(rr.errors.join(' · '));
  await saveWalletRefreshState(w,chain,`project:${projectKey}`,{last_checked_at:new Date().toISOString(),last_refreshed_at:new Date().toISOString(),last_result:'refreshed'});
  return {ok:true};
}
const projectAutoRefreshInFlight=new Map();
async function maybeAutoRefreshProject(projectKey,chain,targetId){
  const flightKey=`${projectKey}|${chain}`;
  if(projectAutoRefreshInFlight.has(flightKey))return projectAutoRefreshInFlight.get(flightKey);
  const job=(async()=>{
    const eligible=wallets.filter(w=>walletAddressForChain(w,chain)&&!refreshedToday(w,chain,`project:${projectKey}`));
    if(!eligible.length)return renderProjectLpTab(projectKey,[chain],targetId,'2025-12-31',false);
    const scratch=document.getElementById('centralProjectRefreshScratch');
    for(const w of eligible){try{const rebuild=needsDataRebuild(w,chain,`project:${projectKey}`);if(scratch)scratch.innerHTML=`<div class="note">${escapeAttr(w.label)} · ${escapeAttr(CHAIN_META[chain]?.label||chain)} ${rebuild?'Projekt-Cache wird wegen neuer Datenlogik neu aufgebaut…':'Projekt-Daten werden automatisch aktualisiert…'}</div>`;await refreshProjectWallet(w,projectKey,chain);}catch(e){console.warn('Projekt-Autoload',w.label,e);}}
    return renderProjectLpTab(projectKey,[chain],targetId,'2025-12-31',false);
  })();
  projectAutoRefreshInFlight.set(flightKey,job);
  try{return await job;}finally{projectAutoRefreshInFlight.delete(flightKey);}
}

function renderWalletDataFreshness(){
  const el=document.getElementById('walletDataFreshness');if(!el)return;
  const fmtState=(r,required=1)=>{if(!r?.last_checked_at)return 'noch nie geprüft';if(Number(r.data_version||0)<Number(required||1))return `Neuaufbau erforderlich · Cache v${Number(r.data_version||0)}, Soll v${required}`;const checked=new Date(r.last_checked_at).toLocaleString('de-CH');if(r.last_result==='no_relevant_activity')return `geprüft ${checked} · keine relevante Aktivität`;if(r.last_result==='no_nfts')return `geprüft ${checked} · keine NFTs gefunden`;const refreshed=r.last_refreshed_at?new Date(r.last_refreshed_at).toLocaleString('de-CH'):checked;return `aktualisiert ${refreshed}`;};
  const body=wallets.map(w=>{
    const balanceStates=Object.keys(CHAIN_CONFIG).filter(c=>walletAddressForChain(w,c)&&CHAIN_CONFIG[c]?.balanceProvider).map(c=>walletRefreshStates.get(refreshStateKey(walletDbId(w),c,'balances'))).filter(Boolean);
    const newest=balanceStates.sort((a,b)=>new Date(b.last_checked_at||0)-new Date(a.last_checked_at||0))[0];
    const proj=walletRefreshStates.get(refreshStateKey(walletDbId(w),'bsc','project:tln_vow')),nft=walletRefreshStates.get(refreshStateKey(walletDbId(w),'','nft'));
    return `<tr><td><strong>${escapeAttr(w.label)}</strong></td><td>${escapeAttr(fmtState(newest))}</td><td>${w.evm?escapeAttr(fmtState(proj,requiredDataVersion('bsc','project:tln_vow'))):'–'}</td><td>${escapeAttr(fmtState(nft,requiredDataVersion('','nft')))}</td></tr>`;
  }).join('');
  el.innerHTML=`<div class="custom-token-card"><div class="chain-title">Datenstand pro Wallet</div><div class="note" style="margin-bottom:8px">„Geprüft“ bedeutet: Die Blockchain wurde heute kontrolliert; ohne relevante Aktivität wurde der bestehende Datenstand bewusst weiterverwendet.</div><div class="chain-table-wrap"><table><thead><tr><th>Wallet</th><th>Bestände</th><th>TLN/VOW · LP & Staking</th><th>NFTs</th></tr></thead><tbody>${body||'<tr><td colspan="4">Keine Wallets vorhanden.</td></tr>'}</tbody></table></div></div>`;
}

async function loadAllCore(options = {}) {
  const automatic=!!options.automatic,btn=document.getElementById('loadBtn');if(btn)btn.disabled=true;
  const progress=[];renderCentralRefreshProgress(progress);renderCacheStatusNote(automatic?'Tägliche Wallet-Prüfung läuft…':'Vollständige Aktualisierung läuft…');
  await refreshAllCurrentPrices({manual:false}).catch(e=>console.warn('Preisabruf:',e));
  const configuredChains=Object.keys(CHAIN_CONFIG).filter(c=>!!CHAIN_CONFIG[c]?.balanceProvider),failures=[];
  for(const w of wallets){
    progress.push(`● ${w.label}`);renderCentralRefreshProgress(progress);
    let walletChanged=!automatic;const changedChains=new Set();
    for(const chain of configuredChains){
      const addr=walletAddressForChain(w,chain);if(!addr)continue;
      const state=walletRefreshStates.get(refreshStateKey(walletDbId(w),chain,'balances'));
      if(automatic&&refreshedToday(w,chain,'balances'))continue;
      let shouldRefresh=true,activity={changed:true,latestBlock:null,reason:'manuell'};
      if(automatic&&CHAIN_CONFIG[chain]?.walletType==='evm'){
        try{activity=await evmRelevantActivitySince(w,chain,state);shouldRefresh=activity.changed;}catch(e){activity={changed:true,reason:'Activity-Check fehlgeschlagen'};}
      }
      if(shouldRefresh){
        progress.push(`  ${CHAIN_META[chain]?.label||chain}: Bestände laden`);renderCentralRefreshProgress(progress);
        const r=await loadWalletChain(w,chain,automatic);if(r?.ok===false)failures.push(r);else {walletChanged=true;changedChains.add(chain);}
      }
      await saveWalletRefreshState(w,chain,'balances',{last_checked_at:new Date().toISOString(),last_refreshed_at:shouldRefresh?new Date().toISOString():(state?.last_refreshed_at||null),last_checked_block:activity.latestBlock??state?.last_checked_block??null,last_result:shouldRefresh?'refreshed':'no_relevant_activity'});
    }
    // Projektpositionen gehören wirtschaftlich zur Token-Übersicht und werden deshalb im Full-Refresh mitgeführt.
    if(w.evm&&(!automatic||needsDataRebuild(w,'bsc','project:tln_vow')||!refreshedToday(w,'bsc','project:tln_vow'))){
      const ps=walletRefreshStates.get(refreshStateKey(walletDbId(w),'bsc','project:tln_vow'));
      const forceProjectRebuild=needsDataRebuild(w,'bsc','project:tln_vow');
      if(!automatic||forceProjectRebuild||changedChains.has('bsc')||!ps?.last_checked_at){
        try{progress.push('  TLN/VOW: LP & Staking');renderCentralRefreshProgress(progress);await refreshProjectWallet(w,'tln_vow','bsc');walletChanged=true;}catch(e){failures.push({ok:false,error:`${w.label} TLN/VOW: ${e.message}`});}
      }else await saveWalletRefreshState(w,'bsc','project:tln_vow',{last_checked_at:new Date().toISOString(),last_refreshed_at:ps?.last_refreshed_at||null,last_result:'no_relevant_activity'});
    }
    // NFTs als letzter automatischer Prozess pro Wallet. Discovery und Gebühren bleiben bewusst manuell.
    if(!automatic||!refreshedToday(w,'','nft')){
      const ns=walletRefreshStates.get(refreshStateKey(walletDbId(w),'','nft'));
      if(!automatic||changedChains.size>0||!ns?.last_checked_at){
        try{progress.push('  NFTs laden');renderCentralRefreshProgress(progress);const nr=await refreshNftsForWallet(w);if(nr?.errors?.length)throw new Error(nr.errors.join(' · '));await saveWalletRefreshState(w,'','nft',{last_checked_at:new Date().toISOString(),last_refreshed_at:new Date().toISOString(),last_result:Number(nr?.count||0)===0?'no_nfts':'refreshed'});}catch(e){failures.push({ok:false,error:`${w.label} NFTs: ${e.message}`});}
      }else await saveWalletRefreshState(w,'','nft',{last_checked_at:new Date().toISOString(),last_refreshed_at:ns?.last_refreshed_at||null,last_result:'no_relevant_activity'});
    }
  }
  // LP-/Staking-Cache in die Tokenübersicht einmischen und aktuelle LP-Werte für Wallet-LPs bewerten.
  if(window.WalletLPEngine){for(const w of wallets){for(const chain of Object.keys(walletData[w.id]||{})){const cd=walletData[w.id]?.[chain];if(!cd?.tokens||!w.evm)continue;for(const t of cd.tokens){try{const p=await window.WalletLPEngine.pairInfo(chain,t.address);if(!p)continue;const pos=(await window.WalletLPEngine.positions(chain,w.evm,[t.address]))[0];if(pos)t.lpInfo=pos;}catch{}}}}}
  await mergeTlnBscStakingCacheIntoWalletData();renderResults();renderSafeTokenTable();renderCustomTokenList();renderAllocationChart();renderDashboard();
  if(failures.length===0){
    await createSnapshot(true);
    renderCacheStatusNote(automatic?'Tägliche Prüfung abgeschlossen · relevante Änderungen aktualisiert.':'Vollständige Aktualisierung abgeschlossen.');
    progress.push('✓ Fertig');
  }else{
    renderCacheStatusNote(`Aktualisierung mit ${failures.length} Hinweis${failures.length===1?'':'en'} abgeschlossen. Letzter vollständiger Cache bleibt als Fallback erhalten.`);
    progress.push(`⚠ ${failures.length} Hinweis${failures.length===1?'':'e'} aus der Datenaktualisierung:`);
    for(const failure of failures){
      const detail=String(failure?.error||failure?.message||'Unbekannter Fehler');
      progress.push(`  ↳ ${detail}`);
    }
    progress.push(`⚠ Fertig mit ${failures.length} Hinweis${failures.length===1?'':'en'}`);
  }
  renderCentralRefreshProgress(progress,{collapsed:true,finished:true});renderWalletDataFreshness();if(btn)btn.disabled=false;return {failures};
}

let dashboardProjectSummaryPromise=null;
async function refreshDashboardProjectSummaries(){
  if(!currentUser||!wallets.length)return;
  if(dashboardProjectSummaryPromise)return dashboardProjectSummaryPromise;
  dashboardProjectSummaryPromise=(async()=>{
    const jobs=[];
    if(window.TLNVOWDiscovery?.loadDashboardSummary)jobs.push(window.TLNVOWDiscovery.loadDashboardSummary().catch(e=>console.warn("TLN Dashboard-Grunddaten",e)));
    if(window.DAO1Project?.loadDashboardSummary)jobs.push(window.DAO1Project.loadDashboardSummary().catch(e=>console.warn("DAO1 Dashboard-Grunddaten",e)));
    jobs.push(loadDashboardLpPositionCache().catch(e=>console.warn("Dashboard LP-Positionscache",e)));
    await Promise.all(jobs);renderDashboard();
  })();
  try{return await dashboardProjectSummaryPromise;}finally{dashboardProjectSummaryPromise=null;}
}
window.refreshDashboardProjectSummaries=refreshDashboardProjectSummaries;

async function loadAll(options = {}) {
  const automatic=!!options.automatic;
  markRequestAudit(automatic?"refresh:auto:start":"refresh:manual:start");
  try{
    const result=await runDataJob(automatic?"Daten werden aktualisiert …":"Daten werden vollständig aktualisiert …",()=>loadAllCore(options));
    refreshDashboardProjectSummaries().catch(e=>console.warn("Dashboard Project-Summaries",e));
    return result;
  }finally{markRequestAudit(automatic?"refresh:auto:end":"refresh:manual:end");}
}

// ---- Rendering ----
function badge(safe) {
  return safe
    ? `<span class="badge safe">sicher</span>`
    : `<span class="badge unsafe">ungeprüft</span>`;
}

function fmt(n, tokenMeta=null, options={}) {
  if(tokenMeta && typeof tokenMeta==="object") return formatTokenAmountGlobal(n,tokenMeta,options);
  return Number(n).toLocaleString('de-CH', { maximumFractionDigits: 6 });
}

// Nur noch echte Nullen/Rundungsrauschen gelten als Staub - Token mit z.B. 18
// Dezimalstellen können einen realen, aber winzigen Bestand haben (bis zur 18. Stelle),
// der nicht fälschlich ausgeblendet werden soll.
const DUST_THRESHOLD = 1e-25;

// Kurs für Token-Zeilen anhand des Symbols (nur exaktes USDT/USDC, siehe oben)
function isTlnVowManagedToken(chain,address){
  if(!address || address === "native") return false;
  const key=chain+"|"+normalizeAddress(address,chain);
  return String(predefinedTokenProject[key]||"").toLowerCase().replace(/[\s\/-]+/g,"_")==="tln_vow";
}

function priceForToken(chain, address) {
  if (!address) return null;
  const normalized = normalizeAddress(address, chain);

  // TLN/VOW hat genau eine autoritative aktuelle Preisquelle: die zentrale
  // Projekt-PriceEngine (BSC: PancakeSwap, ETH: Uniswap). Für diese Contracts
  // darf niemals auf den allgemeinen CoinGecko-/GeckoTerminal-Cache gefallen werden.
  if (isTlnVowManagedToken(chain, normalized)) {
    return window.TLNVOWProject?.getPrice(chain, normalized) || null;
  }

  // Für nicht projektverwaltete Token bleibt die allgemeine Preislogik bestehen.
  if (window.TLNVOWProject) {
    const projectPrice = window.TLNVOWProject.getPrice(chain, normalized);
    if (projectPrice) return projectPrice;
  }

  const key = chain + "|" + normalized;
  return tokenPrices[key] || null;
}

function chainRows(chainData, chainKey) {
  if (!chainData) return null;
  if (chainData.error) return { error: chainData.error };
  const rows = [];
  if (chainData.native !== null && chainData.native !== undefined && chainData.native >= DUST_THRESHOLD) {
    const p = nativePrices[chainKey];
    rows.push({
      symbol: chainData.nativeSymbol + " (nativ)",
      amount: chainData.native,
      safe: true,
      isNative: true,
      price: p ? p.price : undefined,
      change24h: p ? p.change24h : undefined,
      source: p ? "CoinGecko" : undefined,
      chain: chainKey,
      usdValue: p ? chainData.native * p.price : undefined
    });
  }
  (chainData.tokens || []).forEach(t => {
    const safe = isSafeTokenAddress(t.address, chainKey);
    if (t.amount >= DUST_THRESHOLD && safe) {
      const p = priceForToken(chainKey, t.address);
      rows.push({
        symbol: t.symbol,
        amount: t.amount,
        safe,
        isNative: false,
        address: t.address,
        chain: chainKey,
        price: p ? p.price : undefined,
        change24h: p ? p.change24h : undefined,
        source: t.lpInfo ? `${t.lpInfo.lpLabel} · ${t.lpInfo.t0.symbol}/${t.lpInfo.t1.symbol}` : (p ? p.source : undefined),
        lpInfo: t.lpInfo || null,
        price: t.lpInfo && t.amount>0 && t.lpInfo.usd!=null ? t.lpInfo.usd/t.amount : (p ? p.price : undefined),
        usdValue: t.lpInfo?.usd != null ? t.lpInfo.usd : (p ? t.amount * p.price : undefined)
      });
    }
  });
  return { rows };
}

function dashboardTokenDisplayName(chain,address,symbol){
  const normalized=normalizeAddress(address,chain), key=chain+"|"+normalized;
  const custom=customSafeTokens.find(t=>t.chain===chain&&normalizeAddress(t.address,chain)===normalized);
  const cached=tokenMetaCache[key]||{};
  const candidates=[predefinedTokenNames[key],predefinedTokenLabels[key],predefinedTokenSymbols[key],custom?.label,cached.name,cached.symbol,symbol];
  const named=candidates.map(x=>String(x||"").trim()).find(x=>x && normalizeAddress(x,chain)!==normalized && !/^0x[0-9a-f]{40}$/i.test(x));
  return named||dashboardShortAddress(address)||String(address||"").trim();
}

function dashboardShortAddress(address){
  const a=String(address||"").trim();
  if(!a||a==="native")return "";
  return a.length>12?`${a.slice(0,6)}…${a.slice(-4)}`:a;
}
async function copyDashboardAddress(address,btn){
  try{
    await navigator.clipboard.writeText(String(address||""));
    if(btn){const old=btn.textContent;btn.textContent="✓";setTimeout(()=>{btn.textContent=old;},900);}
  }catch(e){console.error("Adresse konnte nicht kopiert werden",e);}
}
window.copyDashboardAddress=copyDashboardAddress;
function dashboardSymbolMetaHtml(symbol,address,displayName){
  const sym=String(symbol||"").trim(), addr=String(address||"").trim();
  if(!sym || sym===displayName || sym.toLowerCase()===addr.toLowerCase() || sym.toLowerCase()==="native") return "";
  return `<div class="meta">${escapeAttr(sym)}</div>`;
}

function dashboardAddressHtml(address){
  const short=dashboardShortAddress(address);
  if(!short)return "";
  return `<div class="meta dashboard-token-address"><code>${escapeAttr(short)}</code><button type="button" class="dashboard-copy-address" style="padding:0 3px;margin-left:4px;border:0;background:transparent;color:inherit;box-shadow:none;font-size:.9em;vertical-align:baseline" title="Token-Adresse kopieren" aria-label="Token-Adresse kopieren" onclick="copyDashboardAddress('${escapeAttr(address)}',this)">⧉</button></div>`;
}

function dao1PriceSourceParts(price){
  const raw=String(price?.source||"").trim();
  if(!raw)return {source:"–",route:"–",pools:[]};
  const parts=raw.split(" · ").map(x=>x.trim()).filter(Boolean);
  const source=parts[0]||"Apertum DEX";
  const pools=parts.filter(x=>/^0x[a-fA-F0-9]{40}$/.test(x));
  let route=source.replace(/^Apertum DEX\s*/i,"").trim();
  if(!route||route===source)route=parts.find(x=>x.includes("/")||x.includes("→"))||"–";
  return {source:"Apertum DEX",route,pools};
}
function renderDao1PricesPools(){
  const target=document.getElementById("dao1PricesPoolsContent");
  if(!target)return;
  const prefix="apertum|", rows=[];
  for(const key of new Set([...Object.keys(predefinedTokenSymbols),...Object.keys(predefinedTokenLabels),...Object.keys(predefinedTokenNames)])){
    if(!key.startsWith(prefix))continue;
    const address=key.slice(prefix.length),symbol=predefinedTokenSymbols[key]||predefinedTokenLabels[key]||predefinedTokenNames[key]||address;
    const project=predefinedTokenProject[key];
    if(project!=="dao1" && !["WAPTM","APTM","WUSDT","USDT"].includes(String(symbol).toUpperCase()))continue;
    const price=priceForToken("apertum",address); if(!price)continue;
    const info=dao1PriceSourceParts(price);
    rows.push({address,symbol,displayName:dashboardTokenDisplayName("apertum",address,symbol),price,info});
  }
  const native=nativePrices.apertum;
  if(native)rows.unshift({address:"native",symbol:"APTM",displayName:"APTM (nativ)",price:native,info:dao1PriceSourceParts(native)});
  const ref=window.DAO1Project?.getAptmUsdtPairAddress?.()||null;
  target.innerHTML=`<div class="custom-token-card"><h3 style="margin-top:0">DAO1 · Kurse &amp; Pools</h3><div class="note">Diese Ansicht verwendet ausschließlich die bereits vorhandene DAO1-/Apertum-Preislogik. Es wird keine zusätzliche Preisquelle und keine neue Preisermittlung gestartet. APTM und wAPTM werden 1:1 behandelt; die USD-Referenz stammt aus dem bestehenden wAPTM/wUSDT-Pool.</div>${ref?`<div class="note" style="margin-top:8px"><strong>Referenzpool wAPTM/wUSDT:</strong> <code>${escapeAttr(dashboardShortAddress(ref))}</code> <button type="button" class="dashboard-copy-address" title="Pool-Adresse kopieren" onclick="copyDashboardAddress('${escapeAttr(ref)}',this)">⧉</button></div>`:""}</div>
  <div class="custom-token-card" style="margin-top:10px"><div class="chain-table-wrap"><table class="chain-admin-table"><thead><tr><th>Token</th><th class="num">Kurs USD</th><th>Datenquelle</th><th>Preisroute</th><th>Pool(s)</th></tr></thead><tbody>${rows.length?rows.map(r=>`<tr><td><strong>${escapeAttr(r.displayName||r.symbol)}</strong>${dashboardAddressHtml(r.address)}</td><td class="num">${fmtPrice(r.price.price)}</td><td>${escapeAttr(r.info.source)}</td><td>${escapeAttr(r.info.route)}</td><td>${r.info.pools.length?r.info.pools.map(a=>`${escapeAttr(dashboardShortAddress(a))} <button type="button" class="dashboard-copy-address" title="Pool-Adresse kopieren" onclick="copyDashboardAddress('${escapeAttr(a)}',this)">⧉</button>`).join("<br>"):"–"}</td></tr>`).join(""):`<tr><td colspan="5">Noch kein gespeicherter aktueller DAO1-Preisstand vorhanden. Die bestehende zentrale Preisaktualisierung liefert diese Daten.</td></tr>`}</tbody></table></div></div>`;
}
window.renderDao1PricesPools=renderDao1PricesPools;

function dashboardProjectHasSummaryEvidence(projectKey){
  const st=dashboardProjectCacheStats[projectKey]||{};
  if(projectKey==="dao1" && (st.dao1Partners!=null||st.aptmdaoPartners!=null))return true;
  if(projectKey==="tln_vow" && st.teamPartners!=null)return true;
  return ["rewards","referralRewards","bonusRewards"].some(field=>Object.values(st[field]||{}).some(rows=>Array.isArray(rows)&&rows.some(x=>Number(x?.amount||0)!==0)));
}
function dashboardPriceRows(targetWallets=walletsForCurrentView(),involvedProjects=new Set()){
  // Phase 5.39: positive Bestände werden automatisch berücksichtigt, sobald ihr
  // bewertbarer Gesamtbestand > USD 1 ist. Das Flag bedeutet nur noch "immer anzeigen"
  // und hält einen Kurs auch bei Bestand 0 sichtbar. Projekt-Token bleiben verborgen,
  // solange der User im betreffenden Projekt nicht nachweisbar beteiligt ist.
  const held=new Map();
  for(const w of (targetWallets||[])) for(const chain of Object.keys(CHAIN_META)){
    const result=chainRows(walletData[w.id]?.[chain],chain);if(!result||result.error)continue;
    for(const row of result.rows||[]){
      const address=row.isNative?"native":(row.address?normalizeAddress(row.address,chain):"");if(!address)continue;
      const key=`${chain}|${address}`,cur=held.get(key)||{amount:0,usdValue:0,hasUsd:false,symbol:row.symbol};
      cur.amount+=Number(row.amount||0)||0;
      if(Number.isFinite(Number(row.usdValue))){cur.usdValue+=Number(row.usdValue);cur.hasUsd=true;}
      held.set(key,cur);
    }
  }
  const candidateKeys=new Set([...held.keys(),...Object.keys(predefinedTokenDashboardVisible)]),rows=[];
  for(const key of candidateKeys){
    const split=key.indexOf("|");if(split<1)continue;
    const chain=key.slice(0,split),address=key.slice(split+1),h=held.get(key)||{amount:0,usdValue:0,hasUsd:false};
    const always=predefinedTokenDashboardVisible[key]===true;
    const autoHeld=Number(h.amount)>0 && h.hasUsd && Number(h.usdValue)>1;
    if(!always&&!autoHeld)continue;
    const project=predefinedTokenProject[key]||null;
    if(project && !involvedProjects.has(project))continue;
    const native=address==="native",meta=native?predefinedNativeAssets[chain]:null;
    const symbol=meta?.symbol||predefinedTokenSymbols[key]||predefinedTokenLabels[key]||h.symbol||address;
    const displayName=meta?.name||dashboardTokenDisplayName(chain,address,symbol);
    const price=native?nativePrices[chain]:priceForToken(chain,address);
    rows.push({key,chain,address,symbol,displayName,project,price,amount:Number(h.amount)||0,usdValue:h.hasUsd?Number(h.usdValue):null,always});
  }
  return rows.sort((a,b)=>(a.project||"").localeCompare(b.project||"")||a.symbol.localeCompare(b.symbol));
}

let dashboardLpPositionCache=[];
async function loadDashboardLpPositionCache(){
  if(!currentUser?.id||!wallets.length||!sb){dashboardLpPositionCache=[];return []}
  const ids=wallets.map(w=>persistedWalletDbId(w)).filter(Boolean);
  if(!ids.length){dashboardLpPositionCache=[];return []}
  try{
    const {data,error}=await sb.from('lp_position_cache').select('project_key,chain_key,wallet_id,wallet_address,pair_address,current_wallet_lp,current_staked_lp,current_lp,current_usd,refreshed_at,updated_at').eq('user_id',currentUser.id).in('wallet_id',ids);
    if(error)throw error;
    dashboardLpPositionCache=(data||[]).filter(r=>Number(r.current_lp||0)>0||Number(r.current_staked_lp||0)>0);
    const stamps=dashboardLpPositionCache.map(r=>r.refreshed_at||r.updated_at).filter(Boolean).sort();
    setWtDataStatus('lp-positions',{updatedAt:stamps.at(-1)||null,cacheAt:stamps.at(-1)||null,source:'cache',label:'LP-Positionscache'});
    return dashboardLpPositionCache;
  }catch(e){console.warn('Dashboard LP-Positionscache',e);return dashboardLpPositionCache}
}
window.loadDashboardLpPositionCache=loadDashboardLpPositionCache;

function dashboardPortfolio(targetWallets){
  let freeUsd=0,boundUsd=0,unknownValues=0,boundEvidence=0;
  const integratedLpKeys=new Set();
  const unknownAssets=new Map();
  const projects=new Map();
  for(const w of targetWallets){
    for(const chain of Object.keys(CHAIN_META)){
      const result=chainRows(walletData[w.id]?.[chain],chain);if(!result||result.error)continue;
      for(const row of result.rows){
        const usdValue=Number(row.usdValue);
        const staked=Number(row.lpInfo?.stakedBalance||0);
        const totalAmount=Number(row.amount||0);
        let rowBound=0;
        if(staked>0&&totalAmount>0&&Number.isFinite(usdValue)){
          rowBound=usdValue*Math.min(1,staked/totalAmount);boundEvidence++;
          if(row.address)integratedLpKeys.add(`${String(w.dbId||w.id||'')}|${chain}|${normalizeAddress(row.address,chain)}`);
        }
        if(Number.isFinite(usdValue)){boundUsd+=rowBound;freeUsd+=Math.max(0,usdValue-rowBound);}else {unknownValues++;const uk=`${chain}|${row.isNative?"native":normalizeAddress(row.address||"",chain)}`;if(!unknownAssets.has(uk))unknownAssets.set(uk,{symbol:row.symbol||row.name||"Token",chain,address:row.isNative?"native":row.address||null});}
        if(!row.isNative&&row.address){
          const key=chain+"|"+normalizeAddress(row.address,chain),projectKey=predefinedTokenProject[key];
          if(projectKey){const p=projects.get(projectKey)||{valueUsd:0,freeUsd:0,boundUsd:0,assets:0};if(Number.isFinite(usdValue)){p.valueUsd+=usdValue;p.freeUsd+=Math.max(0,usdValue-rowBound);}p.boundUsd+=rowBound;p.assets++;projects.set(projectKey,p);}
        }
      }
    }
  }
  // Persistente LP-Positionen sind die fachliche Quelle für gebundene LP-Werte. Nur der
  // gestakte Anteil wird zusätzlich zum Wallet-Bestand berücksichtigt; der frei im Wallet
  // liegende LP-Anteil steckt bereits in den normalen Beständen und würde sonst doppelt zählen.
  const selectedIds=new Set((targetWallets||[]).map(w=>String(w.dbId||w.id||'')));
  for(const r of dashboardLpPositionCache){
    if(selectedIds.size&&!selectedIds.has(String(r.wallet_id||'')))continue;
    const totalLp=Number(r.current_lp||0),stakedLp=Number(r.current_staked_lp||0),usd=Number(r.current_usd);
    if(!(stakedLp>0)||!(totalLp>0)||!Number.isFinite(usd))continue;
    const stakedUsd=usd*Math.min(1,stakedLp/totalLp);if(!(stakedUsd>0))continue;
    const lpKey=`${String(r.wallet_id||'')}|${String(r.chain_key||'')}|${normalizeAddress(r.pair_address||'',String(r.chain_key||''))}`;
    // TLN/VOW integriert gestaktes LP bereits in walletData (Wallet-LP + Staking).
    // Nur nicht bereits integrierte Positionscaches – z. B. DAO1 – zusätzlich zählen.
    if(integratedLpKeys.has(lpKey))continue;
    boundUsd+=stakedUsd;boundEvidence++;
    const projectKey=String(r.project_key||'');if(projectKey){const p=projects.get(projectKey)||{valueUsd:0,freeUsd:0,boundUsd:0,assets:0};p.valueUsd+=stakedUsd;p.boundUsd+=stakedUsd;p.assets++;projects.set(projectKey,p);}
  }
  return {freeUsd,boundUsd,totalUsd:freeUsd+boundUsd,unknownValues,unknownAssets:[...unknownAssets.values()],boundEvidence,projects};
}

function dashboardAddFirstWallet(){
  if(!wallets.length)addWallet();
  showTab("wallets");
  setTimeout(()=>{document.querySelector("#walletInputs input")?.focus?.();document.getElementById("walletInputs")?.scrollIntoView?.({behavior:"smooth",block:"start"});},80);
}
window.dashboardAddFirstWallet=dashboardAddFirstWallet;

function dashboardProjectTitle(key){return defiProjectsCache.find(p=>p.project_key===key)?.name||({tln_vow:"TLN / VOW",dao1:"DAO1 / APTM"}[key]||key);}
function dashboardProjectOpen(key){if(key==="tln_vow")showTab("tlnvow");else if(key==="dao1")showTab("dao1");else showTab("projects-overview");}
window.dashboardProjectOpen=dashboardProjectOpen;

const dashboardEmptyRewardPeriods=()=>({total:[],previousYear:[],year:[],month:[]});
const dashboardProjectCacheStats={
  tln_vow:{teamPartners:null,activePartners:null,rewards:dashboardEmptyRewardPeriods(),referralRewards:dashboardEmptyRewardPeriods(),bonusRewards:dashboardEmptyRewardPeriods()},
  dao1:{teamPartners:null,activePartners:null,rewards:dashboardEmptyRewardPeriods(),referralRewards:dashboardEmptyRewardPeriods()}
};
function dashboardMetric(v,formatter){return v==null?"–":(formatter?formatter(v):String(v));}
function dashboardRewardAssetKey(x){return `${String(x?.chain||"").toLowerCase()}|${String(x?.address||x?.assetId||x?.symbol||"").toLowerCase()}`;}
function dashboardRewardAmount(n,asset={}){const v=Number(n||0);if(!Number.isFinite(v))return "–";return formatTokenAmountGlobal(v,{chain:asset.chain,address:asset.address||"",symbol:asset.symbol||asset.name},{summary:true});}
function dashboardRewardPeriodHtml(rows,assetOrder=null){const list=Array.isArray(rows)?rows:[];if(!assetOrder?.length){if(!list.length)return "–";return `<span class="dashboard-reward-assets">${list.map(x=>`<span><strong>${dashboardRewardAmount(x.amount,x)}</strong> ${escapeAttr(x.symbol||x.name||"TOKEN")}</span>`).join("")}</span>`;}const map=new Map(list.map(x=>[dashboardRewardAssetKey(x),x]));return `<span class="dashboard-reward-assets">${assetOrder.map(a=>{const x=map.get(a.key);return `<span><strong>${x?dashboardRewardAmount(x.amount,x):"–"}</strong> ${escapeAttr(a.symbol||"TOKEN")}</span>`}).join("")}</span>`;}
function dashboardRewardAssetOrder(group){const map=new Map();for(const period of ["total","previousYear","year","month"]){for(const x of (Array.isArray(group?.[period])?group[period]:[])){const key=dashboardRewardAssetKey(x);if(key&&!map.has(key))map.set(key,{key,symbol:x.symbol||x.name||"TOKEN"});}}return [...map.values()].sort((a,b)=>String(a.symbol).localeCompare(String(b.symbol)));}
function dashboardMergeRewardPeriods(field){const out=dashboardEmptyRewardPeriods();for(const period of Object.keys(out)){const byKey=new Map();for(const st of Object.values(dashboardProjectCacheStats)){for(const x of (Array.isArray(st?.[field]?.[period])?st[field][period]:[])){const key=dashboardRewardAssetKey(x);if(!key)continue;const cur=byKey.get(key)||{...x,amount:0};cur.amount+=Number(x.amount||0);byKey.set(key,cur);}}out[period]=[...byKey.values()].filter(x=>Number.isFinite(Number(x.amount))&&Number(x.amount)!==0).sort((a,b)=>String(a.symbol||"").localeCompare(String(b.symbol||"")));}return out;}
function dashboardActivePartners(stats){
  const unknown=Number(stats?.activePartnersUnknown||0),verified=Number(stats?.activePartnersVerified);
  if(unknown>0 && Number.isFinite(verified))return `${verified} bestätigt · ${unknown} offen`;
  return dashboardMetric(stats?.activePartners);
}
function dashboardProjectSummaryStorageKey(){return currentUser?.id?`wallettracking:dashboard-project-summary:${currentUser.id}`:null;}
function dashboardWalletScopeSignature(){return (wallets||[]).filter(w=>w?.isOwnWallet!==false).map(w=>String(w.dbId||w.id||"")+":"+String(w.evm||"").toLowerCase()).sort().join("|");}
function restoreDashboardProjectCacheStats(){const key=dashboardProjectSummaryStorageKey();if(!key)return;try{const saved=JSON.parse(localStorage.getItem(key)||"null");if(!saved||typeof saved!=="object")return;if(saved.__walletScopeSignature!==dashboardWalletScopeSignature()){localStorage.removeItem(key);return;}for(const projectKey of ["tln_vow","dao1"]){const x=saved[projectKey];if(!x)continue;dashboardProjectCacheStats[projectKey]={...dashboardProjectCacheStats[projectKey],...x,rewards:{...(dashboardProjectCacheStats[projectKey].rewards||{}),...(x.rewards||{})},referralRewards:{...(dashboardProjectCacheStats[projectKey].referralRewards||{}),...(x.referralRewards||{})},bonusRewards:{...(dashboardProjectCacheStats[projectKey].bonusRewards||{}),...(x.bonusRewards||{})}};}}catch(e){console.warn("Dashboard Project-Summary Cache",e);}}
function persistDashboardProjectCacheStats(){const key=dashboardProjectSummaryStorageKey();if(!key)return;try{localStorage.setItem(key,JSON.stringify({...dashboardProjectCacheStats,__walletScopeSignature:dashboardWalletScopeSignature()}));}catch(e){console.warn("Dashboard Project-Summary speichern",e);}}
function setDashboardProjectCacheStats(projectKey,patch={}){
  const cur=dashboardProjectCacheStats[projectKey]||(dashboardProjectCacheStats[projectKey]={rewards:{}});
  if(Object.prototype.hasOwnProperty.call(patch,"teamPartners"))cur.teamPartners=patch.teamPartners;
  if(Object.prototype.hasOwnProperty.call(patch,"activePartners"))cur.activePartners=patch.activePartners;
  if(Object.prototype.hasOwnProperty.call(patch,"activePartnersVerified"))cur.activePartnersVerified=patch.activePartnersVerified;
  if(Object.prototype.hasOwnProperty.call(patch,"activePartnersUnknown"))cur.activePartnersUnknown=patch.activePartnersUnknown;
  for(const field of ["dao1Partners","aptmdaoPartners","expiredPartnerStakings","upcomingPartnerStakings","recentPartnerActivities"])if(Object.prototype.hasOwnProperty.call(patch,field))cur[field]=patch[field];
  if(patch.rewards)cur.rewards={...(cur.rewards||{}),...patch.rewards};
  if(patch.referralRewards)cur.referralRewards={...(cur.referralRewards||{}),...patch.referralRewards};
  if(patch.bonusRewards)cur.bonusRewards={...(cur.bonusRewards||{}),...patch.bonusRewards};
  cur.updatedAt=patch.updatedAt||new Date().toISOString();persistDashboardProjectCacheStats();
  renderDashboard();
}
window.setDashboardProjectCacheStats=setDashboardProjectCacheStats;

function chainIconHtml(chain,sizeClass="sm") {
  const key=String(chain||"").trim();
  const meta=CHAIN_META[key]||{};
  const sym=String(NATIVE_SYMBOL[key]||meta.nativeSymbol||key||"?").trim();
  const title=escapeAttr(meta.label||key.toUpperCase());
  if(meta.iconPath){
    return `<span class="crypto-icon ${escapeAttr(sizeClass)}" title="${title}" aria-hidden="true"><img src="${escapeAttr(meta.iconPath)}" alt=""></span><span class="dashboard-chain-native-symbol">${escapeAttr(sym.slice(0,5))}</span>`;
  }
  return `<span class="dashboard-chain-native-symbol" title="${title}">${escapeAttr(sym.slice(0,5))}</span>`;
}

function renderDashboard(){
  const root=document.getElementById("dashboardContent");if(!root)return;
  renderGlobalWalletPersonFilter();
  const targetWallets=walletsForCurrentView(),portfolio=dashboardPortfolio(targetWallets);
  const involvedProjects=new Set([...portfolio.projects.entries()].filter(([,p])=>p.assets>0).map(([key])=>key));
  for(const key of ["tln_vow","dao1"])if(dashboardProjectHasSummaryEvidence(key))involvedProjects.add(key);
  const prices=dashboardPriceRows(targetWallets,involvedProjects);
  if(wallets.length===0){
    root.innerHTML=`<div class="dashboard-heading"><div><h2>Willkommen bei WalletTracking</h2><p>Dein Dashboard wird automatisch aufgebaut, sobald du deine erste Wallet erfasst hast.</p></div></div><section class="dashboard-empty-onboarding"><article class="dashboard-card dashboard-onboarding-card"><div class="dashboard-onboarding-icon">＋</div><h3>Noch keine Wallet erfasst</h3><p>Erfasse zuerst eine oder mehrere Wallets. Danach lädt WalletTracking die benötigten Grunddaten automatisch im Hintergrund und aktualisiert dieses Dashboard. Für Detailanalysen kannst du später die einzelnen Projektbereiche öffnen.</p><button onclick="dashboardAddFirstWallet()">Erste Wallet erfassen</button><div class="dashboard-onboarding-steps"><span><b>1</b> Wallet erfassen</span><span><b>2</b> Grunddaten werden geladen</span><span><b>3</b> Dashboard füllt sich automatisch</span></div></article></section>`;
    setWtDataStatus("dashboard",{source:"local",label:"Dashboard · noch keine Wallet"});return;
  }
  const money=v=>fmtUsd(Number(v||0));
  const boundValue=portfolio.boundEvidence?money(portfolio.boundUsd):"–";
  const chainIcon=r=>chainIconHtml(r.chain,"sm");
  const priceRows=rows=>`<div class="dashboard-table-wrap"><table class="dashboard-price-table dashboard-price-table-compact"><thead><tr><th>Token</th><th title="Chain">Chain</th><th>Projekt</th><th class="num">Kurs USD</th><th class="num">24 Std.</th><th>Datenquelle</th></tr></thead><tbody>${rows.map(r=>{const primary=String(r.displayName||r.symbol||"");const isAddr=/^0x[0-9a-f]{40}$/i.test(primary);return `<tr><td><strong>${escapeAttr(isAddr?dashboardShortAddress(primary):primary)}</strong>${isAddr?"":dashboardSymbolMetaHtml(r.symbol,r.address,r.displayName)}${isAddr?"":dashboardAddressHtml(r.address)}</td><td class="dashboard-chain-icon-cell">${chainIcon(r)}</td><td>${escapeAttr(r.project?dashboardProjectTitle(r.project):"Allgemein")}</td><td class="num">${r.price?fmtPrice(r.price.price):"–"}</td><td class="num">${r.price?fmtChange(r.price.change24h):"–"}</td><td>${r.price?`<strong>${escapeAttr(r.price.source||"Quelle unbekannt")}</strong>${r.price.route?`<div class="meta">${escapeAttr(r.price.route)}</div>`:""}`:"Kein gespeicherter Kurs"}</td></tr>`}).join("")}</tbody></table></div>`;
  const split=Math.ceil(prices.length/2),priceTable=prices.length?`<div class="dashboard-price-columns">${priceRows(prices.slice(0,split))}${priceRows(prices.slice(split))}</div>`:`<div class="empty">Keine Dashboard-Kurse gemäß aktueller Regel: Bestand &gt; 1 USD oder Flag „Im Dashboard immer anzeigen“.</div>`;
  const projectCards=[...involvedProjects].map(key=>[key,portfolio.projects.get(key)||{valueUsd:0,freeUsd:0,boundUsd:0,assets:0}]).map(([key,p])=>{
    const projectPrices=prices.filter(x=>x.project===key);
    const stats=dashboardProjectCacheStats[key]||{rewards:{}};
    const rewards=stats.rewards||{},referralRewards=stats.referralRewards||{},bonusRewards=stats.bonusRewards||{};
    const rewardBlock=(title,data)=>{const order=dashboardRewardAssetOrder(data);return `<div class="dashboard-reward-group"><div class="dashboard-reward-group-title">${title}</div><div class="dashboard-reward-lines"><div><span>Gesamt</span>${dashboardRewardPeriodHtml(data.total,order)}</div><div><span>Vorjahr</span>${dashboardRewardPeriodHtml(data.previousYear,order)}</div><div><span>Jahr</span>${dashboardRewardPeriodHtml(data.year,order)}</div><div><span>Monat</span>${dashboardRewardPeriodHtml(data.month,order)}</div></div></div>`;};
    const teamStats=key==="dao1"?`<div><span>Partner-Wallets</span><strong>${dashboardMetric(stats.teamPartners)}</strong></div><div><span>DAO1 Bezug</span><strong>${dashboardMetric(stats.dao1Partners)}</strong></div><div><span>APTMDAO Bezug</span><strong>${dashboardMetric(stats.aptmdaoPartners)}</strong></div>`:`<div><span>Teampartner</span><strong>${dashboardMetric(stats.teamPartners)}</strong></div><div><span>davon aktiv</span><strong>${dashboardActivePartners(stats)}</strong></div>`;
    return `<article class="dashboard-project-card"><div class="dashboard-project-head"><div><span class="dashboard-project-kicker">Projekt</span><h3>${escapeAttr(dashboardProjectTitle(key))}</h3></div><strong>${money(p.valueUsd)}</strong></div>
      <div class="dashboard-project-stats dashboard-project-stats-compact"><div><span>Frei verfügbar</span><strong>${money(p.freeUsd||0)}</strong></div><div><span>Aktuell gebunden</span><strong>${p.boundUsd>0?money(p.boundUsd):"–"}</strong></div><div><span>Projektwert gesamt</span><strong>${money(p.valueUsd||0)}</strong></div>${teamStats}</div>
      ${rewardBlock("Rewards",rewards)}${rewardBlock("Referral Rewards",referralRewards)}${key==="tln_vow"?rewardBlock("Bonus Rewards",bonusRewards):""}
      ${projectPrices.length?`<div class="dashboard-project-prices">${projectPrices.map(r=>`<span><span class="dashboard-project-token-name">${escapeAttr(r.displayName||r.symbol)}</span>${dashboardSymbolMetaHtml(r.symbol,r.address,r.displayName)}${dashboardAddressHtml(r.address)} <strong>${r.price?fmtPrice(r.price.price):"–"}</strong></span>`).join("")}</div>`:""}<button class="secondary" onclick="dashboardProjectOpen('${escapeAttr(key)}')">Projekt öffnen</button><div class="dashboard-cache-note">Dashboard-Grunddaten werden aus persistenten Projektcaches übernommen. Fehlende/veraltete Grunddaten werden durch den zentralen Hintergrundlauf nachgeführt; vollständige Discovery bleibt projektbezogen.</div></article>`;
  }).join("");
  const globalRewards=dashboardMergeRewardPeriods("rewards"),globalReferralRewards=dashboardMergeRewardPeriods("referralRewards");
  const rewardKpi=(title,group)=>{const order=dashboardRewardAssetOrder(group);return `<article class="dashboard-kpi dashboard-kpi-gold dashboard-reward-kpi"><span>${title}</span><div class="dashboard-kpi-reward-lines"><div><small>Gesamt</small>${dashboardRewardPeriodHtml(group.total,order)}</div><div><small>Vorjahr</small>${dashboardRewardPeriodHtml(group.previousYear,order)}</div><div><small>Jahr</small>${dashboardRewardPeriodHtml(group.year,order)}</div><div><small>Monat</small>${dashboardRewardPeriodHtml(group.month,order)}</div></div></article>`;};
  const staleWallets=targetWallets.filter(w=>Object.keys(CHAIN_CONFIG).some(c=>walletAddressForChain(w,c)&&!refreshedToday(w,c,"balances"))).length;
  root.innerHTML=`
    <div class="dashboard-heading"><div><h2>Persönliches Dashboard</h2><p>Gespeicherter Stand für ${escapeAttr(document.getElementById("globalWalletPersonFilter")?.selectedOptions?.[0]?.textContent||"Eigene Wallets")}</p></div><button onclick="loadAll()">Daten aktualisieren</button></div>
    <section class="dashboard-kpi-grid dashboard-kpi-grid-main">
      <article class="dashboard-kpi dashboard-kpi-blue dashboard-wealth-kpi"><span class="dashboard-kpi-main-title">Vermögen</span><div class="dashboard-wealth-lines" style="display:grid;grid-template-columns:1fr;gap:0">
        <div style="display:grid;grid-template-columns:minmax(150px,auto) 1fr;gap:16px;align-items:center;padding:10px 0;border-top:1px solid rgba(80,110,160,.16)"><strong style="font-size:clamp(1.35rem,2.2vw,2rem);white-space:nowrap">${money(portfolio.totalUsd)}</strong><span style="font-size:.82rem;line-height:1.35"><b>Gesamtvermögen</b><br><span style="opacity:.78">aktuell bewertbarer Cache-Stand</span></span></div>
        <div style="display:grid;grid-template-columns:minmax(150px,auto) 1fr;gap:16px;align-items:center;padding:10px 0;border-top:1px solid rgba(80,110,160,.16)"><strong style="font-size:clamp(1.35rem,2.2vw,2rem);white-space:nowrap">${money(portfolio.freeUsd)}</strong><span style="font-size:.82rem;line-height:1.35"><b>Frei verfügbar</b><br><span style="opacity:.78">direkt in ${targetWallets.length} ausgewählten Wallet(s)</span></span></div>
        <div style="display:grid;grid-template-columns:minmax(150px,auto) 1fr;gap:16px;align-items:center;padding:10px 0;border-top:1px solid rgba(80,110,160,.16)"><strong style="font-size:clamp(1.35rem,2.2vw,2rem);white-space:nowrap">${boundValue}</strong><span style="font-size:.82rem;line-height:1.35"><b>Aktuell gebunden</b><br><span style="opacity:.78">${portfolio.boundEvidence?`${[...portfolio.projects.entries()].filter(([,x])=>Number(x.boundUsd)>0).map(([k,x])=>`${dashboardProjectTitle(k)} ${money(x.boundUsd)}`).join(" · ")||"aus persistentem Positionscache"}`:"noch kein bewertbarer Positionscache"}</span></span></div>
      </div></article>
      ${rewardKpi("Rewards",globalRewards)}
      ${rewardKpi("Referral Rewards",globalReferralRewards)}
    </section>
    ${portfolio.unknownValues?`<div class="dashboard-data-warning"><strong>${portfolio.unknownValues} Vermögenswert(e) ohne gespeicherten Kurs:</strong> ${portfolio.unknownAssets.map(x=>`${escapeAttr(x.symbol)} (${escapeAttr(CHAIN_META[x.chain]?.label||x.chain.toUpperCase())})`).join(", ")} – nicht in den Geldsummen enthalten.</div>`:""}
    <section class="dashboard-main-grid"><article class="dashboard-card"><div class="dashboard-card-head"><div><h3>Aktuelle Kurse</h3><p>Bestand &gt; 1 USD sowie „immer anzeigen“-Token</p></div><button class="secondary" onclick="refreshAllCurrentPrices({manual:true})">Preise aktualisieren</button></div>${priceTable}</article><article class="dashboard-card"><div class="dashboard-card-head"><div><h3>Was muss ich tun?</h3><p>Nur aus bestätigten Cache-Daten</p></div></div><div class="dashboard-action-list">${staleWallets?`<div><span class="dashboard-action-icon warning">!</span><p><strong>${staleWallets} Wallet(s) mit älterem Bestandsstand</strong><small>Eine Aktualisierung ist verfügbar.</small></p></div>`:`<div><span class="dashboard-action-icon ok">✓</span><p><strong>Bestandsstände aktuell</strong><small>Keine fällige Bestandsaktualisierung erkannt.</small></p></div>`}${(()=>{const tlnStats=dashboardProjectCacheStats.tln_vow||{};const rows=Array.isArray(tlnStats.expiredPartnerStakings)?tlnStats.expiredPartnerStakings:[];if(!tlnStats.updatedAt)return `<div><span class="dashboard-action-icon">↻</span><p><strong>TLN / VOW</strong><small>Partner-Stakings werden aus dem persistenten Lifecycle-Cache geladen …</small></p></div>`;if(!rows.length)return `<div><span class="dashboard-action-icon ok">✓</span><p><strong>TLN / VOW</strong><small>Keine verifizierten abgelaufenen, noch gestakten Partner-Positionen im aktuellen Team-Cache.</small></p></div>`;return `<div class="dashboard-action-project"><span class="dashboard-action-icon warning">!</span><div style="min-width:0;flex:1"><strong>TLN / VOW</strong><details style="margin-top:5px"><summary style="cursor:pointer;font-weight:700">${rows.length} abgelaufene Partner-Staking${rows.length===1?'':'s'} noch zu unstaken</summary><div class="meta" style="margin-top:6px">${rows.map(r=>`${escapeAttr(r.name||r.tlnId||'Partner')} · ${escapeAttr(r.asset||'Staking')} · abgelaufen ${escapeAttr(r.expiry||'')}`).join('<br>')}</div></details></div></div>`})()}</div></article></section>
    ${(()=>{const acts=Object.values(dashboardProjectCacheStats).flatMap(x=>Array.isArray(x?.recentPartnerActivities)?x.recentPartnerActivities:[]).filter(x=>x?.date).sort((a,b)=>new Date(b.date)-new Date(a.date)).slice(0,10);if(!acts.length)return `<section class="dashboard-card dashboard-activities"><div class="dashboard-card-head"><div><h3>Letzte Partneraktivitäten</h3><p>Noch keine bestätigten Aktivitäten im geladenen Projektcache.</p></div></div></section>`;return `<section class="dashboard-card dashboard-activities"><div class="dashboard-card-head"><div><h3>Letzte Partneraktivitäten</h3><p>Die letzten 10 bestätigten Bot-Käufe bzw. Partner-Stakings · projektübergreifend</p></div></div><div class="dashboard-activity-list">${acts.map(a=>`<div><time>${escapeAttr(new Date(a.date).toLocaleDateString("de-CH"))}</time><strong>${escapeAttr(a.project||"")}</strong><span>${escapeAttr(a.partner||"Partner")}</span><span>${escapeAttr(a.what||"Aktivität")}</span></div>`).join("")}</div></section>`;})()}
    <div class="dashboard-section-title"><h3>Projekte</h3><span>Nur vorhandene Projekte</span></div>
    <section class="dashboard-project-grid">${projectCards||'<div class="empty">In den ausgewählten Wallets ist noch kein Projektbestand im gespeicherten Stand vorhanden.</div>'}</section>
    ${isAdmin?`<div class="dashboard-section-title dashboard-admin-title"><h3>Administration</h3><span>Nur Admin</span></div><section class="dashboard-admin-grid"><article class="dashboard-project-card dashboard-admin-card"><div class="dashboard-project-head"><div><span class="dashboard-project-kicker">Administration</span><h3>Prüfliste & Verwaltung</h3></div><strong>Admin</strong></div><div class="dashboard-admin-links"><button class="secondary" onclick="showTab('admin');showAdminTab('customtokens')">Neue sichere Token prüfen</button><button class="secondary" onclick="showTab('tlnvow')">TLN-Staking-Varianten prüfen</button></div><div class="dashboard-cache-note">Administrationsfunktionen sind bewusst vom Projektbereich getrennt.</div></article></section>`:""}`;
  setWtDataStatus("dashboard",{updatedAt:currentPriceCacheState.capturedAt,cacheAt:currentPriceCacheState.capturedAt,source:"cache",label:"Dashboard"});
}
window.renderDashboard=renderDashboard;

function fmtChange(pct) {
  if (pct === undefined || pct === null || isNaN(pct)) {
    return '<span style="color:var(--muted)">–</span>';
  }
  const positive = pct >= 0;
  const color = positive ? "#46c878" : "var(--danger)";
  const sign = positive ? "+" : "";
  return `<span style="color:${color}">${sign}${pct.toFixed(2)}%</span>`;
}

// ---- Snapshots (Token-Bestand zu einem Zeitpunkt) ----
let snapshots = []; // [{id, createdAt, visible, items: [...]}]
let snapshotsLoaded = false;
let snapshotsLoadPromise = null;

function ensureSnapshotsLoaded() {
  if (snapshotsLoaded) return Promise.resolve(snapshots);
  if (!snapshotsLoadPromise) snapshotsLoadPromise = loadSnapshotsFromDb().finally(()=>{ snapshotsLoadPromise = null; });
  return snapshotsLoadPromise;
}

async function loadSnapshotsFromDb() {
  const { data: snapRows, error: e1 } = await sb.from("snapshots").select("*").eq("is_automated", false).order("created_at", { ascending: false });
  if (e1) { console.error(e1); snapshots = []; return snapshots; }
  const { data: itemRows, error: e2 } = await sb.from("snapshot_items").select("*");
  if (e2) console.error(e2);
  const byId = {};
  (itemRows || []).forEach(it => {
    const w=wallets.find(x=>String(x.dbId||x.id)===String(it.wallet_id));
    if(!w)return;
    byId[it.snapshot_id] = byId[it.snapshot_id] || [];
    byId[it.snapshot_id].push({...it,wallet_label:w.label});
  });
  const prevVisibility = {};
  snapshots.forEach(s => { prevVisibility[s.id] = s.visible; });
  snapshots = (snapRows || []).map(s => ({
    id: s.id,
    createdAt: s.created_at,
    visible: prevVisibility.hasOwnProperty(s.id) ? prevVisibility[s.id] : true,
    items: byId[s.id] || []
  }));
  snapshotsLoaded = true;
  return snapshots;
}

// ---- Automatisierter Tages-Cache (Bestände) ----
// Rekonstruiert walletData je Wallet + Chain aus dem automatisierten Snapshot, statt live abzufragen.
// Gibt den Zeitstempel des Snapshots zurück (für die "zuletzt geladen"-Anzeige) oder null,
// falls noch kein Cache existiert (z.B. beim allerersten Login).
async function loadFromAutomatedCache() {
  const { data: snap, error: e1 } = await sb.from("snapshots").select("*").eq("user_id", currentUser.id).eq("is_automated", true).maybeSingle();
  if (e1) { console.error(e1); return null; }
  if (!snap) return null;

  const { data: items, error: e2 } = await sb.from("snapshot_items").select("*").eq("snapshot_id", snap.id);
  if (e2) { console.error(e2); return null; }

  // Snapshot-Items wieder den aktuell geladenen Wallet-Objekten zuordnen.
  // Primär über die stabile DB-ID, zusätzlich über das gespeicherte Wallet-Label als
  // Fallback (z.B. falls eine Wallet zwischenzeitlich neu gespeichert wurde).
  const byWalletChain = {};
  wallets.forEach(w => { byWalletChain[w.id] = {}; });

  (items || []).forEach(it => {
    const matchingWallet = wallets.find(w =>
      String(w.dbId||w.id) === String(it.wallet_id)
    );
    if (!matchingWallet) return;

    const walletKey = matchingWallet.id;
    byWalletChain[walletKey] = byWalletChain[walletKey] || {};
    const entry = byWalletChain[walletKey][it.chain] =
      byWalletChain[walletKey][it.chain] || { native: null, nativeSymbol: null, tokens: [] };

    if (it.is_native) {
      entry.native = Number(it.amount);
      entry.nativeSymbol = (it.symbol || "").replace(" (nativ)", "");
    } else {
      entry.tokens.push({ symbol: it.symbol, address: it.address, amount: Number(it.amount) });
    }
  });

  walletData = byWalletChain;
  return snap.created_at;
}

function renderCacheStatusNote(text) {
  const el = document.getElementById("cacheStatusNote");
  if (el) el.textContent = text;
}

function buildCurrentSnapshotItems() {
  const items = [];
  wallets.forEach(w => {
    if (!w.dbId) return; // ungespeicherte Wallet (noch keine DB-ID) - nicht in den Snapshot aufnehmen,
                          // sonst gibt's später keine zuverlässige Zuordnung mehr möglich
    Object.keys(CHAIN_META).forEach(chain => {
      const result = chainRows((walletData[w.id] || {})[chain], chain);
      if (!result || result.error) return;
      result.rows.forEach(r => {
        items.push({
          wallet_id: w.dbId,
          chain,
          symbol: r.symbol,
          address: r.isNative ? null : (r.address || null),
          is_native: !!r.isNative,
          amount: r.amount,
          price_usd: r.price !== undefined ? r.price : null, // Kurs ZUM ZEITPUNKT des Snapshots, nicht live nachträglich
          user_id: currentUser.id
        });
      });
    });
  });
  return items;
}

// isAutomated=false (Standard): manueller Snapshot, bleibt dauerhaft, taucht in der Verwaltung
// und der Verlauf-Grafik auf. isAutomated=true: interner Tages-Cache, ersetzt sich selbst bei
// jedem echten Neuladen, taucht NICHT in der normalen Snapshot-Liste/Grafik auf.
async function createSnapshot(isAutomated) {
  isAutomated = !!isAutomated;

  if (!isAutomated) {
    const unsaved = wallets.filter(w => !w.dbId);
    if (unsaved.length > 0) {
      const proceed = confirm(
        `Diese Wallet(s) sind noch nicht gespeichert und werden im Snapshot fehlen: ${unsaved.map(w => w.label).join(", ")}.\n\n` +
        `Zuerst auf "Speichern" klicken (im Tab "Meine Wallets") und danach den Snapshot erstellen? Trotzdem jetzt fortfahren?`
      );
      if (!proceed) return;
    }
  }

  const items = buildCurrentSnapshotItems();

  if (items.length === 0) {
    if (!isAutomated) alert("Keine Bestände gefunden, die gespeichert werden können. Erst 'Alle laden' ausführen und warten, bis Daten da sind.");
    return;
  }

  if (isAutomated) {
    // alten Cache-Snapshot ersetzen statt anzuhäufen
    await sb.from("snapshots").delete().eq("user_id", currentUser.id).eq("is_automated", true);
  }

  const { data: snap, error: snapErr } = await sb.from("snapshots").insert({ user_id: currentUser.id, is_automated: isAutomated }).select().single();
  if (snapErr) { if (!isAutomated) alert("Fehler beim Erstellen des Snapshots: " + snapErr.message); return; }

  const rows = items.map(it => ({ ...it, snapshot_id: snap.id }));
  const { error: itemsErr } = await sb.from("snapshot_items").insert(rows);
  if (itemsErr) { if (!isAutomated) alert("Fehler beim Speichern der Snapshot-Daten: " + itemsErr.message); return; }

  if (!isAutomated) {
    await loadSnapshotsFromDb();
    renderSnapshotManager();
    renderResults();
  }
}

async function deleteSnapshot(id) {
  if (!confirm("Diesen Snapshot unwiderruflich löschen?")) return;
  await sb.from("snapshots").delete().eq("id", id);
  snapshots = snapshots.filter(s => s.id !== id);
  renderSnapshotManager();
  renderResults();
}

function toggleSnapshotVisible(id, isVisible) {
  const s = snapshots.find(s => s.id === id);
  if (s) s.visible = isVisible;
  renderResults();
}

function setAllSnapshotsVisible(visible) {
  snapshots.forEach(s => { s.visible = visible; });
  renderSnapshotManager();
  renderResults();
}

function fmtSnapshotDateTime(iso) {
  const d = new Date(iso);
  return d.toLocaleDateString('de-CH') + ", " + d.toLocaleTimeString('de-CH', { hour: '2-digit', minute: '2-digit' });
}

function isSameLocalCalendarDay(value, reference = new Date()) {
  if (!value) return false;
  const d = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(d.getTime())) return false;
  return d.getFullYear() === reference.getFullYear() &&
    d.getMonth() === reference.getMonth() &&
    d.getDate() === reference.getDate();
}

function renderSnapshotManager() {
  const el = document.getElementById("snapshotManagerList");
  if (!el) return;
  if (snapshots.length === 0) {
    el.innerHTML = `<div class="empty">Noch keine Snapshots erstellt.</div>`;
    return;
  }
  const actions = `<div class="action-row" style="margin-bottom:10px">
    <button class="secondary" style="padding:4px 10px;font-size:0.78rem" onclick="setAllSnapshotsVisible(true)">Alle einblenden</button>
    <button class="secondary" style="padding:4px 10px;font-size:0.78rem" onclick="setAllSnapshotsVisible(false)">Alle ausblenden</button>
  </div>`;
  el.innerHTML = actions + snapshots.map(s => `
    <div class="custom-token-row">
      <label style="display:flex;align-items:center;gap:8px;cursor:pointer;margin:0">
        <input type="checkbox" ${s.visible ? "checked" : ""} onchange="toggleSnapshotVisible('${s.id}', this.checked)" style="width:auto" />
        ${fmtSnapshotDateTime(s.createdAt)}
      </label>
      <button class="remove" onclick="deleteSnapshot('${s.id}')">Löschen</button>
    </div>
  `).join("");
}

// ---- Verlauf-Grafik (ein Token über Zeit, Snapshots + aktueller Bestand) ----
let snapshotChartInstance = null;

function renderChartWalletSelect() {
  const el = document.getElementById("chartWalletSelect");
  if (!el) return;
  const visibleWallets=walletsForCurrentView();
  const current = el.value;
  el.innerHTML = `<option value="">Total (alle Wallets)</option>` +
    visibleWallets.map(w => `<option value="${w.id}">${escapeAttr(w.label)}</option>`).join("");
  if (current === "" || visibleWallets.some(w => w.id === current)) el.value = current;
}

// Ermittelt genau die Chain/Token-Kombinationen, die auch in der Summary-Tabelle
// auftauchen würden (aktueller Bestand > 0 ODER in irgendeinem Snapshot vorhanden) -
// unabhängig vom Chain-Sichtbarkeits-Filter oben, damit die Grafik-Auswahl stabil bleibt.
function computeAvailableChartOptions() {
  const options = [];
  Object.keys(CHAIN_META).forEach(chain => {
    const found = {}; // key -> {label, isNative}

    walletsForCurrentView().forEach(w => {
      const cd = (walletData[w.id] || {})[chain];
      if (!cd || cd.error) return;
      if (cd.native !== null && cd.native !== undefined && cd.native > 0) {
        found.native = { label: (NATIVE_SYMBOL[chain] || chain.toUpperCase()) + " (nativ)", isNative: true };
      }
      (cd.tokens || []).forEach(t => {
        if (t.amount <= 0 || !isSafeTokenAddress(t.address, chain)) return;
        found[(t.address || "").toLowerCase()] = { label: t.symbol, isNative: false };
      });
    });

    snapshots.forEach(s => {
      s.items.filter(it => it.chain === chain).forEach(it => {
        const key = it.is_native ? "native" : (it.address || "").toLowerCase();
        if (!found[key]) {
          found[key] = { label: it.is_native ? (NATIVE_SYMBOL[chain] || chain.toUpperCase()) + " (nativ)" : it.symbol, isNative: it.is_native };
        }
      });
    });

    Object.keys(found).forEach(key => {
      options.push({ chain, key, label: found[key].label, isNative: found[key].isNative });
    });
  });
  return options;
}

function renderChartChainSelect() {
  const el = document.getElementById("chartChainSelect");
  if (!el) return;
  const available = computeAvailableChartOptions();
  const chainsWithData = Object.keys(CHAIN_META).filter(c => available.some(o => o.chain === c));
  el.innerHTML = `<option value="">– Chain wählen –</option>` +
    chainsWithData.map(c => `<option value="${c}">${CHAIN_META[c].label}</option>`).join("");
  if (chainsWithData.length === 0) {
    el.innerHTML = `<option value="">Keine Bestände/Snapshots vorhanden</option>`;
  }
}

function populateChartTokenSelect() {
  const chain = document.getElementById("chartChainSelect").value;
  const tokenSelect = document.getElementById("chartTokenSelect");
  if (!chain) {
    tokenSelect.innerHTML = `<option value="">– zuerst Chain wählen –</option>`;
    tokenSelect.disabled = true;
    document.getElementById("snapshotChartContainer").innerHTML = "";
    return;
  }
  const available = computeAvailableChartOptions().filter(o => o.chain === chain);
  const options = [`<option value="">– Token wählen –</option>`];
  available.forEach(o => {
    const value = o.isNative ? "native" : o.key;
    options.push(`<option value="${value}">${escapeAttr(o.label)}</option>`);
  });

  tokenSelect.innerHTML = options.join("");
  tokenSelect.disabled = false;
  document.getElementById("snapshotChartContainer").innerHTML = "";
}

function generateSnapshotChart() {
  const walletId = document.getElementById("chartWalletSelect").value;
  const chain = document.getElementById("chartChainSelect").value;
  const tokenVal = document.getElementById("chartTokenSelect").value;
  const container = document.getElementById("snapshotChartContainer");

  if (!chain || !tokenVal) {
    container.innerHTML = "";
    return;
  }

  const matchWallet = walletId ? wallets.find(w => w.id === walletId) : null;
  const isNative = tokenVal === "native";
  const key = isNative ? "native" : tokenVal.toLowerCase();

  // Historische Punkte aus ALLEN Snapshots (unabhängig von deren Ein-/Ausblenden-Status
  // in der Tabellen-Ansicht), chronologisch aufsteigend sortiert.
  const sortedSnaps = snapshots.slice().sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
  const points = sortedSnaps.map(s => ({
    label: fmtSnapshotDateTime(s.createdAt),
    value: snapshotValueForKey(s, chain, key, matchWallet) || 0
  }));

  // Aktueller Live-Bestand als letzter Punkt
  let currentVal = 0;
  const wallets_ = matchWallet ? [matchWallet] : wallets;
  wallets_.forEach(w => {
    const cd = (walletData[w.id] || {})[chain];
    if (!cd) return;
    if (isNative) {
      currentVal += cd.native || 0;
    } else {
      const t = (cd.tokens || []).find(t => (t.address || "").toLowerCase() === key);
      if (t) currentVal += t.amount;
    }
  });
  points.push({ label: "Jetzt", value: currentVal });

  if (points.length < 2) {
    container.innerHTML = `<div class="empty">Zu wenig Datenpunkte (mind. 1 Snapshot nötig, um einen Verlauf zu zeigen).</div>`;
    return;
  }

  const tokenLabel = isNative
    ? (NATIVE_SYMBOL[chain] || chain.toUpperCase()) + " (nativ)"
    : (document.getElementById("chartTokenSelect").selectedOptions[0].textContent);
  const walletLabel = matchWallet ? matchWallet.label : "Total (alle Wallets)";

  container.innerHTML = `<canvas id="snapshotChartCanvas" height="90"></canvas>`;
  const ctx = document.getElementById("snapshotChartCanvas").getContext("2d");
  if (snapshotChartInstance) snapshotChartInstance.destroy();
  snapshotChartInstance = new Chart(ctx, {
    type: "line",
    data: {
      labels: points.map(p => p.label),
      datasets: [{
        label: `${tokenLabel} · ${CHAIN_META[chain].label} · ${walletLabel}`,
        data: points.map(p => p.value),
        borderColor: "#6c8cff",
        backgroundColor: "rgba(108,140,255,0.15)",
        fill: true,
        tension: 0.2,
        pointRadius: 4,
        pointBackgroundColor: "#6c8cff"
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: { labels: { color: "#e8e9ec" } },
        tooltip: { callbacks: { label: (ctx) => fmt(ctx.parsed.y) } }
      },
      scales: {
        x: { ticks: { color: "#9aa0ac" }, grid: { color: "#2a2e38" } },
        y: { ticks: { color: "#9aa0ac", callback: (v) => fmt(v) }, grid: { color: "#2a2e38" } }
      }
    }
  });
}

// ---- Portfolio-Allokation (Kreisdiagramm, nach USD-Wert) ----
let allocationChartInstance = null;
const ALLOC_COLORS = ["#6c8cff", "#f0b90b", "#8247e5", "#28a0f0", "#0052ff", "#e84142", "#00c2a8", "#ff060a", "#f7931a", "#14f195", "#46c878", "#ff6b6b", "#9aa0ac"];

function renderAllocWalletSelect() {
  const el = document.getElementById("allocWalletSelect");
  if (!el) return;
  const visibleWallets=walletsForCurrentView();
  const current = el.value;
  el.innerHTML = `<option value="">Total (alle Wallets)</option>` +
    visibleWallets.map(w => `<option value="${w.id}">${escapeAttr(w.label)}</option>`).join("");
  if (current === "" || visibleWallets.some(w => w.id === current)) el.value = current;
}

function renderAllocationChart() {
  const container = document.getElementById("allocationChartContainer");
  if (!container) return;
  const walletId = document.getElementById("allocWalletSelect").value;
  const groupBy = document.getElementById("allocGroupSelect").value; // "chain" | "token"
  const visibleWallets=walletsForCurrentView();
  const targetWallets = walletId ? visibleWallets.filter(w => w.id === walletId) : visibleWallets;

  const totals = {}; // key -> {label, value}
  let hasAnyValue = false;

  targetWallets.forEach(w => {
    Object.keys(CHAIN_META).forEach(chain => {
      const result = chainRows((walletData[w.id] || {})[chain], chain);
      if (!result || result.error) return;
      result.rows.forEach(r => {
        const key = groupBy === "chain" ? chain : r.symbol.replace(" (nativ)", "");
        const label = groupBy === "chain" ? CHAIN_META[chain].label : key;
        if (!totals[key]) totals[key] = { label, value: 0 };
        if (r.usdValue !== undefined) {
          totals[key].value += r.usdValue;
          hasAnyValue = true;
        } else {
          totals["_unknown"] = totals["_unknown"] || { label: "Unbekannt (kein Kurs)", value: 0 };
          // ohne Kurs kann kein USD-Wert beigetragen werden - Menge lässt sich nicht sinnvoll mit anderen mischen,
          // wird nur als Hinweis separat ausgewiesen (0 USD, taucht nicht im Kreis auf, aber im Hinweistext).
        }
      });
    });
  });

  if (!hasAnyValue) {
    container.innerHTML = `<div class="empty">Keine Bestände mit bekanntem Kurs vorhanden.</div>`;
    return;
  }

  const entries = Object.entries(totals).filter(([k, v]) => k !== "_unknown" && v.value > 0).sort((a, b) => b[1].value - a[1].value);

  container.innerHTML = `<canvas id="allocationChartCanvas"></canvas>`;
  const ctx = document.getElementById("allocationChartCanvas").getContext("2d");
  if (allocationChartInstance) allocationChartInstance.destroy();
  allocationChartInstance = new Chart(ctx, {
    type: "doughnut",
    data: {
      labels: entries.map(([k, v]) => v.label),
      datasets: [{
        data: entries.map(([k, v]) => v.value),
        backgroundColor: entries.map((_, i) => ALLOC_COLORS[i % ALLOC_COLORS.length]),
        borderColor: "#171a21",
        borderWidth: 2
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: { position: "bottom", labels: { color: getComputedStyle(document.documentElement).getPropertyValue("--text").trim() || "#10213f", boxWidth: 12, padding: 10 } },
        tooltip: {
          callbacks: {
            label: (ctx) => {
              const total = entries.reduce((s, [, v]) => s + v.value, 0);
              const pct = total > 0 ? (ctx.parsed / total * 100).toFixed(1) : "0";
              return ` ${ctx.label}: ${fmtUsd(ctx.parsed)} (${pct}%)`;
            }
          }
        }
      }
    }
  });
}

function visibleSnapshots() {
  return snapshots.filter(s => s.visible).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
}

// Prüft, ob für eine Chain (+ optional ein bestimmtes Wallet) überhaupt Snapshot-Daten
// existieren - damit eine Chain-Karte nicht ausgeblendet wird, nur weil der AKTUELLE
// Bestand 0 ist, obwohl ein Snapshot noch etwas zeigen würde.
// Ordnet eine Snapshot-Position einer Wallet zu - zuerst über die DB-ID (stabiler Normalfall),
// falls die nicht passt zusätzlich über den Wallet-Namen (Fallback, falls eine Wallet
// zwischenzeitlich neu gespeichert wurde und dadurch eine neue ID bekommen hat - der Name
// bleibt in dem Fall meist gleich, die ID aber nicht mehr).
function snapshotItemBelongsToWallet(it, matchWallet) {
  if (!matchWallet) return true;
  if(Array.isArray(matchWallet))return matchWallet.some(w=>String(it.wallet_id||"")===String(w.dbId||w.id||""));
  return String(it.wallet_id||"") === String(matchWallet.dbId||matchWallet.id||"");
}

function hasVisibleSnapshotDataForChain(chain, matchWallet) {
  return visibleSnapshots().some(s => s.items.some(it => it.chain === chain && snapshotItemBelongsToWallet(it, matchWallet)));
}

// ---- Bestands-Tabelle. wallet+chain optional: nur bei Angabe werden Snapshot-Spalten
// (fixierte Hauptspalten, seitlich scrollbar) angehängt - Summary bleibt unverändert. ----
const SNAPSHOT_COL_WIDTHS = { token: 260, amount: 140, price: 140, change: 90, value: 150, snap: 190 };

function rowKey(row) {
  return row.isNative ? "native" : (row.address || "").toLowerCase();
}

// Summiert den Bestand eines Tokens in einem Snapshot - entweder für EIN Wallet (matchWallet
// gesetzt) oder über ALLE Wallets summiert (matchWallet null, für die Summary-Tabelle).
function snapshotValueForKey(snap, chain, key, matchWallet) {
  const items = snap.items.filter(it => it.chain === chain && snapshotItemBelongsToWallet(it, matchWallet));
  const matching = items.filter(it => (it.is_native ? "native" : (it.address || "").toLowerCase()) === key);
  if (matching.length === 0) return null;
  return matching.reduce((sum, it) => sum + Number(it.amount), 0);
}

// Historischer USD-Kurs, der zusammen mit dem Snapshot gespeichert wurde.
// Bei einer Summary können mehrere Wallet-Zeilen zum selben Token existieren;
// da sie zum selben Snapshot-Zeitpunkt entstanden sind, genügt der erste
// vorhandene Kurswert. Alte Snapshots ohne price_usd liefern null.
function snapshotPriceForKey(snap, chain, key, matchWallet) {
  const items = snap.items.filter(it =>
    it.chain === chain &&
    snapshotItemBelongsToWallet(it, matchWallet) &&
    (it.is_native ? "native" : (it.address || "").toLowerCase()) === key
  );
  const priced = items.find(it => it.price_usd !== null && it.price_usd !== undefined && isFinite(Number(it.price_usd)));
  return priced ? Number(priced.price_usd) : null;
}

// Hängt an jede Zeile die Werte aus den sichtbaren Snapshots an (r.snapshotValues) und ergänzt
// Zeilen für Token, die aktuell 0 Bestand haben, aber in einem Snapshot vorkamen.
// matchWallet: ein Wallet-Objekt (Einzelwallet-Ansicht) oder null (Summary, über alle Wallets).
function attachSnapshotColumns(rows, chain, matchWallet) {
  const snaps = visibleSnapshots();
  if (snaps.length === 0) return rows;

  rows.forEach(r => {
    r.snapshotValues = {};
    r.snapshotPrices = {};
    snaps.forEach(s => {
      r.snapshotValues[s.id] = snapshotValueForKey(s, chain, rowKey(r), matchWallet);
      r.snapshotPrices[s.id] = snapshotPriceForKey(s, chain, rowKey(r), matchWallet);
    });
  });

  const presentKeys = new Set(rows.map(rowKey));
  const extraKeys = new Set();
  const extraRows = [];
  snaps.forEach(s => {
    s.items
      .filter(it => it.chain === chain && snapshotItemBelongsToWallet(it, matchWallet))
      .forEach(it => {
        const key = it.is_native ? "native" : (it.address || "").toLowerCase();
        if (presentKeys.has(key) || extraKeys.has(key)) return;
        extraKeys.add(key);
        const p = it.is_native ? nativePrices[chain] : priceForToken(chain, it.address);
        const extraRow = {
          symbol: it.symbol + " (aktuell 0)",
          chain,
          amount: 0, safe: true, isNative: it.is_native, address: it.address,
          price: p ? p.price : undefined, usdValue: 0, isHistoricalOnly: true,
          snapshotValues: {},
          snapshotPrices: {}
        };
        snaps.forEach(s2 => {
          extraRow.snapshotValues[s2.id] = snapshotValueForKey(s2, chain, key, matchWallet);
          extraRow.snapshotPrices[s2.id] = snapshotPriceForKey(s2, chain, key, matchWallet);
        });
        extraRows.push(extraRow);
      });
  });
  return rows.concat(extraRows);
}

function renderTable(rows, skipHeader) {
  if (!rows || rows.length === 0) return null;
  const snaps = visibleSnapshots();
  const hasSnaps = snaps.length > 0 && rows.some(r => r.snapshotValues);

  if (!hasSnaps) {
    return `<table class="balance-table">
      <colgroup>
        <col class="col-token"><col class="col-amount"><col class="col-price"><col class="col-change"><col class="col-value">
      </colgroup>
      ${skipHeader ? "" : '<thead><tr><th>Token</th><th style="text-align:right">Anzahl</th><th style="text-align:right">Kurs (USD)</th><th style="text-align:right">24h %</th><th style="text-align:right">Wert (USD)</th></tr></thead>'}
      <tbody>
      ${rows.map(r => `<tr class="${r.isNative ? 'native-row' : ''}">
        <td>${r.symbol} ${badge(r.safe)}${r.lpInfo?.stakedBalance>0?`<span class="price-source">davon gestakt: ${fmt(r.lpInfo.stakedBalance,{chain:r.chain||"",address:r.address,symbol:r.symbol})} ${escapeAttr(r.lpInfo.lpLabel||"LP")}</span>`:""}</td>
        <td class="num">${fmt(r.amount,{chain:r.chain||"",address:r.address,symbol:r.symbol})}</td>
        <td class="num">${r.price !== undefined ? fmtPrice(r.price) + (r.source ? `<span class="price-source">${r.source}</span>` : "") : '<span style="color:var(--muted)">–</span>'}</td>
        <td class="num">${fmtChange(r.change24h)}</td>
        <td class="num">${r.usdValue !== undefined ? fmtUsd(r.usdValue) : '<span style="color:var(--muted)">–</span>'}</td>
      </tr>`).join("")}
    </tbody></table>`;
  }

  const w = SNAPSHOT_COL_WIDTHS;
  const sticky = `position:sticky;left:0px;background:var(--card);z-index:2;`;

  const colgroup = `<colgroup>
    <col style="width:${w.token}px"><col style="width:${w.amount}px"><col style="width:${w.price}px"><col style="width:${w.change}px"><col style="width:${w.value}px">
    ${snaps.map(() => `<col style="width:${w.snap}px">`).join("")}
  </colgroup>`;

  const headerRow = skipHeader ? "" : `<thead><tr>
    <th style="${sticky}">Token</th>
    <th style="text-align:right">Anzahl</th>
    <th style="text-align:right">Kurs (USD)</th>
    <th style="text-align:right">24h %</th>
    <th style="text-align:right">Wert (USD)</th>
    ${snaps.map(s => `<th style="text-align:right;white-space:normal">${fmtSnapshotDateTime(s.createdAt)}<span class="price-source">Anzahl · Kurs damals</span></th>`).join("")}
  </tr></thead>`;

  const bodyRows = rows.map(r => {
    const snapCells = snaps.map(s => {
      const amt = r.snapshotValues ? r.snapshotValues[s.id] : null;
      const historicalPrice = r.snapshotPrices ? r.snapshotPrices[s.id] : null;
      const amountHtml = amt !== null && amt !== undefined ? fmt(amt,{chain:r.chain||"",address:r.address,symbol:r.symbol}) : '<span style="color:var(--muted)">–</span>';
      const priceHtml = historicalPrice !== null && historicalPrice !== undefined
        ? fmtPrice(historicalPrice)
        : '<span style="color:var(--muted)">–</span>';
      return `<td class="num">
        <div>${amountHtml}</div>
        <span class="price-source">Kurs: ${priceHtml}</span>
      </td>`;
    }).join("");
    const mutedStyle = r.isHistoricalOnly ? "opacity:0.6;" : "";
    return `<tr class="${r.isNative ? 'native-row' : ''}" style="${mutedStyle}">
      <td style="${sticky}${mutedStyle}">${r.symbol}${r.isHistoricalOnly ? '' : ' ' + badge(r.safe)}${r.lpInfo?.stakedBalance>0?`<span class="price-source">davon gestakt: ${fmt(r.lpInfo.stakedBalance,{chain:r.chain||"",address:r.address,symbol:r.symbol})} ${escapeAttr(r.lpInfo.lpLabel||"LP")}</span>`:""}</td>
      <td class="num" style="${mutedStyle}">${fmt(r.amount,{chain:r.chain||"",address:r.address,symbol:r.symbol})}</td>
      <td class="num" style="${mutedStyle}">${r.price !== undefined ? fmtPrice(r.price) + (r.source ? `<span class="price-source">${r.source}</span>` : "") : '<span style="color:var(--muted)">–</span>'}</td>
      <td class="num" style="${mutedStyle}">${fmtChange(r.change24h)}</td>
      <td class="num" style="${mutedStyle}">${r.usdValue !== undefined ? fmtUsd(r.usdValue) : '<span style="color:var(--muted)">–</span>'}</td>
      ${snapCells}
    </tr>`;
  }).join("");

  return `<div style="overflow-x:auto"><table class="balance-table" style="width:max-content;min-width:100%">${colgroup}${headerRow}<tbody>${bodyRows}</tbody></table></div>`;
}

// Eine einzige Spaltenüberschrift-Zeile pro Wallet, mit dem Wallet-Namen anstelle von
// "Token" - spart die sonst pro Chain-Karte wiederholte Kopfzeile. Lange Wallet-Namen
// brechen dank normaler Tabellenzelle von selbst um, statt die Spalten zu überlagern.
function renderWalletHeader(walletLabel) {
  const snaps = visibleSnapshots();
  const w = SNAPSHOT_COL_WIDTHS;
  const titleStyle = "font-size:1.05rem;font-weight:700;white-space:normal;overflow:visible;text-overflow:clip;line-height:1.3;text-transform:none;color:var(--text);";

  if (snaps.length === 0) {
    return `<table class="balance-table" style="margin-bottom:2px">
      <colgroup><col class="col-token"><col class="col-amount"><col class="col-price"><col class="col-change"><col class="col-value"></colgroup>
      <thead><tr>
        <th style="${titleStyle}">💼 ${escapeAttr(walletLabel)}</th>
        <th style="text-align:right">Anzahl</th>
        <th style="text-align:right">Kurs (USD)</th>
        <th style="text-align:right">24h %</th>
        <th style="text-align:right">Wert (USD)</th>
      </tr></thead>
    </table>`;
  }

  const colgroup = `<colgroup>
    <col style="width:${w.token}px"><col style="width:${w.amount}px"><col style="width:${w.price}px"><col style="width:${w.change}px"><col style="width:${w.value}px">
    ${snaps.map(() => `<col style="width:${w.snap}px">`).join("")}
  </colgroup>`;
  const sticky = `position:sticky;left:0px;background:var(--card2);z-index:2;`;

  return `<div style="overflow-x:auto"><table class="balance-table" style="width:max-content;min-width:100%;margin-bottom:2px">
    ${colgroup}
    <thead><tr>
      <th style="${sticky}${titleStyle}">💼 ${escapeAttr(walletLabel)}</th>
      <th style="text-align:right">Anzahl</th>
      <th style="text-align:right">Kurs (USD)</th>
      <th style="text-align:right">24h %</th>
      <th style="text-align:right">Wert (USD)</th>
      ${snaps.map(s => `<th style="text-align:right;white-space:normal">${fmtSnapshotDateTime(s.createdAt)}<span class="price-source">Anzahl · Kurs damals</span></th>`).join("")}
    </tr></thead>
  </table></div>`;
}

function explorerUrlForWallet(chain, wallet) {
  const cfg = CHAIN_CONFIG[chain];
  if (!cfg || !cfg.explorerUrlTemplate || !cfg.walletType) return null;

  const fieldByWalletType = {
    evm: "evm",
    btc: "btc",
    xrp: "xrp",
    sol: "sol",
    tron: "tron",
    akash: "akash"
  };
  const field = fieldByWalletType[cfg.walletType];
  const address = field ? wallet?.[field] : null;
  if (!address) return null;

  return cfg.explorerUrlTemplate.replace("{address}", encodeURIComponent(address));
}


// TLN/VOW-Tab nur anzeigen, wenn die aktuelle Gesamtübersicht tatsächlich
// mindestens einen gehaltenen TLN/VOW-klassifizierten Token enthält.
// Zuordnung ausschließlich über Chain + Contract-Adresse, nie über Symbol/Name.
function hasTlnVowTokenInSummary() {
  for (const chain of Object.keys(CHAIN_META)) {
    const totals = {};

    for (const w of wallets) {
      const cd = (walletData[w.id] || {})[chain];
      if (!cd || cd.error) continue;

      for (const token of (cd.tokens || [])) {
        if (!token.address || Number(token.amount) <= 0) continue;
        if (!isSafeTokenAddress(token.address, chain)) continue;

        const address = normalizeAddress(token.address, chain);
        const key = chain + "|" + address;
        totals[key] = (totals[key] || 0) + Number(token.amount);
      }
    }

    for (const [key, amount] of Object.entries(totals)) {
      // Gleiche Sichtbarkeitsschwelle wie in der Summary.
      if (amount < DUST_THRESHOLD) continue;

      // Wert der Kategorie ist egal: v_currency, lp_token oder tln_vow_token
      // zählen alle. Entscheidend ist nur, dass die TLN/VOW-Spalte nicht leer ist.
      const category = predefinedTokenCategory[key];
      const project = predefinedTokenProject[key];
      if (project === "tln_vow" && category) return true;
    }
  }
  return false;
}

function updateDefiProjectsNavGroupVisibility() {
  const group = document.getElementById("defiProjectsNavGroup");
  if (!group) return false;
  const anyVisible = [...group.querySelectorAll(".tab-btn")].some(btn => btn.style.display !== "none");
  group.style.display = anyVisible ? "flex" : "none";
  return anyVisible;
}

function updateTlnVowTabVisibility() {
  const btn = document.getElementById("tlnVowTabBtn");
  const visible = hasTlnVowTokenInSummary();

  if (btn) btn.style.display = visible ? "inline-block" : "none";
  updateDefiProjectsNavGroupVisibility();

  // Falls der User gerade im Projekt-Tab ist und der letzte passende Bestand
  // verschwindet, automatisch zurück zum Wallet-Tracking.
  const panel = document.getElementById("tab-tlnvow");
  if (!visible && panel && panel.classList.contains("active")) {
    showTab("tracking");
  }

  return visible;
}

function renderResults() {
  const visibleWallets=walletsForCurrentView();
  // --- Details je Wallet ---
  const resultsContainer = document.getElementById("resultsContainer");
  if (visibleWallets.length === 0) {
    resultsContainer.innerHTML = `<div class="empty">Für den gewählten Personenfilter sind keine Wallets vorhanden.</div>`;
  } else {
    resultsContainer.innerHTML = visibleWallets.map(w => {
      const data = walletData[w.id] || {};
      const chainCards = Object.keys(CHAIN_META).filter(chain => activeChainFilter.has(chain)).map(chain => {
        const meta = CHAIN_META[chain];
        const hasSnapshotData = hasVisibleSnapshotDataForChain(chain, w);
        let result = chainRows(data[chain], chain);

        // Wichtig: Wenn beim Seitenstart noch kein aktueller Chain-Datensatz vorhanden ist,
        // aber ein sichtbarer Snapshot Werte für dieses Wallet enthält, trotzdem eine
        // Detailkarte erzeugen. Früher wurde hier sofort return "" ausgeführt; dadurch war
        // die Summary sichtbar, die Detailansicht je Wallet aber leer.
        if (!result) {
          if (!hasSnapshotData) return "";
          result = { rows: [] };
        }

        if (!result.error && result.rows.length === 0 && !hasSnapshotData) return "";

        let body;
        if (result.error) {
          body = `<div class="error">Fehler beim Laden: ${result.error}</div>`;
        } else {
          body = renderTable(attachSnapshotColumns(result.rows, chain, w), true) || '<div class="empty">Keine aktuellen Bestände, aber Snapshot-Daten vorhanden.</div>';
        }
        const explorerUrl = explorerUrlForWallet(chain, w);
        const explorerLink = explorerUrl ? ` <a href="${explorerUrl}" target="_blank" rel="noopener" style="font-size:0.72rem;color:var(--accent);font-weight:400;margin-left:6px">Auf Explorer ansehen ↗</a>` : "";
        return `<div class="chain-card">
          <div class="chain-title"><span class="dot" style="background:${escapeAttr(CHAIN_CONFIG[meta.dot]?.displayColor || "#6b7280")}"></span> ${meta.label}${explorerLink}</div>
          ${body}
        </div>`;
      }).join("");

      return `<div class="wallet-block" id="wallet-block-${w.id}">
        ${renderWalletHeader(w.label)}
        ${chainCards || '<div class="empty">Keine Bestände gefunden.</div>'}
      </div>`;
    }).join("");
  }

  renderWalletNav();
  renderChartChainSelect(); // Verfügbare Chains/Token für die Grafik hängen von Bestand+Snapshots ab, hier immer aktuell halten

  // --- Summary über alle Wallets, pro Chain aggregiert ---
  const summaryContainer = document.getElementById("summaryContainer");
  const summaryCards = Object.keys(CHAIN_META).filter(chain => activeChainFilter.has(chain)).map(chain => {
    const meta = CHAIN_META[chain];
    const totals = {}; // key -> {symbol, amount, safe, isNative}
    let hadError = false;

    visibleWallets.forEach(w => {
      const cd = (walletData[w.id] || {})[chain];
      if (!cd) return;
      if (cd.error) { hadError = true; return; }
      if (cd.native !== null && cd.native !== undefined && cd.native > 0) {
        const key = "native";
        totals[key] = totals[key] || { symbol: cd.nativeSymbol + " (nativ)", amount: 0, safe: true, isNative: true };
        totals[key].amount += cd.native;
      }
      (cd.tokens || []).forEach(t => {
        if (t.amount <= 0) return;
        const safe = isSafeTokenAddress(t.address, chain);
        const key = (t.address || t.symbol).toLowerCase();
        totals[key] = totals[key] || { symbol: t.symbol, amount: 0, safe, isNative: false, address: t.address };
        totals[key].amount += t.amount;
      });
    });

    // Erst NACH dem Aufsummieren über alle Wallets filtern - eine Summe kann trotz
    // einzelner Mini-Beträge unter der Sichtbarkeitsschwelle liegen.
    const rows = Object.values(totals).filter(r => r.safe && r.amount >= DUST_THRESHOLD);
    const p = nativePrices[chain];
    rows.forEach(r => {
      if (r.isNative && p) {
        r.price = p.price;
        r.change24h = p.change24h;
        r.source = "CoinGecko";
        r.usdValue = r.amount * p.price;
      } else if (!r.isNative) {
        const tp = priceForToken(chain, r.address);
        if (tp) {
          r.price = tp.price;
          r.change24h = tp.change24h;
          r.source = tp.source;
          r.usdValue = r.amount * tp.price;
        }
      }
    });

    if (rows.length === 0 && !hadError && !hasVisibleSnapshotDataForChain(chain, visibleWallets)) return ""; // keine Bestände -> gar nicht anzeigen

    const sortedRows = rows.sort((a, b) => b.amount - a.amount);
    let body = renderTable(attachSnapshotColumns(sortedRows, chain, visibleWallets)) || '<div class="empty">Keine aktuellen Bestände, aber Snapshot-Daten vorhanden.</div>';
    if (hadError) {
      body += `<div class="error" style="margin-top:6px">Hinweis: Bei mindestens einem Wallet trat auf dieser Chain ein Fehler auf — Summe ist unvollständig.</div>`;
    }

    return `<div class="chain-card">
      <div class="chain-title"><span class="dot" style="background:${escapeAttr(CHAIN_CONFIG[meta.dot]?.displayColor || "#6b7280")}"></span> ${meta.label} — Total</div>
      ${body}
    </div>`;
  }).join("");

  summaryContainer.innerHTML = summaryCards || '<div class="empty">Keine Bestände gefunden.</div>';
  updateTlnVowTabVisibility();
  window.DAO1Project?.updateVisibility?.();
}

// ============================================================

async function lpWalletTransfersSince(chain,address,fromBlock=0,contractAddresses=null){
  const out=[],seen=new Set(),add=(x)=>{const k=`${x.contract}|${x.tx_hash}|${x.block_number}`;if(!seen.has(k)){seen.add(k);out.push(x);}};
  const minBlock=Math.max(0,Number(fromBlock||0));
  const filterSet=contractAddresses?.length?new Set(contractAddresses.map(a=>normalizeAddress(a,chain))):null;
  if(CHAIN_CONFIG[chain]?.discoveryProvider==="alchemy"){
    for(const direction of ["fromAddress","toAddress"]){
      let pageKey=null,pages=0;
      do{
        const q={fromBlock:taxBlockHex(minBlock),toBlock:"latest",category:["erc20"],withMetadata:false,excludeZeroValue:false,maxCount:"0x3e8"};
        q[direction]=address;
        // Für klassifizierte Projekt-LPs direkt bei Alchemy auf genau diese Contracts begrenzen.
        // Dadurch werden normale ERC-20-Token gar nicht mehr als mögliche V2-Paare geprüft.
        if(filterSet?.size)q.contractAddresses=[...filterSet];
        if(pageKey)q.pageKey=pageKey;
        const r=await alchemyRpc(chain,"alchemy_getAssetTransfers",[q],"discovery");
        for(const t of (r?.transfers||[])){const a=t.rawContract?.address,b=t.blockNum?Number(BigInt(t.blockNum)):0,h=t.hash,na=a?normalizeAddress(a,chain):null;if(na&&h&&b>=minBlock&&(!filterSet||filterSet.has(na)))add({contract:na,tx_hash:h,block_number:b});}
        pageKey=r?.pageKey||null;pages++;
      }while(pageKey&&pages<100);
    }
    return out;
  }
  const base=String(CHAIN_CONFIG[chain]?.discoveryApiBase||CHAIN_CONFIG[chain]?.balanceApiBase||"").replace(/\/$/,"");
  if(base){
    let url=`${base}/addresses/${address}/token-transfers?type=ERC-20`,pages=0,done=false;
    while(url&&!done&&pages++<200){
      const res=await fetch(url);if(!res.ok)throw new Error(`${chain}: Explorer HTTP ${res.status}`);const j=await res.json();
      for(const t of (j.items||[])){const b=Number(t.block_number||0);if(b<minBlock){done=true;continue;}const a=t.token?.address,h=t.transaction_hash||t.tx_hash,na=a?normalizeAddress(a,chain):null;if(na&&h&&(!filterSet||filterSet.has(na)))add({contract:na,tx_hash:h,block_number:b});}
      const np=j.next_page_params;url=(!done&&np)?`${base}/addresses/${address}/token-transfers?type=ERC-20&${new URLSearchParams(np)}`:null;
    }
  }
  return out;
}


function projectClassifiedLpAddresses(projectKey,chain){
  const out=[];
  for(const [key,project] of Object.entries(predefinedTokenProject||{})){
    if(project!==projectKey||predefinedTokenCategory?.[key]!=="lp_token")continue;
    const sep=key.indexOf("|");if(sep<0)continue;
    const c=key.slice(0,sep),a=key.slice(sep+1);if(c===chain&&a)out.push(normalizeAddress(a,chain));
  }
  return [...new Set(out)];
}

function projectUnderlyingTokenAddresses(projectKey,chain){
  const out=[];
  for(const [key,project] of Object.entries(predefinedTokenProject||{})){
    if(project!==projectKey||predefinedTokenCategory?.[key]==="lp_token")continue;
    const sep=key.indexOf("|");if(sep<0)continue;
    const c=key.slice(0,sep),a=key.slice(sep+1);if(c===chain&&a)out.push(normalizeAddress(a,chain));
  }
  return [...new Set(out)];
}

function lpPairBelongsToProject(pair,chain,projectKey){
  const k0=chain+'|'+normalizeAddress(pair.t0.address,chain),k1=chain+'|'+normalizeAddress(pair.t1.address,chain);
  return predefinedTokenProject[k0]===projectKey||predefinedTokenProject[k1]===projectKey;
}

function projectLpScanType(projectKey,chain){
  const classifiedOnly=projectKey==="tln_vow"&&["bsc","eth"].includes(chain);
  return (projectKey==="tln_vow"&&chain==="bsc")?"lp_history_v7_legacy_discovery":(classifiedOnly?"lp_history_v3_classified":"lp_history_v2");
}

async function syncProjectLpHistory(projectKey,chain,walletAddress){
  if(!window.WalletLPEngine)return {events:[],scanned:0,newEvents:0,pairs:[]};
  const engine=window.WalletLPEngine,cached=await engine.loadHistory(projectKey,chain,walletAddress).catch(()=>[]);
  const classifiedOnly=projectKey==="tln_vow"&&["bsc","eth"].includes(chain);
  const legacyDiscovery=projectKey==="tln_vow"&&chain==="bsc";
  const configuredPairs=classifiedOnly?projectClassifiedLpAddresses(projectKey,chain):[];
  const projectUnderlying=new Set(projectUnderlyingTokenAddresses(projectKey,chain));
  // BSC/TLN/VOW: historische LPs werden aus der Wallet-Transferhistorie entdeckt.
  // Ein Kandidat gilt als Projekt-LP, wenn token0 ODER token1 ein aktueller/Legacy-
  // Projekt-Underlying aus predefined_tokens ist. Dadurch bleiben alte VOW/v$-Pools
  // auffindbar, auch wenn ihre LP-Adresse heute nicht mehr als lp_token geführt wird.
  if(classifiedOnly&&!legacyDiscovery&&configuredPairs.length===0){
    return {events:cached,scanned:0,newEvents:0,pairs:[],warning:`${chain}: Keine als lp_token klassifizierten ${projectKey}-Pools konfiguriert; Live-LP-Scan übersprungen.`};
  }
  if(legacyDiscovery&&projectUnderlying.size===0){
    return {events:cached,scanned:0,newEvents:0,pairs:[],warning:`${chain}: Keine TLN/VOW-Projekt-Underlyings konfiguriert; Legacy-LP-Discovery übersprungen.`};
  }
  const cachedPairs=new Set(cached.map(r=>normalizeAddress(r.pair_address,chain)).filter(Boolean));
  const scanType=projectLpScanType(projectKey,chain);
  let last=0;try{last=await engine.getScanState(projectKey,chain,walletAddress,scanType);}catch{}
  let latest=0;
  try{latest=await engine.latestBlock(chain);}
  catch(e){return {events:cached,scanned:last,newEvents:0,pairs:[],warning:`RPC eth_blockNumber: ${e?.message||String(e)}`};}
  const from=last>0?Math.max(0,last-50):0;
  let transfers=[],syncWarning=null;
  try{
    // Legacy-Discovery braucht beim ersten v7-Lauf bewusst die gesamte ERC-20-Historie.
    // Danach läuft derselbe Scan inkrementell ab dem letzten erfolgreichen Block weiter.
    transfers=await lpWalletTransfersSince(chain,walletAddress,from,legacyDiscovery?null:(classifiedOnly?configuredPairs:null));
  }catch(e){syncWarning=`Transfer-Discovery: ${e?.message||String(e)}`;}

  const pairMap=new Map();
  const initialPairs=[...new Set([...configuredPairs,...cachedPairs])];
  for(const a of initialPairs){
    // Für History reicht die LP-Identität. Aktuelle Reserven/Supply dürfen Discovery
    // nicht blockieren; genau das war die Regression gegenüber der isolierten Testseite.
    const p=engine.pairDescriptor?await engine.pairDescriptor(chain,a):await engine.pairInfo(chain,a);
    if(p&&lpPairBelongsToProject(p,chain,projectKey))pairMap.set(normalizeAddress(a,chain),p);
  }

  let candidateContracts=[];
  // Legacy-Discovery entspricht jetzt bewusst dem erfolgreichen isolierten Test:
  // ERC20-Contract -> token0/token1 -> Projekt-Treffer -> factory/decimals/meta.
  // getReserves()/totalSupply() sind KEINE Voraussetzung für historische Events.
  if(legacyDiscovery){
    candidateContracts=[...new Set(transfers.map(t=>normalizeAddress(t.contract,chain)).filter(Boolean))];
    for(const a of candidateContracts){
      if(pairMap.has(a))continue;
      const basic=engine.pairTokens?await engine.pairTokens(chain,a):null;
      if(!basic)continue;
      if(!projectUnderlying.has(normalizeAddress(basic.token0,chain))&&!projectUnderlying.has(normalizeAddress(basic.token1,chain)))continue;
      const p=engine.pairDescriptor?await engine.pairDescriptor(chain,a):await engine.pairInfo(chain,a);
      if(p&&lpPairBelongsToProject(p,chain,projectKey))pairMap.set(a,p);
    }
  }else if(!classifiedOnly){
    for(const t of transfers){
      const a=normalizeAddress(t.contract,chain);if(pairMap.has(a))continue;
      const p=await engine.pairInfo(chain,a);if(p&&lpPairBelongsToProject(p,chain,projectKey))pairMap.set(a,p);
    }
  }

  let newEvents=0,newStakingEvents=0,earliestFailedBlock=null;const done=new Set(cached.map(r=>`${normalizeAddress(r.pair_address,chain)}|${String(r.tx_hash).toLowerCase()}|${r.event_type}`));
  for(const t of transfers){
    const pair=pairMap.get(normalizeAddress(t.contract,chain));if(!pair)continue;
    const txKey=`${pair.address}|${String(t.tx_hash).toLowerCase()}`;
    if([...done].some(k=>k.startsWith(txKey+'|')))continue;
    try{
      const ev=await engine.historyEventFromReceipt(chain,pair,walletAddress,t.tx_hash,t.block_number,{
        classifyTransfer: async ({direction,counterparty,pairAddress}) => {
          if(!window.WalletStakingEngine)return {eventType:direction==="out"?"send":"receive",staking:null};
          return window.WalletStakingEngine.classifyTransfer(projectKey,chain,direction,counterparty,pairAddress);
        }
      });if(!ev)continue;
      const k=`${pair.address}|${String(t.tx_hash).toLowerCase()}|${ev.event_type}`;if(done.has(k))continue;
      await engine.saveHistory(projectKey,chain,walletAddress,pair,ev);done.add(k);newEvents++;if(ev.event_type==="stake"||ev.event_type==="unstake")newStakingEvents++;
    }catch(e){earliestFailedBlock=earliestFailedBlock==null?Number(t.block_number):Math.min(earliestFailedBlock,Number(t.block_number));console.warn("LP-History Event",chain,t.tx_hash,e);}
  }
  if(!syncWarning){
    const safeScannedBlock=earliestFailedBlock==null?latest:Math.max(0,earliestFailedBlock-1);
    await engine.setScanState(projectKey,chain,walletAddress,safeScannedBlock,scanType,{transfersSeen:transfers.length,candidateContracts:candidateContracts.length,projectPairs:pairMap.size,eventsSaved:newEvents,stakingEvents:newStakingEvents,result:earliestFailedBlock==null?'ok':'partial',message:earliestFailedBlock==null?null:`Mindestens ein LP-History-Event ab Block ${earliestFailedBlock} konnte nicht gespeichert/verarbeitet werden.`});
  }
  return {events:await engine.loadHistory(projectKey,chain,walletAddress),scanned:latest,newEvents,pairs:[...pairMap.values()],warning:syncWarning,diagnostics:{transfersSeen:transfers.length,candidateContracts:candidateContracts.length,projectPairs:pairMap.size,eventsSaved:newEvents,stakingEvents:newStakingEvents}};
}

const projectLpWalletFilters={};
window.setProjectLpWalletFilter=function(targetId,value){projectLpWalletFilters[targetId]=value||'all';const chain=targetId.includes('Eth')?'eth':'bsc';return renderProjectLpTab('tln_vow',[chain],targetId,'2025-12-31',false);};

async function renderProjectLpTab(projectKey,chains,targetId,dateStr="2025-12-31",refresh=false,options={}){
  const el=document.getElementById(targetId);if(!el||!window.WalletLPEngine)return;
  const chainArg=chains.length===1?chains[0]:"";
  const refreshButton=`<button class="secondary" style="margin-top:10px" onclick="refreshProjectLpData('${projectKey}','${chainArg}','${targetId}')">Daten aktualisieren</button>`;
  // Der Button wird absichtlich VOR allen asynchronen Arbeiten gerendert. Beim normalen
  // Öffnen folgen ausschließlich Supabase-Lesezugriffe; RPC/Explorer laufen nur bei refresh=true.
  el.innerHTML=`<div class="custom-token-card"><div class="chain-title">Liquidity Pools</div><div class="note">Beim Öffnen werden <strong>ausschließlich die zuletzt gespeicherten Supabase-Daten</strong> angezeigt. Blockchain, Explorer, Reserven, Kurse und Historie werden nur über „Daten aktualisieren“ neu abgefragt.</div>${refreshButton}<div class="status" style="margin-top:10px"><span class="loading">${refresh?'LP/PCLP-Daten werden aktualisiert…':'Gespeicherte LP/PCLP-Daten werden geladen…'}</span></div></div>`;

  const scopeWallets=options.walletId?wallets.filter(w=>walletDbId(w)===String(options.walletId)):wallets;
  const rows=[],history=[],scanStatuses=[];let cacheNew=0,cacheErrors=[],cacheWarnings=[],latestCacheRefresh=null;
  const targetEpoch=Math.floor(new Date(dateStr+'T23:59:59Z').getTime()/1000);

  for(const chain of chains){
    // Wichtig: Stichtagsblock nur bei explizitem Refresh bestimmen. Das war der versteckte
    // Blockchain-Aufruf, durch den der Tab zuvor trotz "Cache" lange hängen blieb.
    let block=null;
    if(refresh){try{block=(await taxEvmBlockByTime(chain,targetEpoch)).block;}catch(e){cacheWarnings.push(`${CHAIN_META[chain]?.label||chain}: Stichtagsblock ${dateStr} nicht ermittelbar (${e?.message||e})`);}}

    for(const w of scopeWallets){
      const wa=walletAddressForChain(w,chain);if(!wa)continue;
      let sync={events:[],pairs:[]};

      if(!refresh){
        // Reiner DB-Modus: weder pairInfo(), balanceOf(), getReserves(), Blocksuche noch Preise.
        try{
          const [events,posRows]=await Promise.all([
            window.WalletLPEngine.loadHistory(projectKey,chain,wa),
            window.WalletLPEngine.loadPositionCache(projectKey,chain,wa)
          ]);
          sync.events=events||[];
          const cachedPairSet=new Set();
          for(const c of (posRows||[])){
            const pairAddress=normalizeAddress(c.pair_address,chain);cachedPairSet.add(pairAddress);
            const refreshed=c.refreshed_at?new Date(c.refreshed_at):null;if(refreshed&&(!latestCacheRefresh||refreshed>latestCacheRefresh))latestCacheRefresh=refreshed;
            rows.push({
              chain,w,
              pair:{address:c.pair_address,t0:{address:c.token0_address,symbol:c.token0_symbol||'Token0',decimals:c.token0_decimals},t1:{address:c.token1_address,symbol:c.token1_symbol||'Token1',decimals:c.token1_decimals}},
              cur:{balance:Number(c.current_lp||0),walletBalance:Number(c.current_wallet_lp??c.current_lp??0),stakedBalance:Number(c.current_staked_lp||0),amount0:Number(c.current_amount0||0),amount1:Number(c.current_amount1||0),share:Number(c.current_share||0),usd:c.current_usd==null?null:Number(c.current_usd)},
              histBal:Number(c.snapshot_lp||0),histWalletBal:Number(c.snapshot_wallet_lp??c.snapshot_lp??0),histStakedBal:Number(c.snapshot_staked_lp||0),histUsd:c.snapshot_usd==null?null:Number(c.snapshot_usd),cached:true
            });
          }
          // Historische LP-Wallets dürfen nicht verschwinden, nur weil ein älterer Lauf
          // keinen lp_position_cache-Eintrag erzeugt hat oder der heutige Bestand 0 ist.
          // In diesem Fall wird aus lp_history_events eine reine Historienzeile aufgebaut.
          const historicalPairs=new Map();
          for(const e of sync.events){
            const pa=normalizeAddress(e.pair_address,chain);if(!pa||cachedPairSet.has(pa)||historicalPairs.has(pa))continue;
            historicalPairs.set(pa,e);
          }
          for(const [pa,e] of historicalPairs){
            rows.push({
              chain,w,historicalOnly:true,
              pair:{address:pa,t0:{address:e.token0_address,symbol:e.token0_symbol||'Token0',decimals:e.token0_decimals},t1:{address:e.token1_address,symbol:e.token1_symbol||'Token1',decimals:e.token1_decimals}},
              cur:{balance:0,walletBalance:0,stakedBalance:0,amount0:0,amount1:0,share:0,usd:null},
              histBal:null,histWalletBal:null,histStakedBal:null,histUsd:null,cached:true
            });
          }
        }catch(e){cacheErrors.push(`${CHAIN_META[chain]?.label||chain}/${w.label}: Cache konnte nicht gelesen werden: ${e.message}`);}
      }else{
        try{sync=await syncProjectLpHistory(projectKey,chain,wa);cacheNew+=sync.newEvents||0;if(sync.warning)cacheWarnings.push(`${CHAIN_META[chain]?.label||chain}/${w.label}: ${sync.warning}`);}catch(e){cacheErrors.push(`${CHAIN_META[chain]?.label||chain}/${w.label}: ${e.message}`);console.warn("LP-Cache Sync",chain,wa,e);try{sync.events=await window.WalletLPEngine.loadHistory(projectKey,chain,wa);}catch{}}

        const classifiedOnly=projectKey==="tln_vow"&&["bsc","eth"].includes(chain);
        const currentCandidates=classifiedOnly?projectClassifiedLpAddresses(projectKey,chain):(walletData[w.id]?.[chain]?.tokens||[]).map(t=>t.address).filter(Boolean);
        const candidates=new Set([...currentCandidates,...sync.events.map(e=>e.pair_address),...(sync.pairs||[]).map(p=>p.address)].filter(Boolean).map(a=>normalizeAddress(a,chain)));
        const walletPositionCache=[];
        for(const a of candidates){
          let fullPair=null;try{fullPair=await window.WalletLPEngine.pairInfo(chain,a);}catch{}
          let pair=fullPair||(sync.pairs||[]).find(p=>normalizeAddress(p.address,chain)===a)||null;
          if(!pair&&window.WalletLPEngine.pairDescriptor){try{pair=await window.WalletLPEngine.pairDescriptor(chain,a);}catch{}}
          if(!pair||!lpPairBelongsToProject(pair,chain,projectKey))continue;
          let walletCur=null,walletCurBal=0;
          if(fullPair){try{walletCur=(await window.WalletLPEngine.positions(chain,wa,[a]))[0]||null;walletCurBal=Number(walletCur?.balance||0);}catch{}}
          else if(window.WalletLPEngine.balance){try{walletCurBal=Number(await window.WalletLPEngine.balance(chain,pair,wa)||0);}catch{}}
          const stakedCur=(projectKey==="tln_vow"&&chain==="bsc"&&window.WalletStakingEngine)?window.WalletStakingEngine.stakeBalanceAt(sync.events,a):0;
          const economicCurBal=walletCurBal+Number(stakedCur||0);
          let cur=null;if(economicCurBal>DUST_THRESHOLD&&fullPair){try{cur={...fullPair,...await window.WalletLPEngine.valuePosition(chain,fullPair,economicCurBal),walletBalance:walletCurBal,stakedBalance:Number(stakedCur||0)};}catch{cur=walletCur?{...walletCur,walletBalance:walletCurBal,stakedBalance:Number(stakedCur||0),balance:economicCurBal}:null;}}
          if(!cur&&economicCurBal>DUST_THRESHOLD)cur={balance:economicCurBal,walletBalance:walletCurBal,stakedBalance:Number(stakedCur||0),amount0:0,amount1:0,share:0,usd:null,valuationUnavailable:true};
          let histWalletBal=0,histStakedBal=0,histBal=0,histPrice=null,histUsd=null;if(block){try{histWalletBal=(await taxEvmTokenBalance(chain,wa,{address:a,decimals:pair.decimals},block)).amount;histStakedBal=(projectKey==="tln_vow"&&chain==="bsc"&&window.WalletStakingEngine)?window.WalletStakingEngine.stakeBalanceAt(sync.events,a,new Date(dateStr+'T23:59:59Z')):0;histBal=Number(histWalletBal||0)+Number(histStakedBal||0);if(histBal>DUST_THRESHOLD){histPrice=await taxV2LpHistoricalPrice(chain,{address:a,decimals:pair.decimals,symbol:window.WalletLPEngine.label(chain)},block,dateStr);histUsd=histPrice?.price!=null?histBal*histPrice.price:null;}}catch(e){console.warn('LP historisch',chain,a,e);}}
          if(cur||histBal>DUST_THRESHOLD||sync.events.some(e=>normalizeAddress(e.pair_address,chain)===a)){
            rows.push({chain,w,pair,cur,histBal,histWalletBal,histStakedBal,histPrice,histUsd});
            walletPositionCache.push({pair_address:pair.address,lp_label:window.WalletLPEngine.label(chain),token0_address:pair.t0.address,token0_symbol:pair.t0.symbol,token0_decimals:pair.t0.decimals,token1_address:pair.t1.address,token1_symbol:pair.t1.symbol,token1_decimals:pair.t1.decimals,current_wallet_lp:walletCurBal,current_staked_lp:Number(stakedCur||0),current_lp:economicCurBal,current_amount0:cur?.amount0||0,current_amount1:cur?.amount1||0,current_share:cur?.share||0,current_usd:cur?.usd??null,snapshot_date:dateStr,snapshot_wallet_lp:histWalletBal,snapshot_staked_lp:histStakedBal,snapshot_lp:histBal||0,snapshot_usd:histUsd});
          }
        }
        try{await window.WalletLPEngine.replacePositionCache(projectKey,chain,wa,walletPositionCache);latestCacheRefresh=new Date();}catch(e){cacheErrors.push(`${CHAIN_META[chain]?.label||chain}/${w.label}: Positions-Cache konnte nicht gespeichert werden: ${e.message}`);}
      }

      try{
        const scanType=projectLpScanType(projectKey,chain);
        const info=window.WalletLPEngine.getScanStateInfo?await window.WalletLPEngine.getScanStateInfo(projectKey,chain,wa,scanType):{last_scanned_block:await window.WalletLPEngine.getScanState(projectKey,chain,wa,scanType),last_scanned_at:null,scan_type:scanType};
        const walletRows=rows.filter(r=>r.chain===chain&&r.w?.id===w.id);
        scanStatuses.push({chain,w,address:wa,scanType,lastBlock:Number(info?.last_scanned_block||0),lastAt:info?.last_scanned_at||null,eventCount:(sync.events||[]).length,pairCount:new Set((sync.events||[]).map(e=>normalizeAddress(e.pair_address,chain)).filter(Boolean)).size,positionCount:walletRows.length,warning:sync.warning||info?.last_scan_message||null,transfersSeen:Number(info?.last_transfers_seen||0),candidateContracts:Number(info?.last_candidate_contracts||0),projectPairs:Number(info?.last_project_pairs||0),eventsSaved:Number(info?.last_events_saved||0),stakingEvents:Number(info?.last_staking_events||0),scanResult:info?.last_scan_result||null});
      }catch(e){
        scanStatuses.push({chain,w,address:wa,scanType:projectLpScanType(projectKey,chain),lastBlock:0,lastAt:null,eventCount:(sync.events||[]).length,pairCount:new Set((sync.events||[]).map(e=>normalizeAddress(e.pair_address,chain)).filter(Boolean)).size,positionCount:rows.filter(r=>r.chain===chain&&r.w?.id===w.id).length,warning:`Scan-Status nicht lesbar: ${e?.message||e}`});
      }

      const running=new Map();
      for(const e of [...sync.events].sort((a,b)=>Number(a.block_number)-Number(b.block_number)||Number(a.log_index||0)-Number(b.log_index||0))){const k=normalizeAddress(e.pair_address,chain),saldo=(running.get(k)||0)+Number(e.lp_delta||0);running.set(k,saldo);history.push({...e,chain,w,running_balance:saldo});}
    }
  }

  const availableWalletIds=[...new Set([
    ...rows.map(r=>walletDbId(r.w)),
    ...history.map(r=>walletDbId(r.w)),
    ...scanStatuses.filter(s=>Number(s.eventCount||0)>0||Number(s.positionCount||0)>0).map(s=>walletDbId(s.w))
  ].filter(Boolean))];
  let selectedWallet=projectLpWalletFilters[targetId]||'all';if(selectedWallet!=='all'&&!availableWalletIds.includes(selectedWallet))selectedWallet='all';projectLpWalletFilters[targetId]=selectedWallet;
  const walletFilterHtml=`<div class="field-grid" style="grid-template-columns:minmax(220px,360px);margin-top:12px"><div><span class="field-label">Wallet</span><select onchange="setProjectLpWalletFilter('${targetId}',this.value)"><option value="all">Alle Wallets</option>${scopeWallets.filter(w=>availableWalletIds.includes(walletDbId(w))).map(w=>`<option value="${escapeAttr(walletDbId(w))}" ${selectedWallet===walletDbId(w)?'selected':''}>${escapeAttr(w.label)}</option>`).join('')}</select></div></div>`;
  const displayRows=selectedWallet==='all'?rows:rows.filter(r=>walletDbId(r.w)===selectedWallet);
  const displayHistory=selectedWallet==='all'?history:history.filter(r=>walletDbId(r.w)===selectedWallet);
  const displayScanStatuses=selectedWallet==='all'?scanStatuses:scanStatuses.filter(r=>walletDbId(r.w)===selectedWallet);

  const f=(n,meta={},summary=false)=>formatTokenAmountGlobal(n,meta,{summary}),u=n=>n==null?'–':'$'+Number(n).toLocaleString('de-CH',{minimumFractionDigits:2,maximumFractionDigits:2}),dt=x=>x?new Date(x).toLocaleString('de-CH'):'–';
  const histCell=(n,r)=>n==null?'–':f(n,{chain:r.chain,address:r.pair?.address,symbol:window.WalletLPEngine.label(r.chain)});
  // v61: Gemeinsamer produktiver Tabellenstil aus der TLN/VOW-Discovery.
  // Gilt gleichermaßen für TLN/VOW, DAO1 und künftige Projekt-LP-Tabellen.
  const projectLpWrapClass=' project-data-table';

  const currentTable=`<h3 class="lp-section-title">LP-Positionen</h3><div class="chain-table-wrap lp-table-scroll${projectLpWrapClass}"><table class="lp-position-table"><thead><tr><th>Wallet</th><th>Pool</th><th>LP in Wallet</th><th>LP gestakt</th><th>LP gesamt</th><th>aktuelle Underlyings</th><th>aktuell USD</th><th>${dateStr} Wallet</th><th>${dateStr} gestakt</th><th>${dateStr} gesamt</th><th>${dateStr} USD</th></tr></thead><tbody>${displayRows.length?displayRows.map(r=>`<tr><td>${escapeAttr(r.w.label)}${r.historicalOnly?'<div class="meta"><span class="badge">nur Historie</span></div>':''}</td><td><strong>${window.WalletLPEngine.label(r.chain)} ${escapeAttr(r.pair.t0.symbol)}/${escapeAttr(r.pair.t1.symbol)}</strong><div class="meta lp-address">${escapeAttr(r.pair.address)}</div></td><td>${f(r.cur?.walletBalance??r.cur?.balance??0,{chain:r.chain,address:r.pair.address,symbol:window.WalletLPEngine.label(r.chain)})}</td><td>${f(r.cur?.stakedBalance||0,{chain:r.chain,address:r.pair.address,symbol:window.WalletLPEngine.label(r.chain)})}</td><td><strong>${f(r.cur?.balance||0,{chain:r.chain,address:r.pair.address,symbol:window.WalletLPEngine.label(r.chain)})}</strong></td><td>${r.historicalOnly?'–':(r.cur?`<div>${f(r.cur.amount0,{chain:r.chain,address:r.pair.t0.address,symbol:r.pair.t0.symbol})} ${escapeAttr(r.pair.t0.symbol)}</div><div>${f(r.cur.amount1,{chain:r.chain,address:r.pair.t1.address,symbol:r.pair.t1.symbol})} ${escapeAttr(r.pair.t1.symbol)}</div><div class="meta">wirtschaftlicher Pool-Anteil ${(r.cur.share*100).toLocaleString('de-CH',{maximumFractionDigits:6})}%</div>`:'–')}</td><td>${r.historicalOnly?'–':u(r.cur?.usd)}</td><td>${histCell(r.histWalletBal??r.histBal,r)}</td><td>${histCell(r.histStakedBal,r)}</td><td><strong>${histCell(r.histBal,r)}</strong></td><td>${r.histBal==null?'–':u(r.histUsd??(r.histPrice?.price!=null?r.histBal*r.histPrice.price:null))}</td></tr>`).join(''):'<tr><td colspan="11">Noch keine gespeicherten LP-Positionen. Bitte „Daten aktualisieren“ ausführen.</td></tr>'}</tbody></table></div>`;

  const scanStatusTable=`<details class="lp-scan-details debug-frame"><summary>Technische LP-Scan-Informationen</summary><div class="note" style="margin-bottom:8px">Diagnose pro Wallet. Diese Informationen sind primär für Fehleranalyse und Administration gedacht.</div><div class="chain-table-wrap lp-table-scroll${projectLpWrapClass}"><table class="lp-scan-table"><thead><tr><th>Wallet</th><th>Adresse</th><th>Status</th><th>Letzter Scan</th><th>bis Block</th><th>Transfers</th><th>Kandidaten</th><th>Projekt-LPs</th><th>neu Events</th><th>davon Staking</th><th>Historien-Ereignisse</th><th>Positionszeilen</th></tr></thead><tbody>${displayScanStatuses.length?displayScanStatuses.map(s=>`<tr><td><strong>${escapeAttr(s.w?.label||'')}</strong></td><td class="meta lp-address">${escapeAttr(s.address||'')}</td><td>${s.warning?`<span class="badge danger">unvollständig</span><div class="meta">${escapeAttr(s.warning)}</div>`:s.lastBlock>0?`<span class="badge ${s.scanResult==='partial'?'danger':'safe'}">${s.scanResult==='partial'?'teilweise':'gescannt'}</span>`:'<span class="badge">noch nicht gescannt</span>'}</td><td>${s.lastAt?dt(s.lastAt):'–'}</td><td>${s.lastBlock>0?Number(s.lastBlock).toLocaleString('de-CH'):'–'}</td><td>${Number(s.transfersSeen||0).toLocaleString('de-CH')}</td><td>${Number(s.candidateContracts||0).toLocaleString('de-CH')}</td><td>${Number(s.projectPairs||0).toLocaleString('de-CH')}</td><td>${Number(s.eventsSaved||0).toLocaleString('de-CH')}</td><td>${Number(s.stakingEvents||0).toLocaleString('de-CH')}</td><td>${Number(s.eventCount||0).toLocaleString('de-CH')}</td><td>${Number(s.positionCount||0).toLocaleString('de-CH')}</td></tr>`).join(''):'<tr><td colspan="12">Keine Wallet-Adressen für diese Chain vorhanden.</td></tr>'}</tbody></table></div></details>`;

  const hrows=[...displayHistory].sort((a,b)=>Number(b.block_number)-Number(a.block_number)||Number(b.log_index||0)-Number(a.log_index||0));
  const actionLabel=e=>({add:'Add Liquidity',remove:'Remove Liquidity',stake:'Stake',unstake:'Unstake',send:'Versenden',receive:'Empfangen'}[e.event_type]||e.event_type);
  const actionBadge=e=>['add','stake','receive'].includes(e.event_type)?'safe':['remove','unstake'].includes(e.event_type)?'danger':'';
  const historyTable=`<h3 class="lp-section-title">LP-/Staking-Historie</h3><div class="chain-table-wrap lp-history-scroll${projectLpWrapClass}"><table class="lp-history-table"><thead><tr><th>Zeit</th><th>Wallet</th><th>Aktion</th><th>Pool</th><th>Gegenstelle / Staking</th><th>LP Δ</th><th>Wallet-LP-Saldo</th><th>Underlying</th><th>historischer USD-Wert</th></tr></thead><tbody>${hrows.length?hrows.map(e=>`<tr><td>${dt(e.tx_timestamp)}<div class="meta">Block ${e.block_number}</div></td><td>${escapeAttr(e.w.label)}</td><td><span class="badge ${actionBadge(e)}">${escapeAttr(actionLabel(e))}</span></td><td><strong>${escapeAttr(e.lp_label||window.WalletLPEngine.label(e.chain))} ${escapeAttr(e.token0_symbol||'Token0')}/${escapeAttr(e.token1_symbol||'Token1')}</strong><div class="meta lp-address">${escapeAttr(e.pair_address||'')}</div></td><td>${e.staking_label?`<strong>${escapeAttr(e.staking_label)}</strong><div class="meta lp-address">${escapeAttr(e.staking_contract||e.counterparty||'')}</div>`:`<div class="meta lp-address">${escapeAttr(e.counterparty||'–')}</div>`}</td><td>${Number(e.lp_delta)>0?'+':''}${f(e.lp_delta,{chain:e.chain,address:e.pair_address,symbol:e.lp_label||window.WalletLPEngine.label(e.chain)})}</td><td>${f(e.running_balance,{chain:e.chain,address:e.pair_address,symbol:e.lp_label||window.WalletLPEngine.label(e.chain)})}</td><td><div>${f(e.amount0,{chain:e.chain,address:e.token0_address,symbol:e.token0_symbol})} ${escapeAttr(e.token0_symbol||'')}</div><div>${f(e.amount1,{chain:e.chain,address:e.token1_address,symbol:e.token1_symbol})} ${escapeAttr(e.token1_symbol||'')}</div></td><td><strong>${u(e.value_usd)}</strong>${e.price_source?`<div class="meta lp-price-source">${escapeAttr(e.price_source)}</div>`:''}</td></tr>`).join(''):'<tr><td colspan="9">Noch keine LP-Ereignisse im Cache.</td></tr>'}</tbody></table></div>`;

  const stakingLots=(projectKey==="tln_vow"&&chains.includes("bsc")&&window.WalletStakingEngine)?scopeWallets.flatMap(w=>window.WalletStakingEngine.buildLots(displayHistory.filter(e=>e.chain==="bsc"&&e.w?.id===w.id)).map(l=>({...l,w}))):[];
  const stakingTable=projectKey==="tln_vow"&&chains.includes("bsc")?`<h3 class="lp-section-title">Staking-Positionen</h3><div class="note" style="margin-bottom:8px">Jeder Stake bleibt als eigenes Lot sichtbar. Unstakes reduzieren die offenen Lots chronologisch (FIFO). Eine Lock-Dauer wird nur angezeigt, wenn sie im Staking-Contract-Katalog verifiziert hinterlegt ist.</div><div class="chain-table-wrap lp-table-scroll project-data-table"><table class="lp-staking-table"><thead><tr><th>Wallet</th><th>Pool</th><th>Staking-Bezeichnung</th><th>Staking-Contract</th><th>Stake-Datum</th><th>LP ursprünglich</th><th>LP offen</th><th>Status</th></tr></thead><tbody>${stakingLots.length?stakingLots.slice().reverse().map(l=>`<tr><td>${escapeAttr(l.w?.label||'')}</td><td class="meta lp-address">${escapeAttr(l.pair_address||'')}</td><td><strong>${escapeAttr(l.staking_label||window.WalletStakingEngine.displayName(l,'LP'))}</strong></td><td class="meta lp-address">${escapeAttr(l.staking_contract||'–')}</td><td>${dt(l.stake_timestamp)}</td><td>${f(l.original_lp,{chain:'bsc',address:l.pair_address,symbol:'LP'})}</td><td><strong>${f(l.remaining_lp,{chain:'bsc',address:l.pair_address,symbol:'LP'})}</strong></td><td>${l.status==='closed'?'<span class="badge">beendet</span>':l.status==='partial'?'<span class="badge">teilweise unstaked</span>':'<span class="badge safe">offen</span>'}</td></tr>`).join(''):'<tr><td colspan="8">Keine Staking-Positionen im Cache erkannt.</td></tr>'}</tbody></table></div>`:'';

  const cacheStand=latestCacheRefresh?`<div class="lp-cache-stand">Cache-Stand: ${latestCacheRefresh.toLocaleString('de-CH')}</div>`:'<div class="lp-cache-stand">Cache-Stand: noch kein Positions-Cache vorhanden</div>';
  el.innerHTML=`<div class="custom-token-card"><div class="chain-title">Liquidity Pools</div><div class="note">Beim Öffnen werden <strong>ausschließlich Supabase-Caches</strong> gelesen. Blockchain, Explorer, Reserven, Kurse und Historie werden nur über „Daten aktualisieren“ erneuert. Add-/Remove-Historie und Positionsdaten bleiben danach gespeichert. Auf BSC heißen V2-LP-Token <strong>PCLP</strong>.</div>${refreshButton}${walletFilterHtml}${cacheStand}${scanStatusTable}${cacheNew?`<div class="success" style="margin-top:8px">${cacheNew} neue LP-Historien-Ereignis(se) im DB-Cache gespeichert.</div>`:''}${cacheWarnings.length?`<div class="note" style="margin-top:8px"><strong>LP-Historie momentan nicht vollständig nachladbar:</strong> ${escapeAttr(cacheWarnings.join(' · '))}</div>`:''}${cacheErrors.length?`<div class="error" style="margin-top:8px">${refresh?'Cache teilweise nicht aktualisiert':'Cache teilweise nicht lesbar'}: ${escapeAttr(cacheErrors.join(' · '))}</div>`:''}</div>${stakingTable}${currentTable}${historyTable}`;
  if(refresh&&projectKey==="tln_vow"&&chains.includes("bsc")){await mergeTlnBscStakingCacheIntoWalletData();renderResults();renderAllocationChart();}
  return {errors:cacheErrors,warnings:cacheWarnings,newEvents:cacheNew};

}
window.renderProjectLpTab=renderProjectLpTab;
window.refreshProjectLpData=async function(projectKey,chain,targetId){
  const chains=chain?[chain]:(projectKey==="dao1"?["apertum"]:[]);
  await renderProjectLpTab(projectKey,chains,targetId,"2025-12-31",true);
  for(const w of wallets)for(const c of chains)if(walletAddressForChain(w,c))await saveWalletRefreshState(w,c,`project:${projectKey}`,{last_checked_at:new Date().toISOString(),last_refreshed_at:new Date().toISOString(),last_result:'manual'});
};
window.showTlnLpChain=function(chain,btn){
  const b=document.getElementById("tlnvowLpBscContent"),e=document.getElementById("tlnvowLpEthContent");
  if(b)b.style.display=chain==="bsc"?"block":"none";if(e)e.style.display=chain==="eth"?"block":"none";
  document.querySelectorAll("#tlnvow-subtab-liquidity .project-subtabs .tab-btn").forEach(x=>x.classList.toggle("active",x===btn));
  return maybeAutoRefreshProject("tln_vow",chain,chain==="bsc"?"tlnvowLpBscContent":"tlnvowLpEthContent");
};

// "Entdecken" - findet Token, die eine Wallet hält, aber die
// noch nicht auf der sicheren Liste stehen. Läuft nur auf Klick.
// ============================================================

// ---- Discovery: Wallet-Pflichtauswahl + Chain-Filter ----
function discoveryChains() { return Object.keys(CHAIN_CONFIG).filter(c => CHAIN_CONFIG[c]?.discoveryEnabled === true); }
let activeDiscoveryChains = new Set();

function renderDiscoveryChainFilter() {
  const el = document.getElementById("discoveryChainContainer");
  if (!el) return;
  el.innerHTML = discoveryChains().map(chain => {
    const meta = CHAIN_META[chain];
    const checked = activeDiscoveryChains.has(chain) ? "checked" : "";
    return `<label style="display:flex;align-items:center;gap:6px;font-size:0.85rem;cursor:pointer">
      <input type="checkbox" ${checked} onchange="toggleDiscoveryChain('${chain}', this.checked)" style="width:auto" />
      <span class="dot" style="background:${escapeAttr(CHAIN_CONFIG[meta.dot]?.displayColor || "#6b7280")}"></span> ${meta.label}
    </label>`;
  }).join("");
}

function toggleDiscoveryChain(chain, isChecked) {
  if (isChecked) activeDiscoveryChains.add(chain);
  else activeDiscoveryChains.delete(chain);
}

function setAllDiscoveryChains(selectAll) {
  activeDiscoveryChains = selectAll ? new Set(discoveryChains()) : new Set();
  renderDiscoveryChainFilter();
}

// ---- Gebühren-Auswertung ----
// Gebühren ohne Alchemy: ETH/Avalanche via Routescan, BSC via NodeReal/BSCTrace,
// Polygon/Arbitrum/Base via Blockscout. Alle EVM-Gebühren werden in Supabase
// inkrementell gecacht; Phase 1 speichert/zeigt nur die native Coin-/Token-Gebühr.
let activeFeesChains = new Set();
const FEES_MAX_PAGES = 50;
const FEE_COOLDOWN_DAYS = 30;

// Credential/Endpoint-Ausnahme: NodeReal-Key bleibt bewusst im Frontend.
// Welche Chain NodeReal verwendet, kommt dagegen aus public.chains.fee_provider.
const NODEREAL_BSC_URL = "https://bsc-mainnet.nodereal.io/v1/65ef2c8e97554306a0c34579410ea31b";

function feeChains() {
  return Object.keys(CHAIN_CONFIG).filter(chain => {
    const c = CHAIN_CONFIG[chain];
    return c?.feesEnabled === true && !!c?.feeProvider;
  });
}

function configuredFeeBase(chain) {
  const base = CHAIN_CONFIG[chain]?.feeApiBase;
  if (!base) throw new Error(`${CHAIN_META[chain]?.label || chain}: Gebühren API-Basis fehlt in public.chains`);
  return base.replace(/\/+$/, "");
}
let feeCaches = new Map(); // key walletId|chain -> DB row

function feeCacheKey(walletId, chain) { return String(walletId) + "|" + chain; }
function sleepMs(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }
function bigIntSafe(v) { try { return BigInt(v ?? 0); } catch { return 0n; } }
function weiToDecimalString(wei) {
  const x = bigIntSafe(wei), d = 1000000000000000000n;
  const whole = x / d;
  const frac = (x % d).toString().padStart(18, "0").replace(/0+$/, "");
  return frac ? `${whole}.${frac}` : whole.toString();
}
function decimalStringToWei(v) {
  const s = String(v ?? "0").trim();
  if (!s || !/^[-+]?\d+(\.\d+)?$/.test(s)) return 0n;
  const neg = s.startsWith("-");
  const clean = s.replace(/^[-+]/, "");
  const [a, b = ""] = clean.split(".");
  const out = BigInt(a || "0") * 1000000000000000000n + BigInt((b + "0".repeat(18)).slice(0, 18));
  return neg ? -out : out;
}
function normalizeTxTimestamp(v) {
  if (v === null || v === undefined || v === "") return null;
  if (typeof v === "string" && !/^\d+$/.test(v)) {
    const d = new Date(v); return isNaN(d.getTime()) ? null : d.toISOString();
  }
  let n = Number(v);
  if (!Number.isFinite(n)) return null;
  if (n < 1e12) n *= 1000;
  const d = new Date(n); return isNaN(d.getTime()) ? null : d.toISOString();
}

function renderFeesChainFilter() {
  const el = document.getElementById("feesChainContainer");
  if (!el) return;
  el.innerHTML = feeChains().map(chain => {
    const meta = CHAIN_META[chain];
    const checked = activeFeesChains.has(chain) ? "checked" : "";
    return `<label style="display:flex;align-items:center;gap:6px;font-size:0.85rem;cursor:pointer">
      <input type="checkbox" ${checked} onchange="toggleFeesChain('${chain}', this.checked)" style="width:auto" />
      <span class="dot" style="background:${escapeAttr(CHAIN_CONFIG[meta.dot]?.displayColor || "#6b7280")}"></span> ${meta.label}
    </label>`;
  }).join("");
}
function toggleFeesChain(chain, isChecked) { if (isChecked) activeFeesChains.add(chain); else activeFeesChains.delete(chain); }
function setAllFeesChains(selectAll) { activeFeesChains = selectAll ? new Set(feeChains()) : new Set(); renderFeesChainFilter(); }
function renderFeesWalletSelect() {
  const el = document.getElementById("feesWalletSelect");
  if (!el) return;
  const current = el.value;
  el.innerHTML = `<option value="">– Wallet wählen –</option>` + wallets.map(w => `<option value="${w.id}">${escapeAttr(w.label)}</option>`).join("");
  if (wallets.some(w => String(w.id) === String(current))) el.value = current;
}


function currentGasCoinPrice(chain) {
  const p = nativePrices && nativePrices[chain] ? Number(nativePrices[chain].price) : NaN;
  return Number.isFinite(p) ? p : null;
}
function formatUsdPrice(v) {
  if (!Number.isFinite(Number(v))) return "–";
  const n=Number(v);
  return n >= 100 ? "$"+n.toLocaleString("de-CH",{minimumFractionDigits:2,maximumFractionDigits:2})
    : n >= 1 ? "$"+n.toLocaleString("de-CH",{minimumFractionDigits:2,maximumFractionDigits:4})
    : "$"+n.toLocaleString("de-CH",{minimumFractionDigits:4,maximumFractionDigits:8});
}
async function loadAllFeeCaches() {
  if (!currentUser) return [];
  const { data, error } = await sb.from("wallet_fee_cache").select("*").eq("user_id", currentUser.id);
  if (error) { console.error("Gebühren-Summary laden:", error); return []; }
  for (const row of (data||[])) feeCaches.set(feeCacheKey(row.wallet_id,row.chain),row);
  return data||[];
}
async function renderFeesSummary() {
  const el=document.getElementById("feesSummary"); if(!el||!currentUser)return;
  const rows=await loadAllFeeCaches();
  const walletIds=new Set(wallets.map(w=>String(w.id)));
  const ownRows=rows.filter(r=>walletIds.has(String(r.wallet_id)));
  if(!ownRows.length){el.innerHTML=`<div class="custom-token-card"><h3 style="margin:0 0 8px">Gesamtübersicht aller Wallets</h3><div class="note">Noch keine gespeicherten Gebühren vorhanden.</div></div>`;return;}
  const sums=new Map();
  for(const r of ownRows){
    const x=sums.get(r.chain)||{fee:0,tx:0,latest:null};
    x.fee+=Number(r.total_fee_native||0); x.tx+=Number(r.tx_count||0);
    if(r.last_scanned_at&&(!x.latest||r.last_scanned_at>x.latest))x.latest=r.last_scanned_at;
    sums.set(r.chain,x);
  }
  const body=feeChains().filter(c=>sums.has(c)).map(c=>{
    const x=sums.get(c), sym=NATIVE_SYMBOL[c]||c.toUpperCase(), price=currentGasCoinPrice(c);
    return `<tr><td><span class="dot" style="background:${escapeAttr(CHAIN_CONFIG[CHAIN_META[c].dot]?.displayColor || "#6b7280")}"></span> ${CHAIN_META[c].label}</td><td class="num">${x.tx}</td><td class="num">${fmt(x.fee)} ${sym}</td><td class="num">${formatUsdPrice(price)}</td><td><span class="note">${x.latest?new Date(x.latest).toLocaleString("de-CH"):"–"}</span></td></tr>`;
  }).join("");
  el.innerHTML=`<div class="custom-token-card"><h3 style="margin:0 0 10px">Gesamtübersicht aller Wallets</h3><table><thead><tr><th>Chain</th><th style="text-align:right">Anzahl Tx</th><th style="text-align:right">Gebühren (nativ)</th><th style="text-align:right">Aktueller Coin-Kurs</th><th>Letzter Stand</th></tr></thead><tbody>${body}</tbody></table><div class="note" style="margin-top:8px">Der aktuelle Coin-Kurs dient nur als Anhaltspunkt und wird nicht zur historischen Bewertung der Gebühren verwendet.</div></div>`;
}
async function loadFeeCacheForWallet(walletId) {
  if (!currentUser || !walletId) return [];
  const { data, error } = await sb.from("wallet_fee_cache").select("*")
    .eq("user_id", currentUser.id).eq("wallet_id", String(walletId));
  if (error) { console.error("Gebühren-Cache laden:", error); return []; }
  for (const row of (data || [])) feeCaches.set(feeCacheKey(walletId, row.chain), row);
  return data || [];
}
function feeNextAllowedDate(cache) {
  if (!cache || !cache.last_scanned_at) return null;
  const d = new Date(cache.last_scanned_at);
  if (isNaN(d.getTime())) return null;
  d.setDate(d.getDate() + FEE_COOLDOWN_DAYS);
  return d;
}
function feeScanAllowed(cache) { return isAdmin || !feeNextAllowedDate(cache) || Date.now() >= feeNextAllowedDate(cache).getTime(); }

async function onFeesWalletChange() {
  const select = document.getElementById("feesWalletSelect");
  const walletId = select ? select.value : "";
  const info = document.getElementById("feesCacheInfo");
  if (!walletId) { if (info) info.textContent = ""; return; }
  const w = wallets.find(x => String(x.id) === String(walletId));
  if (!w) return;
  const rows = await loadFeeCacheForWallet(walletId);
  if (rows.length) {
    const results = rows.map(r => ({ chain:r.chain, totalFee:Number(r.total_fee_native || 0), txCount:Number(r.tx_count || 0), cached:true, cachedAt:r.last_scanned_at, source:r.data_source }));
    renderFeesResults(w, results);
    const newest = rows.map(r => r.last_scanned_at).filter(Boolean).sort().pop();
    if (info) info.textContent = newest ? `Gespeicherter Gebührenstand geladen · letzte Aktualisierung ${new Date(newest).toLocaleString("de-CH")}` : "Gespeicherter Gebührenstand geladen.";
  } else {
    if (info) info.textContent = "Noch kein gespeicherter EVM-Gebührenstand für diese Wallet.";
  }
}

async function currentSafeBlock(chain) {
  const latestHex = await evmRpcCall(configuredRpcUrl(chain), "eth_blockNumber", []);
  const latest = Number(bigIntSafe(latestHex));
  const lag = Number(CHAIN_CONFIG[chain]?.feeFinalityBlocks || 0);
  return Math.max(0, latest - lag);
}

function routescanFeeWei(tx) {
  const used = bigIntSafe(tx.gasUsed ?? tx.receipt?.gasUsed ?? tx.gas?.used);
  const price = bigIntSafe(tx.effectiveGasPrice ?? tx.gasPrice ?? tx.receipt?.effectiveGasPrice ?? tx.gas?.price);
  if (used && price) return used * price;
  for (const k of ["fee", "txFee", "transactionFee"]) {
    if (tx[k] !== undefined && tx[k] !== null) { const b = bigIntSafe(tx[k]); if (b) return b; }
  }
  return 0n;
}

async function fetchRoutescanFeeTransactions(chain, address, startBlock, endBlock, onProgress) {
  let next = null, page = 0;
  const out = [];
  do {
    page++; if (onProgress) onProgress(page);
    const cfg = CHAIN_CONFIG[chain] || {};
    const chainId = cfg.evmChainId;
    if (!chainId) throw new Error("EVM Chain-ID fehlt in public.chains für " + chain);
    const base = cfg.feeApiBase || `https://api.routescan.io/v2/network/mainnet/evm/${chainId}`;
    const u = new URL(`${base.replace(/\/+$/, "")}/address/${address}/transactions`);
    u.searchParams.set("categories", "evm_tx"); u.searchParams.set("direction", "sent"); u.searchParams.set("sort", "asc"); u.searchParams.set("limit", "100");
    // Beim Initialscan keine Blockfilter mitsenden: genau dieser Modus wurde mit alten Wallets
    // erfolgreich gegen Routescan validiert. Den sicheren Head filtern wir danach lokal.
    // Erst bei inkrementellen Scans verwenden wir einen begrenzten Blockbereich.
    if (startBlock !== null && startBlock !== undefined) {
      u.searchParams.set("blockNumberFrom", String(startBlock));
      if (endBlock !== null && endBlock !== undefined) {
        u.searchParams.set("blockNumberTo", String(endBlock + 1)); // API: obere Grenze exklusiv
      }
    }
    if (next) u.searchParams.set("next", next);
    const res = await fetch(u);
    if (!res.ok) throw new Error("Routescan HTTP " + res.status);
    const data = await res.json();
    if (!Array.isArray(data.items)) throw new Error("Unerwartete Routescan-Antwort");
    for (const tx of data.items) {
      const hash = tx.id || tx.txHash || tx.hash || tx.transactionHash || "";
      const block = Number(tx.blockNumber ?? tx.block ?? 0) || 0;
      if (!hash || !block || block > endBlock) continue;
      const feeWei = routescanFeeWei(tx);
      if (feeWei === 0n && bigIntSafe(tx.gasUsed ?? tx.receipt?.gasUsed ?? tx.gas?.used) > 0n) throw new Error("Routescan: Fee-Feld fehlt bei " + hash);
      out.push({ tx_hash:hash.toLowerCase(), block_number:block, fee_native:weiToDecimalString(feeWei), tx_timestamp:normalizeTxTimestamp(tx.timestamp ?? tx.createdAt ?? tx.timeStamp) });
    }
    next = data?.link?.nextToken || null;
    if (next) await sleepMs(520);
    if (page > 5000) throw new Error("Routescan Sicherheitsabbruch nach 5000 Seiten");
  } while (next);
  return out;
}

async function fetchBlockscoutFeeTransactions(chain, address, startBlock, endBlock, onProgress) {
  const base = CHAIN_CONFIG[chain]?.feeApiBase;
  if (!base) throw new Error("Blockscout API-Basis fehlt in public.chains für " + chain);
  const addrLower = address.toLowerCase();
  let nextParams = null, page = 0;
  const out = [];
  do {
    page++; if (onProgress) onProgress(page);
    const u = new URL(`${base}/api/v2/addresses/${address}/transactions`);
    u.searchParams.set("filter", "from");
    if (nextParams) Object.entries(nextParams).forEach(([k,v]) => { if (v !== null && v !== undefined) u.searchParams.set(k, String(v)); });
    const res = await fetch(u);
    if (!res.ok) throw new Error(`Blockscout HTTP ${res.status}`);
    const data = await res.json();
    if (!Array.isArray(data.items)) throw new Error("Unerwartete Blockscout-Antwort");
    let reachedOldRange = false;
    for (const tx of data.items) {
      const from = String(tx.from?.hash ?? tx.from_address ?? tx.from ?? "").toLowerCase();
      if (from && from !== addrLower) continue;
      const hash = String(tx.hash ?? tx.transaction_hash ?? "");
      const block = Number(tx.block_number ?? tx.blockNumber ?? 0) || 0;
      if (!hash || !block) continue;
      if (endBlock !== null && endBlock !== undefined && block > endBlock) continue;
      if (startBlock !== null && startBlock !== undefined && block < startBlock) { reachedOldRange = true; continue; }
      let feeWei = 0n;
      const feeObj = tx.fee;
      if (feeObj && typeof feeObj === "object") feeWei = bigIntSafe(feeObj.value);
      else feeWei = bigIntSafe(feeObj);
      if (!feeWei) {
        const used = bigIntSafe(tx.gas_used ?? tx.gasUsed);
        const price = bigIntSafe(tx.effective_gas_price ?? tx.effectiveGasPrice ?? tx.gas_price ?? tx.gasPrice);
        if (used && price) feeWei = used * price;
      }
      out.push({ tx_hash:hash.toLowerCase(), block_number:block, fee_native:weiToDecimalString(feeWei), tx_timestamp:normalizeTxTimestamp(tx.timestamp) });
    }
    nextParams = reachedOldRange && startBlock !== null && startBlock !== undefined ? null : (data.next_page_params || null);
    if (nextParams) await sleepMs(180);
    if (page > 5000) throw new Error("Blockscout Sicherheitsabbruch nach 5000 Seiten");
  } while (nextParams);
  return out;
}

async function nodeRealRpc(method, params) {
  const res = await fetch(NODEREAL_BSC_URL, {
    method: "POST",
    headers: {"Content-Type":"application/json"},
    body: JSON.stringify({jsonrpc:"2.0", method, params:[params], id:1})
  });
  const text = await res.text();
  let data;
  try { data = JSON.parse(text); }
  catch { throw new Error(`NodeReal lieferte keine JSON-Antwort (HTTP ${res.status})`); }
  if (!res.ok) throw new Error(`NodeReal HTTP ${res.status}`);
  if (data.error) throw new Error(data.error.message || JSON.stringify(data.error));
  return data.result || {};
}
async function fetchNodeRealRange(address, fromBlock, toBlock, onProgress, progressState) {
  let pageKey = null;
  const out = [];
  do {
    progressState.page++; if (onProgress) onProgress(progressState.page);
    const p = { category:["external"], fromAddress:address, order:"asc", maxCount:"0x3E8" };
    if (fromBlock !== null && fromBlock !== undefined) p.fromBlock = "0x" + Number(fromBlock).toString(16);
    if (toBlock !== null && toBlock !== undefined) p.toBlock = "0x" + Number(toBlock).toString(16);
    if (pageKey) p.pageKey = pageKey;
    const r = await nodeRealRpc("nr_getAssetTransfers", p);
    const txs = Array.isArray(r.transfers) ? r.transfers : [];
    for (const tx of txs) {
      if (String(tx.from || "").toLowerCase() !== address.toLowerCase()) continue;
      const block = Number(bigIntSafe(tx.blockNum));
      if (toBlock !== null && block > toBlock) continue;
      const feeWei = bigIntSafe(tx.gasUsed || 0) * bigIntSafe(tx.gasPrice || 0);
      out.push({ tx_hash:String(tx.hash || "").toLowerCase(), block_number:block, fee_native:weiToDecimalString(feeWei), tx_timestamp:normalizeTxTimestamp(tx.blockTimestamp ?? tx.blockTimeStamp) });
    }
    pageKey = r.pageKey || r.PageKey || null;
    if (pageKey) await sleepMs(250);
  } while (pageKey);
  return out;
}
async function fetchBscFeeTransactions(address, startBlock, endBlock, onProgress) {
  const progressState = {page:0};
  if (startBlock === null || startBlock === undefined) {
    // Vollscan: ohne Blockfilter, damit NodeReal nicht automatisch auf 100k Blöcke begrenzt.
    const all = await fetchNodeRealRange(address, null, null, onProgress, progressState);
    return all.filter(tx => tx.block_number <= endBlock);
  }
  const out = [];
  let from = startBlock;
  while (from <= endBlock) {
    const to = Math.min(endBlock, from + 99999); // NodeReal erlaubt max. 100k Blockspanne
    out.push(...await fetchNodeRealRange(address, from, to, onProgress, progressState));
    from = to + 1;
  }
  return out;
}

async function loadExistingFeeHashes(walletId, chain, startBlock) {
  const hashes = new Set();
  let from = 0;
  const pageSize = 1000;
  while (true) {
    let q = sb.from("wallet_fee_transactions").select("tx_hash,block_number")
      .eq("user_id", currentUser.id).eq("wallet_id", String(walletId)).eq("chain", chain)
      .order("block_number", {ascending:true}).range(from, from + pageSize - 1);
    if (startBlock !== null && startBlock !== undefined) q = q.gte("block_number", startBlock);
    const { data, error } = await q;
    if (error) throw new Error("Supabase TX-Hash-Abgleich: " + error.message);
    for (const row of (data || [])) hashes.add(String(row.tx_hash || "").toLowerCase());
    if (!data || data.length < pageSize) break;
    from += pageSize;
  }
  return hashes;
}

async function insertNewFeeTransactions(walletId, chain, txs) {
  for (let i=0; i<txs.length; i+=500) {
    const rows = txs.slice(i, i+500).map(tx => ({ user_id:currentUser.id, wallet_id:String(walletId), chain, ...tx }));
    const { error } = await sb.from("wallet_fee_transactions").upsert(rows, {onConflict:"user_id,wallet_id,chain,tx_hash"});
    if (error) throw new Error("Supabase Gebühren-TX speichern: " + error.message);
  }
}
async function upsertFeeCache(walletId, chain, totalWei, txCount, lastScannedBlock, source) {
  const row = {
    user_id:currentUser.id,
    wallet_id:String(walletId),
    chain,
    total_fee_native:weiToDecimalString(totalWei),
    tx_count:txCount,
    last_scanned_block:lastScannedBlock,
    last_scanned_at:new Date().toISOString(),
    data_source:source,
    updated_at:new Date().toISOString()
  };
  const { data, error } = await sb.from("wallet_fee_cache")
    .upsert(row, {onConflict:"user_id,wallet_id,chain"})
    .select().single();
  if (error) throw new Error("Supabase Gebühren-Cache speichern: " + error.message);
  feeCaches.set(feeCacheKey(walletId, chain), data || row);
  return data || row;
}

async function storedFeeTransactionCount(walletId, chain) {
  const { count, error } = await sb.from("wallet_fee_transactions")
    .select("id", { count:"exact", head:true })
    .eq("user_id", currentUser.id).eq("wallet_id", String(walletId)).eq("chain", chain);
  if (error) throw new Error("Supabase Gebühren-TX Count: " + error.message);
  return Number(count || 0);
}

async function scanCachedEvmFees(chain, wallet, onProgress) {
  let cache = feeCaches.get(feeCacheKey(wallet.id, chain)) || null;

  if (cache) {
    const storedCount = await storedFeeTransactionCount(wallet.id, chain);
    const cacheCount = Number(cache.tx_count || 0);
    if (storedCount !== cacheCount || (cacheCount === 0 && storedCount === 0)) {
      cache = null;
      feeCaches.delete(feeCacheKey(wallet.id, chain));
    }
  }

  if (!feeScanAllowed(cache)) {
    const next = feeNextAllowedDate(cache);
    return {
      chain,
      totalFee:Number(cache.total_fee_native || 0),
      txCount:Number(cache.tx_count || 0),
      cached:true,
      cachedAt:cache.last_scanned_at,
      source:cache.data_source,
      note:`Nächste Aktualisierung ab ${next.toLocaleString("de-CH")}`
    };
  }

  const safeHead = await currentSafeBlock(chain);
  const startBlock = cache && cache.last_scanned_block !== null && cache.last_scanned_block !== undefined
    ? Math.max(0, Number(cache.last_scanned_block) - Number(CHAIN_CONFIG[chain]?.feeOverlapBlocks || 0))
    : null;

  const provider = CHAIN_CONFIG[chain]?.feeProvider;
  let txs;
  if (provider === "routescan") txs = await fetchRoutescanFeeTransactions(chain, wallet.evm, startBlock, safeHead, onProgress);
  else if (provider === "nodereal") txs = await fetchBscFeeTransactions(wallet.evm, startBlock, safeHead, onProgress);
  else if (provider === "blockscout") txs = await fetchBlockscoutFeeTransactions(chain, wallet.evm, startBlock, safeHead, onProgress);
  else throw new Error("Kein EVM-Gebührenprovider in public.chains konfiguriert für " + chain);

  const unique = new Map();
  for (const tx of txs) if (tx.tx_hash) unique.set(tx.tx_hash, tx);

  const existing = cache ? await loadExistingFeeHashes(wallet.id, chain, startBlock) : new Set();
  const candidates = cache
    ? [...unique.values()].filter(tx => !existing.has(tx.tx_hash))
    : [...unique.values()];

  await insertNewFeeTransactions(wallet.id, chain, candidates);

  const addedWei = candidates.reduce((sum, tx) => sum + decimalStringToWei(tx.fee_native), 0n);
  const oldWei = cache ? decimalStringToWei(cache.total_fee_native) : 0n;
  const oldCount = cache ? Number(cache.tx_count || 0) : 0;
  const source = CHAIN_CONFIG[chain]?.feeProvider || "unbekannt";
  const saved = await upsertFeeCache(wallet.id, chain, oldWei + addedWei, oldCount + candidates.length, safeHead, source);

  return {
    chain,
    totalFee:Number(saved.total_fee_native || 0),
    txCount:Number(saved.tx_count || 0),
    cached:false,
    cachedAt:saved.last_scanned_at,
    source,
    note:candidates.length ? `${candidates.length} neue TX hinzugefügt` : "Keine neuen TX"
  };
}

// Alle unterstützten EVM-Gebühren laufen jetzt ohne Alchemy über inkrementelle Provider.

// XRP: xrpscan.com liefert die Gebühr direkt in Drops.
async function fetchBitcoinFees(chain,address,onProgress){
  const base=(configuredFeeBase(chain)||"https://mempool.space/api").replace(/\/$/,"");
  let after="", page=0, totalSat=0n, txCount=0;
  const seen=new Set();
  while(true){
    page++; if(onProgress)onProgress(page);
    const url=`${base}/address/${encodeURIComponent(address)}/txs/chain${after?`/${encodeURIComponent(after)}`:""}`;
    const res=await fetch(url); if(!res.ok)throw new Error(`Bitcoin Gebühren-API HTTP ${res.status}`);
    const txs=await res.json(); if(!Array.isArray(txs)||!txs.length)break;
    for(const tx of txs){
      if(!tx?.txid||seen.has(tx.txid))continue; seen.add(tx.txid);
      const outgoing=(tx.vin||[]).some(v=>String(v?.prevout?.scriptpubkey_address||"")===String(address));
      if(!outgoing)continue;
      totalSat+=bigIntSafe(tx.fee); txCount++;
    }
    if(txs.length<25)break;
    after=txs[txs.length-1]?.txid||""; if(!after)break;
    if(page>20000)throw new Error("Bitcoin Pagination Sicherheitslimit erreicht");
  }
  return {totalFee:Number(totalSat)/1e8,txCount,source:"mempool.space"};
}

async function fetchTronFees(chain,address,onProgress){
  const base=(configuredFeeBase(chain)||"https://apilist.tronscanapi.com/api").replace(/\/$/,"");
  let start=0,page=0,totalSun=0n,txCount=0;
  const limit=50;
  while(true){
    page++; if(onProgress)onProgress(page);
    const qs=new URLSearchParams({sort:"-timestamp",count:"true",limit:String(limit),start:String(start),fromAddress:address,confirm:"0"});
    const res=await fetch(`${base}/transaction?${qs}`); if(!res.ok)throw new Error(`TRON Gebühren-API HTTP ${res.status}`);
    const json=await res.json(); const txs=Array.isArray(json?.data)?json.data:[];
    for(const tx of txs){
      const fee=tx?.cost?.fee ?? tx?.fee ?? 0;
      totalSun+=bigIntSafe(fee); txCount++;
    }
    if(txs.length<limit)break;
    start+=limit;
    // Tronscan begrenzt start+limit auf 10'000. Nicht stillschweigend unvollständig rechnen.
    if(start+limit>10000)throw new Error("TRON-Historie überschreitet das 10'000-Transaktionslimit von Tronscan; vollständige Gebührenberechnung benötigt eine zeitbasierte Pagination-Erweiterung.");
  }
  return {totalFee:Number(totalSun)/1e6,txCount,source:"Tronscan"};
}

async function fetchXrpFees(chain, address, onProgress) {
  let marker=null,totalFeeDrops=0,txCount=0,page=0;
  do {
    page++; if (onProgress) onProgress(page);
    const base=configuredFeeBase(chain);
    const url=`${base}/account/${address}/transactions`+(marker?`?marker=${encodeURIComponent(marker)}`:"");
    const res=await fetch(url); if(!res.ok) throw new Error("HTTP "+res.status);
    const data=await res.json();
    (data.transactions||[]).forEach(tx=>{ if(tx.Account===address){ const fee=parseFloat(tx.Fee||"0"); if(isFinite(fee)){totalFeeDrops+=fee;txCount++;} } });
    marker=data.marker||null;
  } while(marker&&page<FEES_MAX_PAGES);
  return {totalFee:totalFeeDrops/1e6,txCount,truncated:!!marker&&page>=FEES_MAX_PAGES,source:"xrpscan"};
}

const SOLANA_FEES_MAX_PAGES = 20;
async function fetchSolanaFees(chain,address,onProgress){
  let rpcUrl=configuredFeeBase(chain);
  if(rpcUrl.includes("publicnode.com")&&PUBLICNODE_TOKEN&&!rpcUrl.endsWith(PUBLICNODE_TOKEN)){
    rpcUrl=rpcUrl.replace(/\/+$/,"")+"/"+publicnodeToken(chain);
  }
  let before,totalFeeLamports=0,txCount=0,page=0;
  while(page<SOLANA_FEES_MAX_PAGES){
    page++; if(onProgress)onProgress(page);
    const params=before?[address,{limit:1000,before}]:[address,{limit:1000}];
    const res=await fetch(rpcUrl,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({jsonrpc:"2.0",id:1,method:"getSignaturesForAddress",params})});
    const data=await res.json(); if(data.error)throw new Error(data.error.message);
    const sigs=data.result||[]; if(sigs.length===0)break;
    for(let i=0;i<sigs.length;i+=20){
      const chunk=sigs.slice(i,i+20),batchBody=chunk.map((x,idx)=>({jsonrpc:"2.0",id:idx,method:"getTransaction",params:[x.signature,{maxSupportedTransactionVersion:0}]}));
      const bres=await fetch(rpcUrl,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(batchBody)}),bdata=await bres.json();
      const arr=Array.isArray(bdata)?bdata:[bdata];
      arr.forEach(r=>{const tx=r&&r.result;if(!tx||!tx.meta)return;const keys=tx.transaction&&tx.transaction.message&&tx.transaction.message.accountKeys;if(!keys||!keys.length)return;const payer=typeof keys[0]==="string"?keys[0]:(keys[0].pubkey||"");if(payer===address){totalFeeLamports+=tx.meta.fee||0;txCount++;}});
    }
    before=sigs[sigs.length-1].signature;if(sigs.length<1000)break;
  }
  return {totalFee:totalFeeLamports/1e9,txCount,truncated:page>=SOLANA_FEES_MAX_PAGES,source:"publicnode-solana"};
}

async function fetchApertumFees(chain,address,onProgress){
  let nextParams=null,totalFeeWei=0n,txCount=0,page=0;const addrLower=address.toLowerCase();
  do{
    page++;if(onProgress)onProgress(page);let url=`${configuredFeeBase(chain)}/addresses/${address}/transactions`;if(nextParams)url+="?"+new URLSearchParams(nextParams).toString();
    const res=await fetch(url);if(!res.ok)throw new Error("HTTP "+res.status);const data=await res.json();
    (data.items||[]).forEach(tx=>{const fromAddr=((tx.from&&tx.from.hash)||tx.from_address||"").toLowerCase();if(fromAddr!==addrLower)return;let feeWei=null;try{if(tx.fee&&tx.fee.value)feeWei=BigInt(tx.fee.value);else if(tx.gas_used&&tx.gas_price)feeWei=BigInt(tx.gas_used)*BigInt(tx.gas_price);}catch(e){}if(feeWei!==null){totalFeeWei+=feeWei;txCount++;}});
    nextParams=data.next_page_params||null;
  }while(nextParams&&page<FEES_MAX_PAGES);
  return {totalFee:Number(totalFeeWei)/1e18,txCount,truncated:!!nextParams&&page>=FEES_MAX_PAGES,source:"apertum-explorer"};
}

// ---- Token-Approval-Checker (nur lesend, Revoke passiert extern über revoke.cash) ----
function approvalsChains() { return Object.keys(CHAIN_CONFIG).filter(c => CHAIN_CONFIG[c]?.approvalsEnabled === true); }
let activeApprovalsChains = new Set();

function renderApprovalsChainFilter() {
  const el = document.getElementById("approvalsChainContainer");
  if (!el) return;
  el.innerHTML = approvalsChains().map(chain => {
    const meta = CHAIN_META[chain];
    const checked = activeApprovalsChains.has(chain) ? "checked" : "";
    return `<label style="display:flex;align-items:center;gap:6px;font-size:0.85rem;cursor:pointer">
      <input type="checkbox" ${checked} onchange="toggleApprovalsChain('${chain}', this.checked)" style="width:auto" />
      <span class="dot" style="background:${escapeAttr(CHAIN_CONFIG[meta.dot]?.displayColor || "#6b7280")}"></span> ${meta.label}
    </label>`;
  }).join("");
}
function toggleApprovalsChain(chain, isChecked) {
  if (isChecked) activeApprovalsChains.add(chain);
  else activeApprovalsChains.delete(chain);
}
function setAllApprovalsChains(selectAll) {
  activeApprovalsChains = selectAll ? new Set(approvalsChains()) : new Set();
  renderApprovalsChainFilter();
}

function renderApprovalsWalletSelect() {
  const el = document.getElementById("approvalsWalletSelect");
  if (!el) return;
  const current = el.value;
  el.innerHTML = `<option value="">– Wallet wählen –</option>` +
    wallets.map(w => `<option value="${w.id}">${escapeAttr(w.label)}</option>`).join("");
  if (wallets.some(w => w.id === current)) el.value = current;
}

// "Unlimitiert" ist bei ERC20-Freigaben keine feste Zahl, sondern Konvention - Wallets/Dapps
// setzen dafür meist den maximal möglichen uint256-Wert. Alles über 2^255 wird hier als
// praktisch unlimitiert behandelt (deckt auch leicht abweichende "Fast-Maximalwerte" ab).
const APPROVAL_UNLIMITED_THRESHOLD = 2n ** 255n;

async function genericRpcCall(url, method, params) {
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type":"application/json" },
    body: JSON.stringify({ jsonrpc:"2.0", id:1, method, params })
  });
  if (!res.ok) throw new Error("RPC HTTP " + res.status);
  const data = await res.json();
  if (data.error) throw new Error(data.error.message || "RPC-Fehler");
  return data.result;
}

async function fetchBlockscoutApprovalPairs(chain, address, onProgress) {
  const base = CHAIN_CONFIG[chain]?.approvalsApiBase;
  if (!base) throw new Error("Freigaben API-Basis fehlt in public.chains");
  const ownerLower = address.toLowerCase();
  const pairs = new Map();
  let nextParams = null;
  let page = 0;

  // Blockscout liefert die ausgehenden Transaktionen der Wallet. Für jede Transaktion
  // lesen wir die Logs und suchen ERC-20 Approval(address,address,uint256).
  do {
    page++;
    if (onProgress) onProgress(page);
    let url = `${base.replace(/\/+$/,"")}/addresses/${address}/transactions`;
    if (nextParams) url += "?" + new URLSearchParams(nextParams).toString();
    const res = await fetch(url);
    if (!res.ok) throw new Error("Blockscout HTTP " + res.status);
    const data = await res.json();

    const outgoing = (data.items || []).filter(tx => {
      const fromAddr = ((tx.from && tx.from.hash) || tx.from_address || "").toLowerCase();
      return fromAddr === ownerLower && tx.hash;
    });

    // Begrenzte Parallelität, um den Explorer nicht unnötig zu belasten.
    for (let i=0; i<outgoing.length; i+=8) {
      const chunk=outgoing.slice(i,i+8);
      const logRows=await Promise.all(chunk.map(async tx=>{
        const lr=await fetch(`${base.replace(/\/+$/,"")}/transactions/${tx.hash}/logs`);
        if(!lr.ok) return [];
        const ld=await lr.json();
        return (ld.items || []).map(log=>({log,tx}));
      }));
      logRows.flat().forEach(({log,tx})=>{
        const topics=log.topics || [];
        if(topics.length<3) return;
        const topic0=String(topics[0]||"").toLowerCase();
        if(!topic0.startsWith("0x8c5be1e5")) return;
        const owner="0x"+String(topics[1]).slice(-40).toLowerCase();
        if(owner!==ownerLower) return;
        const spender="0x"+String(topics[2]).slice(-40);
        const token=((log.address && (log.address.hash || log.address)) || "").toLowerCase();
        if(!/^0x[0-9a-f]{40}$/.test(token)) return;
        pairs.set(token+"|"+spender.toLowerCase(), {
          token, spender,
          blockNumber: tx.block_number || tx.blockNumber || null,
          timestamp: tx.timestamp || null
        });
      });
    }

    nextParams = data.next_page_params || null;
  } while (nextParams && page < FEES_MAX_PAGES);

  return [...pairs.values()];
}

async function fetchBlockscoutApprovalsForChain(chain,address,onProgress) {
  const cfg=CHAIN_CONFIG[chain]||{};
  const rpcUrl=cfg.rpcUrl;
  if(!rpcUrl) throw new Error("RPC-URL für aktuelle Allowance fehlt in public.chains");

  const pairs=await fetchBlockscoutApprovalPairs(chain,address,onProgress);
  if(!pairs.length) return [];

  const ownerArg=address.toLowerCase().replace(/^0x/,"").padStart(64,"0");
  const active=[];

  // Aktuelle allowance() direkt on-chain prüfen. Damit verschwinden historisch
  // widerrufene Approvals aus der Anzeige.
  for(let i=0;i<pairs.length;i+=10){
    const chunk=pairs.slice(i,i+10);
    const rows=await Promise.all(chunk.map(async p=>{
      const spenderArg=p.spender.toLowerCase().replace(/^0x/,"").padStart(64,"0");
      const data="0xdd62ed3e"+ownerArg+spenderArg;
      try {
        const rawHex=await genericRpcCall(rpcUrl,"eth_call",[{to:p.token,data},"latest"]);
        const raw=BigInt(rawHex||"0x0");
        if(raw<=0n) return null;

        // Symbol/Decimals über Standard-ERC20 eth_call. Fehlende Metadaten sind kein Abbruchgrund.
        let decimals=18, symbol=null;
        try {
          const d=await genericRpcCall(rpcUrl,"eth_call",[{to:p.token,data:"0x313ce567"},"latest"]);
          if(d) decimals=Number(BigInt(d));
        } catch(_){}
        try {
          const sym=await genericRpcCall(rpcUrl,"eth_call",[{to:p.token,data:"0x95d89b41"},"latest"]);
          if(sym && sym.length>=130){
            const len=Number(BigInt("0x"+sym.slice(66,130)));
            const hex=sym.slice(130,130+len*2);
            symbol=new TextDecoder().decode(new Uint8Array(hex.match(/.{1,2}/g).map(b=>parseInt(b,16))));
          }
        } catch(_){}

        return {
          chain,
          tokenSymbol:symbol || (p.token.slice(0,8)+"…"),
          tokenAddress:p.token,
          spenderAddress:p.spender,
          spenderLabel:null,
          valueFormatted:String(Number(raw)/Math.pow(10,decimals)),
          isUnlimited:raw > APPROVAL_UNLIMITED_THRESHOLD,
          usdAtRisk:null,
          timestamp:p.timestamp || null
        };
      } catch(e) {
        return null;
      }
    }));
    active.push(...rows.filter(Boolean));
  }
  return active;
}

async function fetchAlchemyApprovalsForChain(chain, address, onProgress) {
  const ownerLower = address.toLowerCase();
  const history = await fetchAlchemyOutgoingTxHashes(chain, address, onProgress);
  const approvalPairs = new Map(); // token|spender -> letzter gefundener Block
  const chunkSize = 50;

  // Approval-Events aus den Receipts der Wallet-Transaktionen auslesen.
  // topic0 beginnt für ERC20 Approval(address,address,uint256) mit 0x8c5be1e5.
  for (let offset = 0; offset < history.hashes.length; offset += chunkSize) {
    const chunk = history.hashes.slice(offset, offset + chunkSize);
    const receipts = await alchemyRpcBatch(chain, chunk.map(h => ({ method: "eth_getTransactionReceipt", params: [h] })), "approvals");
    receipts.forEach(receipt => {
      if (!receipt || receipt.__error) return;
      (receipt.logs || []).forEach(log => {
        const topics = log.topics || [];
        if (topics.length < 3 || !(topics[0] || "").toLowerCase().startsWith("0x8c5be1e5")) return;
        const owner = "0x" + topics[1].slice(-40).toLowerCase();
        if (owner !== ownerLower) return;
        const spender = "0x" + topics[2].slice(-40);
        const token = (log.address || "").toLowerCase();
        if (!token) return;
        approvalPairs.set(token + "|" + spender.toLowerCase(), { token, spender, blockNumber: receipt.blockNumber });
      });
    });
  }

  const pairs = [...approvalPairs.values()];
  if (!pairs.length) return [];

  // Aktuelle Allowance + Token-Metadaten abfragen. Alte, bereits auf 0 gesetzte Freigaben
  // werden dadurch nicht mehr angezeigt.
  const calls = [];
  pairs.forEach(p => {
    const ownerArg = address.toLowerCase().replace(/^0x/, "").padStart(64, "0");
    const spenderArg = p.spender.toLowerCase().replace(/^0x/, "").padStart(64, "0");
    calls.push({ method: "eth_call", params: [{ to: p.token, data: "0xdd62ed3e" + ownerArg + spenderArg }, "latest"] });
    calls.push({ method: "alchemy_getTokenMetadata", params: [p.token] });
  });
  const rows = await alchemyRpcBatch(chain, calls, "approvals");

  // Block-Zeitstempel nur für aktive Freigaben nachladen.
  const active = [];
  for (let i = 0; i < pairs.length; i++) {
    const rawAllowance = rows[i * 2];
    const meta = rows[i * 2 + 1];
    if (!rawAllowance || rawAllowance.__error) continue;
    let raw;
    try { raw = BigInt(rawAllowance); } catch (e) { continue; }
    if (raw <= 0n) continue;
    const decimals = meta && !meta.__error && Number.isFinite(Number(meta.decimals)) ? Number(meta.decimals) : 18;
    const valueFormatted = Number(raw) / Math.pow(10, decimals);
    active.push({ ...pairs[i], raw, meta: meta && !meta.__error ? meta : {}, valueFormatted });
  }

  const uniqueBlocks = [...new Set(active.map(a => a.blockNumber).filter(Boolean))];
  const blockRows = await alchemyRpcBatch(chain, uniqueBlocks.map(b => ({ method: "eth_getBlockByNumber", params: [b, false] })), "approvals");
  const blockTs = new Map();
  uniqueBlocks.forEach((b, i) => {
    const row = blockRows[i];
    if (row && !row.__error && row.timestamp) blockTs.set(b, Number(BigInt(row.timestamp)) * 1000);
  });

  return active.map(a => ({
    chain,
    tokenSymbol: a.meta.symbol || (a.token.slice(0, 8) + "…"),
    tokenAddress: a.token,
    spenderAddress: a.spender,
    spenderLabel: null,
    valueFormatted: String(a.valueFormatted),
    isUnlimited: a.raw > APPROVAL_UNLIMITED_THRESHOLD,
    usdAtRisk: null,
    timestamp: blockTs.has(a.blockNumber) ? new Date(blockTs.get(a.blockNumber)).toISOString() : null
  }));
}

async function fetchApprovalsForChain(chain,address,onProgress){
  const provider=CHAIN_CONFIG[chain]?.approvalsProvider;
  if(provider==="alchemy") return fetchAlchemyApprovalsForChain(chain,address,onProgress);
  if(provider==="blockscout") return fetchBlockscoutApprovalsForChain(chain,address,onProgress);
  throw new Error(`Freigaben-Provider "${provider||"–"}" ist nicht implementiert`);
}

async function runApprovalsCheck() {
  const btn = document.getElementById("approvalsBtn");
  const status = document.getElementById("approvalsStatus");
  const walletId = document.getElementById("approvalsWalletSelect").value;

  if (!walletId) { status.textContent = "Bitte zuerst eine Wallet auswählen."; return; }
  if (activeApprovalsChains.size === 0) { status.textContent = "Bitte mindestens eine Chain auswählen."; return; }

  const w = wallets.find(x => x.id === walletId);
  if (!w || !w.evm) { status.textContent = "Diese Wallet hat keine EVM-Adresse erfasst."; return; }

  btn.disabled = true;
  btn.textContent = "Scan läuft…";
  let allApprovals = [];

  try {
    for (const chain of approvalsChains().filter(c => activeApprovalsChains.has(c))) {
      status.textContent = `Prüfe Freigaben für ${w.label} auf ${CHAIN_META[chain].label}...`;
      try {
        const found = await fetchApprovalsForChain(chain, w.evm, (page) => {
          status.textContent = `Prüfe Freigaben für ${w.label} auf ${CHAIN_META[chain].label}... (Seite ${page})`;
        });
        allApprovals = allApprovals.concat(found);
      } catch (e) {
        allApprovals.push({ chain, error: e.message });
      }
    }

    renderApprovalsResults(w, allApprovals);
    status.textContent = "Fertig.";
  } finally {
    btn.disabled = false;
    btn.textContent = "Freigaben prüfen";
  }
}

function renderApprovalsResults(wallet, approvals) {
  const el = document.getElementById("approvalsResults");
  const errors = approvals.filter(a => a.error);
  const valid = approvals.filter(a => !a.error);

  if (valid.length === 0 && errors.length === 0) {
    el.innerHTML = `<div class="empty">Keine aktiven Freigaben gefunden - sauber!</div>`;
    return;
  }

  const unlimitedCount = valid.filter(a => a.isUnlimited).length;
  const revokeUrl = `https://revoke.cash/address/${wallet.evm}`;

  const errorNote = errors.length > 0
    ? `<div class="error" style="margin-bottom:10px">Fehler bei: ${errors.map(e => CHAIN_META[e.chain].label + " (" + e.error + ")").join(", ")}</div>`
    : "";

  el.innerHTML = `
    <div class="custom-token-card">
      <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;margin-bottom:12px">
        <h3 style="margin:0">${escapeAttr(wallet.label)} — ${valid.length} aktive Freigabe(n)${unlimitedCount > 0 ? `, ${unlimitedCount} davon unlimitiert` : ""}</h3>
        <a href="${revokeUrl}" target="_blank" rel="noopener"><button class="secondary">Alle auf revoke.cash ansehen ↗</button></a>
      </div>
      ${errorNote}
      <table>
        <thead><tr><th>Chain</th><th>Token</th><th>An (Spender)</th><th style="text-align:right">Freigabe</th><th style="text-align:right">USD-Risiko</th><th>Datum</th></tr></thead>
        <tbody>
          ${valid.map(a => {
            const meta = CHAIN_META[a.chain];
            const spenderText = a.spenderLabel ? escapeAttr(a.spenderLabel) : (a.spenderAddress || "").slice(0, 10) + "…";
            const dt = a.timestamp ? new Date(a.timestamp).toLocaleDateString("de-CH") : "–";
            return `<tr style="${a.isUnlimited ? 'background:rgba(255,107,107,0.08)' : ''}">
              <td><span class="dot" style="background:${escapeAttr(CHAIN_CONFIG[meta.dot]?.displayColor || "#6b7280")}"></span> ${meta.label}</td>
              <td>${escapeAttr(a.tokenSymbol)}</td>
              <td style="font-size:0.78rem" title="${a.spenderAddress || ''}">${spenderText}</td>
              <td class="num">${a.isUnlimited ? '<span style="color:var(--danger);font-weight:700">⚠ Unlimitiert</span>' : fmt(parseFloat(a.valueFormatted || "0"))}</td>
              <td class="num">${a.usdAtRisk ? fmtUsd(parseFloat(a.usdAtRisk)) : '<span style="color:var(--muted)">–</span>'}</td>
              <td style="font-size:0.78rem">${dt}</td>
            </tr>`;
          }).join("")}
        </tbody>
      </table>
      <div class="note" style="margin-top:10px">Zum Widerrufen: Link oben in deiner Wallet-App öffnen (siehe Hinweis oben), dort verbinden und "Revoke" pro Freigabe klicken.</div>
    </div>
  `;
}

// ---- NFTs (nur auf Knopfdruck, via Alchemy) ----
function nftChains() { return Object.keys(CHAIN_CONFIG).filter(c => CHAIN_CONFIG[c]?.nftEnabled === true); }
let activeNftChains = new Set();

function renderNftChainFilter() {
  const el = document.getElementById("nftChainContainer");
  if (!el) return;
  el.innerHTML = nftChains().map(chain => {
    const meta = CHAIN_META[chain];
    const checked = activeNftChains.has(chain) ? "checked" : "";
    return `<label style="display:flex;align-items:center;gap:6px;font-size:0.85rem;cursor:pointer">
      <input type="checkbox" ${checked} onchange="toggleNftChain('${chain}', this.checked)" style="width:auto" />
      <span class="dot" style="background:${escapeAttr(CHAIN_CONFIG[meta.dot]?.displayColor || "#6b7280")}"></span> ${meta.label}
    </label>`;
  }).join("");
}
function toggleNftChain(chain, isChecked) {
  if (isChecked) activeNftChains.add(chain);
  else activeNftChains.delete(chain);
}
function setAllNftChains(selectAll) {
  activeNftChains = selectAll ? new Set(nftChains()) : new Set();
  renderNftChainFilter();
}

function renderNftWalletSelect() {
  const el = document.getElementById("nftWalletSelect");
  if (!el) return;
  const current = el.value;
  el.innerHTML = `<option value="all">Alle Wallets</option>` +
    wallets.map(w => `<option value="${w.id}">${escapeAttr(w.label)}</option>`).join("");
  if (current === "all" || wallets.some(w => w.id === current)) el.value = current;
}

async function fetchNftsForChain(chain, address, onProgress) {
  assertAlchemyConfigured();
  if (CHAIN_CONFIG[chain]?.nftProvider !== "alchemy") throw new Error("NFT-Provider ist nicht Alchemy");
  const base = configuredNftBase(chain);
  const nfts = [];
  let pageKey = null;
  let page = 0;

  do {
    page++;
    if (onProgress) onProgress(page);
    const qs = new URLSearchParams({ owner: address, withMetadata: "true", pageSize: "100" });
    if (pageKey) qs.set("pageKey", pageKey);
    const res = await fetch(`${base}/${encodeURIComponent(ALCHEMY_API_KEY)}/getNFTsForOwner?${qs.toString()}`, {
      headers: { "Accept": "application/json" }
    });
    if (!res.ok) throw new Error("Alchemy NFT HTTP " + res.status);
    const data = await res.json();
    for (const n of (data.ownedNfts || [])) {
      const contract = n.contract || {};
      const image = n.image || {};
      const rawMeta=n?.raw?.metadata||{};
      let item={
        chain,
        tokenAddress: contract.address,
        tokenId: n.tokenId,
        name: n.name || rawMeta?.name || contract.name || "Unbenannt",
        image: normalizeNftImageUrl(image.cachedUrl || image.thumbnailUrl || image.pngUrl || image.originalUrl || n?.media?.[0]?.gateway || n?.media?.[0]?.thumbnail || n?.media?.[0]?.raw) || nftMetadataImage(rawMeta),
        imageSource:(image.cachedUrl||image.thumbnailUrl||image.pngUrl||image.originalUrl||n?.media?.[0]?.gateway||n?.media?.[0]?.thumbnail||n?.media?.[0]?.raw)?"alchemy-image":(nftMetadataImage(rawMeta)?"alchemy-raw-metadata":null),
        collectionName: (n.collection && n.collection.name) || (contract.openSeaMetadata && contract.openSeaMetadata.collectionName) || contract.name,
        possibleSpam: contract.isSpam === true || contract.isSpam === "true" || (contract.spamClassifications || []).length > 0,
        contractType: n.tokenType || contract.tokenType
      };
      if(!item.possibleSpam && (!item.image || !item.name || item.name==="Unbenannt"))item=await enrichAlchemyNftMetadata(chain,item);
      if(!item.possibleSpam && !item.image)item=await enrichNftFromTokenUri(chain,item);
      nfts.push(item);
    }
    pageKey = data.pageKey || null;
  } while (pageKey && page < FEES_MAX_PAGES);

  return nfts;
}

// IPFS-Links (ipfs://...) funktionieren nicht direkt im <img>-Tag - über ein öffentliches Gateway umleiten.
function normalizeNftImageUrl(url) {
  if (!url) return null;
  let u = String(url).trim();
  if (!u) return null;
  if (u.startsWith("ipfs://ipfs/")) u = "ipfs://" + u.slice("ipfs://ipfs/".length);
  if (u.startsWith("ipfs://")) return "https://ipfs.io/ipfs/" + u.slice("ipfs://".length);
  if (u.startsWith("ar://")) return "https://arweave.net/" + u.slice(5);
  if (u.startsWith("//")) return "https:" + u;
  return u;
}

function nftMetadataImage(meta,depth=0) {
  if (!meta || typeof meta !== "object") return null;
  const imageObj=meta.image&&typeof meta.image==="object"?meta.image:null;
  const media0=Array.isArray(meta.media)?meta.media[0]:null;
  const file0=Array.isArray(meta.files)?meta.files[0]:null;
  const props=meta.properties&&typeof meta.properties==="object"?meta.properties:{};
  const candidates=[
    typeof meta.image==="string"?meta.image:null,meta.image_url,meta.imageUrl,meta.image_uri,meta.imageUri,
    imageObj?.url,imageObj?.uri,imageObj?.gateway,props.image,props.image_url,props.imageUrl,
    media0?.gateway,media0?.thumbnail,media0?.raw,media0?.url,media0?.uri,
    file0?.uri,file0?.url,meta.animation_url
  ];
  for(const c of candidates){const u=normalizeNftImageUrl(c);if(u)return u;}
  if(depth<2)for(const nested of [meta.metadata,meta.data,meta.nft,meta.token_metadata,meta.tokenMetadata]){
    if(nested&&typeof nested==="object"&&!Array.isArray(nested)){const u=nftMetadataImage(nested,depth+1);if(u)return u;}
  }
  return null;
}

function nftMetadataNameCandidates(meta,depth=0) {
  if(!meta || typeof meta!=="object") return [];
  const out=[];
  const add=(value,source,priority=0)=>{
    if(value==null || (typeof value!=="string" && typeof value!=="number"))return;
    const v=String(value).trim();
    if(!v)return;
    out.push({value:v,source,priority});
  };
  add(meta.name,"metadata.name",100);
  add(meta.title,"metadata.title",96);
  add(meta.display_name ?? meta.displayName,"metadata.display_name",94);
  add(meta.bot_name ?? meta.botName,"metadata.bot_name",98);
  add(meta.model_name ?? meta.modelName,"metadata.model_name",92);
  add(meta.variant_name ?? meta.variantName,"metadata.variant_name",90);
  const props=meta.properties&&typeof meta.properties==="object"?meta.properties:null;
  if(props){
    add(props.name,"metadata.properties.name",95);
    add(props.title,"metadata.properties.title",93);
    add(props.bot_name ?? props.botName,"metadata.properties.bot_name",97);
    add(props.model_name ?? props.modelName,"metadata.properties.model_name",91);
  }
  const attrs=Array.isArray(meta.attributes)?meta.attributes:[];
  for(const a of attrs){
    if(!a || typeof a!=="object")continue;
    const key=String(a.trait_type ?? a.traitType ?? a.name ?? a.key ?? a.title ?? "").trim();
    const value=a.value ?? a.display_value ?? a.displayValue ?? a.val;
    if(value==null)continue;
    const k=key.toLowerCase().replace(/[_-]+/g," ").replace(/\s+/g," ").trim();
    let priority=0;
    if(/^(bot )?name$/.test(k))priority=99;
    else if(/^(bot )?model( name)?$/.test(k))priority=94;
    else if(/^(bot )?variant( name)?$/.test(k))priority=92;
    else if(/^(bot )?series( name)?$/.test(k))priority=88;
    else if(/^(bot )?edition( name)?$/.test(k))priority=86;
    if(priority)add(value,`metadata.attributes.${key||"value"}`,priority);
  }
  if(depth<2){
    for(const [key,nested] of [["metadata",meta.metadata],["data",meta.data],["nft",meta.nft],["token_metadata",meta.token_metadata],["tokenMetadata",meta.tokenMetadata]]){
      if(!nested||typeof nested!=="object"||Array.isArray(nested))continue;
      for(const c of nftMetadataNameCandidates(nested,depth+1))out.push({...c,source:`metadata.${key}.${String(c.source||"").replace(/^metadata\./,"")}`,priority:Number(c.priority||0)+1});
    }
  }
  return out;
}
function bestMetadataStoreName(tokenId,collectionName,...metas){
  const candidates=[];
  for(const meta of metas)candidates.push(...nftMetadataNameCandidates(meta));
  candidates.sort((a,b)=>b.priority-a.priority);
  for(const c of candidates){
    if(nftNameQuality(c.value,tokenId,collectionName)>=3)return c;
  }
  return null;
}

let apertureProjectNftNameCache={loadedAt:0,map:new Map()};
async function loadApertureProjectNftNameMap(force=false){
  const age=Date.now()-Number(apertureProjectNftNameCache.loadedAt||0);
  if(!force && age<300000 && apertureProjectNftNameCache.map instanceof Map)return apertureProjectNftNameCache.map;
  const map=new Map();
  try{
    const {data,error}=await sb.from("project_nfts").select("nft_contract,nft_id,nft_name").eq("project_key","dao1").eq("chain_key","apertum").eq("enabled",true);
    if(error)throw error;
    for(const r of (data||[])){
      const contract=lowerAddressForNft(r.nft_contract),id=String(r.nft_id??"");
      const name=String(r.nft_name||"").trim();
      if(contract&&id&&name)map.set(`${contract}|${id}`,name);
    }
  }catch(e){
    if(!/does not exist|schema cache/i.test(String(e?.message||"")))console.warn("DAO-NFT-Projektnamen:",e);
  }
  for(const o of (nftOwnershipRows||[])){
    const contract=lowerAddressForNft(o?.nft_contract),id=String(o?.nft_id??"");
    const name=String(o?.nft_name||"").trim();
    if(!contract||!id||!name)continue;
    const key=`${contract}|${id}`,old=map.get(key)||"";
    map.set(key,bestNftName(id,"",old,name));
  }
  apertureProjectNftNameCache={loadedAt:Date.now(),map};
  return map;
}
async function applyApertureCanonicalNames(nfts){
  if(!Array.isArray(nfts)||!nfts.length)return nfts||[];
  const names=await loadApertureProjectNftNameMap();
  for(const n of nfts){
    const key=`${lowerAddressForNft(n?.tokenAddress)}|${String(n?.tokenId??"")}`;
    const canonical=names.get(key);
    if(!canonical)continue;
    const chosen=bestNftName(n.tokenId,n.collectionName,n.name,canonical);
    if(chosen!==n.name){n.name=chosen;n.nameSource="dao-project-nft";}
  }
  return nfts;
}

function blockscoutNftSpam(obj) {
  const token=obj?.token || {};
  const flags=[obj?.is_spam,obj?.isSpam,obj?.spam,token?.is_spam,token?.isSpam,token?.spam];
  if(flags.some(v=>v===true || v===1 || String(v).toLowerCase()==="true")) return true;
  const rep=String(obj?.reputation || token?.reputation || "").toLowerCase();
  return ["spam","scam","malicious","suspicious"].includes(rep);
}


function nftNameQuality(name, tokenId="", collectionName="") {
  const raw=String(name||"").trim();
  if(!raw || raw==="Unbenannt")return 0;
  const id=String(tokenId??"").trim().replace(/[.*+?^${}()|[\]\\]/g,"\\$&");
  const lower=raw.toLowerCase();
  const collection=String(collectionName||"").trim().toLowerCase();
  if(/^nft\s*#?\s*\d+$/i.test(raw))return 1;
  if(/^(mine\s*bot|minebot|mining\s*bot|apertum\s*miner)\s*#?\s*\d+$/i.test(raw))return 1;
  if(id && new RegExp(`^${id}$`).test(raw))return 1;
  if(collection && lower===collection)return 1;
  if(["minebot","mine bot","mining bot","apertum miner"].includes(lower))return 1;
  return 3;
}
function nftHasPreferredName(nft){
  return nftNameQuality(nft?.name,nft?.tokenId,nft?.collectionName)>=3;
}
function bestNftName(tokenId,collectionName,...names){
  let best="",score=-1;
  for(const name of names){
    const q=nftNameQuality(name,tokenId,collectionName);
    if(q>score){best=String(name||"").trim();score=q;}
  }
  return best || (collectionName?`${collectionName} #${tokenId}`:`NFT #${tokenId}`);
}
async function enrichApertumNft(chain, nft) {
  if (!nft?.tokenAddress || nft?.tokenId == null) return nft;
  const needsImage=!nft.image;
  const needsPreferredName=!nftHasPreferredName(nft);
  if(!needsImage&&!needsPreferredName)return nft;
  try {
    const base=configuredNftBase(chain);
    const url=`${base}/tokens/${nft.tokenAddress}/instances/${encodeURIComponent(String(nft.tokenId))}`;
    const res=await fetch(url);
    if(!res.ok) return nft;
    const inst=await res.json();
    let meta=inst?.metadata || {};
    const token=inst?.token || {};
    const collectionName=nft.collectionName||token.name||token.symbol;
    let external=null;
    let image=nft.image || normalizeNftImageUrl(inst?.image_url||inst?.media_url) || nftMetadataImage(meta);
    let storeCandidate=bestMetadataStoreName(nft.tokenId,collectionName,meta);
    let preferredName=bestNftName(nft.tokenId,collectionName,
      storeCandidate?.value,meta?.name,inst?.name,nft.name,token.name,token.symbol);
    if(!image || nftNameQuality(preferredName,nft.tokenId,collectionName)<3){
      const uri=inst?.metadata_url||inst?.token_uri||inst?.tokenUri||token?.metadata_url||token?.token_uri||null;
      external=uri?await fetchExternalNftMetadata(uri):null;
      if(external){
        meta={...external,...meta};
        image=image || nftMetadataImage(external);
        storeCandidate=bestMetadataStoreName(nft.tokenId,collectionName,meta,external)||storeCandidate;
        preferredName=bestNftName(nft.tokenId,collectionName,
          storeCandidate?.value,meta?.name,external?.name,inst?.name,nft.name,token.name,token.symbol);
      }
    }
    let out={
      ...nft,
      name:preferredName,
      nameSource:storeCandidate?.value===preferredName?(storeCandidate?.source||"apertum-store-metadata"):(nft.nameSource||null),
      collectionName: nft.collectionName || token.name || token.symbol || null,
      image,
      imageSource:nft.imageSource||(image?"apertum-explorer-metadata":null),
      possibleSpam: !!(nft.possibleSpam || blockscoutNftSpam(inst))
    };
    if(!out.possibleSpam&&!out.image)out=await enrichNftFromTokenUri(chain,out);
    return out;
  } catch(e) {
    wtTrackNftMigrationIssue("apertum-instance-metadata",`${nft.tokenAddress||""}#${nft.tokenId??""}`,e);
    console.warn("Apertum NFT-Metadaten konnten nicht ergänzt werden:", nft.tokenAddress, nft.tokenId, e);
    return nft;
  }
}

// Apertum: eigene Blockscout-API (Alchemy wird dafür hier nicht verwendet).
function apertureNftFromOwnedItem(chain, item) {
  const token=item?.token || {};
  const meta=item?.metadata || {};
  const tokenAddress=token.address || token.address_hash || item.token_address || item.token_address_hash || "";
  const tokenId=item.id ?? item.token_id ?? item.tokenId ?? "";
  const collectionName=token.name || token.symbol || item.collection_name || null;
  return {
    chain,
    tokenAddress,
    tokenId:String(tokenId),
    name:meta.name || item.name || (collectionName ? `${collectionName} #${tokenId}` : `NFT #${tokenId}`),
    image:normalizeNftImageUrl(item.image_url || item.media_url) || nftMetadataImage(meta),
    imageSource:(item.image_url||item.media_url)?"apertum-owned-image":(nftMetadataImage(meta)?"apertum-owned-metadata":null),
    collectionName,
    possibleSpam:blockscoutNftSpam(item) || blockscoutNftSpam(token),
    contractType:token.type || item.token_type || item.type
  };
}

async function fetchApertumOwnedNfts(chain,address,onProgress){
  const base=configuredNftBase(chain);
  let nextParams=null,page=0;
  const out=[];
  do{
    page++;
    if(onProgress)onProgress(page,"Besitz");
    let url=`${base}/addresses/${address}/nft`;
    if(nextParams)url+="?"+new URLSearchParams(nextParams).toString();
    const res=await fetch(url);
    if(!res.ok)throw new Error("HTTP "+res.status+" (/nft)");
    const data=await res.json();
    for(const item of (data.items||[])){
      let nft=apertureNftFromOwnedItem(chain,item);
      if(!nft.image || !nftHasPreferredName(nft)) nft=await enrichApertumNft(chain,nft);
      out.push(nft);
    }
    nextParams=data.next_page_params||null;
  }while(nextParams && page<FEES_MAX_PAGES);
  return out;
}

async function fetchApertumCollectionNfts(chain,address,onProgress){
  let nextParams=null,page=0;
  const out=[];
  do{
    page++;
    if(onProgress)onProgress(page,"Collections");
    const base=configuredNftBase(chain);
    let url=`${base}/addresses/${address}/nft/collections`;
    if(nextParams)url+="?"+new URLSearchParams(nextParams).toString();
    const res=await fetch(url);
    if(!res.ok)throw new Error("HTTP "+res.status+" (/nft/collections)");
    const data=await res.json();
    for(const coll of (data.items||[])){
      const collectionName=coll.token && (coll.token.name || coll.token.symbol);
      const collectionSpam=blockscoutNftSpam(coll) || blockscoutNftSpam(coll.token||{});
      for(const inst of (coll.token_instances||[])){
        const meta=inst.metadata||{};
        let nft={
          chain,
          tokenAddress:coll.token && (coll.token.address || coll.token.address_hash),
          tokenId:String(inst.id),
          name:meta.name || inst.name || (collectionName ? `${collectionName} #${inst.id}` : `NFT #${inst.id}`),
          image:normalizeNftImageUrl(inst.image_url) || nftMetadataImage(meta),
          collectionName,
          possibleSpam:!!(collectionSpam || blockscoutNftSpam(inst)),
          contractType:coll.token && coll.token.type
        };
        if(!nft.image || !nftHasPreferredName(nft))nft=await enrichApertumNft(chain,nft);
        out.push(nft);
      }
    }
    nextParams=data.next_page_params||null;
  }while(nextParams && page<FEES_MAX_PAGES);
  return out;
}

async function fetchApertumNfts(chain,address,onProgress){
  const perfStarted=performance.now();
  let owned=[],collections=[],errors=[];

  // Phase 6.18: Beide Apertum-Quellen sind fachlich voneinander unabhängig.
  // Deshalb parallel laden statt Owner -> Collections seriell abzuwarten.
  const ownedTask=(async()=>{
    const started=performance.now();
    try{
      const items=await fetchApertumOwnedNfts(chain,address,onProgress);
      return {items,ms:Math.round(performance.now()-started),error:null};
    }catch(error){
      return {items:[],ms:Math.round(performance.now()-started),error};
    }
  })();
  const collectionsTask=(async()=>{
    const started=performance.now();
    try{
      const items=await fetchApertumCollectionNfts(chain,address,onProgress);
      return {items,ms:Math.round(performance.now()-started),error:null};
    }catch(error){
      return {items:[],ms:Math.round(performance.now()-started),error};
    }
  })();

  const [ownedResult,collectionsResult]=await Promise.all([ownedTask,collectionsTask]);
  owned=ownedResult.items||[];
  collections=collectionsResult.items||[];
  const ownedMs=ownedResult.ms;
  const collectionsMs=collectionsResult.ms;
  if(ownedResult.error){
    errors.push(ownedResult.error);
    console.warn("Apertum NFT Owner-Endpoint:",ownedResult.error);
  }
  if(collectionsResult.error){
    errors.push(collectionsResult.error);
    console.warn("Apertum NFT Collections-Endpoint:",collectionsResult.error);
  }

  if(!owned.length && !collections.length && errors.length) throw errors[0];

  let mark=performance.now();
  const merged=new Map();
  for(const nft of [...owned,...collections]){
    const key=`${lowerAddressForNft(nft.tokenAddress)}|${String(nft.tokenId)}`;
    const old=merged.get(key);
    if(!old){
      merged.set(key,nft);
    }else{
      merged.set(key,{
        ...old,
        name:bestNftName(nft.tokenId,old.collectionName||nft.collectionName,old.name,nft.name),
        image:old.image || nft.image,
        collectionName:old.collectionName || nft.collectionName,
        possibleSpam:!!(old.possibleSpam || nft.possibleSpam),
        contractType:old.contractType || nft.contractType
      });
    }
  }
  const result=[...merged.values()];
  const mergeMs=Math.round(performance.now()-mark);
  mark=performance.now();
  await applyApertureCanonicalNames(result);
  const canonicalNamesMs=Math.round(performance.now()-mark);
  const totalMs=Math.round(performance.now()-perfStarted);
  console.info(`Apertum NFT Fetch Performance · mode=parallel · ownedMs=${ownedMs} · collectionsMs=${collectionsMs} · mergeMs=${mergeMs} · canonicalNamesMs=${canonicalNamesMs} · totalMs=${totalMs} · owned=${owned.length} · collections=${collections.length} · result=${result.length}`);
  return result;
}

function lowerAddressForNft(v){ return String(v||"").toLowerCase(); }

// ---- NFT-Cache in Supabase: Live-Abfrage nur auf Knopfdruck ----
let nftCaches = new Map(); // wallet_id -> DB-Zeile
let nftOwnershipRows = []; // DAO1/Apertum-Besitzhistorie, userbezogen
let nftGlobalFirstOwned = new Map(); // contract|id -> frühester Eingang in irgendeine eigene Wallet
let nftGlobalFirstOwnedLoaded=false;
let nftGlobalFirstOwnedPromise=null;
let lastNftFindings = [];

function nftKey(n) {
  return `${n.chain}|${normalizeAddress(n.tokenAddress || "", n.chain)}|${String(n.tokenId)}`;
}
function isNftSpam(n) {
  if (n.userMarkedSpam) return true;
  if (n.userMarkedSafe) return false;
  return !!n.possibleSpam;
}

async function loadNftOwnershipCacheFromDb(){
  if(!currentUser){nftOwnershipRows=[];nftGlobalFirstOwned=new Map();return;}
  try{
    const {data,error}=await sb.from("project_nft_ownership").select("wallet_id,nft_contract,nft_id,nft_name,owned_from_block,owned_to_block,owned_from_at,owned_to_at,is_current,entry_from_address,entry_tx_hash,acquisition_kind,acquisition_verified,acquisition_tx_hash")
      .eq("user_id",currentUser.id).eq("project_key","dao1").eq("chain_key","apertum").order("owned_from_block",{ascending:true});
    if(error)throw error;
    nftOwnershipRows=data||[];
  }catch(e){
    nftOwnershipRows=[];
    if(!/does not exist|schema cache/i.test(String(e?.message||"")))console.warn("NFT-Besitzhistorie:",e);
  }

  nftGlobalFirstOwnedLoaded=false;
  nftGlobalFirstOwned=new Map();
}

async function loadNftGlobalFirstOwnedFromDb(){
  // Robuster zweiter Wahrheitsweg für "Erstmals von dir erworben":
  // Aus dem GLOBALEN öffentlichen Apertum-Transfercache wird der früheste Eingang
  // an irgendeine eigene Wallet ermittelt. Damit bleibt ein Walletwechsel korrekt,
  // selbst wenn eine historische project_nft_ownership-Periode fehlt.
  nftGlobalFirstOwned=new Map();
  try{
    const ownedAddresses=new Set((wallets||[]).map(w=>{
      const v=w?.evm;
      if(typeof v==="string")return lowerAddressForNft(v);
      return lowerAddressForNft(v?.hash||v?.address||v?.address_hash||"");
    }).filter(Boolean));
    if(!ownedAddresses.size){nftGlobalFirstOwnedLoaded=true;return nftGlobalFirstOwned;}

    const nftPairs=new Map();
    for(const cache of nftCaches.values()){
      for(const n of (Array.isArray(cache?.nfts)?cache.nfts:[])){
        if(String(n?.chain||"")!=="apertum")continue;
        const contract=lowerAddressForNft(n?.tokenAddress);
        const id=String(n?.tokenId??"");
        if(contract&&id)nftPairs.set(`${contract}|${id}`,{contract,id});
      }
    }
    if(!nftPairs.size){nftGlobalFirstOwnedLoaded=true;return nftGlobalFirstOwned;}

    const byContract=new Map();
    for(const {contract,id} of nftPairs.values()){
      if(!byContract.has(contract))byContract.set(contract,[]);
      byContract.get(contract).push(id);
    }

    for(const [contract,idsRaw] of byContract){
      const ids=[...new Set(idsRaw)].filter(x=>/^\d+$/.test(String(x)));
      for(let off=0;off<ids.length;off+=100){
        const chunk=ids.slice(off,off+100).map(Number);
        const {data,error}=await sb.from("apertum_nft_transfer_cache")
          .select("nft_contract,nft_id,block_number,block_timestamp,to_address,tx_hash,log_index")
          .eq("chain_key","apertum").eq("nft_contract",contract).in("nft_id",chunk)
          .order("block_number",{ascending:true}).order("log_index",{ascending:true});
        if(error)throw error;
        for(const r of (data||[])){
          if(!ownedAddresses.has(lowerAddressForNft(r.to_address)))continue;
          const key=`${lowerAddressForNft(r.nft_contract)}|${String(r.nft_id)}`;
          const candidate={
            owned_from_block:Number(r.block_number||0)||null,
            owned_from_at:r.block_timestamp||null,
            tx_hash:r.tx_hash||null,
            wallet_address:r.to_address||null
          };
          const old=nftGlobalFirstOwned.get(key);
          if(!old || (candidate.owned_from_block>0 && (!old.owned_from_block || candidate.owned_from_block<old.owned_from_block))){
            nftGlobalFirstOwned.set(key,candidate);
          }
        }
      }
    }

    for(const id of ["7993","7994"]){
      const key=[...nftGlobalFirstOwned.keys()].find(k=>k.endsWith(`|${id}`));
      if(key)console.info("DAO1 NFT Solar globaler Ersterwerb",id,nftGlobalFirstOwned.get(key));
    }
  }catch(e){
    // Der Anzeige-Fallback darf die vorhandene Besitzhistorie nie blockieren.
    console.warn("Apertum globaler NFT-Ersterwerb konnte nicht geladen werden:",e);
    nftGlobalFirstOwned=new Map();
  }
  nftGlobalFirstOwnedLoaded=true;
  return nftGlobalFirstOwned;
}
async function ensureNftGlobalFirstOwnedLoaded(){
  if(nftGlobalFirstOwnedLoaded)return nftGlobalFirstOwned;
  if(!nftGlobalFirstOwnedPromise)nftGlobalFirstOwnedPromise=loadNftGlobalFirstOwnedFromDb().finally(()=>{nftGlobalFirstOwnedPromise=null;});
  return nftGlobalFirstOwnedPromise;
}

function nftOwnershipInfo(n){
  if(String(n?.chain||"")!=="apertum"){
    const at=n?.acquiredAt||null,block=Number(n?.acquiredBlock||0)||null;
    return at||block?{known:true,firstOwnedAt:at,firstOwnedBlock:block,firstOwnedWalletId:String(n?.walletId||n?.wallet_id||""),firstOwnedWalletAddress:n?.walletAddress||null,walletSinceAt:at,walletSinceBlock:block,currentWalletId:String(n?.walletId||n?.wallet_id||""),currentInWallet:true,source:n?.acquisitionSource||"incoming-nft-transfer"}:{known:false};
  }
  const contract=lowerAddressForNft(n?.tokenAddress);
  const id=String(n?.tokenId??"");
  const rows=nftOwnershipRows
    .filter(r=>lowerAddressForNft(r.nft_contract)===contract&&String(r.nft_id)===id)
    .sort((x,y)=>{
      const xb=Number(x.owned_from_block||0),yb=Number(y.owned_from_block||0);
      if(xb&&yb&&xb!==yb)return xb-yb;
      const xt=x.owned_from_at?new Date(x.owned_from_at).getTime():Number.POSITIVE_INFINITY;
      const yt=y.owned_from_at?new Date(y.owned_from_at).getTime():Number.POSITIVE_INFINITY;
      return xt-yt;
    });
  if(!rows.length)return {known:false};

  // "Erstmals von dir erworben" ist walletübergreifend: frühester Besitzabschnitt
  // irgendeiner eigenen Wallet. "In diesem Wallet seit" bleibt wallet-spezifisch.
  let first=rows.reduce((best,r)=>{
    if(!best)return r;
    const bb=Number(best.owned_from_block||0),rb=Number(r.owned_from_block||0);
    if(rb>0 && (bb<=0 || rb<bb))return r;
    if(rb===bb){
      const bt=best.owned_from_at?new Date(best.owned_from_at).getTime():Infinity;
      const rt=r.owned_from_at?new Date(r.owned_from_at).getTime():Infinity;
      if(rt<bt)return r;
    }
    return best;
  },null);

  const globalFirst=nftGlobalFirstOwned.get(`${contract}|${id}`)||null;
  if(globalFirst){
    const fb=Number(first?.owned_from_block||0),gb=Number(globalFirst.owned_from_block||0);
    if(gb>0 && (fb<=0 || gb<fb)){
      // Der globale Transfercache kann einen früheren Eingang belegen als der userbezogene
      // Ownership-Read. In diesem Fall müssen Datum, Wallet UND Erwerbs-Tx aus derselben
      // Evidenz stammen; sonst würde die Preisprüfung eine spätere Transfer-Tx mit einem
      // früheren Erwerbsdatum vermischen.
      first={
        ...first,
        owned_from_block:gb,
        owned_from_at:globalFirst.owned_from_at||null,
        wallet_address:globalFirst.wallet_address||first?.wallet_address||null,
        wallet_id:null,
        entry_tx_hash:globalFirst.tx_hash||null,
        acquisition_tx_hash:globalFirst.tx_hash||null,
        acquisition_verified:false,
        acquisition_kind:"wallet_receipt_only",
        _source:"global-transfer-cache"
      };
    }
  }

  const walletId=String(n?.walletId||n?.wallet_id||"");
  const walletRows=rows.filter(r=>String(r.wallet_id||"")===walletId)
    .sort((x,y)=>Number(x.owned_from_block||0)-Number(y.owned_from_block||0));
  const current=walletRows.find(r=>r.is_current)||walletRows[walletRows.length-1]||null;

  // "Erstmals von dir erworben" muss immer auf der frühesten eigenen Besitz-Evidenz
  // beruhen. Eine spätere verifizierte Transferperiode darf den Ersterwerb nicht ersetzen.
  // Auch eine noch nicht als Kauf verifizierte Entry-Tx bleibt für den Preisresolver wertvoll.
  const acquisitionVerified=first?.acquisition_verified===true;
  return {
    known:true,
    acquisitionVerified,
    acquisitionKind:first?.acquisition_kind||"wallet_receipt_only",
    acquisitionTxHash:first?.acquisition_tx_hash||first?.entry_tx_hash||null,
    firstOwnedAt:first?.owned_from_at||null,
    firstOwnedBlock:Number(first?.owned_from_block||0)||null,
    firstOwnedWalletId:String(first?.wallet_id||""),
    firstOwnedWalletAddress:first?.wallet_address||globalFirst?.wallet_address||null,
    walletSinceAt:current?.owned_from_at||null,
    walletSinceBlock:Number(current?.owned_from_block||0)||null,
    currentWalletId:String(current?.wallet_id||walletId||""),
    currentInWallet:!!current?.is_current
  };
}

function nftOwnershipDate(value){
  if(!value)return "–";
  const d=new Date(value);
  return Number.isNaN(d.getTime())?"–":d.toLocaleString("de-CH",{day:"2-digit",month:"2-digit",year:"numeric",hour:"2-digit",minute:"2-digit"});
}
function nftWalletAddressById(walletId,chain="apertum"){
  const w=wallets.find(x=>String(x.id||x.dbId||"")===String(walletId||""));
  return w?walletAddressForChain(w,chain):null;
}
function nftWalletAddressHtml(address,label="Wallet"){
  const a=String(address||"").trim();
  if(!a)return `<div class="meta">${escapeAttr(label)}: –</div>`;
  return `<div class="meta" style="display:flex;align-items:center;gap:5px;flex-wrap:wrap"><span>${escapeAttr(label)}: ${escapeAttr(dashboardShortAddress(a))}</span><button type="button" class="dashboard-copy-address" style="padding:0 3px;margin-left:1px;border:0;background:transparent;color:inherit;box-shadow:none;font-size:.9em;vertical-align:baseline" title="Wallet-Adresse kopieren" aria-label="Wallet-Adresse kopieren" onclick="copyDashboardAddress('${escapeAttr(a)}',this)">⧉</button></div>`;
}

async function refreshSelectedApertumNftOwnership(){
  const status=document.getElementById("nftStatus");
  const btn=document.getElementById("nftOwnershipBtn");
  if(!window.DAO1Project?.refreshNftOwnershipForWallet){if(status)status.textContent="DAO1-Besitzhistorie ist nicht verfügbar.";return;}
  const walletId=document.getElementById("nftWalletSelect")?.value||"";
  const targets=walletId==="all"?wallets.filter(w=>!!w.evm):wallets.filter(w=>String(w.id)===String(walletId)&&!!w.evm);
  if(!targets.length){if(status)status.textContent="Bitte eine Wallet mit EVM-/Apertum-Adresse wählen.";return;}
  if(btn){btn.disabled=true;btn.textContent="Besitzhistorie wird aktualisiert…";}
  let nfts=0,periods=0,failed=0;
  try{
    for(let i=0;i<targets.length;i++){
      const w=targets[i];
      if(status)status.textContent=`Apertum-Besitzhistorie ${i+1}/${targets.length}: ${w.label}…`;
      const r=await window.DAO1Project.refreshNftOwnershipForWallet(w);
      nfts+=Number(r?.nfts||0);periods+=Number(r?.ownership||0);failed+=Number(r?.failed||0);
    }
    await loadNftOwnershipCacheFromDb();
    lastNftFindings=cachedNftsForSelection();
    renderNftResults(lastNftFindings,[]);
    if(status)status.textContent=`Apertum-Besitzhistorie aktualisiert: ${nfts} NFT(s), ${periods} Besitzabschnitt(e)${failed?`, ${failed} Historie(n) nicht abrufbar`:""}. Hinweis: BSC-Erwerbsdaten und NFT-Bilder werden über „NFTs jetzt aktualisieren“ neu geladen.`;
  }catch(e){
    console.error(e);if(status)status.textContent="Besitzhistorie konnte nicht vollständig aktualisiert werden: "+(e.message||e);
  }finally{if(btn){btn.disabled=false;btn.textContent="Apertum Besitzhistorie aktualisieren";}}
}

let nftCacheLoaded = false;
let nftCacheLoadPromise = null;

function ensureNftCacheLoaded() {
  if (nftCacheLoaded) return Promise.resolve(nftCaches);
  if (!nftCacheLoadPromise) nftCacheLoadPromise = loadNftCacheFromDb().finally(()=>{ nftCacheLoadPromise = null; });
  return nftCacheLoadPromise;
}

async function loadNftCacheFromDb() {
  if (!currentUser) return;
  const { data, error } = await sb.from("nft_cache").select("*").eq("user_id", currentUser.id);
  if (error) {
    console.error("NFT-Cache:", error);
    return;
  }
  nftCaches = new Map();
  (data || []).forEach(row => nftCaches.set(String(row.wallet_id), row));
  await loadNftOwnershipCacheFromDb();
  nftCacheLoaded = true;
  onNftWalletChange();
  return nftCaches;
}

function cachedNftsForSelection() {
  const walletId = document.getElementById("nftWalletSelect")?.value || "";
  const rows = walletId === "all"
    ? [...nftCaches.values()]
    : (nftCaches.get(String(walletId)) ? [nftCaches.get(String(walletId))] : []);
  return rows.flatMap(r => Array.isArray(r.nfts) ? r.nfts : []);
}

// DAO1 darf exakt dieselbe persistente NFT-Quelle verwenden wie der normale NFT-Tab.
// Nur Daten des aktuell angemeldeten Users aus dessen bereits geladenem nft_cache.
window.getCachedNftsForWalletId = function(walletId) {
  const row=nftCaches.get(String(walletId));
  return Array.isArray(row?.nfts) ? row.nfts : [];
};
window.getAllCachedNfts = function() {
  return [...nftCaches.values()].flatMap(row=>Array.isArray(row?.nfts)?row.nfts:[]);
};
window.isCentralNftCacheLoaded = () => !!nftCacheLoaded;
window.getCentralNftOwnershipRows = () => nftCacheLoaded ? nftOwnershipRows.map(r=>({...r})) : null;

function onNftWalletChange() {
  lastNftFindings = cachedNftsForSelection();
  renderNftResults(lastNftFindings, []);
  const info = document.getElementById("nftCacheInfo");
  if (!info) return;
  const walletId = document.getElementById("nftWalletSelect")?.value || "";
  const rows = walletId === "all" ? [...nftCaches.values()] : [nftCaches.get(String(walletId))].filter(Boolean);
  if (!rows.length) {
    info.textContent = "Für diese Auswahl sind noch keine NFTs in Supabase gespeichert.";
  } else {
    const latest = rows.map(r => new Date(r.refreshed_at)).filter(d => !isNaN(d)).sort((a,b)=>b-a)[0];
    info.textContent = `Gespeicherter NFT-Stand${latest ? " · zuletzt aktualisiert " + latest.toLocaleString("de-CH") : ""}. Live-Abfrage nur über „NFTs jetzt aktualisieren“.`;
  }
}

// Supabase/PostgreSQL akzeptiert in text/jsonb keine Unicode-NUL-Zeichen (U+0000).
// NFT-Metadaten stammen von externen Indexern/Contracts und können solche Steuerzeichen
// in Name, Collection, URL oder sonstigen Textfeldern enthalten. Vor dem Persistieren
// werden ausschließlich U+0000-Zeichen rekursiv entfernt; alle übrigen Daten bleiben unverändert.
function sanitizeNftCacheValue(value, stats=null) {
  if (typeof value === "string") {
    if (!value.includes("\u0000")) return value;
    const cleaned = value.replace(/\u0000/g, "");
    if (stats) stats.nulChars += value.length - cleaned.length;
    return cleaned;
  }
  if (Array.isArray(value)) return value.map(v => sanitizeNftCacheValue(v, stats));
  if (value && typeof value === "object") {
    const out = {};
    for (const [k,v] of Object.entries(value)) out[k] = sanitizeNftCacheValue(v, stats);
    return out;
  }
  return value;
}

function isPersistedWalletUuid(value) {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(String(value||"").trim());
}
function persistedWalletDbId(w,{required=false,context="DB-Zugriff"}={}) {
  const id=String(w?.dbId||"").trim();
  if(isPersistedWalletUuid(id))return id;
  if(required)throw new Error(`${context}: persistierte Wallet-UUID fehlt (${w?.label||w?.id||"Wallet"}).`);
  return null;
}

async function saveNftCacheForWallet(w, nfts, chains) {
  const walletId = persistedWalletDbId(w,{required:true,context:"NFT-Cache"});
  const sanitizeStats = { nulChars: 0 };
  const payload = sanitizeNftCacheValue({
    user_id: currentUser.id,
    wallet_id: walletId,
    wallet_label: w.label,
    selected_chains: chains,
    nfts,
    refreshed_at: new Date().toISOString()
  }, sanitizeStats);
  if (sanitizeStats.nulChars > 0) {
    console.info(`NFT-Cache: ${sanitizeStats.nulChars} unzulässige U+0000-Zeichen aus externen NFT-Metadaten entfernt (${w.label}).`);
  }

  // Kein PostgREST-Upsert mit on_conflict mehr: Auf der produktiven DB kann der
  // erwartete zusammengesetzte Unique-/Primary-Key vom historischen Schema abweichen.
  // Das bisherige upsert(..., {onConflict:"user_id,wallet_id"}) erzeugte dann HTTP 400,
  // obwohl Lesen und normales Aktualisieren der Tabelle funktionieren.
  // Deshalb robust und schema-tolerant: vorhandene Wallet-Zeile gezielt UPDATE,
  // andernfalls INSERT. Damit bleibt weiterhin exakt ein Cache-Datensatz je User/Wallet.
  const updatePayload = {
    wallet_label: payload.wallet_label,
    selected_chains: payload.selected_chains,
    nfts: payload.nfts,
    refreshed_at: payload.refreshed_at
  };
  const { data: updatedRows, error: updateError } = await sb.from("nft_cache")
    .update(updatePayload)
    .eq("user_id", currentUser.id)
    .eq("wallet_id", walletId)
    .select();
  if (updateError) {
    console.error("NFT-Cache UPDATE fehlgeschlagen", {
      code:updateError.code, message:updateError.message, details:updateError.details, hint:updateError.hint,
      wallet_id:walletId
    });
    throw new Error("NFT-Cache konnte nicht aktualisiert werden: " + [updateError.message,updateError.details,updateError.hint].filter(Boolean).join(" · "));
  }

  let row = Array.isArray(updatedRows) && updatedRows.length ? updatedRows[0] : null;
  if (!row) {
    const { data: inserted, error: insertError } = await sb.from("nft_cache")
      .insert(payload)
      .select()
      .single();
    if (insertError) {
      console.error("NFT-Cache INSERT fehlgeschlagen", {
        code:insertError.code, message:insertError.message, details:insertError.details, hint:insertError.hint,
        wallet_id:walletId
      });
      throw new Error("NFT-Cache konnte nicht angelegt werden: " + [insertError.message,insertError.details,insertError.hint].filter(Boolean).join(" · "));
    }
    row = inserted;
  }
  nftCaches.set(walletId, row);
}

async function refreshApertumNftsForWallet(wallet,onProgress=null){
  if(!currentUser||!wallet?.evm)throw new Error("Apertum-Wallet fehlt.");
  const perfStarted=performance.now();
  let mark=perfStarted;
  const chain="apertum",found=await fetchApertumNfts(chain,wallet.evm,p=>onProgress?.(p));
  const fetchMs=Math.round(performance.now()-mark);
  mark=performance.now();
  found.forEach(n=>{n.walletLabel=wallet.label;n.walletId=String(wallet.dbId||wallet.id);});
  const old=nftCaches.get(String(wallet.dbId||wallet.id));
  const flags=new Map(((old&&old.nfts)||[]).map(n=>[nftKey(n),{
    spam:!!n.userMarkedSpam,safe:!!n.userMarkedSafe,image:n.image||null,
    imageSource:n.imageSource||null,metadataUri:n.metadataUri||null,metadataMethod:n.metadataMethod||null,
    name:n.name||null,collectionName:n.collectionName||null,purchaseEvidence:n.purchaseEvidence||null
  }]));
  found.forEach(n=>{
    const f=flags.get(nftKey(n));
    if(f?.spam)n.userMarkedSpam=true;
    if(f?.safe)n.userMarkedSafe=true;
    if(!n.image&&f?.image)n.image=f.image;
    if(!n.imageSource&&f?.imageSource)n.imageSource=f.imageSource;
    if(!n.metadataUri&&f?.metadataUri)n.metadataUri=f.metadataUri;
    if(!n.metadataMethod&&f?.metadataMethod)n.metadataMethod=f.metadataMethod;
    if(f?.name)n.name=bestNftName(n.tokenId,n.collectionName||f.collectionName,n.name,f.name);
    if(!n.collectionName&&f?.collectionName)n.collectionName=f.collectionName;
    if(!n.purchaseEvidence&&f?.purchaseEvidence)n.purchaseEvidence=f.purchaseEvidence;
  });
  const others=((old&&old.nfts)||[]).filter(n=>String(n.chain||"")!==chain);
  const mergeFlagsMs=Math.round(performance.now()-mark);
  mark=performance.now();
  await saveNftCacheForWallet(wallet,others.concat(found),[...new Set([...(old?.selected_chains||[]),chain])]);
  const saveCacheMs=Math.round(performance.now()-mark);
  const totalMs=Math.round(performance.now()-perfStarted);
  console.info(`DAO1 NFT Inventory Performance · wallet=${wallet.label||wallet.id||""} · fetchMs=${fetchMs} · mergeFlagsMs=${mergeFlagsMs} · saveCacheMs=${saveCacheMs} · totalMs=${totalMs} · found=${found.length} · priorCached=${Array.isArray(old?.nfts)?old.nfts.length:0}`);
  return found;
}


function normalizeNftTransferTokenId(v){
  if(v===null||v===undefined)return "";
  const raw=String(v).trim();
  if(!raw)return "";
  try{
    if(/^0x[0-9a-f]+$/i.test(raw))return BigInt(raw).toString(10);
    if(/^\d+$/.test(raw))return BigInt(raw).toString(10);
  }catch(_){}
  return raw.replace(/^0+/,"")||"0";
}

function nftAcquisitionTransferKeys(t){
  const out=[];
  const contract=lowerAddressForNft(t?.rawContract?.address||t?.contract?.address||t?.contractAddress||t?.tokenAddress||"");
  if(!contract)return out;
  const ids=[];
  if(t?.erc721TokenId!=null)ids.push(t.erc721TokenId);
  if(t?.tokenId!=null)ids.push(t.tokenId);
  const meta1155=t?.erc1155Metadata||t?.erc1155MetaData;
  if(Array.isArray(meta1155))for(const m of meta1155)if(m?.tokenId!=null)ids.push(m.tokenId);
  for(const id of ids){
    const n=normalizeNftTransferTokenId(id);
    if(n)out.push(`${contract}|${n}`);
  }
  return [...new Set(out)];
}

function nftTransferBlock(t){
  const v=t?.blockNum??t?.blockNumber??t?.block_number??0;
  try{return typeof v==="string"&&/^0x/i.test(v)?Number(BigInt(v)):Number(v)||0;}catch(_){return 0;}
}
function nftTransferTimestamp(t){
  const v=t?.metadata?.blockTimestamp??t?.blockTimestamp??t?.blockTimeStamp??t?.block_timestamp??t?.timestamp??null;
  if(v===null||v===undefined||v==="")return null;
  let d;
  if(typeof v==="number")d=new Date(v<1e12?v*1000:v);
  else if(/^\d+$/.test(String(v))) { const n=Number(v); d=new Date(n<1e12?n*1000:n); }
  else d=new Date(v);
  return Number.isNaN(d.getTime())?null:d.toISOString();
}

async function fetchIncomingNftTransfersForWallet(chain,address,onProgress=null){
  const addr=String(address||"").toLowerCase();
  const rows=[];
  if(!addr)return rows;

  // BSC: Alchemy ist für NFT-Transfers robuster als der bisherige NodeReal-Pfad.
  // Wenn Alchemy nicht verfügbar ist, fällt BSC weiter auf NodeReal zurück.
  if(chain==="bsc" && CHAIN_CONFIG[chain]?.nftProvider==="alchemy"){
    try{
      let pageKey=null,pages=0;
      do{
        pages++;onProgress?.(`Alchemy ${pages}`);
        const q={fromBlock:"0x0",toBlock:"latest",toAddress:address,category:["erc721","erc1155"],withMetadata:true,excludeZeroValue:false,maxCount:"0x3e8",order:"asc"};
        if(pageKey)q.pageKey=pageKey;
        const r=await alchemyRpc(chain,"alchemy_getAssetTransfers",[q],"discovery");
        for(const t of (r?.transfers||[])){
          const to=String(t?.to||"").toLowerCase();
          if(to&&to!==addr)continue;
          rows.push(t);
        }
        pageKey=r?.pageKey||null;
        if(pageKey)await sleepMs(150);
        if(pages>500)throw new Error("BSC Alchemy NFT-Erwerbshistorie: Sicherheitsabbruch");
      }while(pageKey);
      if(rows.length)return rows;
    }catch(e){
      console.warn("BSC Alchemy NFT-Erwerbshistorie fehlgeschlagen, NodeReal-Fallback:",e);
    }
  }

  if(chain==="bsc"){
    let pageKey=null,pages=0;
    do{
      pages++;onProgress?.(`NodeReal ${pages}`);
      const q={fromBlock:"0x0",toBlock:"latest",toAddress:address,category:["721","1155"],withMetadata:true,excludeZeroValue:false,maxCount:"0x3e8",order:"asc"};
      if(pageKey)q.pageKey=pageKey;
      const r=await nodeRealRpc("nr_getAssetTransfers",q);
      for(const t of (r?.transfers||[])){
        const to=String(t?.to||t?.toAddress||"").toLowerCase();
        if(to&&to!==addr)continue;
        rows.push(t);
      }
      pageKey=r?.pageKey||r?.PageKey||null;
      if(pageKey)await sleepMs(180);
      if(pages>500)throw new Error("BSC NFT-Erwerbshistorie: Sicherheitsabbruch nach 500 Seiten");
    }while(pageKey);
    return rows;
  }

  if(CHAIN_CONFIG[chain]?.nftProvider==="alchemy"){
    let pageKey=null,pages=0;
    do{
      pages++;onProgress?.(pages);
      const q={fromBlock:"0x0",toBlock:"latest",toAddress:address,category:["erc721","erc1155"],withMetadata:true,excludeZeroValue:false,maxCount:"0x3e8",order:"asc"};
      if(pageKey)q.pageKey=pageKey;
      const r=await alchemyRpc(chain,"alchemy_getAssetTransfers",[q],"discovery");
      for(const t of (r?.transfers||[])){
        const to=String(t?.to||"").toLowerCase();
        if(to&&to!==addr)continue;
        rows.push(t);
      }
      pageKey=r?.pageKey||null;
      if(pageKey)await sleepMs(180);
      if(pages>500)throw new Error(`${CHAIN_META[chain]?.label||chain} NFT-Erwerbshistorie: Sicherheitsabbruch`);
    }while(pageKey);
  }
  return rows;
}

async function fetchBscNftAcquisitionByTokenIds(address,nfts,onProgress=null){
  const addr=String(address||"").toLowerCase();
  const out=new Map();
  const groups=new Map();
  for(const n of (nfts||[])){
    const contract=lowerAddressForNft(n?.tokenAddress);
    const id=normalizeNftTransferTokenId(n?.tokenId);
    if(!contract||!id)continue;
    if(!groups.has(contract))groups.set(contract,[]);
    groups.get(contract).push({n,id});
  }
  let requestNo=0;
  for(const [contract,items] of groups){
    for(let offset=0;offset<items.length;offset+=40){
      const batch=items.slice(offset,offset+40);
      let pageKey=null,pages=0;
      do{
        pages++;requestNo++;onProgress?.(requestNo);
        const q={address:contract,tokenIds:batch.map(x=>"0x"+BigInt(x.id).toString(16)),maxCount:"0x3e8"};
        if(pageKey)q.pageKey=pageKey;
        const r=await nodeRealRpc("nr_getTransferByTokenId",q);
        for(const t of (r?.transfers||[])){
          if(String(t?.to||t?.toAddress||"").toLowerCase()!==addr)continue;
          for(const key of nftAcquisitionTransferKeys(t)){
            const block=nftTransferBlock(t),at=nftTransferTimestamp(t);
            const prev=out.get(key);
            if(!prev || (block&&(!prev.block||block<prev.block)))out.set(key,{block:block||null,at,txHash:String(t?.hash||t?.transactionHash||"")||null});
          }
        }
        pageKey=r?.pageKey||r?.PageKey||null;
        if(pageKey)await sleepMs(120);
        if(pages>100)throw new Error("BSC NFT Token-Historie: Sicherheitsabbruch nach 100 Seiten");
      }while(pageKey);
    }
  }
  return out;
}


async function fetchBscNftAcquisitionByAddress(address,onProgress=null){
  const addr=String(address||"").toLowerCase();
  const rows=[];
  let pageKey=null,pages=0;
  do{
    pages++;onProgress?.(pages);
    const q={category:["721","1155"],addressType:"to",address,order:"asc",maxCount:"0x3e8"};
    if(pageKey)q.pageKey=pageKey;
    const r=await nodeRealRpc("nr_getTransactionByAddress",q);
    for(const t of (r?.transfers||[])){
      const to=String(t?.to||t?.toAddress||"").toLowerCase();
      if(to&&to!==addr)continue;
      rows.push(t);
    }
    pageKey=r?.pageKey||r?.PageKey||null;
    if(pageKey)await sleepMs(120);
    if(pages>500)throw new Error("BSC NFT-Adresshistorie: Sicherheitsabbruch nach 500 Seiten");
  }while(pageKey);
  return rows;
}


async function evmNftMetadataUri(chain,contract,tokenId){
  try{
    const rpc=configuredRpcUrl(chain);
    const provider=new ethers.JsonRpcProvider(rpc);
    const id=BigInt(String(tokenId));
    const calls=[
      {sig:"tokenURI(uint256)",abi:["function tokenURI(uint256) view returns (string)"],args:[id]},
      {sig:"uri(uint256)",abi:["function uri(uint256) view returns (string)"],args:[id]},
      {sig:"getTokenURI(uint256)",abi:["function getTokenURI(uint256) view returns (string)"],args:[id]},
      {sig:"metadataURI(uint256)",abi:["function metadataURI(uint256) view returns (string)"],args:[id]},
      {sig:"tokenMetadataURI(uint256)",abi:["function tokenMetadataURI(uint256) view returns (string)"],args:[id]}
    ];
    for(const c of calls){
      try{
        const iface=new ethers.Interface(c.abi);
        const name=c.sig.slice(0,c.sig.indexOf("("));
        const raw=await provider.call({to:contract,data:iface.encodeFunctionData(name,c.args)});
        const [uri]=iface.decodeFunctionResult(name,raw);
        if(uri){
          let out=String(uri);
          if(out.includes("{id}"))out=out.replaceAll("{id}",id.toString(16).padStart(64,"0"));
          return {uri:out,method:c.sig};
        }
      }catch(_){}
    }

    // Contracts, die nur eine Basis-URI veröffentlichen.
    const baseCalls=[
      {sig:"baseURI()",abi:["function baseURI() view returns (string)"]},
      {sig:"baseTokenURI()",abi:["function baseTokenURI() view returns (string)"]},
      {sig:"BASE_URI()",abi:["function BASE_URI() view returns (string)"]}
    ];
    for(const c of baseCalls){
      try{
        const iface=new ethers.Interface(c.abi),name=c.sig.slice(0,c.sig.indexOf("("));
        const raw=await provider.call({to:contract,data:iface.encodeFunctionData(name,[])});
        const [base]=iface.decodeFunctionResult(name,raw);
        if(!base)continue;
        const b=String(base);
        const candidates=[
          b+id.toString(),
          b+id.toString()+".json",
          b.replace(/\/?$/,"/")+id.toString(),
          b.replace(/\/?$/,"/")+id.toString()+".json"
        ];
        for(const uri of candidates){
          const meta=await fetchExternalNftMetadata(uri);
          if(meta)return {uri,method:c.sig+" + tokenId"};
        }
      }catch(_){}
    }
  }catch(e){console.warn("NFT Metadaten-URI konnte nicht gelesen werden",chain,contract,tokenId,e);}
  return null;
}

async function enrichNftFromTokenUri(chain,nft){
  if(!nft?.tokenAddress||nft?.tokenId==null)return nft;
  try{
    const resolved=await evmNftMetadataUri(chain,nft.tokenAddress,nft.tokenId);
    if(!resolved?.uri)return {...nft,metadataMethod:nft.metadataMethod||"keine unterstützte URI-Funktion"};
    const uri=resolved.uri;
    let meta=null;
    if(/^data:application\/json[,;]/i.test(uri)){
      const payload=uri.split(",",2)[1]||"";
      try{meta=JSON.parse(uri.includes(";base64,")?atob(payload):decodeURIComponent(payload));}catch(_){}
    }else{
      meta=await fetchExternalNftMetadata(uri);
    }
    if(!meta)return {...nft,metadataUri:uri,metadataMethod:resolved.method||null};
    const resolvedImage=nft.image||nftMetadataImage(meta)||null;
    return {
      ...nft,
      name:nft.name&&nft.name!=="Unbenannt"?nft.name:(meta.name||nft.name),
      image:resolvedImage,
      imageSource:nft.imageSource||(resolvedImage?"onchain-contract-metadata":null),
      metadataUri:uri,
      metadataMethod:resolved.method||null
    };
  }catch(e){
    console.warn("NFT tokenURI-Metadaten-Fallback:",chain,nft?.tokenAddress,nft?.tokenId,e);
    return nft;
  }
}

async function enrichAlchemyNftMetadata(chain,nft){
  if(!nft?.tokenAddress||nft?.tokenId==null)return nft;
  if(CHAIN_CONFIG[chain]?.nftProvider!=="alchemy")return nft;
  try{
    assertAlchemyConfigured();
    const base=configuredNftBase(chain);
    const qs=new URLSearchParams({
      contractAddress:String(nft.tokenAddress),
      tokenId:String(nft.tokenId),
      refreshCache:"true"
    });
    const res=await fetch(`${base}/${encodeURIComponent(ALCHEMY_API_KEY)}/getNFTMetadata?${qs.toString()}`,{headers:{"Accept":"application/json"}});
    if(!res.ok)return nft;
    const data=await res.json();
    const rawMeta=data?.raw?.metadata||data?.metadata||data?.rawMetadata||{};
    const img=data?.image||{};
    const image=normalizeNftImageUrl(
      img.cachedUrl||img.thumbnailUrl||img.pngUrl||img.originalUrl||
      data?.media?.[0]?.gateway||data?.media?.[0]?.thumbnail||data?.media?.[0]?.raw
    )||nftMetadataImage(rawMeta);
    return {
      ...nft,
      name:nft.name&&nft.name!=="Unbenannt"?nft.name:(data?.name||rawMeta?.name||nft.name),
      collectionName:nft.collectionName||data?.collection?.name||data?.contract?.name||null,
      image:nft.image||image||null
    };
  }catch(e){
    console.warn("Alchemy NFT-Metadaten-Fallback:",chain,nft?.tokenAddress,nft?.tokenId,e);
    return nft;
  }
}

function isNftMetadataWebPageUrl(url){
  try{
    const u=new URL(String(url||""));
    const host=u.hostname.toLowerCase();
    // explorer.apertum.io/token/.../instance/... sowie ?tab=metadata sind HTML-UI-Seiten.
    // Sie sind weder JSON-Metadatenendpunkte noch browserseitig CORS-freigegeben.
    if(host==="explorer.apertum.io" && (/^\/token\//i.test(u.pathname)||u.searchParams.has("tab")))return true;
    return false;
  }catch(_){return false;}
}
async function fetchExternalNftMetadata(uri){
  const url=normalizeNftImageUrl(uri);
  if(!url||isNftMetadataWebPageUrl(url))return null;
  try{
    const u=new URL(url);
    if(u.protocol==="https:" && u.hostname==="api.aptmdao.io" && /^\/nft\/\d+\/?$/.test(u.pathname)){
      try{
        const data=await invokeWalletPrivate("nft_metadata_fetch",{url:u.toString()});
        if(data?.found===false)return null;
        const payload=data?.metadata??null;
        return payload&&typeof payload==="object"?payload:null;
      }catch(e){
        wtTrackNftMigrationIssue("aptmdao-metadata",u.toString(),e);
        console.warn("APTMDAO NFT-Metadaten serverseitig nicht abrufbar:",u.toString(),e);
        return null;
      }
    }
    if(u.hostname==="api.dao1.ai" && /^\/miner\/\d+\/?$/.test(u.pathname)){
      const minerId=u.pathname.match(/\d+/)?.[0];
      const {data,error}=await sb.functions.invoke("nft-metadata-proxy",{body:{provider:"dao1-miner",miner_id:minerId}});
      if(error)throw error;
      const payload=data?.metadata??data;
      return payload&&typeof payload==="object"?payload:null;
    }
    const res=await fetch(url,{headers:{"Accept":"application/json"}});
    if(!res.ok)return null;
    const contentType=String(res.headers.get("content-type")||"").toLowerCase();
    if(contentType && !contentType.includes("json") && !contentType.includes("text/plain"))return null;
    const j=await res.json();
    return j&&typeof j==="object"?j:null;
  }catch(e){
    wtTrackNftMigrationIssue("external-metadata",url,e);
    console.warn("Externe NFT-Metadaten nicht abrufbar:",url,e);
    return null;
  }
}


const NFT_ACQUISITION_TX_HINTS={bsc:["0x36d8ea20beca0e24f8e61a6df7d1bcf6f8d873062d6984a3865f61fcf4cb6b71"]};
async function recoverNftAcquisitionFromTxHints(chain,address,nfts){
  const hints=NFT_ACQUISITION_TX_HINTS[chain]||[]; if(!hints.length)return new Map();
  const wanted=new Set((nfts||[]).map(n=>`${lowerAddressForNft(n.tokenAddress)}|${normalizeNftTransferTokenId(n.tokenId)}`));
  const out=new Map(),wallet=String(address||"").toLowerCase(),provider=new ethers.JsonRpcProvider(configuredRpcUrl(chain));
  const t721=ethers.id("Transfer(address,address,uint256)").toLowerCase(),t1=ethers.id("TransferSingle(address,address,address,uint256,uint256)").toLowerCase(),tb=ethers.id("TransferBatch(address,address,address,uint256[],uint256[])").toLowerCase();
  for(const hash of hints)try{
    const rc=await provider.getTransactionReceipt(hash); if(!rc)continue;
    const b=await provider.getBlock(rc.blockNumber),at=b?.timestamp?new Date(Number(b.timestamp)*1000).toISOString():null;
    for(const log of (rc.logs||[])){
      const c=lowerAddressForNft(log.address),tp=(log.topics||[]).map(x=>String(x).toLowerCase()); if(!c||!tp.length)continue;
      if(tp[0]===t721&&tp.length>=4){const to="0x"+tp[2].slice(-40),id=normalizeNftTransferTokenId(tp[3]),k=`${c}|${id}`;if(to.toLowerCase()===wallet&&wanted.has(k))out.set(k,{block:Number(rc.blockNumber),at,txHash:hash});}
      else if(tp[0]===t1&&tp.length>=4){const to="0x"+tp[3].slice(-40);if(to.toLowerCase()!==wallet)continue;const [id]=ethers.AbiCoder.defaultAbiCoder().decode(["uint256","uint256"],log.data),k=`${c}|${normalizeNftTransferTokenId(id)}`;if(wanted.has(k))out.set(k,{block:Number(rc.blockNumber),at,txHash:hash});}
      else if(tp[0]===tb&&tp.length>=4){const to="0x"+tp[3].slice(-40);if(to.toLowerCase()!==wallet)continue;const [ids]=ethers.AbiCoder.defaultAbiCoder().decode(["uint256[]","uint256[]"],log.data);for(const id of ids){const k=`${c}|${normalizeNftTransferTokenId(id)}`;if(wanted.has(k))out.set(k,{block:Number(rc.blockNumber),at,txHash:hash});}}
    }
  }catch(e){console.warn("NFT Erwerbs-TX-Hinweis nicht validierbar",hash,e);}
  return out;
}
async function enrichNftsWithAcquisitionData(chain,address,nfts,onProgress=null){
  if(!Array.isArray(nfts)||!nfts.length||chain==="apertum")return nfts;
  let transfers=[];
  try{
    transfers=await fetchIncomingNftTransfersForWallet(chain,address,onProgress);
  }catch(e){
    console.warn("NFT-Erwerbsdaten konnten nicht geladen werden",chain,address,e);
    return nfts;
  }
  const firstByKey=new Map();
  for(const t of transfers){
    const block=nftTransferBlock(t);
    const at=nftTransferTimestamp(t);
    for(const key of nftAcquisitionTransferKeys(t)){
      const old=firstByKey.get(key);
      if(!old || (block&&(!old.block||block<old.block))){
        firstByKey.set(key,{block:block||null,at,txHash:String(t?.hash||t?.transactionHash||t?.tx_hash||"")||null});
      }
    }
  }
  if(chain==="bsc"){
    let missing=nfts.filter(n=>!firstByKey.has(`${lowerAddressForNft(n.tokenAddress)}|${normalizeNftTransferTokenId(n.tokenId)}`));
    if(missing.length){
      try{
        const direct=await fetchBscNftAcquisitionByTokenIds(address,missing,p=>onProgress?.(`Token-ID ${p}`));
        for(const [k,v] of direct)if(!firstByKey.has(k))firstByKey.set(k,v);
      }catch(e){console.warn("BSC NFT Token-ID-Erwerbshistorie fehlgeschlagen",e);}
    }
    missing=nfts.filter(n=>!firstByKey.has(`${lowerAddressForNft(n.tokenAddress)}|${normalizeNftTransferTokenId(n.tokenId)}`));
    if(missing.length){
      try{
        const byAddress=await fetchBscNftAcquisitionByAddress(address,p=>onProgress?.(`Adresshistorie ${p}`));
        for(const t of byAddress){
          const block=nftTransferBlock(t),at=nftTransferTimestamp(t);
          for(const key of nftAcquisitionTransferKeys(t)){
            if(!firstByKey.has(key))firstByKey.set(key,{block:block||null,at,txHash:String(t?.hash||t?.transactionHash||"")||null});
          }
        }
      }catch(e){console.warn("BSC NFT Adress-Erwerbshistorie fehlgeschlagen",e);}
    }
  }
  if(chain==="bsc"){try{const hinted=await recoverNftAcquisitionFromTxHints(chain,address,nfts);for(const [k,v] of hinted){const old=firstByKey.get(k);if(!old||(v.block&&(!old.block||v.block<old.block)))firstByKey.set(k,v);}}catch(e){console.warn("BSC NFT TX-Hinweis-Fallback fehlgeschlagen",e);}}
  for(const n of nfts){
    const key=`${lowerAddressForNft(n.tokenAddress)}|${normalizeNftTransferTokenId(n.tokenId)}`;
    const hit=firstByKey.get(key);
    if(hit){
      n.acquiredAt=hit.at||n.acquiredAt||null;
      n.acquiredBlock=hit.block||n.acquiredBlock||null;
      n.acquisitionTxHash=hit.txHash||n.acquisitionTxHash||null;
      n.acquisitionSource="incoming-nft-transfer";
    }
  }
  return nfts;
}

async function runNftLoad() {
  const btn = document.getElementById("nftBtn");
  const status = document.getElementById("nftStatus");
  const walletId = document.getElementById("nftWalletSelect").value;

  if (activeNftChains.size === 0) { status.textContent = "Bitte mindestens eine Chain auswählen."; return; }

  const targetWallets = walletId === "all"
    ? wallets.filter(w => !!w.evm)
    : (wallets.find(x => String(x.id) === String(walletId) && x.evm)
        ? [wallets.find(x => String(x.id) === String(walletId))] : []);

  if (targetWallets.length === 0) { status.textContent = "Keine Wallet mit EVM-Adresse gefunden."; return; }

  btn.disabled = true;
  btn.textContent = "NFTs werden aktualisiert…";
  const errors = [];

  for (const w of targetWallets) {
    let walletNfts = [];
    for (const chain of nftChains().filter(c => activeNftChains.has(c))) {
      status.textContent = `Lade NFTs für ${w.label} auf ${CHAIN_META[chain].label}...`;
      try {
        const nftProvider = CHAIN_CONFIG[chain]?.nftProvider;
        let found;
        if (nftProvider === "blockscout") {
          found = await fetchApertumNfts(chain, w.evm, page => status.textContent = `Lade NFTs für ${w.label} auf ${CHAIN_META[chain].label}... (Seite ${page})`);
        } else if (nftProvider === "alchemy") {
          found = await fetchNftsForChain(chain, w.evm, page => status.textContent = `Lade NFTs für ${w.label} auf ${CHAIN_META[chain].label}... (Seite ${page})`);
        } else {
          throw new Error(`NFT-Provider "${nftProvider || "–"}" ist nicht implementiert`);
        }
        found.forEach(n => { n.walletLabel = w.label; n.walletId = String(w.dbId || w.id); });
        if(chain!=="apertum"){
          status.textContent=`Erwerbsdaten für ${w.label} auf ${CHAIN_META[chain].label} werden angereichert…`;
          await enrichNftsWithAcquisitionData(chain,w.evm,found,page=>status.textContent=`Erwerbsdaten für ${w.label} auf ${CHAIN_META[chain].label}… (Seite ${page})`);
        }

        // vorhandene manuelle Spam-Markierungen über Contract + Token-ID übernehmen
        const old = nftCaches.get(String(w.dbId || w.id));
        const oldMap = new Map(((old && old.nfts) || []).map(n => [nftKey(n), {
          spam:!!n.userMarkedSpam,
          safe:!!n.userMarkedSafe,
          acquiredAt:n.acquiredAt||null,
          acquiredBlock:n.acquiredBlock||null,
          acquisitionTxHash:n.acquisitionTxHash||null,
          acquisitionSource:n.acquisitionSource||null,
          image:n.image||null,
          imageSource:n.imageSource||null,
          metadataUri:n.metadataUri||null,
          metadataMethod:n.metadataMethod||null,
          name:n.name||null,
          collectionName:n.collectionName||null,
          purchaseEvidence:n.purchaseEvidence||null
        }]));
        found.forEach(n => {
          const flags=oldMap.get(nftKey(n));
          if(flags?.spam)n.userMarkedSpam=true;
          if(flags?.safe)n.userMarkedSafe=true;
          if(!n.acquiredAt&&flags?.acquiredAt)n.acquiredAt=flags.acquiredAt;
          if(!n.acquiredBlock&&flags?.acquiredBlock)n.acquiredBlock=flags.acquiredBlock;
          if(!n.acquisitionTxHash&&flags?.acquisitionTxHash)n.acquisitionTxHash=flags.acquisitionTxHash;
          if(!n.acquisitionSource&&flags?.acquisitionSource)n.acquisitionSource=flags.acquisitionSource;
          if(!n.image&&flags?.image)n.image=flags.image;
          if(!n.imageSource&&flags?.imageSource)n.imageSource=flags.imageSource;
          if(!n.metadataUri&&flags?.metadataUri)n.metadataUri=flags.metadataUri;
          if(!n.metadataMethod&&flags?.metadataMethod)n.metadataMethod=flags.metadataMethod;
          if(flags?.name)n.name=bestNftName(n.tokenId,n.collectionName||flags.collectionName,n.name,flags.name);
          if(!n.collectionName&&flags?.collectionName)n.collectionName=flags.collectionName;
          if(!n.purchaseEvidence&&flags?.purchaseEvidence)n.purchaseEvidence=flags.purchaseEvidence;
        });
        walletNfts = walletNfts.concat(found);
      } catch (e) {
        errors.push(`${w.label} / ${CHAIN_META[chain].label}: ${e.message}`);
      }
    }
    try {
      await saveNftCacheForWallet(w, walletNfts, [...activeNftChains]);
      await saveWalletRefreshState(w,'','nft',{last_checked_at:new Date().toISOString(),last_refreshed_at:new Date().toISOString(),last_result:'manual'});
      if(activeNftChains.has('apertum')&&window.DAO1Project?.repairNftOwnershipForWallet){
        status.textContent=`Apertum-Besitzhistorie für ${w.label} wird auf offene Lücken geprüft…`;
        const rr=await window.DAO1Project.repairNftOwnershipForWallet(w);
        if(rr?.failed)errors.push(`${w.label} / Apertum Besitzhistorie: ${rr.failed} NFT(s) nicht vollständig abrufbar`);
      }
    } catch(e) {
      errors.push(`${w.label}: ${e.message}`);
    }
  }

  lastNftFindings = cachedNftsForSelection();
  renderNftResults(lastNftFindings, errors);
  onNftWalletChange();
  status.textContent = errors.length ? "Aktualisierung mit Hinweisen abgeschlossen." : "NFTs aktualisiert und in Supabase gespeichert.";
  btn.disabled = false;
  btn.textContent = "NFTs jetzt aktualisieren";
}

async function setNftUserSpam(walletId, chain, tokenAddress, tokenId, marked) {
  const cache = nftCaches.get(String(walletId));
  if (!cache) return;
  const key = `${chain}|${normalizeAddress(tokenAddress || "", chain)}|${String(tokenId)}`;
  const updated = (cache.nfts || []).map(n =>
    nftKey(n) === key ? { ...n, userMarkedSpam: !!marked, userMarkedSafe: marked ? false : !!n.userMarkedSafe } : n
  );
  const { data, error } = await sb.from("nft_cache")
    .update({ nfts: sanitizeNftCacheValue(updated) })
    .eq("user_id", currentUser.id)
    .eq("wallet_id", String(walletId))
    .select().single();
  if (error) {
    alert("Spam-Markierung konnte nicht gespeichert werden: " + error.message);
    return;
  }
  nftCaches.set(String(walletId), data);
  lastNftFindings = cachedNftsForSelection();
  renderNftResults(lastNftFindings, []);
}


async function setNftUserSafe(walletId, chain, tokenAddress, tokenId, marked) {
  const cache=nftCaches.get(String(walletId));
  if(!cache)return;
  const key=`${chain}|${normalizeAddress(tokenAddress||"",chain)}|${String(tokenId)}`;
  const updated=(cache.nfts||[]).map(n =>
    nftKey(n)===key ? {...n,userMarkedSafe:!!marked,userMarkedSpam:marked?false:!!n.userMarkedSpam} : n
  );
  const {data,error}=await sb.from("nft_cache")
    .update({nfts:updated})
    .eq("user_id",currentUser.id)
    .eq("wallet_id",String(walletId))
    .select().single();
  if(error){
    alert("Spam-Ausnahme konnte nicht gespeichert werden: "+error.message);
    return;
  }
  nftCaches.set(String(walletId),data);
  lastNftFindings=cachedNftsForSelection();
  renderNftResults(lastNftFindings,[]);
}

function nftPurchaseText(n){
  const p=n?.purchaseEvidence?.purchase;
  if(Number(p?.amount||0)>0)return `${Number(p.amount).toLocaleString("de-CH",{maximumFractionDigits:8})} ${escapeAttr(p.symbol||"TOKEN")}`;
  if(["transfer_no_purchase_expected","mint_no_purchase_expected"].includes(n?.purchaseEvidence?.status))return "–";
  if(n?.purchaseEvidence?.checked)return "keine eindeutige Zahlung";
  return "Kaufpreis-Prüfung offen";
}

function centralNftPurchaseEvidenceKey(n,own=null){
  own=own||nftOwnershipInfo(n);
  const acquisitionWallet=normalizeAddress(own?.firstOwnedWalletAddress||nftWalletAddressById(own?.firstOwnedWalletId,n?.chain)||"",n?.chain||"apertum");
  return [
    acquisitionWallet||"",
    String(Number(own?.firstOwnedBlock||n?.acquiredBlock||0)||0),
    String((own?.acquisitionTxHash||n?.acquisitionTxHash||"").toLowerCase()),
    String(own?.acquisitionKind||"")
  ].join("|");
}

function centralNftPurchaseEvidenceIsCurrent(n){
  const ev=n?.purchaseEvidence||null;
  if(Number(ev?.resolverVersion||0)<3)return false;
  if(!ev?.status)return false;
  return String(ev?.inputEvidenceKey||"")===centralNftPurchaseEvidenceKey(n);
}

function centralNftPurchaseEvidenceNeedsRefresh({walletIds=null}={}){
  const walletScope=walletIds?new Set((Array.isArray(walletIds)?walletIds:[walletIds]).map(String)):null;
  for(const [walletId,row] of nftCaches){
    if(walletScope&&!walletScope.has(String(walletId)))continue;
    for(const n of (Array.isArray(row?.nfts)?row.nfts:[])){
      if(String(n?.chain||"")!=="apertum")continue;
      if(!centralNftPurchaseEvidenceIsCurrent(n))return true;
    }
  }
  return false;
}

async function enrichCentralNftPurchaseEvidence({force=false,walletIds=null}={}){
  if(!currentUser||!window.DAO1Project?.resolveNftPurchaseEvidence)return 0;
  let changed=0;
  const walletScope=walletIds?new Set((Array.isArray(walletIds)?walletIds:[walletIds]).map(String)):null;
  for(const [walletId,row] of nftCaches){
    if(walletScope&&!walletScope.has(String(walletId)))continue;
    const list=Array.isArray(row?.nfts)?row.nfts:[];let rowChanged=false;
    for(const n of list){
      if(String(n?.chain||"")!=="apertum")continue;
      // Alte 5.56-Negativbefunde ohne konkrete Erwerbs-Tx waren nicht belastbar und
      // werden in 5.58 automatisch erneut geprüft.
      const ev=n?.purchaseEvidence||null;
      const own=nftOwnershipInfo(n);
      // Resolver-v3 unterscheidet "Preis verifiziert" und "deterministisch noch offen".
      // Beides ist ein persistierbarer Cache-Stand. Ohne geänderte Erwerbs-Evidenz darf
      // ein bewusst offener Fall nicht bei jedem NFT-Tab-Einstieg erneut Netzrequests auslösen.
      if(!force&&centralNftPurchaseEvidenceIsCurrent(n))continue;
      const acquisitionWallet=own?.firstOwnedWalletAddress||nftWalletAddressById(own?.firstOwnedWalletId,n.chain);
      if(!acquisitionWallet)continue;
      try{
        const ev=await window.DAO1Project.resolveNftPurchaseEvidence({
          contract:n.tokenAddress,tokenId:n.tokenId,acquisitionWallet,
          acquiredAt:own?.firstOwnedAt||n.acquiredAt,acquiredBlock:own?.firstOwnedBlock||n.acquiredBlock,
          acquisitionTxHash:own?.acquisitionTxHash||n.acquisitionTxHash,acquisitionKind:own?.acquisitionKind||null
        });
        if(ev){n.purchaseEvidence={...ev,inputEvidenceKey:centralNftPurchaseEvidenceKey(n,own)};rowChanged=true;changed++;}
      }catch(e){console.warn("NFT Kaufpreis-Evidenz",n?.tokenId,e);}
    }
    if(rowChanged){
      const w=wallets.find(x=>String(x.dbId||x.id)===String(walletId));
      if(w)await saveNftCacheForWallet(w,list,row.selected_chains||[]);
    }
  }
  if(changed){lastNftFindings=cachedNftsForSelection();renderNftResults(lastNftFindings,[]);}
  return changed;
}


function nftDisplayType(n){
  try{
    const t=window.DAO1Project?.classifyNftType?.({
      chain:n?.chain,contract:n?.tokenAddress,id:n?.tokenId,name:n?.name,collection:n?.collectionName
    });
    if(t)return t;
  }catch(_){ }
  const label=`${n?.name||""} ${n?.collectionName||""}`.toLowerCase();
  if(/hearts?\s*nft|spark\s*of\s*change/.test(label))return "Hearts NFT";
  if(/trading[ _-]*bot|trade[ _-]*bot/.test(label))return "TradeBot";
  if(/mine[ _-]*bot|minebot|mining[ _-]*bot|apertum\s*miner/.test(label))return "MineBot";
  if(/\bdid\b/.test(label))return "DID";
  return "Sonstige";
}
function renderNftResults(nfts, errors = []) {
  const el = document.getElementById("nftResults");
  const errorNote = errors.length > 0 ? `<div class="error" style="margin-bottom:12px">Fehler bei: ${errors.join(", ")}</div>` : "";

  const oldToggle = document.getElementById("nftHideSpamToggle");
  const hideSpam = oldToggle ? oldToggle.checked : true;
  const typeFilter=document.getElementById("nftTypeFilter")?.value||"__all";
  const spamCount = nfts.filter(isNftSpam).length;
  const spamFiltered = hideSpam ? nfts.filter(n => !isNftSpam(n)) : nfts;
  const visibleRaw = typeFilter==="__all" ? spamFiltered : spamFiltered.filter(n=>nftDisplayType(n)===typeFilter);
  const visible=[...visibleRaw].sort((a,b)=>{
    const ao=nftOwnershipInfo(a),bo=nftOwnershipInfo(b);
    const at=ao?.firstOwnedAt?new Date(ao.firstOwnedAt).getTime():0;
    const bt=bo?.firstOwnedAt?new Date(bo.firstOwnedAt).getTime():0;
    if(bt!==at)return bt-at;
    const ab=Number(ao?.firstOwnedBlock||0),bb=Number(bo?.firstOwnedBlock||0);
    if(bb!==ab)return bb-ab;
    return String(a?.name||"").localeCompare(String(b?.name||""),"de");
  });

  const filterBar = `<div class="custom-token-card" style="margin-bottom:14px;display:flex;gap:14px;align-items:end;flex-wrap:wrap">
    <div style="min-width:190px"><span class="field-label">NFT-Typ</span><select id="nftTypeFilter" onchange="renderNftResults(lastNftFindings, [])">
      <option value="__all" ${typeFilter==="__all"?"selected":""}>Alle Typen</option>
      <option value="DID" ${typeFilter==="DID"?"selected":""}>DID</option>
      <option value="MineBot" ${typeFilter==="MineBot"?"selected":""}>MineBot</option>
      <option value="Hearts NFT" ${typeFilter==="Hearts NFT"?"selected":""}>Hearts NFT</option>
      <option value="TradeBot" ${typeFilter==="TradeBot"?"selected":""}>TradeBot</option>
    </select></div>
    <label style="display:flex;align-items:center;gap:8px;cursor:pointer;font-size:0.85rem;padding-bottom:8px">
      <input type="checkbox" id="nftHideSpamToggle" style="width:auto" onchange="renderNftResults(lastNftFindings, [])" ${hideSpam ? "checked" : ""} />
      Spam-verdächtige NFTs ausblenden (${spamCount} von ${nfts.length})
    </label>
  </div>`;

  if (nfts.length === 0) {
    el.innerHTML = errorNote + `<div class="empty">Keine gespeicherten NFTs für diese Auswahl vorhanden.</div>`;
    return;
  }
  if (visible.length === 0) {
    el.innerHTML = errorNote + filterBar + `<div class="empty">Alle gespeicherten NFTs sind als Spam-verdächtig markiert und ausgeblendet.</div>`;
    return;
  }

  const missingImages=visible.filter(n=>!n.image);
  const imageDebug=missingImages.length?`<div class="custom-token-card debug-frame" style="margin-bottom:14px">
    <strong>DEBUG / DEV · NFTs ohne Bild (${missingImages.length})</strong>
    <div class="note">Zeigt, ob eine Metadatenquelle/Token-URI gefunden wurde. DID-NFTs können absichtlich kein Bild besitzen.</div>
    <div class="chain-table-wrap" style="margin-top:8px;max-height:360px;overflow:auto"><table class="dao1-transaction-table"><thead><tr><th>NFT</th><th>Chain</th><th>Contract / ID</th><th>Bildquelle</th><th>URI-Methode</th><th>Metadata URI</th></tr></thead><tbody>
      ${missingImages.map(n=>`<tr><td>${escapeAttr(n.name||"NFT")}</td><td>${escapeAttr(n.chain||"")}</td><td><code>${escapeAttr(n.tokenAddress||"")}</code><br>#${escapeAttr(String(n.tokenId||""))}</td><td>${escapeAttr(n.imageSource||"keine Bildquelle gefunden")}</td><td>${escapeAttr(n.metadataMethod||"–")}</td><td><code>${escapeAttr(n.metadataUri||"–")}</code></td></tr>`).join("")}
    </tbody></table></div></div>`:"";

  el.innerHTML = `${errorNote}${filterBar}${imageDebug}
    <div class="custom-token-card" style="padding:0;overflow:hidden">
      <div style="display:flex;justify-content:space-between;align-items:center;gap:12px;padding:14px 16px;border-bottom:1px solid var(--border,#2b303b)">
        <div><strong>NFT-Bestand</strong><div class="meta">${visible.length} von ${nfts.length} NFT(s) angezeigt${typeFilter!=="__all"?` · Typ: ${escapeAttr(typeFilter)}`:""} · nach Erwerbsdatum sortiert · neuestes zuerst · On-Chain-Erwerbsdaten aus Cache/Besitzhistorie</div></div>
      </div>
      <div class="project-data-table nft-modern-table" style="margin:0;border:0;border-radius:0;max-height:720px">
        <table><thead><tr><th>Bild</th><th>NFT</th><th>Chain / Wallet</th><th>Erstmals von dir erworben</th><th>Kaufpreis</th><th>In diesem Wallet seit</th><th>Status</th><th>Aktionen</th></tr></thead><tbody>
        ${visible.map(n => {
          const meta = CHAIN_META[n.chain] || {dot:"",label:n.chain};
          const spam = isNftSpam(n);
          const own=nftOwnershipInfo(n);
          const firstOwned=own?.known
            ? nftOwnershipDate(own.firstOwnedAt)
            : "Besitzhistorie offen";
          const walletSince=own?.known?nftOwnershipDate(own.walletSinceAt):"Besitzhistorie offen";
          const firstWalletAddress=own?.firstOwnedWalletAddress||nftWalletAddressById(own?.firstOwnedWalletId,n.chain);
          const currentWalletAddress=nftWalletAddressById(own?.currentWalletId||n?.walletId||n?.wallet_id,n.chain)||n?.walletAddress||null;
          const statusParts=[];
          if(spam)statusParts.push(`<span class="badge unsafe">⚠ ${n.userMarkedSpam ? "Spam markiert" : "Spam-Verdacht"}</span>`);
          if(n.userMarkedSafe)statusParts.push(`<span class="badge safe">✓ Sicher</span>`);
          if(!statusParts.length)statusParts.push(`<span class="badge safe">✓ unauffällig</span>`);
          return `<tr>
            <td>${n.image?`<img class="nft-table-thumb" src="${escapeAttr(n.image)}" loading="lazy" onerror="this.style.display='none'">`:`<div class="nft-table-placeholder">Kein Bild</div>`}</td>
            <td><strong>${escapeAttr(n.name)}</strong><div class="meta">${n.collectionName?escapeAttr(n.collectionName)+" · ":""}#${escapeAttr(String(n.tokenId))}</div><div class="meta"><code>${escapeAttr(String(n.tokenAddress||""))}</code></div></td>
            <td><div style="display:flex;align-items:center;gap:5px"><span class="dot ${meta.dot}" style="width:7px;height:7px"></span><strong>${escapeAttr(meta.label||n.chain)}</strong></div><div class="meta">${escapeAttr(n.walletLabel||"")}</div></td>
            <td><strong>${firstOwned}</strong>${nftWalletAddressHtml(firstWalletAddress,"Kauf/Mint-Wallet")}${own?.firstOwnedBlock?`<div class="meta">Block ${Number(own.firstOwnedBlock).toLocaleString("de-CH")}</div>`:""}${own?.known?(own?.acquisitionVerified?`<div class="meta">${own.acquisitionKind==="purchase_same_tx"?"✓ Kauf on-chain belegt":"✓ Mint/Erwerb on-chain belegt"}</div>`:`<div class="meta">Nur Wallet-Eingang on-chain belegt</div>`):`<div class="meta">Transfer-/Ownership-Historie wird noch aufgebaut</div>`}${own?.acquisitionTxHash&&CHAIN_META[n.chain]?.explorer?`<div class="meta"><a href="${CHAIN_META[n.chain].explorer}/tx/${escapeAttr(own.acquisitionTxHash)}" target="_blank" rel="noopener">Erwerbs-TX</a></div>`:""}</td>
            <td><strong>${nftPurchaseText(n)}</strong>${n?.purchaseEvidence?.purchase?`<div class="meta">on-chain Zahlung</div>`:(n?.purchaseEvidence?.checked?`<div class="meta">geprüft · keine eindeutige Zahlung</div>`:"")}</td>
            <td><strong>${walletSince}</strong>${nftWalletAddressHtml(currentWalletAddress,"Aktuelles Wallet")}${own?.walletSinceBlock?`<div class="meta">Block ${Number(own.walletSinceBlock).toLocaleString("de-CH")}${own.currentInWallet?" · aktuell":""}</div>`:""}</td>
            <td>${statusParts.join("<br>")}</td>
            <td><div style="display:flex;gap:6px;flex-wrap:wrap">
              ${!n.userMarkedSafe ? `<button class="${n.userMarkedSpam ? "secondary" : "remove"}" style="padding:6px 8px;font-size:.72rem" onclick="setNftUserSpam('${escapeAttr(String(n.walletId || ""))}','${n.chain}','${escapeAttr(n.tokenAddress || "")}','${escapeAttr(String(n.tokenId))}',${n.userMarkedSpam ? "false" : "true"})">${n.userMarkedSpam ? "Spam entfernen" : "Als Spam markieren"}</button>` : ""}
              ${!n.userMarkedSpam ? `<button class="secondary" style="padding:6px 8px;font-size:.72rem" onclick="setNftUserSafe('${escapeAttr(String(n.walletId || ""))}','${n.chain}','${escapeAttr(n.tokenAddress || "")}','${escapeAttr(String(n.tokenId))}',${n.userMarkedSafe ? "false" : "true"})">${n.userMarkedSafe ? "Sicher entfernen" : "Als sicher klassifizieren"}</button>` : ""}
            </div></td>
          </tr>`;
        }).join("")}
        </tbody></table>
      </div>
    </div>`;
  window.applyDebugModeVisibility?.();
}

// ---- Chat (User <-> Admin) ----

const CHAT_NOTIFICATION_FUNCTION = "chat-notify";

function setChatUnreadBadge(id,count){
  const el=document.getElementById(id);
  if(!el)return;
  const n=Number(count||0);
  el.textContent=n>99?"99+":String(n);
  el.style.display=n>0?"inline-flex":"none";
}

async function updateChatUnreadBadge(){
  if(!currentUser)return;
  try{
    if(isAdmin){
      const {count,error}=await sb.from("chat_messages")
        .select("id",{count:"exact",head:true})
        .eq("sender_type","user")
        .is("read_at",null);
      if(error)throw error;
      setChatUnreadBadge("adminChatUnreadBadge",count||0);
    }else{
      const {count,error}=await sb.from("chat_messages")
        .select("id",{count:"exact",head:true})
        .eq("user_id",currentUser.id)
        .eq("sender_type","admin")
        .is("read_at",null);
      if(error)throw error;
      setChatUnreadBadge("userChatUnreadBadge",count||0);
    }
  }catch(e){
    console.warn("Chat-Ungelesen-Zähler:",e);
  }
}

async function markCurrentChatRead(userId=null){
  try{
    const {error}=await sb.rpc("mark_chat_read",{p_user_id:isAdmin?userId:currentUser.id});
    if(error)throw error;
    await updateChatUnreadBadge();
  }catch(e){
    console.warn("Chat als gelesen markieren:",e);
  }
}

async function triggerChatEmailNotification(messageId){
  if(!messageId)return;
  try{
    const {error}=await sb.functions.invoke(CHAT_NOTIFICATION_FUNCTION,{
      body:{message_id:messageId}
    });
    if(error)throw error;
  }catch(e){
    // Nachricht ist bereits gespeichert. Ein Mailfehler darf den Chat nicht blockieren.
    console.warn("Chat-E-Mail-Benachrichtigung konnte nicht ausgelöst werden:",e);
  }
}

// Realtime-Abo: läuft einmal pro Login, unabhängig davon, welcher Tab gerade offen ist -
// so kommt eine neue Nachricht auch an, wenn man den Chat-Tab gerade nicht anschaut.
let chatRealtimeChannel = null;

function setupChatRealtime() {
  if (chatRealtimeChannel) sb.removeChannel(chatRealtimeChannel); // altes Abo aufräumen, falls schon vorhanden

  if (isAdmin) {
    // Admins: auf ALLE neuen Nachrichten reagieren (kein Filter), da unklar ist, welcher
    // User als nächstes schreibt.
    chatRealtimeChannel = sb.channel("chat-admin-" + currentUser.id)
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "chat_messages" }, async (payload) => {
        await updateChatUnreadBadge();
        renderAdminChatUserSelect();
        const selectedUserId = document.getElementById("adminChatUserSelect") ? document.getElementById("adminChatUserSelect").value : "";
        if (selectedUserId && payload.new.user_id === selectedUserId) loadAdminChat();
      })
      .subscribe();
  } else {
    // Normale User: nur auf die eigene Konversation gefiltert (RLS würde ohnehin nichts
    // anderes durchlassen, aber der Filter spart unnötige Events).
    chatRealtimeChannel = sb.channel("chat-user-" + currentUser.id)
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "chat_messages", filter: `user_id=eq.${currentUser.id}` }, async () => {
        await updateChatUnreadBadge();
        const chatPanel=document.getElementById("tab-chat");
        if(chatPanel?.classList.contains("active")) loadOwnChat();
      })
      .subscribe();
  }
}

function renderChatBubble(msg, isOwnSide) {
  const isAdmin = msg.sender_type === "admin";
  const align = isOwnSide ? "flex-end" : "flex-start";
  const bg = isAdmin ? "var(--card2)" : "var(--accent)";
  const color = isAdmin ? "var(--text)" : "#fff";
  const dt = new Date(msg.created_at);
  const dtStr = dt.toLocaleDateString("de-CH") + ", " + dt.toLocaleTimeString("de-CH", { hour: "2-digit", minute: "2-digit" });
  return `<div style="align-self:${align};max-width:75%;">
    <div style="background:${bg};color:${color};padding:8px 12px;border-radius:12px;font-size:0.9rem;white-space:pre-wrap;word-break:break-word">${escapeAttr(msg.message)}</div>
    <div class="note" style="margin:2px 4px 0;font-size:0.68rem">${isAdmin ? "Support" : "Du"} · ${dtStr}</div>
  </div>`;
}

async function loadOwnChat() {
  const el = document.getElementById("chatMessagesContainer");
  const { data, error } = await sb.from("chat_messages").select("*").eq("user_id", currentUser.id).order("created_at", { ascending: true });
  if (error) { el.innerHTML = `<div class="error">Fehler beim Laden: ${error.message}</div>`; return; }
  if (!data || data.length === 0) {
    el.innerHTML = `<div class="empty">Noch keine Nachrichten - schreib uns gern etwas!</div>`;
  } else {
    el.innerHTML = data.map(m => renderChatBubble(m, m.sender_type === "user")).join("");
    el.scrollTop = el.scrollHeight;
  }
  await markCurrentChatRead();
}

async function sendChatMessage() {
  const input = document.getElementById("chatMessageInput");
  const text = input.value.trim();
  if (!text) return;
  const { data, error } = await sb.from("chat_messages").insert({
    user_id: currentUser.id,
    sender_type: "user",
    sender_email: currentUser.email,
    message: text
  }).select("id").single();
  if (error) { alert("Fehler beim Senden: " + error.message); return; }
  input.value = "";
  loadOwnChat();
  triggerChatEmailNotification(data?.id);
}

// ---- Chat: Admin-Seite ----
async function renderAdminChatUserSelect() {
  const el = document.getElementById("adminChatUserSelect");
  const current = el.value;
  const { data, error } = await sb.from("chat_messages").select("user_id, sender_email, sender_type, read_at").eq("sender_type", "user");
  if (error) { console.error(error); return; }
  const users = {};
  (data || []).forEach(r => {
    if(!users[r.user_id]) users[r.user_id]={email:r.sender_email||r.user_id,unread:0};
    if(!r.read_at) users[r.user_id].unread++;
  });
  el.innerHTML = `<option value="">– auswählen –</option>` +
    Object.entries(users).map(([uid, info]) => `<option value="${uid}">${escapeAttr(info.email)}${info.unread?` (${info.unread})`:""}</option>`).join("");
  if (Object.keys(users).some(uid => uid === current)) el.value = current;
  await updateChatUnreadBadge();
}

async function loadAdminChat() {
  const userId = document.getElementById("adminChatUserSelect").value;
  const el = document.getElementById("adminChatMessagesContainer");
  const inputRow = document.getElementById("adminChatInputRow");
  if (!userId) { el.innerHTML = ""; inputRow.style.display = "none"; return; }

  const { data, error } = await sb.from("chat_messages").select("*").eq("user_id", userId).order("created_at", { ascending: true });
  if (error) { el.innerHTML = `<div class="error">Fehler beim Laden: ${error.message}</div>`; return; }
  el.innerHTML = (data || []).map(m => renderChatBubble(m, m.sender_type === "admin")).join("") || `<div class="empty">Noch keine Nachrichten.</div>`;
  el.scrollTop = el.scrollHeight;
  inputRow.style.display = "flex";
  await markCurrentChatRead(userId);
  await renderAdminChatUserSelect();
}

async function sendAdminChatMessage() {
  const userId = document.getElementById("adminChatUserSelect").value;
  if (!userId) return;
  const input = document.getElementById("adminChatMessageInput");
  const text = input.value.trim();
  if (!text) return;
  const { data, error } = await sb.from("chat_messages").insert({
    user_id: userId,
    sender_type: "admin",
    sender_email: currentUser.email,
    message: text
  }).select("id").single();
  if (error) { alert("Fehler beim Senden: " + error.message); return; }
  input.value = "";
  loadAdminChat();
  triggerChatEmailNotification(data?.id);
}

async function calculateFeesForWallet(w, status, results) {
  await loadFeeCacheForWallet(w.id);
  for (const chain of feeChains().filter(c => activeFeesChains.has(c))) {
    if (status) status.textContent=`Berechne Gebühren für ${w.label} auf ${CHAIN_META[chain].label}...`;
    const onProgress=page=>{if(status)status.textContent=`Berechne Gebühren für ${w.label} auf ${CHAIN_META[chain].label}... (Seite ${page})`;};

    try {
      const cfg = CHAIN_CONFIG[chain] || {};
      const provider = cfg.feeProvider;

      let r;
      if (cfg.walletType === "evm" && ["routescan","nodereal","blockscout"].includes(provider)) {
        if (!w.evm) { results.push({chain,error:"Keine EVM-Adresse bei dieser Wallet erfasst"}); continue; }
        r = await scanCachedEvmFees(chain,w,onProgress);
      } else {
        const cache=feeCaches.get(feeCacheKey(w.id,chain))||null;
        if(!feeScanAllowed(cache)){
          const next=feeNextAllowedDate(cache);
          r={totalFee:Number(cache.total_fee_native||0),txCount:Number(cache.tx_count||0),cached:true,cachedAt:cache.last_scanned_at,source:cache.data_source,note:`Nächste Aktualisierung ab ${next.toLocaleString("de-CH")}`};
        } else if(provider==="mempool"){
          if(!w.btc){results.push({chain,error:"Keine Bitcoin-Adresse bei dieser Wallet erfasst"});continue;}
          r=await fetchBitcoinFees(chain,w.btc,onProgress);
        } else if(provider==="tronscan"){
          if(!w.tron){results.push({chain,error:"Keine TRON-Adresse bei dieser Wallet erfasst"});continue;}
          r=await fetchTronFees(chain,w.tron,onProgress);
        } else if(provider==="xrpscan"){
          if(!w.xrp){results.push({chain,error:"Keine XRP-Adresse bei dieser Wallet erfasst"});continue;}
          r=await fetchXrpFees(chain,w.xrp,onProgress);
        } else if(provider==="solana_publicnode"){
          if(!w.sol){results.push({chain,error:"Keine Solana-Adresse bei dieser Wallet erfasst"});continue;}
          r=await fetchSolanaFees(chain,w.sol,onProgress);
        } else if(provider==="apertum_explorer"){
          if(!w.evm){results.push({chain,error:"Keine EVM-Adresse bei dieser Wallet erfasst"});continue;}
          r=await fetchApertumFees(chain,w.evm,onProgress);
        } else {
          results.push({chain,error:`Gebührenprovider "${provider||"–"}" ist nicht implementiert`});
          continue;
        }

        if(!r.cached){
          const saved=await upsertFeeCache(w.id,chain,decimalStringToWei(r.totalFee),Number(r.txCount||0),null,r.source||provider||"direkte API");
          r.cachedAt=saved.last_scanned_at;
        }
      }
      results.push({chain,...r});
    } catch(e) {
      results.push({chain,error:e.message});
    }
  }
}
async function runFeesCalculation() {
  const btn=document.getElementById("feesBtn"),status=document.getElementById("feesStatus"),resultsEl=document.getElementById("feesResults");
  const walletId=document.getElementById("feesWalletSelect").value;
  if(!walletId){status.textContent="Bitte zuerst eine Wallet auswählen.";return;}
  if(activeFeesChains.size===0){status.textContent="Bitte mindestens eine Chain auswählen.";return;}
  const w=wallets.find(x=>String(x.id)===String(walletId));if(!w){status.textContent="Wallet nicht gefunden.";return;}
  btn.disabled=true;resultsEl.innerHTML="";const results=[];
  try{
    await calculateFeesForWallet(w,status,results);
    renderFeesResults(w,results); status.textContent="Fertig.";
    await renderFeesSummary();
    const info=document.getElementById("feesCacheInfo");if(info)info.textContent=isAdmin?"Admin: Aktualisierung ohne 30-Tage-Sperre.":"Gebührenstand gespeichert. Eine erneute Aktualisierung ist für normale Benutzer nach 30 Tagen möglich.";
  }finally{btn.disabled=false;}
}

async function runAllFeesCalculation(){
  const btn=document.getElementById("feesAllBtn"),single=document.getElementById("feesBtn"),status=document.getElementById("feesStatus"),resultsEl=document.getElementById("feesResults");
  if(activeFeesChains.size===0){status.textContent="Bitte mindestens eine Chain auswählen.";return;}
  btn.disabled=true;single.disabled=true;resultsEl.innerHTML="";
  try{
    for(let i=0;i<wallets.length;i++){
      const w=wallets[i],results=[];
      status.textContent=`Wallet ${i+1}/${wallets.length}: ${w.label}...`;
      await calculateFeesForWallet(w,status,results);
      if(String(document.getElementById("feesWalletSelect").value)===String(w.id)) renderFeesResults(w,results);
      await renderFeesSummary();
      if(i<wallets.length-1) await sleepMs(250);
    }
    status.textContent=`Fertig. ${wallets.length} Wallet${wallets.length===1?"":"s"} geprüft.`;
  }finally{btn.disabled=false;single.disabled=false;}
}

function renderFeesResults(wallet,results){
  const el=document.getElementById("feesResults");
  if(!results||results.length===0){el.innerHTML="";return;}
  if(results.every(r=>r.error)){el.innerHTML=`<div class="error">Alle Abfragen sind fehlgeschlagen. Bitte später nochmal versuchen.</div>`;return;}
  el.innerHTML=`<div class="custom-token-card"><h3 style="margin:0 0 10px">${escapeAttr(wallet.label)} — Gebühren-Total</h3>
    <table><thead><tr><th>Chain</th><th style="text-align:right">Anzahl Tx</th><th style="text-align:right">Gebühren (nativ)</th><th style="text-align:right">Aktueller Coin-Kurs</th><th>Quelle / Stand</th></tr></thead><tbody>
    ${results.map(r=>{
      if(r.error)return `<tr><td><span class="dot" style="background:${escapeAttr(CHAIN_CONFIG[CHAIN_META[r.chain].dot]?.displayColor || "#6b7280")}"></span> ${CHAIN_META[r.chain].label}</td><td colspan="4" class="error" style="text-align:left">Fehler: ${escapeAttr(r.error)}</td></tr>`;
      const nativeSym=NATIVE_SYMBOL[r.chain]||r.chain.toUpperCase(), source=r.source||"bisherige API", when=r.cachedAt?new Date(r.cachedAt).toLocaleString("de-CH"):"live", price=currentGasCoinPrice(r.chain);
      return `<tr><td><span class="dot" style="background:${escapeAttr(CHAIN_CONFIG[CHAIN_META[r.chain].dot]?.displayColor || "#6b7280")}"></span> ${CHAIN_META[r.chain].label}${r.truncated?' <span class="badge unsafe">gekürzt</span>':''}${r.cached?' <span class="badge safe">Cache</span>':''}</td><td class="num">${r.txCount}</td><td class="num">${fmt(r.totalFee)} ${nativeSym}</td><td class="num">${formatUsdPrice(price)}</td><td><span class="note">${escapeAttr(source)} · ${escapeAttr(when)}${r.note?'<br>'+escapeAttr(r.note):''}</span></td></tr>`;
    }).join("")}</tbody></table>
    <div class="note" style="margin-top:10px">Phase 1: Es werden nur die tatsächlich bezahlten Netzwerkgebühren im nativen Coin angezeigt. Der aktuelle Coin-Kurs ist lediglich ein Anhaltspunkt; für die spätere historische USD-Bewertung wird der jeweilige Kurs zum Transaktionszeitpunkt benötigt. ${isAdmin?"Admins können jederzeit aktualisieren.":`Eine erneute Gebührenabfrage ist nach ${FEE_COOLDOWN_DAYS} Tagen möglich.`}</div></div>`;
}

function renderDiscoveryWalletSelect() {
  const el = document.getElementById("discoveryWalletSelect");
  if (!el) return;
  const current = el.value;
  el.innerHTML = `<option value="">– Wallet wählen –</option>` +
    wallets.map(w => `<option value="${w.id}">${escapeAttr(w.label)}</option>`).join("");
  if (wallets.some(w => w.id === current)) el.value = current;
}

// Erkennt typische Phishing-/Airdrop-Scam-Muster im Token-Namen oder -Symbol
// (z.B. "Visit claim-rewards.xyz", "$1000 USDT Bonus" o.ä.) - eine der häufigsten
// Betrugsmaschen bei unaufgeforderten Token-Airdrops. Läuft zusätzlich zur GoPlus-Prüfung.
function isLikelyScamName(text) {
  if (!text) return false;
  return /https?:\/\/|www\.|\.(com|io|net|org|xyz|app|finance|claim|airdrop|site|click|link|gift|bonus|vip|top)\b|visit |claim now|reward|bonus|voucher/i.test(text);
}

// Alchemy Token API: liest alle ERC20-Bestände einer Wallet auf der gewählten Chain.
// Die Scam-Einschätzung erfolgt weiterhin über Namens-Heuristik + GoPlus; Moralis-spezifische
// possible_spam-Daten gibt es hier nicht mehr.
async function discoverEvmTokens(chain, address) {
  const result = await alchemyRpc(chain, "alchemy_getTokenBalances", [address, "erc20"]);
  const balances = (result && result.tokenBalances) || [];
  const nonZero = balances; // aktuelle 0-Bestände bleiben Kandidaten; Historie ergänzt weitere Contracts.

  const known = new Set(
    (SAFE_ADDRESSES[chain] || []).concat(customSafeTokens.filter(t => t.chain === chain).map(t => t.address))
  );
  const unknown = nonZero.filter(t => t.contractAddress && !known.has(t.contractAddress.toLowerCase()));

  // Metadaten gebündelt in Alchemy laden.
  const metas = await alchemyRpcBatch(chain, unknown.map(t => ({ method: "alchemy_getTokenMetadata", params: [t.contractAddress] })));
  const found = [];
  unknown.forEach((t, i) => {
    const addr = t.contractAddress.toLowerCase();
    const meta = metas[i] && !metas[i].__error ? metas[i] : {};
    const decimals = Number.isFinite(Number(meta.decimals)) ? Number(meta.decimals) : 18;
    let raw;
    try { raw = BigInt(t.tokenBalance || "0x0"); } catch (e) { return; }
    const amount = Number(raw) / Math.pow(10, decimals);
    if (!isFinite(amount) || amount < 0) return;
    const nameScamFlag = isLikelyScamName(meta.symbol) || isLikelyScamName(meta.name);
    found.push({
      chain, address: addr,
      symbol: meta.symbol || (addr.slice(0, 8) + "…"),
      name: meta.name,
      amount,
      nameScamFlag,
      alchemySpam: false,
      historical: amount < DUST_THRESHOLD
    });
  });
  return found;
}

// GoPlus Security: kostenlose Risiko-Einschätzung für EVM-Token (kein Key nötig).
// Kein hartes Urteil, nur Signale - Apertum/Tron werden von GoPlus nicht abgedeckt.

async function checkGoPlusRisk(chain, addresses) {
  const chainId = CHAIN_CONFIG[chain]?.evmChainId ? String(CHAIN_CONFIG[chain].evmChainId) : null;
  if (!chainId || addresses.length === 0) return {};
  try {
    const res = await fetch(`https://api.gopluslabs.io/api/v1/token_security/${chainId}?contract_addresses=${addresses.join(",")}`);
    if (!res.ok) return {};
    const data = await res.json();
    return data.result || {};
  } catch (e) {
    return {};
  }
}

function riskFlags(info) {
  if (!info) return [];
  const flags = [];
  if (info.is_honeypot === "1") flags.push("Honeypot");
  if (info.is_blacklisted === "1") flags.push("gelistet als bösartig");
  if (info.cannot_sell_all === "1") flags.push("evtl. nicht verkaufbar");
  if (info.is_mintable === "1") flags.push("beliebig nachprägbar");
  if (info.is_open_source === "0") flags.push("Contract nicht verifiziert");
  return flags;
}


// ---- Discovery-Cache (Supabase): Nicht-Admins max. 1 Scan pro Wallet alle 30 Tage; Admins ohne Sperre ----
const DISCOVERY_COOLDOWN_DAYS = 30;
let discoveryCaches = new Map(); // wallet_id -> Cache-Zeile
let discoveryCache = null;       // Cache der aktuell ausgewählten Wallet
let discoveryCacheLoaded = false;
let discoveryCacheLoadPromise = null;

function ensureDiscoveryCacheLoaded() {
  if (discoveryCacheLoaded) return Promise.resolve(discoveryCaches);
  if (!discoveryCacheLoadPromise) discoveryCacheLoadPromise = loadDiscoveryCacheFromDb().finally(()=>{ discoveryCacheLoadPromise = null; });
  return discoveryCacheLoadPromise;
}

function currentDiscoveryWalletId() {
  const select = document.getElementById("discoveryWalletSelect");
  return select ? String(select.value || "") : "";
}

function getDiscoveryCacheForWallet(walletId) {
  if (!walletId) return null;
  return discoveryCaches.get(String(walletId)) || null;
}

function discoveryNextAllowedDate(cache = discoveryCache) {
  if (!cache || !cache.next_scan_at) return null;
  const d = new Date(cache.next_scan_at);
  return isNaN(d.getTime()) ? null : d;
}

function discoveryScanAllowed(cache = discoveryCache) {
  if (isAdmin) return true;
  const next = discoveryNextAllowedDate(cache);
  return !next || Date.now() >= next.getTime();
}

function formatDiscoveryDate(iso) {
  if (!iso) return "–";
  const d = new Date(iso);
  if (isNaN(d.getTime())) return "–";
  return d.toLocaleDateString("de-CH") + ", " + d.toLocaleTimeString("de-CH", { hour: "2-digit", minute: "2-digit" });
}

async function loadDiscoveryCacheFromDb() {
  if (!currentUser) return;
  const { data, error } = await sb
    .from("discovery_cache")
    .select("*")
    .eq("user_id", currentUser.id)
    .order("scanned_at", { ascending: false });

  if (error) {
    console.error("Discovery-Cache:", error);
    discoveryCaches = new Map();
    discoveryCache = null;
    renderDiscoveryCacheState("Discovery-Cache konnte nicht geladen werden.");
    return;
  }

  discoveryCaches = new Map();
  (data || []).forEach(row => {
    if (row.wallet_id !== null && row.wallet_id !== undefined) {
      discoveryCaches.set(String(row.wallet_id), row);
    }
  });

  discoveryCacheLoaded = true;
  onDiscoveryWalletChange();
  return discoveryCaches;
}

function onDiscoveryWalletChange() {
  const walletId = currentDiscoveryWalletId();
  discoveryCache = getDiscoveryCacheForWallet(walletId);

  if (discoveryCache) {
    lastDiscoveryFindings = Array.isArray(discoveryCache.findings) ? discoveryCache.findings : [];
    // Chain-Auswahl ist eine Scan-Einstellung, kein Bestandteil des gespeicherten Ergebnisses.
    // Jeder neue Seiten-/Wallet-Aufruf startet mit allen aktuell aktivierten Discovery-Chains.
    activeDiscoveryChains = new Set(discoveryChains());
    renderDiscoveryChainFilter();
  } else {
    lastDiscoveryFindings = [];
  }

  renderDiscoveryCacheState();
  renderDiscoveryResults(lastDiscoveryFindings);
}

function renderDiscoveryCacheState(extraMessage) {
  const btn = document.getElementById("discoveryBtn");
  const info = document.getElementById("discoveryCacheInfo");
  if (!btn || !info) return;

  const walletId = currentDiscoveryWalletId();
  if (!walletId) {
    btn.disabled = false;
    btn.textContent = "Scan starten";
    info.textContent = extraMessage || "Bitte zuerst eine Wallet auswählen.";
    return;
  }

  discoveryCache = getDiscoveryCacheForWallet(walletId);
  if (!discoveryCache) {
    btn.disabled = false;
    btn.textContent = "Scan starten";
    info.textContent = extraMessage || "Für diese Wallet gibt es noch keinen gespeicherten Discovery-Scan.";
    return;
  }

  const allowed = discoveryScanAllowed(discoveryCache);
  const scanned = formatDiscoveryDate(discoveryCache.scanned_at);
  const next = formatDiscoveryDate(discoveryCache.next_scan_at);
  const walletText = discoveryCache.wallet_label ? ` · Wallet: ${discoveryCache.wallet_label}` : "";

  btn.disabled = !allowed;
  btn.textContent = allowed ? "Discovery aktualisieren" : "Scan noch gesperrt";
  info.textContent = extraMessage ||
    (isAdmin
      ? `Gespeicherter Scan: ${scanned}${walletText}. Admin: Aktualisierung ohne 30-Tage-Sperre.`
      : `Gespeicherter Scan: ${scanned}${walletText}. ${allowed ? "Ein neuer Scan ist jetzt möglich." : `Nächster Scan ab ${next}.`}`);
}

async function saveDiscoveryCache(w, findings, scanNotes) {
  const scannedAt = new Date();
  const nextAt = new Date(scannedAt.getTime() + DISCOVERY_COOLDOWN_DAYS * 24 * 60 * 60 * 1000);
  const walletId = persistedWalletDbId(w,{required:true,context:"Discovery-Cache"});

  const payload = {
    user_id: currentUser.id,
    wallet_id: walletId,
    wallet_label: w.label,
    selected_chains: [...activeDiscoveryChains],
    findings,
    scan_notes: scanNotes || [],
    scanned_at: scannedAt.toISOString(),
    next_scan_at: nextAt.toISOString()
  };

  const { data, error } = await sb
    .from("discovery_cache")
    .upsert(payload, { onConflict: "user_id,wallet_id" })
    .select()
    .single();

  if (error) {
    const adminHint = isAdmin && /erst wieder ab|cooldown|30[- ]?tage/i.test(String(error.message || ""))
      ? " (Admin-Cooldown-Bypass in Supabase noch nicht aktiv; Migration 031 ausführen.)"
      : "";
    throw new Error("Discovery-Ergebnis konnte nicht gespeichert werden: " + error.message + adminHint);
  }

  discoveryCaches.set(walletId, data);
  discoveryCache = data;
  renderDiscoveryCacheState();
}

async function runDiscoveryScan() {
  const btn = document.getElementById("discoveryBtn");
  const status = document.getElementById("discoveryStatus");
  const resultsEl = document.getElementById("discoveryResults");
  const walletId = document.getElementById("discoveryWalletSelect").value;

  if (!walletId) {
    status.textContent = "Bitte zuerst eine Wallet auswählen.";
    return;
  }
  if (activeDiscoveryChains.size === 0) {
    status.textContent = "Bitte mindestens eine Chain auswählen.";
    return;
  }

  const w = wallets.find(x => x.id === walletId);
  if (!w) { status.textContent = "Wallet nicht gefunden."; return; }

  btn.disabled = true;
  resultsEl.innerHTML = "";

  const allFindings = []; // {walletLabel, chain, address, symbol, name, amount, risk: [] | null, nameScamFlag}
  const scanNotes = [];

  // Chains mit discovery_provider=wallet_data: volle Tokenliste liegt bereits im normalen Wallet-Load vor.
  discoveryChains().filter(c => activeDiscoveryChains.has(c) && CHAIN_CONFIG[c]?.discoveryProvider === "wallet_data").forEach(chain => {
    const cd = (walletData[w.id] || {})[chain];
    if (!cd || cd.error) return;
    (cd.tokens || []).forEach(t => {
      if (!isSafeTokenAddress(t.address, chain) && t.amount >= DUST_THRESHOLD) {
        const nameScamFlag = isLikelyScamName(t.symbol) || isLikelyScamName(t.name);
        allFindings.push({ walletLabel: w.label, chain, address: t.address, symbol: t.symbol, name: t.name, amount: t.amount, risk: null, nameScamFlag });
      }
    });
  });

  // EVM-Chains: Alchemy Token API pro Chain
  if (w.evm) {
    for (const chain of discoveryChains().filter(c => activeDiscoveryChains.has(c) && CHAIN_CONFIG[c]?.discoveryProvider === "alchemy")) {
      status.textContent = `Durchsuche ${w.label} auf ${CHAIN_META[chain].label}...`;
      try {
        const found = await discoverEvmTokens(chain, w.evm);
        found.forEach(f => allFindings.push({ walletLabel: w.label, ...f, risk: null }));
      } catch (e) {
        scanNotes.push(`${CHAIN_META[chain].label}: Scan fehlgeschlagen (${e.message}).`);
      }
    }
  }

  // Historische Kandidaten + generische V2-LP-Erkennung.
  if(w.evm){
    for(const chain of discoveryChains().filter(c=>activeDiscoveryChains.has(c) && CHAIN_CONFIG[c]?.evmChainId)){
      try{
        const hist=await historicalErc20Candidates(chain,w.evm,null);
        const unknown=hist.filter(a=>!isSafeTokenAddress(a,chain));
        const metas=await fetchEvmTokenMetadata(chain,unknown);
        const knownFinding=new Set(allFindings.filter(f=>f.chain===chain).map(f=>f.address.toLowerCase()));
        for(const a of unknown){if(knownFinding.has(a))continue;const k=chain+"|"+a,m=metas[a]||tokenMetaCache[k]||{};allFindings.push({walletLabel:w.label,chain,address:a,symbol:predefinedTokenSymbols[k]||m.symbol||a.slice(0,8)+"…",name:predefinedTokenNames[k]||m.name||null,decimals:predefinedTokenDecimals[k]??m.decimals,amount:0,risk:null,nameScamFlag:false,historical:true});}
      }catch(e){scanNotes.push(`${CHAIN_META[chain]?.label||chain}: historische Kandidaten unvollständig (${e.message}).`);}
    }
    if(window.WalletLPEngine){for(const f of allFindings){if(!CHAIN_CONFIG[f.chain]?.evmChainId)continue;try{const p=await window.WalletLPEngine.pairInfo(f.chain,f.address);if(p){f.isLp=true;f.lpLabel=window.WalletLPEngine.label(f.chain);f.symbol=`${f.lpLabel} ${p.t0.symbol}/${p.t1.symbol}`;f.name=`${p.t0.symbol}/${p.t1.symbol} Liquidity Pool`;}}catch{}}}
  }

  // GoPlus-Risiko-Check, gebündelt pro Chain
  status.textContent = "Prüfe Risiko-Signale...";
  const byChain = {};
  allFindings.forEach(f => {
    if (!CHAIN_CONFIG[f.chain]?.evmChainId) return;
    byChain[f.chain] = byChain[f.chain] || new Set();
    byChain[f.chain].add(f.address);
  });
  for (const chain of Object.keys(byChain)) {
    const addrs = [...byChain[chain]];
    const result = await checkGoPlusRisk(chain, addrs);
    allFindings.forEach(f => {
      if (f.chain === chain && result[f.address.toLowerCase()]) {
        f.risk = riskFlags(result[f.address.toLowerCase()]);
      }
    });
  }

  lastDiscoveryFindings = allFindings;
  renderDiscoveryResults(allFindings);
  const scamCount = allFindings.filter(f => isFindingScam(f)).length;
  let statusText = `Fertig. ${allFindings.length} unbekannte(r) Token gefunden` + (scamCount > 0 ? `, davon ${scamCount} als möglicher Scam markiert.` : ".");
  if (scanNotes.length > 0) statusText += " Hinweis: " + scanNotes.join(" ");

  try {
    await saveDiscoveryCache(w, allFindings, scanNotes);
    statusText += " Ergebnis in Supabase gespeichert.";
  } catch (e) {
    console.error(e);
    statusText += " Achtung: " + e.message;
  }

  status.textContent = statusText;
  renderDiscoveryCacheState();
}

// Fasst GoPlus-Risiko-Flags + Namens-Heuristik zu einer einzigen Scam-Einschätzung zusammen
function isFindingScamSuspect(f) {
  if (f.nameScamFlag) return true;
  if (f.risk && f.risk.length > 0) return true;
  return false;
}
function isFindingScam(f) { return !!f.userMarkedScam || isFindingScamSuspect(f); }

window.historicalErc20Candidates = historicalErc20Candidates;
let lastDiscoveryFindings = [];
let discoveryHideSuspect = false;
let discoveryHideMarkedScam = true;

function renderDiscoveryResults(findings) {
  const el = document.getElementById("discoveryResults");
  if (findings.length === 0) {
    el.innerHTML = `<div class="empty">Keine unbekannten Token gefunden - alles, was deine Wallets halten, steht bereits auf der sicheren Liste (oder es gibt nichts Nennenswertes).</div>`;
    return;
  }

  const suspectEl=document.getElementById("hideScamSuspectToggle"), markedEl=document.getElementById("hideMarkedScamToggle");
  if(suspectEl) discoveryHideSuspect=suspectEl.checked;
  if(markedEl) discoveryHideMarkedScam=markedEl.checked;
  const visible = findings.filter(f => !(discoveryHideMarkedScam && f.userMarkedScam) && !(discoveryHideSuspect && isFindingScamSuspect(f)));
  const suspectCount=findings.filter(f=>isFindingScamSuspect(f)).length, markedCount=findings.filter(f=>f.userMarkedScam).length;
  const filterBar = `<div class="custom-token-card" style="margin-bottom:14px;display:flex;gap:22px;flex-wrap:wrap;align-items:center">
    ${suspectCount?`<button class="remove" onclick="markAllDiscoverySuspectsAsSpam()">Alle Spam-Verdachte als Spam markieren</button>`:""}
    <label style="display:flex;align-items:center;gap:8px;cursor:pointer;font-size:0.85rem">
      <input type="checkbox" id="hideScamSuspectToggle" style="width:auto" onchange="discoveryHideSuspect=this.checked;renderDiscoveryResults(lastDiscoveryFindings)" ${discoveryHideSuspect ? "checked" : ""} />
      Spam-Verdacht ausblenden (${suspectCount} von ${findings.length})
    </label>
    <label style="display:flex;align-items:center;gap:8px;cursor:pointer;font-size:0.85rem">
      <input type="checkbox" id="hideMarkedScamToggle" style="width:auto" onchange="discoveryHideMarkedScam=this.checked;renderDiscoveryResults(lastDiscoveryFindings)" ${discoveryHideMarkedScam ? "checked" : ""} />
      Als Spam markierte ausblenden (${markedCount} von ${findings.length})
    </label>
  </div>`;

  if (visible.length === 0) {
    el.innerHTML = filterBar + `<div class="empty">Alle gefundenen Token werden durch die aktiven Spam-Filter ausgeblendet.</div>`;
    return;
  }

  el.innerHTML = filterBar + visible.map(f => {
    const meta = CHAIN_META[f.chain];
    const scam = isFindingScam(f);
    let riskHtml = "";
    if (scam) {
      const reasons = [];
      if (f.userMarkedScam) reasons.push("vom Benutzer als Spam markiert");
      if (f.nameScamFlag) reasons.push("verdächtiger Name/Symbol (Phishing-Muster)");
      if (f.risk && f.risk.length > 0) reasons.push(...f.risk);
      riskHtml = `<span class="badge unsafe" style="background:rgba(255,107,107,0.18);color:var(--danger);font-weight:700">⚠ SPAM-VERDACHT: ${reasons.join(", ")}</span>`;
    } else if (f.risk === null) {
      riskHtml = `<span class="badge unsafe">kein Risiko-Check verfügbar</span>`;
    } else {
      riskHtml = `<span class="badge safe">keine Warnung</span>`;
    }
    return `<div class="custom-token-row" style="align-items:flex-start;${scam ? 'border-color:var(--danger)' : ''}">
      <div>
        <div><span class="dot" style="margin-right:6px;background:${escapeAttr(CHAIN_CONFIG[f.chain]?.displayColor || "#6b7280")}"></span>${escapeAttr(f.symbol)}${f.name && f.name !== f.symbol ? ' <span class="note" style="display:inline">(' + escapeAttr(f.name) + ')</span>' : ''} · ${f.historical && Number(f.amount)<DUST_THRESHOLD ? '<span class="badge">historisch gehalten</span>' : fmt(f.amount,{chain:f.chain,address:f.address,symbol:f.symbol})} · <span class="note" style="display:inline">${escapeAttr(f.walletLabel)}</span></div>
        <div class="meta">${meta.label} · ${f.address}</div>
        <div style="margin-top:6px">${riskHtml}</div>
      </div>
      <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
        ${scam && f.userMarkedScam
          ? `<button class="secondary" onclick="setDiscoveryUserScam('${f.chain}','${f.address}',false)">Spam-Markierung entfernen</button>`
          : `<button class="remove" onclick="setDiscoveryUserScam('${f.chain}','${f.address}',true)">Als Spam markieren</button>`}
        ${!f.userMarkedScam ? `<button onclick="addDiscoveredToken('${f.chain}','${f.address}','${escapeAttr(f.symbol)}')">Als sicher hinzufügen</button>` : ''}
      </div>
    </div>`;
  }).join("");
}


async function markAllDiscoverySuspectsAsSpam(){
  const suspects=lastDiscoveryFindings.filter(f=>isFindingScamSuspect(f)&&!f.userMarkedScam);
  if(!suspects.length)return;
  if(!confirm(`${suspects.length} Spam-Verdacht(e) dieser Wallet wirklich als Spam markieren?`))return;
  lastDiscoveryFindings=lastDiscoveryFindings.map(f=>isFindingScamSuspect(f)?{...f,userMarkedScam:true}:f);
  renderDiscoveryResults(lastDiscoveryFindings);
  const walletId=currentDiscoveryWalletId(),cache=getDiscoveryCacheForWallet(walletId);if(!cache)return;
  const {data,error}=await sb.from('discovery_cache').update({findings:lastDiscoveryFindings}).eq('user_id',currentUser.id).eq('wallet_id',String(walletId)).select().single();
  if(error){alert('Spam-Markierungen konnten nicht gespeichert werden: '+error.message);return;}
  discoveryCaches.set(String(walletId),data);discoveryCache=data;renderDiscoveryCacheState();
}

async function setDiscoveryUserScam(chain, address, marked) {
  const normAddr = normalizeAddress(address, chain);
  let changed = false;

  lastDiscoveryFindings = lastDiscoveryFindings.map(f => {
    if (f.chain === chain && normalizeAddress(f.address, chain) === normAddr) {
      changed = true;
      return { ...f, userMarkedScam: !!marked };
    }
    return f;
  });

  if (!changed) return;

  renderDiscoveryResults(lastDiscoveryFindings);

  // Den aktuellen wallet-spezifischen Discovery-Cache aktualisieren.
  // Dies ist KEIN neuer Scan und darf deshalb den 30-Tage-Cooldown nicht neu starten.
  const walletId = currentDiscoveryWalletId();
  const cache = getDiscoveryCacheForWallet(walletId);
  if (!cache) return;

  const updatedCache = {
    ...cache,
    findings: lastDiscoveryFindings
  };

  const { data, error } = await sb
    .from("discovery_cache")
    .update({ findings: lastDiscoveryFindings })
    .eq("user_id", currentUser.id)
    .eq("wallet_id", String(walletId))
    .select()
    .single();

  if (error) {
    console.error("Spam-Markierung speichern:", error);
    alert("Die Spam-Markierung konnte nicht gespeichert werden: " + error.message);
    return;
  }

  discoveryCaches.set(String(walletId), data || updatedCache);
  discoveryCache = data || updatedCache;
  renderDiscoveryCacheState();
}

async function addDiscoveredToken(chain, address, symbol) {
  document.getElementById("customChain").value = chain;
  document.getElementById("customAddress").value = address;
  document.getElementById("customLabel").value = symbol;
  await addCustomSafeToken();

  // Aus der lokalen Discovery-Anzeige entfernen; der gespeicherte Monats-Scan bleibt
  // als historisches Ergebnis unverändert und wird beim nächsten Scan ersetzt.
  lastDiscoveryFindings = lastDiscoveryFindings.filter(f =>
    !(f.chain === chain && normalizeAddress(f.address, chain) === normalizeAddress(address, chain))
  );
  showTab("custom");
}

// ---- Initialisierung ----
// Alles Weitere (Wallets/Token laden, rendern) passiert erst nach erfolgreichem
// Login in initAuth() -> onLoggedIn(), siehe oben.
initAuth();

/* WalletTracking Crypto-Icons · zentraler UI-Decorator · Build 20260916-020500 */
(function initCryptoIdentityDecorator(){
  const ICONS={
    aptm:'./assets/crypto/aptm.svg', waptm:'./assets/crypto/aptm.svg', apertum:'./assets/crypto/aptm.svg',
    bnb:'./assets/crypto/bnb.svg', bsc:'./assets/crypto/bnb.svg',
    avax:'./assets/crypto/avax.svg', avalanche:'./assets/crypto/avax.svg',
    eth:'./assets/crypto/eth.svg', ethereum:'./assets/crypto/eth.svg',
    usdt:'./assets/crypto/usdt.svg', wusdt:'./assets/crypto/usdt.svg',
    vow:'./assets/crypto/vow.svg', btc:'./assets/crypto/btc.svg', bitcoin:'./assets/crypto/btc.svg',
    sol:'./assets/crypto/sol.svg', solana:'./assets/crypto/sol.svg', xrp:'./assets/crypto/xrp.svg',
    trx:'./assets/crypto/trx.svg', tron:'./assets/crypto/trx.svg', akt:'./assets/crypto/akt.svg', akash:'./assets/crypto/akt.svg',
    pol:'./assets/crypto/polygon.svg', matic:'./assets/crypto/polygon.svg', polygon:'./assets/crypto/polygon.svg'
  };
  function iconKey(text){
    const t=String(text||'').trim().toLowerCase();
    if(!t) return '';
    if(/^(w?aptm)\b/.test(t)||t.startsWith('apertum')) return t.startsWith('waptm')?'waptm':'aptm';
    if(/^w?usdt\b/.test(t)) return t.startsWith('wusdt')?'wusdt':'usdt';
    if(/^bnb\b/.test(t)||t.startsWith('bnb smart chain')) return 'bnb';
    if(/^avax\b/.test(t)||t.startsWith('avalanche')) return 'avax';
    if(/^eth\b/.test(t)||t.startsWith('ethereum')) return 'eth';
    if(/^vow\b/.test(t)) return 'vow';
    if(/^btc\b/.test(t)||t.startsWith('bitcoin')) return 'btc';
    if(/^sol\b/.test(t)||t.startsWith('solana')) return 'sol';
    if(/^xrp\b/.test(t)) return 'xrp';
    if(/^trx\b/.test(t)||t.startsWith('tron')) return 'trx';
    if(/^akt\b/.test(t)||t.startsWith('akash')) return 'akt';
    if(/^pol\b/.test(t)||/^matic\b/.test(t)||t.startsWith('polygon')) return 'polygon';
    for(const [chain,meta] of Object.entries(CHAIN_META||{})){
      const label=String(meta?.label||'').toLowerCase(),sym=String(NATIVE_SYMBOL?.[chain]||meta?.nativeSymbol||'').toLowerCase();
      if((label&&t.startsWith(label))||(sym&&new RegExp('^'+sym.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+'\\b').test(t))) return meta?.iconPath?`chain:${chain}`:'';
    }
    return '';
  }
  function decorate(root=document){
    const nodes=root.querySelectorAll?.('td, .chain-card h3, .chain-card h4, .project-summary-box .label, .project-data-table td')||[];
    nodes.forEach(el=>{
      if(el.dataset.cryptoDecorated==='1'||el.querySelector(':scope > .crypto-icon')) return;
      const key=iconKey(el.textContent); const src=key?.startsWith('chain:')?CHAIN_META[key.slice(6)]?.iconPath:ICONS[key]; if(!key||!src) return;
      const badge=document.createElement('span'); badge.className='crypto-icon sm'; badge.setAttribute('aria-hidden','true');
      const img=document.createElement('img'); img.src=src; img.alt=''; badge.appendChild(img);
      el.insertBefore(badge,el.firstChild); el.dataset.cryptoDecorated='1';
    });
  }
  function boot(){
    decorate(document);
    const target=document.getElementById('appContent')||document.body;
    let queued=false;
    new MutationObserver(()=>{if(queued)return;queued=true;requestAnimationFrame(()=>{queued=false;decorate(target);});}).observe(target,{childList:true,subtree:true});
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',boot,{once:true}); else boot();
})();


/* WalletTracking Tabellen-Semantik · Build 20260916-063600
   Einheitlich im ganzen Dokument: Text/Datum links, Zahlen/Beträge rechts.
   Header und Zellen einer Spalte erhalten immer dieselbe Ausrichtung. */
(function initTableColumnAlignment(){
  const numericHeader = /(?:^|\b)(anzahl|menge|betrag|bestand|gesamtbestand|wert|preis|kurs|usd|eur|chf|claims?|zahlungen?|rewards?|gebühr(?:en)?|gas|anteil|prozent|%|saldo|delta|\bΔ\b|lp(?:\s|$)|staked|token\s*menge|auszahlung(?:en)?|eingang|ausgang|positionen|transaktionen|nfts?|block(?:nummer)?|slot|ledger)(?:\b|$)/i;
  const textHeader = /(?:datum|zeit|timestamp|wallet|adresse|address|token|asset|chain|status|quelle|source|typ|type|methode|method|richtung|partner|tln\s*id|level|name|pool|contract|aktion|gegenstelle|staking|claim\s*\/\s*nft)/i;

  function classifyTable(table){
    if(!table || table.dataset.columnAlignmentDone==='1') return;
    const headRow=table.tHead?.rows?.[table.tHead.rows.length-1] || table.querySelector('tr');
    if(!headRow) return;
    const headers=[...headRow.cells];
    headers.forEach((th,idx)=>{
      const label=(th.textContent||'').replace(/\s+/g,' ').trim();
      let numeric=th.classList.contains('num');
      if(!numeric && !textHeader.test(label) && numericHeader.test(label)) numeric=true;
      /* Bereits explizit numerische Datenzellen machen auch den Titel numerisch. */
      if(!numeric){
        const rows=[...(table.tBodies||[])].flatMap(tb=>[...tb.rows]).slice(0,12);
        numeric=rows.some(row=>row.cells[idx]?.classList.contains('num'));
      }
      const cls=numeric?'col-numeric':'col-text';
      th.classList.add(cls);
      for(const tb of table.tBodies||[]){
        for(const row of tb.rows){ if(row.cells[idx]) row.cells[idx].classList.add(cls); }
      }
    });
    table.dataset.columnAlignmentDone='1';
  }
  function scan(root=document){
    if(root.matches?.('table')) classifyTable(root);
    root.querySelectorAll?.('table').forEach(classifyTable);
  }
  function boot(){
    scan(document);
    const target=document.getElementById('appContent')||document.body;
    let queued=false;
    new MutationObserver(()=>{
      if(queued)return; queued=true;
      requestAnimationFrame(()=>{queued=false; target.querySelectorAll('table').forEach(t=>{t.dataset.columnAlignmentDone=''; classifyTable(t);});});
    }).observe(target,{childList:true,subtree:true});
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',boot,{once:true}); else boot();
})();
