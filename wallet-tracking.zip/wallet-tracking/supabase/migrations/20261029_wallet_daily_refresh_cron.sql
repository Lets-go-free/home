-- Voraussetzung: pg_cron/pg_net sind bereits installiert; Vault enthaelt zwei Secrets:
-- wallet_daily_refresh_url = https://<project-ref>.supabase.co
-- wallet_daily_refresh_auth = separater zufaelliger 64-Zeichen-Hex-Secret,
-- identisch zum Edge-Function-Secret WALLET_DAILY_REFRESH_SECRET.
-- Alle 5 Min. eine Wallet, erst ab 03:00 Europe/Zurich; kein Job je Browser-Session.
DO $$ BEGIN
 IF EXISTS(SELECT 1 FROM cron.job WHERE jobname='wallet-daily-refresh-5m') THEN
   PERFORM cron.unschedule('wallet-daily-refresh-5m');
 END IF;
END $$;
SELECT cron.schedule('wallet-daily-refresh-5m','*/5 * * * *', $job$
 SELECT net.http_post(
  url := (SELECT decrypted_secret FROM vault.decrypted_secrets WHERE name='wallet_daily_refresh_url') || '/functions/v1/wallet-daily-refresh',
  headers := jsonb_build_object(
   'Content-Type','application/json',
   'x-wallet-refresh-secret',(SELECT decrypted_secret FROM vault.decrypted_secrets WHERE name='wallet_daily_refresh_auth')
  ),
  body := '{}'::jsonb,
  timeout_milliseconds := 120000
 );
$job$);
