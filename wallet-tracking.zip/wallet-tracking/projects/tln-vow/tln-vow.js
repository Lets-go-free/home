// Phase 7.62 · 28.10.2026 16:01:44 CET: Alchemy Transfers API + Receipt-verifizierte Swaps, statt Token-Pool-Discovery. Build 20261028-160144.
// Phase 7.61 · 28.10.2026: tokenbasierte VOW/v$-Pool-Discovery, persistente Discovery-/Pool-Cursor, historischer Backfill neu entdeckter Pools.
// Phase 7.60 · 28.10.2026 14:21:10 CET: VOW/v$ Handel – RPC-Adresse-Limit fix. Build 20261028-142110.
// Phase 7.58 · 28.10.2026 13:59:53 CET: RPC-Timeouts, Fortschritt und gemeinsamer Multi-Pool-Logscan für VOW/vUSD Handel. Keine Änderung der Preis-/Staking-Engine.
// Phase 7.57 · 28.10.2026 13:47:01 CET: Neuer Tab VOW/vUSD Handel mit DEX-Swap-Analyse für 24 h, 7 Tage und 30 Tage auf BSC/Ethereum sowie Total; grösste Händler inkl. vorhandener TLN-ID. Build 20261028-134701.
// Phase 7.56 · 09.10.2026 01:40:29 CEST: LP-Preise als USD je 1 LP-Token beschriftet; Ideenliste konsolidiert und bestätigte Tests nachgeführt. Keine Änderung der Preise, Decimals, Supply, Discovery oder Refresh-Jobs. Build 20261009-014029.
// Phase 7.53 · 08.10.2026 18:29:47 CEST: 24-Stunden-Vergleich für DEX-Kurse über dieselbe aktuelle Bewertungsroute; globaler Cache, ehrliche Lücken und Referenzkennzeichnung. Build 20261008-182947.
// Phase 7.03 · 02.10.2026 04:52:42 CEST: BSC-Voucher-Prefetch an die unveraenderte Fachroute angepasst: auf BSC werden nur Voucher/VOW + VOW/USDT vorab gesucht; ETH behaelt direkte Stablecoin-Kandidaten. Build 20261002-045242.
// Phase 7.02 · 02.10.2026 04:37:13 CEST: Referenzassets werden cache-/stammdaten-first aufgelöst; der bisherige LP-On-Chain-Scan bleibt nur als Fallback. Preisrouten und Preisformeln unverändert. Build 20261002-043713.
// Phase 7.01 · 02.10.2026 04:18:28 CEST: TLN/VOW-Preisrefresh wird ohne Preislogikänderung nach BSC/ETH und Refresh-Stufen diagnostiziert; RPC- und HTTP-Anteile sind je Stufe sichtbar. Build 20261002-041828.
// Phase 6.99 · 01.10.2026 20:12:06 CEST: Preis-Routing-Pairs und LP-Zusatzdaten getrennt; doppelte factory()-Reads entfallen, Preisformeln bleiben unverändert. Build 20261001-201206.
// Phase 6.98 · 01.10.2026 18:19:31 CEST: konfigurierte V2-Pooltypen und alle aktuellen Pair-States werden chainweit vorab gebatcht; Preis-/LP-Felder bleiben unverändert. Build 20261001-181931.
// Phase 6.97 · 01.10.2026 17:36:51 CEST: RPC-Diagnose zaehlt Preis-eth_calls zusätzlich nach ABI-Methode, damit verbliebene Pair-State-Kosten messbar sind. Build 20261001-173651.
// Phase 6.96 · 01.10.2026 17:15:03 CEST: V2-getPair-Discovery wird chain-weit vorab gebatcht; parallele identische Pair-Lookups teilen einen In-Flight-Cache. RPC-Diagnose zaehlt HTTP-Batches/eth_calls. Build 20261001-171503.
// Phase 6.95 · 01.10.2026 16:47:46 CEST: bekannte Token-Metadaten kommen aus predefined_tokens; aktuelle Pair-Reads werden als JSON-RPC-Batch gebündelt. Dashboard-Preisjob bleibt render-frei. Build 20261001-164746.
// Phase 6.94 · 01.10.2026 16:20:46 CEST: globaler Preisjob berechnet TLN/VOW nur noch einmal ohne DOM-Render; Projektpreise werden danach aus demselben Cache exportiert. Preis-Snapshot v2 invalidiert alte Dust-Kurse. Build 20261001-162046.
// Phase 6.93 · 01.10.2026 14:16:13 CEST: Ethereum V2-Pair-Lookup prueft alle aktiven V2-Factorys plus die offizielle Uniswap-V2-Factory; keine Abhaengigkeit mehr von der ersten dex_configs-Zeile. Build 20261001-141613.
// Phase 5.97 · 22.09.2026 23:14:40 CEST: ethers-v6 JsonRpcProvider erhält die Network-Instanz auch in options.staticNetwork; behebt den verbliebenen staticNetwork.matches-Fehler im globalen Preisjob. Build 20260922-231440.
// Phase 5.96 · 22.09.2026 21:35:26 CEST: ethers-v6 staticNetwork erhält echte Network-Instanzen; behebt „staticNetwork.matches is not a function“ bei Preis-/Pool-Providerinitialisierung. Build 20260922-213526.
// Phase 5.80 · 21.09.2026 18:15:39 CEST: gespeicherter Current-Price-Snapshot wird 30s in-flight/session wiederverwendet, damit App-Start und direktes Projektöffnen keinen identischen Supabase-Read erzeugen. Fachliche Preislogik unverändert. Build 20260921-181539.
// Phase 5.78 · 21.09.2026 17:29:35 CEST: DEX/RPC-Provider werden erst im Kurse/Pools-Untertab initialisiert; bekannte BSC/ETH-Netzwerke nutzen staticNetwork ohne zusätzliche Chain-Erkennung. Build 20260921-172935.
window.TLNVOWProject = (() => {

/* =========================================================
   GENERISCHE DEFI-/DEX-KONFIGURATION AUS SUPABASE
========================================================= */
const PROJECT_KEY = "tln_vow";
let PROJECT_NAME = "TLN/VOW";
let CONFIG = {};
let providers = {};
let projectChains = [];

/* =========================================================
   ABIs
========================================================= */
const ERC20_ABI = [
  "function name() view returns (string)",
  "function symbol() view returns (string)",
  "function decimals() view returns (uint8)",
  "function balanceOf(address) view returns (uint256)"
];

const V2_ABI = [
  "function token0() view returns (address)",
  "function token1() view returns (address)",
  "function getReserves() view returns (uint112 reserve0,uint112 reserve1,uint32 blockTimestampLast)",
  "function totalSupply() view returns (uint256)",
  "function balanceOf(address) view returns (uint256)",
  "function decimals() view returns (uint8)",
  "function symbol() view returns (string)",
  "function factory() view returns (address)"
];

const FACTORY_ABI = [
  "function getPair(address tokenA,address tokenB) view returns (address)"
];
const FACTORY_IFACE = new ethers.Interface(FACTORY_ABI);

const PRICE_RPC_METHOD_BY_SELECTOR = new Map([
  [ethers.id("getPair(address,address)").slice(0,10),"getPair"],
  [ethers.id("token0()").slice(0,10),"token0"],
  [ethers.id("token1()").slice(0,10),"token1"],
  [ethers.id("getReserves()").slice(0,10),"getReserves"],
  [ethers.id("totalSupply()").slice(0,10),"totalSupply"],
  [ethers.id("decimals()").slice(0,10),"decimals"],
  [ethers.id("factory()").slice(0,10),"factory"],
  [ethers.id("symbol()").slice(0,10),"symbol"],
  [ethers.id("name()").slice(0,10),"name"],
  [ethers.id("balanceOf(address)").slice(0,10),"balanceOf"],
  [ethers.id("slot0()").slice(0,10),"slot0"],
  [ethers.id("liquidity()").slice(0,10),"liquidity"],
  [ethers.id("fee()").slice(0,10),"fee"]
]);
const priceRpcStats = {
  httpBatchRequests:0,
  ethCalls:0,
  getPairCalls:0,
  pairDiscoveryBatches:0,
  methods:{},
  byChain:{},
  ensureChain(chain){
    const key=String(chain||"unknown");
    if(!this.byChain[key])this.byChain[key]={httpBatchRequests:0,ethCalls:0,getPairCalls:0,pairDiscoveryBatches:0,methods:{}};
    return this.byChain[key];
  },
  countCalls(calls,chain){
    const cs=this.ensureChain(chain);
    for(const call of Array.isArray(calls)?calls:[]){
      const selector=String(call?.data||"").slice(0,10).toLowerCase();
      const name=PRICE_RPC_METHOD_BY_SELECTOR.get(selector)||selector||"unknown";
      this.methods[name]=(this.methods[name]||0)+1;
      cs.methods[name]=(cs.methods[name]||0)+1;
    }
  },
  recordBatch(chain,calls){
    const count=Array.isArray(calls)?calls.length:0,cs=this.ensureChain(chain);
    this.httpBatchRequests++;this.ethCalls+=count;
    cs.httpBatchRequests++;cs.ethCalls+=count;
    this.countCalls(calls,chain);
  },
  recordGetPair(chain,count=1){
    const n=Math.max(0,Number(count)||0),cs=this.ensureChain(chain);
    this.getPairCalls+=n;cs.getPairCalls+=n;
  },
  recordDiscoveryBatch(chain){
    const cs=this.ensureChain(chain);
    this.pairDiscoveryBatches++;cs.pairDiscoveryBatches++;
  },
  reset(){ this.httpBatchRequests=0; this.ethCalls=0; this.getPairCalls=0; this.pairDiscoveryBatches=0; this.methods={}; this.byChain={}; },
  snapshot(){
    return {
      httpBatchRequests:this.httpBatchRequests,ethCalls:this.ethCalls,getPairCalls:this.getPairCalls,pairDiscoveryBatches:this.pairDiscoveryBatches,methods:{...this.methods},
      byChain:Object.fromEntries(Object.entries(this.byChain).map(([chain,v])=>[chain,{...v,methods:{...(v.methods||{})}}]))
    };
  }
};

function subtractCounterMap(after={},before={}){
  const out={};
  for(const key of new Set([...Object.keys(before||{}),...Object.keys(after||{})])){
    const value=Number(after?.[key]||0)-Number(before?.[key]||0);
    if(value)out[key]=value;
  }
  return out;
}
function rpcStatsDelta(before={},after={}){
  const out={
    httpBatchRequests:Number(after.httpBatchRequests||0)-Number(before.httpBatchRequests||0),
    ethCalls:Number(after.ethCalls||0)-Number(before.ethCalls||0),
    getPairCalls:Number(after.getPairCalls||0)-Number(before.getPairCalls||0),
    pairDiscoveryBatches:Number(after.pairDiscoveryBatches||0)-Number(before.pairDiscoveryBatches||0),
    methods:subtractCounterMap(after.methods,before.methods),
    byChain:{}
  };
  for(const chain of new Set([...Object.keys(before.byChain||{}),...Object.keys(after.byChain||{})])){
    const b=before.byChain?.[chain]||{},a=after.byChain?.[chain]||{};
    out.byChain[chain]={
      httpBatchRequests:Number(a.httpBatchRequests||0)-Number(b.httpBatchRequests||0),
      ethCalls:Number(a.ethCalls||0)-Number(b.ethCalls||0),
      getPairCalls:Number(a.getPairCalls||0)-Number(b.getPairCalls||0),
      pairDiscoveryBatches:Number(a.pairDiscoveryBatches||0)-Number(b.pairDiscoveryBatches||0),
      methods:subtractCounterMap(a.methods,b.methods)
    };
  }
  return out;
}
function projectRequestAuditSnapshot(){
  try{return window.getRequestAuditSnapshot?.()||null;}catch(_){return null;}
}
function projectRequestAuditSummary(startIndex){
  const snap=projectRequestAuditSnapshot(),entries=Array.isArray(snap?.entries)?snap.entries:[];
  if(!Number.isInteger(startIndex))return {requests:null,topResources:{},topCallers:{}};
  const rows=entries.slice(Math.max(0,startIndex)),resources={},callers={};
  for(const row of rows){
    const resource=String(row?.resource||"unknown"),caller=String(row?.caller||"unknown");
    resources[resource]=(resources[resource]||0)+1;callers[caller]=(callers[caller]||0)+1;
  }
  const top=o=>Object.fromEntries(Object.entries(o).sort((a,b)=>b[1]-a[1]).slice(0,8));
  return {requests:rows.length,topResources:top(resources),topCallers:top(callers)};
}
async function measureProjectPriceStage(diag,name,fn){
  const reqSnap=projectRequestAuditSnapshot(),startIndex=Array.isArray(reqSnap?.entries)?reqSnap.entries.length:null;
  const before=priceRpcStats.snapshot(),t0=performance.now();
  try{return await fn();}
  finally{
    const after=priceRpcStats.snapshot();
    diag.stages[name]={elapsedMs:Math.round((performance.now()-t0)*10)/10,...projectRequestAuditSummary(startIndex),rpc:rpcStatsDelta(before,after)};
  }
}

const V3_ABI = [
  "function token0() view returns (address)",
  "function token1() view returns (address)",
  "function slot0() view returns (uint160 sqrtPriceX96,int24 tick,uint16 observationIndex,uint16 observationCardinality,uint16 observationCardinalityNext,uint8 feeProtocol,bool unlocked)",
  "function liquidity() view returns (uint128)",
  "function fee() view returns (uint24)",
  "function factory() view returns (address)"
];

/* =========================================================
   STATE / CACHE
========================================================= */
let database = { bsc: [], eth: [] };
let references = {};
const predefinedMeta = new Map();

const tokenCache = new Map();
const pairCache  = new Map();
const priceCache = new Map();
// Öffentliche Preisbrücke zur Hauptseite. Schlüssel immer chain|Contract-Adresse.
const exportedPrices = new Map();

function exportProjectPrice(chain,address,result,kind="token"){
  if(!address || !result || !Number.isFinite(Number(result.price))) return;
  exportedPrices.set(chain + "|" + norm(address), {
    price:Number(result.price),
    change24h:undefined,
    source:chain === "bsc" ? "PancakeSwap" : (chain === "eth" ? "Uniswap" : ("DEX · " + PROJECT_NAME)),
    route:result.route || null,
    kind,
    valuationBasis: result.source==="stable-self" || result.hops===0 ? {type:"fixed",price:Number(result.price)} : {
      type:"path",base:norm(address),quote:norm(references[chain]?.[String(result.stable||"USDT").toLowerCase()]),
      pools:(result.edges || (result.pools|| (result.pool?[result.pool]:[])).map(pool=>({pool,type:result.source==="direct-v3"?"v3":"v2"}))).map(x=>({address:norm(x.pool),type:x.type||"v2"}))
    }
  });
}
const v3PoolCache = new Map();
const poolTypeCache = new Map();
const lpSymbolCache = new Map();

const CURRENT_PRICE_SNAPSHOT_TABLE = "defi_current_price_snapshots";
const CURRENT_PRICE_SNAPSHOT_VERSION = "tln-vow-current-price-v2";
const PRICE_TIMEZONE = "Europe/Zurich";
let currentPriceCapturedAt = null;
let currentPriceSource = "live";
let priceRefreshPromise = null;
let infrastructurePromise = null;
let currentPriceSnapshotReadPromise = null;
let currentPriceSnapshotReadCache = null;
const CURRENT_PRICE_SNAPSHOT_READ_TTL_MS = 30000;


/*
 * Preisgraph pro Chain.
 * Voucher-Währungen werden NICHT mehr automatisch über VOW geroutet.
 */
const graphCache = {};

/* =========================================================
   BASICS
========================================================= */
function norm(x){ return String(x || "").trim().toLowerCase(); }
function same(a,b){ return !!a && !!b && norm(a) === norm(b); }

function zurichDay(value=new Date()){
  const d = value instanceof Date ? value : new Date(value);
  if(Number.isNaN(d.getTime())) return null;
  const parts = new Intl.DateTimeFormat("en-CA",{
    timeZone:PRICE_TIMEZONE, year:"numeric", month:"2-digit", day:"2-digit"
  }).formatToParts(d);
  const get=t=>parts.find(p=>p.type===t)?.value;
  return `${get("year")}-${get("month")}-${get("day")}`;
}

function isTodayZurich(iso){
  return !!iso && zurichDay(iso) === zurichDay(new Date());
}

function formatPriceTimestamp(iso){
  if(!iso) return "–";
  const d=new Date(iso);
  if(Number.isNaN(d.getTime())) return "–";
  return d.toLocaleString("de-CH",{timeZone:PRICE_TIMEZONE,dateStyle:"medium",timeStyle:"medium"});
}

function serializableMap(map){
  return [...map.entries()].filter(([,v])=>v && typeof v?.then !== "function");
}

function restoreMap(map,rows){
  map.clear();
  for(const row of Array.isArray(rows)?rows:[]){
    if(Array.isArray(row) && row.length===2 && row[0]) map.set(String(row[0]),row[1]);
  }
}

function setPriceStatus(text,kind="note"){
  const el=document.getElementById("tlnvowPriceStatus");
  if(!el) return;
  el.className=kind;
  el.textContent=text;
}

function setPriceRefreshBusy(busy){
  const btn=document.getElementById("tlnvowRefreshPricesBtn");
  if(btn){
    btn.disabled=!!busy;
    btn.textContent=busy ? "Preise werden aktualisiert…" : "Preise aktualisieren";
  }
}

function rpcBlockTag(block="latest"){
  if(block==null || block==="latest")return "latest";
  const n=Number(block);
  return Number.isFinite(n)?"0x"+Math.max(0,Math.trunc(n)).toString(16):String(block);
}

async function batchRpcCalls(chain,calls,block="latest"){
  const rpc=CONFIG[chain]?.rpc;
  if(!rpc || !Array.isArray(calls) || !calls.length)throw new Error(`${chain}: RPC-Batch nicht verfügbar.`);
  const tag=rpcBlockTag(block);
  const payload=calls.map((x,i)=>({jsonrpc:"2.0",id:i+1,method:"eth_call",params:[{to:x.to,data:x.data},tag]}));
  priceRpcStats.recordBatch(chain,calls);
  const response=await fetch(rpc,{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify(payload)});
  if(!response.ok)throw new Error(`${chain}: RPC-Batch HTTP ${response.status}`);
  const json=await response.json();
  if(!Array.isArray(json))throw new Error(`${chain}: RPC-Batch-Antwort ist kein Array.`);
  const byId=new Map(json.map(x=>[Number(x.id),x]));
  return payload.map(req=>{
    const item=byId.get(req.id);
    if(!item || item.error || typeof item.result!=="string")throw new Error(`${chain}: RPC-Batch-Call ${req.id} fehlgeschlagen${item?.error?.message?`: ${item.error.message}`:""}`);
    return item.result;
  });
}

function configureSharedPriceEngine(){
  if(!window.WalletPriceEngine) return;
  window.WalletPriceEngine.configure(() => ({
    provider: chain => providers[chain] || null,
    batchCall: async (chain,calls,block) => await batchRpcCalls(chain,calls,block),
    tokenMeta: async (chain,address) => await getToken(chain,address),
    references: chain => references[chain] || {},
    tokenCategory: (chain,address) => rowType(findDbRow(chain,address)),
    findPair: async (chain,tokenA,tokenB) => await findPair(chain,tokenA,tokenB),
    listPools: chain => configuredLPs(chain),
    poolType: async (chain,address) => await detectPoolType(chain,address),
    readV3Pool: async (chain,address) => await readV3Pool(chain,address)
  }));
}

/* Zentrale Anzeigepräzision kommt aus public.predefined_tokens.
 * Technische ERC-20 decimals bleiben davon vollständig getrennt. */
function displayDecimalsFor(symbol,{kind="token",summary=false,address=null}={}){
  const globalDigits=window.WalletTokenFormat?.digits;
  if(typeof globalDigits==="function") return globalDigits({chain:"bsc",address,symbol},summary);
  return kind==="lp"?6:6;
}

function formatTokenAmount(value,symbol,options={}){
  const globalFormat=window.WalletTokenFormat?.amount;
  if(typeof globalFormat==="function") return globalFormat(value,{chain:"bsc",address:options?.address||null,symbol},{summary:!!options?.summary});
  const n=Number(value);
  if(!Number.isFinite(n)) return "–";
  return n.toLocaleString("de-CH",{maximumFractionDigits:options?.kind==="lp"?6:6});
}

function fmt(value, decimals=8){
  if(value === null || value === undefined || !Number.isFinite(value)) return "-";
  return value.toLocaleString("de-CH",{maximumFractionDigits:decimals});
}

function usd(value){
  if(value === null || value === undefined || !Number.isFinite(value)) return "nicht verfügbar";
  if(value === 0) return "$0";
  return "$" + value.toLocaleString("en-US",{
    minimumFractionDigits:value < 1 ? 6 : 2,
    maximumFractionDigits:value < 1 ? 10 : 2
  });
}

/*
 * Neue Supabase-Klassifikation.
 *
 * Generische Werte:
 *   voucher_currency
 *   lp_token
 *   defi_token
 *
 * Supabase-Spalten:
 *   defi_project_key
 *   defi_category
 */
function rowType(row){
  if(!row) return "";
  return norm(row.defi_category);
}

function isAllowedRow(row){
  return norm(row?.defi_project_key) === PROJECT_KEY &&
    ["voucher_currency","lp_token","defi_token"].includes(rowType(row));
}

function isLP(row){ return rowType(row) === "lp_token"; }
function isVoucherRow(row){ return rowType(row) === "voucher_currency"; }
function isProjectToken(row){ return rowType(row) === "defi_token"; }

function chainRows(chain){
  return (database[chain] || []).filter(isAllowedRow);
}
function configuredLPs(chain){ return chainRows(chain).filter(isLP); }
function configuredTokens(chain){
  return chainRows(chain).filter(r => {
    if(!r || !r.address) return false;

    const type = rowType(r);

    // Token-Übersicht: ausschließlich echte Projekt-/Voucher-Tokens.
    if(type !== "voucher_currency" && type !== "defi_token"){
      return false;
    }

    return true;
  });
}

function findDbRow(chain,address){
  return chainRows(chain).find(r => r.address && same(r.address,address)) || null;
}

function findTokenByLabel(chain,label){
  return configuredTokens(chain).find(r => norm(r.label) === norm(label)) || null;
}

function findTokenByLabelContains(chain,text){
  return configuredTokens(chain).find(r => norm(r.label).includes(norm(text))) || null;
}

function displayTokenLabel(dbRow,token){
  const label = String(dbRow?.label || "").trim();
  return label || token.name || token.symbol || token.address;
}

function displayPoolLabel(dbRow,pool){
  const label = String(dbRow?.label || "").trim();
  if(label) return label;
  if(pool?.token0 && pool?.token1) return `${pool.token0.symbol} / ${pool.token1.symbol}`;
  return "Liquidity Pool";
}

/*
 * Referenz-Tokens werden NICHT mehr anhand des Supabase-Labels gesucht.
 * Das Label ist nur für die Anzeige.
 * Für USDT/USDC/BUSD/WBNB/BTCB/WETH wird das tatsächliche On-Chain-Symbol
 * des Token-Contracts verwendet. VOW bleibt bewusst fix hinterlegt.
 */
async function loadProjectInfrastructure(){
  const [{data:project,error:projectError},{data:tokens,error:tokenError},{data:dexRows,error:dexError}] = await Promise.all([
    sb.from("defi_projects").select("*").eq("project_key",PROJECT_KEY).eq("enabled",true).maybeSingle(),
    sb.from("defi_project_tokens").select("*").eq("project_key",PROJECT_KEY).eq("enabled",true),
    sb.from("dex_configs").select("*").eq("enabled",true)
  ]);
  if(projectError) throw projectError;
  if(tokenError) throw tokenError;
  if(dexError) throw dexError;
  if(!project) throw new Error(`DeFi-Projekt ${PROJECT_KEY} ist in Supabase nicht aktiv konfiguriert.`);

  PROJECT_NAME = project.name || PROJECT_KEY;
  CONFIG = {};
  providers = {};
  references = {};
  projectChains = [];

  const referenceTokens = (tokens||[]).filter(t => norm(t.role)==="reference");
  for(const ref of referenceTokens){
    const chain = norm(ref.chain_key);
    if(!chain || !CHAIN_CONFIG[chain]) continue;
    if(!CONFIG[chain]) CONFIG[chain]={};
    if(!references[chain]) references[chain]={};
    references[chain].vow = ref.contract_address;
    if(!projectChains.includes(chain)) projectChains.push(chain);
  }

  for(const chain of projectChains){
    const chainDex=(dexRows||[]).filter(d => norm(d.chain_key)===chain);
    const v2Rows=chainDex.filter(d => norm(d.version)==="v2"&&d.factory_address);
    const v3=chainDex.find(d => norm(d.version)==="v3");
    const v2Factories=[...new Set(v2Rows.map(d=>norm(d.factory_address)).filter(Boolean))];
    if(chain==="eth"){
      const uniswapV2=norm("0x5C69bEe701ef814a2B6a3EDD4B1652CB9cc5aA6f");
      if(!v2Factories.includes(uniswapV2))v2Factories.push(uniswapV2);
    }
    CONFIG[chain]={
      rpc: configuredRpcUrl(chain),
      v2Factory:v2Factories[0] || null,
      v2Factories,
      v3Factory:v3?.factory_address || null
    };
    if(!CONFIG[chain].v2Factory) throw new Error(`${PROJECT_NAME}: Für ${chain} fehlt eine aktive V2-DEX-Factory.`);
    const staticNetwork=chain==="bsc"?ethers.Network.from({chainId:56,name:"bsc"}):chain==="eth"?ethers.Network.from({chainId:1,name:"mainnet"}):undefined;
    providers[chain]=staticNetwork
      ? new ethers.JsonRpcProvider(CONFIG[chain].rpc,staticNetwork,{staticNetwork})
      : new ethers.JsonRpcProvider(CONFIG[chain].rpc);
    graphCache[chain]=null;
    references[chain]=references[chain] || {};
  }
}

async function resolveReferences(chain){
  /*
   * Referenz-Assets werden zuerst aus bereits bekannten/cachierten Daten
   * aufgeloest. Das ist fachlich dieselbe Information wie bisher, vermeidet
   * aber den erneuten On-Chain-Scan aller LPs nur zur Symbolerkennung.
   *
   * Reihenfolge:
   * 1) bereits im letzten gueltigen Preisstand aufgeloeste Referenzen,
   * 2) zentraler predefined_tokens-Stammdatensatz,
   * 3) bereits vorab geladene Pair-States der WalletPriceEngine,
   * 4) konfigurierte Projekt-Tokens,
   * 5) alter On-Chain-LP-Scan ausschliesslich als Fallback fuer Luecken.
   *
   * Damit bleibt der alte On-Chain-Weg als Sicherheitsnetz erhalten; sobald
   * die Referenzen bereits eindeutig bekannt sind, entstehen dafuer keine
   * zusaetzlichen RPC-Requests mehr.
   */

  const wanted = chain === "bsc"
    ? ["USDT","USDC","BUSD","WBNB","BTCB"]
    : ["USDT","USDC","WETH"];
  const found = {};
  const put=(symbol,address)=>{
    const sym=String(symbol||"").trim().toUpperCase(),addr=String(address||"").trim();
    if(wanted.includes(sym) && !found[sym] && addr) found[sym]=addr;
  };
  const complete=()=>wanted.every(symbol=>!!found[symbol]);

  // Vorheriger gueltiger Preisstand: dieselben bereits bewiesenen Referenzen
  // wiederverwenden. Das verhindert insbesondere bei manuellen Refreshs einen
  // identischen LP-Metadaten-Scan.
  const previous=references[chain]||{};
  put("USDT",previous.usdt);put("USDC",previous.usdc);put("BUSD",previous.busd);
  put("WBNB",previous.wbnb);put("BTCB",previous.btcb);put("WETH",previous.weth);

  // Zentrale Token-Stammdaten. Diese wurden fuer den Refresh ohnehin einmal
  // geladen und enthalten bei den Standard-Referenzassets Symbol + Adresse.
  if(!complete()){
    for(const [key,row] of predefinedMeta){
      if(!key.startsWith(chain+"|"))continue;
      const symbol=String(row.symbol||row.label||row.name||"").trim().toUpperCase();
      if(wanted.includes(symbol) && row.address) put(symbol,row.address);
    }
  }

  // Die konfigurierten V2-Pairs wurden unmittelbar vor dieser Stufe bereits
  // vorab geladen. Fehlende Referenzen koennen daher aus deren gecachtem
  // token0/token1 gelesen werden, ohne einen weiteren RPC-Aufruf auszufuehren.
  if(!complete()){
    try{
      const state=window.WalletPriceEngine?.exportCurrentState?.();
      for(const entry of Array.isArray(state?.pairPriceStates)?state.pairPriceStates:[]){
        if(!Array.isArray(entry)||entry.length!==2)continue;
        const value=entry[1];
        if(norm(value?.chain)!==chain)continue;
        for(const token of [value?.token0,value?.token1]) put(token?.symbol,token?.address);
      }
    }catch(e){console.warn("Referenz-Assets aus PriceEngine-Cache",chain,e);}
  }

  // Explizit konfigurierte Projekt-/Voucher-Tokens bleiben eine weitere Quelle.
  // getToken() nutzt fuer bekannte predefined_tokens keinen RPC-Call.
  if(!complete()){
    for(const row of configuredTokens(chain)){
      try{
        const token = await getToken(chain,row.address);
        put(token.symbol,token.address);
      }catch(e){
        console.warn("Referenz-Token konnte nicht gelesen werden:",row.address,e);
      }
    }
  }

  // Sicherheits-Fallback: nur falls danach wirklich noch eine Referenz fehlt,
  // wird die bisherige LP-On-Chain-Erkennung ausgefuehrt. Preisberechnung und
  // Auswahl der Referenzassets verlieren dadurch keinen bisherigen Datenweg.
  if(!complete()){
    for(const dbPool of configuredLPs(chain)){
      if(complete())break;
      try{
        const type = await detectPoolType(chain,dbPool.address);
        const pool = type === "v3"
          ? await readV3Pool(chain,dbPool.address)
          : await readV2Pool(chain,dbPool.address);
        for(const token of [pool.token0,pool.token1]) put(token.symbol,token.address);
      }catch(e){
        console.warn("Referenz-Asset konnte aus LP nicht gelesen werden:",dbPool.address,e);
      }
    }
  }

  references[chain] = references[chain] || {};
  references[chain].usdt = found.USDT || null;
  references[chain].usdc = found.USDC || null;
  references[chain].busd = found.BUSD || null;
  references[chain].wbnb = found.WBNB || null;
  references[chain].btcb = found.BTCB || null;
  references[chain].weth = found.WETH || null;

  console.log("Resolved references",chain,references[chain]);
}

/* =========================================================
   SUPABASE
========================================================= */
async function loadSupabase(){
  // Ein zentraler Stammdaten-Read versorgt sowohl Projektklassifikation als auch
  // Token-Metadaten/Stablecoin-Referenzen. Dadurch entfallen pro Token bis zu
  // drei ERC-20-Metadaten-Calls (name/symbol/decimals) beim Preisrefresh.
  const {data:rows,error}=await sb.from("predefined_tokens")
    .select("*")
    .eq("enabled",true);
  if(error) throw error;

  predefinedMeta.clear();
  for(const row of rows||[]){
    const chain=norm(row.chain),address=norm(row.address);
    if(chain&&address&&address!=="native")predefinedMeta.set(`${chain}|${address}`,row);
  }
  database={};
  for(const chain of projectChains){
    database[chain]=(rows||[]).filter(r => norm(r.chain)===chain && isAllowedRow(r));
  }
}

async function ensureInfrastructure(){
  if(!infrastructurePromise){
    infrastructurePromise=(async()=>{
      await loadProjectInfrastructure();
      await loadSupabase();
      configureSharedPriceEngine();
      return true;
    })();
  }
  return infrastructurePromise;
}

function resetCurrentPriceCaches(){
  tokenCache.clear();
  pairCache.clear();
  priceCache.clear();
  exportedPrices.clear();
  v3PoolCache.clear();
  poolTypeCache.clear();
  lpSymbolCache.clear();
  projectChains.forEach(c=>graphCache[c]=null);
  if(window.WalletPriceEngine){
    configureSharedPriceEngine();
    window.WalletPriceEngine.clearCurrent();
  }
}

function buildCurrentPriceSnapshot(){
  return {
    schemaVersion:1,
    projectKey:PROJECT_KEY,
    valuationVersion:CURRENT_PRICE_SNAPSHOT_VERSION,
    references,
    exportedPrices:serializableMap(exportedPrices),
    tokenCache:serializableMap(tokenCache),
    pairCache:serializableMap(pairCache),
    v3PoolCache:serializableMap(v3PoolCache),
    poolTypeCache:serializableMap(poolTypeCache),
    lpSymbolCache:serializableMap(lpSymbolCache),
    priceEngine:window.WalletPriceEngine?.exportCurrentState?.() || null
  };
}

function hydrateCurrentPriceSnapshot(payload){
  if(!payload || Number(payload.schemaVersion)!==1) return false;
  references=payload.references || references;
  restoreMap(exportedPrices,payload.exportedPrices);
  restoreMap(tokenCache,payload.tokenCache);
  restoreMap(pairCache,payload.pairCache);
  restoreMap(v3PoolCache,payload.v3PoolCache);
  restoreMap(poolTypeCache,payload.poolTypeCache);
  restoreMap(lpSymbolCache,payload.lpSymbolCache);
  if(window.WalletPriceEngine && payload.priceEngine){
    configureSharedPriceEngine();
    window.WalletPriceEngine.importCurrentState?.(payload.priceEngine,{replaceCurrent:true});
  }
  return true;
}

async function loadCurrentPriceSnapshot({force=false}={}){
  const now=Date.now();
  if(!force && currentPriceSnapshotReadCache && (now-currentPriceSnapshotReadCache.loadedAt)<CURRENT_PRICE_SNAPSHOT_READ_TTL_MS){
    return currentPriceSnapshotReadCache.value;
  }
  if(!force && currentPriceSnapshotReadPromise) return currentPriceSnapshotReadPromise;
  const run=(async()=>{
    try{
      const {data,error}=await sb.from(CURRENT_PRICE_SNAPSHOT_TABLE)
        .select("captured_at,payload,valuation_version")
        .eq("project_key",PROJECT_KEY)
        .eq("valuation_version",CURRENT_PRICE_SNAPSHOT_VERSION)
        .maybeSingle();
      if(error) throw error;
      const value=data?.payload?{capturedAt:data.captured_at,payload:data.payload,fresh:isTodayZurich(data.captured_at)}:null;
      currentPriceSnapshotReadCache={loadedAt:Date.now(),value};
      return value;
    }catch(e){
      console.warn("TLN/VOW Preiscache konnte nicht aus Supabase geladen werden:",e);
      return null;
    }
  })();
  if(!force) currentPriceSnapshotReadPromise=run;
  try{return await run;}finally{if(currentPriceSnapshotReadPromise===run) currentPriceSnapshotReadPromise=null;}
}

async function saveCurrentPriceSnapshot(){
  const capturedAt=new Date().toISOString();
  const row={
    project_key:PROJECT_KEY,
    valuation_version:CURRENT_PRICE_SNAPSHOT_VERSION,
    captured_at:capturedAt,
    updated_at:capturedAt,
    payload:buildCurrentPriceSnapshot()
  };
  try{
    const {error}=await sb.from(CURRENT_PRICE_SNAPSHOT_TABLE)
      .upsert(row,{onConflict:"project_key,valuation_version"});
    if(error) throw error;
    currentPriceCapturedAt=capturedAt;
    currentPriceSnapshotReadCache={loadedAt:Date.now(),value:{capturedAt,payload:row.payload,fresh:true}};
    return true;
  }catch(e){
    console.warn("TLN/VOW Preiscache konnte nicht in Supabase gespeichert werden:",e);
    return false;
  }
}

function notifyCurrentPricesUpdated(manual=false){
  const detail={projectKey:PROJECT_KEY,capturedAt:currentPriceCapturedAt,manual,prices:Object.fromEntries(exportedPrices)};
  window.dispatchEvent(new CustomEvent("wallettracking:prices-updated",{detail}));
  if(typeof window.onWalletTrackingPricesUpdated === "function"){
    try{ window.onWalletTrackingPricesUpdated(detail); }catch(e){ console.warn("Preis-Update-Hook fehlgeschlagen",e); }
  }
}

/* =========================================================
   TOKEN INFO
========================================================= */
async function getToken(chain,address){
  const key = chain + ":" + norm(address);
  if(tokenCache.has(key)) return tokenCache.get(key);

  const master=predefinedMeta.get(chain+"|"+norm(address));
  const masterSymbol=String(master?.symbol||master?.label||"").trim();
  const masterName=String(master?.name||master?.label||masterSymbol||"").trim();
  const masterDecimals=master?.decimals===null||master?.decimals===undefined||master?.decimals===""?null:Number(master.decimals);
  if(masterSymbol && Number.isFinite(masterDecimals)){
    const result={address,name:masterName||masterSymbol,symbol:masterSymbol,decimals:masterDecimals};
    tokenCache.set(key,result);
    return result;
  }

  const contract = new ethers.Contract(address,ERC20_ABI,providers[chain]);

  // Metadaten sind bewusst fehlertolerant. Einige ältere/projektspezifische
  // ERC-20-Contracts implementieren einzelne optionale Metadata-Reads nicht
  // sauber und können z.B. bei name() mit "execution reverted" antworten.
  // Das darf eine ansonsten gültige LP-/Preisabfrage nicht abbrechen.
  let name = null, symbol = null, decimals = 18;
  try { name = await contract.name(); } catch(e) {
    console.warn(`TLN/VOW ${chain} ${address}: name() nicht verfügbar`, e);
  }
  try { symbol = await contract.symbol(); } catch(e) {
    console.warn(`TLN/VOW ${chain} ${address}: symbol() nicht verfügbar`, e);
  }
  try { decimals = Number(await contract.decimals()); } catch(e) {
    console.warn(`TLN/VOW ${chain} ${address}: decimals() nicht verfügbar; Fallback 18`, e);
    decimals = 18;
  }

  const fallback = String(address).slice(0,8) + "…";
  const result = {
    address,
    name: String(name || symbol || fallback),
    symbol: String(symbol || name || fallback),
    decimals: Number.isFinite(Number(decimals)) ? Number(decimals) : 18
  };
  tokenCache.set(key,result);
  return result;
}

/* =========================================================
   V2 PAIR LOOKUP
========================================================= */
function pairCacheKey(chain,tokenA,tokenB){
  return chain + ":" + [norm(tokenA),norm(tokenB)].sort().join(":");
}

async function lookupPairAcrossFactories(chain,tokenA,tokenB){
  const factories=(CONFIG[chain].v2Factories?.length?CONFIG[chain].v2Factories:[CONFIG[chain].v2Factory]).filter(Boolean);
  if(!factories.length) return null;
  const calls=factories.map(factoryAddress=>({
    to:factoryAddress,
    data:FACTORY_IFACE.encodeFunctionData("getPair",[tokenA,tokenB])
  }));
  try{
    priceRpcStats.recordGetPair(chain,calls.length);
    const raws=await batchRpcCalls(chain,calls,"latest");
    for(let i=0;i<raws.length;i++){
      const [pair]=FACTORY_IFACE.decodeFunctionResult("getPair",raws[i]);
      if(pair && pair!==ethers.ZeroAddress) return String(pair);
    }
    return null;
  }catch(e){
    console.warn(`${chain}: gebündelter V2 Pair-Lookup fehlgeschlagen; Einzel-Fallback`,e);
    for(const factoryAddress of factories){
      try{
        const factory=new ethers.Contract(factoryAddress,FACTORY_ABI,providers[chain]);
        priceRpcStats.recordGetPair(chain,1);
        const pair=await factory.getPair(tokenA,tokenB);
        if(pair!==ethers.ZeroAddress)return pair;
      }catch(inner){console.warn(`${chain}: V2 Pair-Lookup über ${factoryAddress} fehlgeschlagen`,inner);}
    }
    return null;
  }
}

async function findPair(chain,tokenA,tokenB){
  if(!tokenA || !tokenB) return null;

  const key = pairCacheKey(chain,tokenA,tokenB);
  if(pairCache.has(key)) return await pairCache.get(key);

  const pending=lookupPairAcrossFactories(chain,tokenA,tokenB);
  pairCache.set(key,pending);
  try{
    const result=await pending;
    pairCache.set(key,result);
    return result;
  }catch(e){
    pairCache.delete(key);
    throw e;
  }
}

function addPairCandidate(map,chain,a,b){
  if(!a || !b || same(a,b))return;
  const key=pairCacheKey(chain,a,b);
  if(pairCache.has(key) || map.has(key))return;
  map.set(key,{key,a,b});
}

async function prefetchV2PairDiscovery(chain){
  const factories=(CONFIG[chain].v2Factories?.length?CONFIG[chain].v2Factories:[CONFIG[chain].v2Factory]).filter(Boolean);
  if(!factories.length)return;
  const ref=references[chain]||{};
  const candidates=new Map();

  // Gemeinsame Referenzroute nur einmal entdecken.
  addPairCandidate(candidates,chain,ref.vow,ref.usdt);

  for(const row of configuredTokens(chain)){
    const address=row.address;
    const type=rowType(row);
    if(type==="voucher_currency"){
      // Fachregel: BSC-Voucher werden ausschließlich über VOW → USDT bewertet.
      // Direkte USDC/USDT-Paare sind dort nicht nur fachlich unzulässig, sondern
      // müssen deshalb auch nicht für den Preisrefresh vorab entdeckt werden.
      if(chain !== "bsc"){
        addPairCandidate(candidates,chain,address,ref.usdc);
        addPairCandidate(candidates,chain,address,ref.usdt);
      }
      addPairCandidate(candidates,chain,address,ref.vow);
    }else if(type==="defi_token"){
      addPairCandidate(candidates,chain,address,ref.vow);
      addPairCandidate(candidates,chain,address,ref.usdt);
    }
  }

  if(!candidates.size)return;
  const entries=[...candidates.values()];
  const calls=[];
  for(const entry of entries){
    for(let factoryIndex=0;factoryIndex<factories.length;factoryIndex++){
      calls.push({
        entry,
        factoryIndex,
        to:factories[factoryIndex],
        data:FACTORY_IFACE.encodeFunctionData("getPair",[entry.a,entry.b])
      });
    }
  }

  // Kleine Chunks vermeiden Provider-Limits; typisch ist je Chain nur ein Batch nötig.
  const rawByCall=new Array(calls.length);
  const chunkSize=80;
  try{
    for(let offset=0;offset<calls.length;offset+=chunkSize){
      const chunk=calls.slice(offset,offset+chunkSize);
      priceRpcStats.recordDiscoveryBatch(chain);
      priceRpcStats.recordGetPair(chain,chunk.length);
      const raws=await batchRpcCalls(chain,chunk.map(x=>({to:x.to,data:x.data})),"latest");
      raws.forEach((raw,i)=>{ rawByCall[offset+i]=raw; });
    }
    const results=new Map(entries.map(x=>[x.key,null]));
    calls.forEach((call,i)=>{
      if(results.get(call.entry.key))return;
      try{
        const [pair]=FACTORY_IFACE.decodeFunctionResult("getPair",rawByCall[i]);
        if(pair && pair!==ethers.ZeroAddress)results.set(call.entry.key,String(pair));
      }catch(e){ console.warn(`${chain}: getPair-Batch-Antwort konnte nicht dekodiert werden`,call.entry.key,e); }
    });
    for(const entry of entries)pairCache.set(entry.key,results.get(entry.key)||null);
  }catch(e){
    // Kein Fehler für die Preislogik: findPair() übernimmt danach mit In-Flight-Deduplizierung.
    console.warn(`${chain}: Pair-Discovery-Batch fehlgeschlagen; Lazy-Fallback aktiv`,e);
  }
}

/* =========================================================
   V2 PRICE
========================================================= */
async function getV2Price(chain,pairAddress,baseToken){
  if(window.WalletPriceEngine){
    configureSharedPriceEngine();
    return await window.WalletPriceEngine.getV2Price(chain,pairAddress,baseToken,"latest");
  }

  const pair = new ethers.Contract(pairAddress,V2_ABI,providers[chain]);
  const [a,b,res] = await Promise.all([pair.token0(),pair.token1(),pair.getReserves()]);
  const [t0,t1] = await Promise.all([getToken(chain,a),getToken(chain,b)]);
  const r0 = Number(ethers.formatUnits(res[0],t0.decimals));
  const r1 = Number(ethers.formatUnits(res[1],t1.decimals));
  if(!r0 || !r1) return null;
  if(same(baseToken,a)) return {price:r1/r0,quote:t1.address};
  if(same(baseToken,b)) return {price:r0/r1,quote:t0.address};
  return null;
}

/* =========================================================
   STABLECOINS
========================================================= */
function stableReference(chain,address){
  const ref = references[chain];
  if(same(address,ref.usdt)) return {price:1,route:"USDT",hops:0};
  if(same(address,ref.usdc)) return {price:1,route:"USDC",hops:0};
  if(chain === "bsc" && same(address,ref.busd)) return {price:1,route:"BUSD",hops:0};
  return null;
}

async function tokenSymbol(chain,address){
  try { return (await getToken(chain,address)).symbol; }
  catch { return address.slice(0,6)+"…"; }
}

/* =========================================================
   PREISGRAPH AUS DEN SUPABASE-LPs AUFBAUEN
========================================================= */
async function buildPriceGraph(chain){
  if(graphCache[chain]) return graphCache[chain];

  const edges = [];

  for(const dbPool of configuredLPs(chain)){
    try{
      const type = await detectPoolType(chain,dbPool.address);

      if(type === "v2"){
        const pool = await readV2Pool(chain,dbPool.address);

        if(pool.r0 > 0 && pool.r1 > 0){
          edges.push({
            type:"v2",
            from:pool.token0.address,
            to:pool.token1.address,
            rate:pool.r1/pool.r0,
            fromSymbol:pool.token0.symbol,
            toSymbol:pool.token1.symbol,
            pool:dbPool.address,
            reserveFrom:pool.r0,
            reserveTo:pool.r1
          });

          edges.push({
            type:"v2",
            from:pool.token1.address,
            to:pool.token0.address,
            rate:pool.r0/pool.r1,
            fromSymbol:pool.token1.symbol,
            toSymbol:pool.token0.symbol,
            pool:dbPool.address,
            reserveFrom:pool.r1,
            reserveTo:pool.r0
          });
        }
      }

      if(type === "v3"){
        const pool = await readV3Pool(chain,dbPool.address);

        if(Number.isFinite(pool.price0) && pool.price0 > 0){
          edges.push({
            type:"v3",
            from:pool.token0.address,
            to:pool.token1.address,
            rate:pool.price0,
            fromSymbol:pool.token0.symbol,
            toSymbol:pool.token1.symbol,
            pool:dbPool.address,
            reserveFrom:null,
            reserveTo:null
          });

          edges.push({
            type:"v3",
            from:pool.token1.address,
            to:pool.token0.address,
            rate:pool.price1,
            fromSymbol:pool.token1.symbol,
            toSymbol:pool.token0.symbol,
            pool:dbPool.address,
            reserveFrom:null,
            reserveTo:null
          });
        }
      }
    }catch(e){
      console.warn("Preisgraph: Pool konnte nicht gelesen werden:",dbPool.address,e);
    }
  }

  graphCache[chain] = edges;
  return edges;
}

/* =========================================================
   SHORTEST-PATH PREISROUTER
========================================================= */
async function enumerateUSDPaths(chain,tokenAddress,maxHops=4,maxPaths=80){
  const stableSelf = stableReference(chain,tokenAddress);
  if(stableSelf){
    return [{
      price:1,
      route:stableSelf.route,
      stable:stableSelf.route,
      hops:0,
      edges:[],
      pathLiquidityUSD:Infinity
    }];
  }

  const edges = await buildPriceGraph(chain);

  const stablePriority = [
    {name:"USDT", address:references[chain].usdt, priority:0},
    {name:"USDC", address:references[chain].usdc, priority:1},
    ...(chain === "bsc"
      ? [{name:"BUSD", address:references.bsc.busd, priority:2}]
      : [])
  ].filter(x => x.address);

  const stableMap = new Map(
    stablePriority.map(x => [norm(x.address), x])
  );

  const paths = [];
  const startSymbol = await tokenSymbol(chain,tokenAddress);

  async function dfs(currentAddress, multiplier, symbols, pathEdges, visited){
    if(paths.length >= maxPaths) return;
    if(pathEdges.length >= maxHops) return;

    const outgoing = edges.filter(e => same(e.from,currentAddress));

    for(const edge of outgoing){
      const nextKey = norm(edge.to);
      if(visited.has(nextKey)) continue;

      const nextMultiplier = multiplier * edge.rate;
      const nextSymbols = [...symbols,edge.toSymbol];
      const nextEdges = [...pathEdges,edge];

      const stable = stableMap.get(nextKey);

      if(stable){
        paths.push({
          price:nextMultiplier,
          route:nextSymbols.join(" → "),
          stable:stable.name,
          stablePriority:stable.priority,
          hops:nextEdges.length,
          edges:nextEdges,
          pathLiquidityUSD:null
        });
        continue;
      }

      const nextVisited = new Set(visited);
      nextVisited.add(nextKey);

      await dfs(
        edge.to,
        nextMultiplier,
        nextSymbols,
        nextEdges,
        nextVisited
      );
    }
  }

  await dfs(
    tokenAddress,
    1,
    [startSymbol],
    [],
    new Set([norm(tokenAddress)])
  );

  return paths;
}


/*
 * Für einen V2-Pfad lässt sich die USD-Liquidität jedes Hops aus
 * der nachfolgenden USD-Bewertung abschätzen:
 *
 * TVL ≈ ReserveFrom * USD(From) + ReserveTo * USD(To)
 *
 * Da die Preise aus genau diesem Pool stammen, sind beide Seiten
 * im Idealfall annähernd gleichwertig.
 *
 * Als Pfad-Liquidität verwenden wir den kleinsten TVL aller Hops
 * ("Bottleneck"). Eine Route ist nur so stark wie ihr schwächster Pool.
 *
 * V3-Hops besitzen hier keine einfachen reserve0/reserve1-Werte.
 * Sie erhalten deshalb keinen erfundenen TVL-Wert; bei gemischten
 * Routen wird nur die messbare V2-Liquidität verwendet.
 */
function scorePathLiquidity(path){
  if(!path.edges.length){
    path.pathLiquidityUSD = Infinity;
    return path;
  }

  let usdTo = 1; // Stablecoin am Ende
  let bottleneck = Infinity;
  let measurableHops = 0;

  for(let i=path.edges.length-1; i>=0; i--){
    const edge = path.edges[i];

    const usdFrom = edge.rate * usdTo;

    if(
      edge.type === "v2" &&
      Number.isFinite(edge.reserveFrom) &&
      Number.isFinite(edge.reserveTo)
    ){
      const tvl =
        edge.reserveFrom * usdFrom +
        edge.reserveTo * usdTo;

      if(Number.isFinite(tvl) && tvl > 0){
        bottleneck = Math.min(bottleneck,tvl);
        measurableHops++;
      }
    }

    usdTo = usdFrom;
  }

  path.pathLiquidityUSD =
    measurableHops > 0
      ? bottleneck
      : null;

  return path;
}


async function graphUSDPrice(chain,tokenAddress,maxHops=4){
  const paths = await enumerateUSDPaths(chain,tokenAddress,maxHops);

  if(!paths.length) return null;

  paths.forEach(scorePathLiquidity);

  /*
   * Auswahl:
   * 1. messbare Liquidität vorhanden -> höchste Bottleneck-Liquidität
   * 2. bei ähnlicher/gleicher Liquidität: USDT bevorzugen
   * 3. danach kürzere Route
   * 4. reine V3-Routen ohne messbare V2-Reserve bleiben nutzbar,
   *    werden aber hinter messbaren Routen einsortiert.
   */
  paths.sort((a,b)=>{
    const aLiq = a.pathLiquidityUSD;
    const bLiq = b.pathLiquidityUSD;

    const aMeasured = Number.isFinite(aLiq);
    const bMeasured = Number.isFinite(bLiq);

    if(aMeasured && bMeasured && aLiq !== bLiq){
      return bLiq - aLiq;
    }

    if(aMeasured !== bMeasured){
      return aMeasured ? -1 : 1;
    }

    if((a.stablePriority ?? 99) !== (b.stablePriority ?? 99)){
      return (a.stablePriority ?? 99) - (b.stablePriority ?? 99);
    }

    return a.hops - b.hops;
  });

  const best = paths[0];

  return {
    price:best.price,
    route:best.route,
    hops:best.hops,
    stable:best.stable,
    pathLiquidityUSD:best.pathLiquidityUSD,
    alternatives:paths.slice(1,4).map(p=>({
      price:p.price,
      route:p.route,
      stable:p.stable,
      hops:p.hops,
      pathLiquidityUSD:p.pathLiquidityUSD
    }))
  };
}

/* =========================================================
   DIREKTE USD-MÄRKTE FÜR EXTERNE / CORE ASSETS
========================================================= */

/*
 * BTCB, WBNB, WETH und VOW werden NICHT über andere Ecosystem-Tokens geroutet.
 *
 * Für diese Assets gilt:
 *   TOKEN -> USDT
 *   TOKEN -> USDC
 *   TOKEN -> BUSD (nur BSC)
 *
 * Auf Ethereum darf ein direkter Uniswap-V3-Pool ebenfalls als
 * direkter Stablecoin-Markt dienen (z.B. WETH/USDC).
 *
 * Es gibt ausdrücklich KEIN:
 *   BTCB -> VOW -> ...
 *   WBNB -> VOW -> ...
 *   WETH -> VOW -> ...
 */

function strictCoreSymbol(symbol){
  return ["BTCB","WBNB","WETH","BNB","ETH"].includes(
    String(symbol || "").trim().toUpperCase()
  );
}

async function directV2StableMarkets(chain,tokenAddress){
  const candidates = [
    {name:"USDT",address:references[chain].usdt,priority:0},
    {name:"USDC",address:references[chain].usdc,priority:1},
    ...(chain === "bsc"
      ? [{name:"BUSD",address:references.bsc.busd,priority:2}]
      : [])
  ].filter(x => x.address);

  const results = [];
  const symbol = await tokenSymbol(chain,tokenAddress);

  for(const stable of candidates){
    try{
      const pairAddress = await findPair(chain,tokenAddress,stable.address);
      if(!pairAddress) continue;

      const pair = await readV2Pool(chain,pairAddress);

      let tokenReserve = null;
      let stableReserve = null;
      let price = null;

      if(same(pair.token0.address,tokenAddress)){
        tokenReserve = pair.r0;
        stableReserve = pair.r1;
        price = pair.r1 / pair.r0;
      }else if(same(pair.token1.address,tokenAddress)){
        tokenReserve = pair.r1;
        stableReserve = pair.r0;
        price = pair.r0 / pair.r1;
      }

      if(
        price === null ||
        !Number.isFinite(price) ||
        price <= 0
      ) continue;

      /*
       * Da der Quote-Token ein USD-Stablecoin ist, können wir den
       * Pool-TVL ohne weitere Preisroute abschätzen:
       *
       * Token-Seite = tokenReserve * price
       * Stable-Seite = stableReserve * $1
       */
      const liquidityUSD =
        tokenReserve * price +
        stableReserve;

      results.push({
        price,
        route:`${symbol} → ${stable.name}`,
        stable:stable.name,
        stablePriority:stable.priority,
        hops:1,
        pathLiquidityUSD:liquidityUSD,
        source:"direct-v2",
        pool:pairAddress
      });
    }catch(e){
      console.warn("Direkter V2-Stablemarkt konnte nicht gelesen werden:",tokenAddress,stable.name,e);
    }
  }

  return results;
}

async function directV3StableMarkets(chain,tokenAddress){
  if(chain !== "eth") return [];

  const candidates = [
    {name:"USDT",address:references.eth.usdt,priority:0},
    {name:"USDC",address:references.eth.usdc,priority:1}
  ].filter(x => x.address);

  const results = [];
  const symbol = await tokenSymbol(chain,tokenAddress);

  /*
   * Wir verwenden ausschließlich die in Supabase als LP/Pool
   * hinterlegten Uniswap-V3-Pools. Keine externe API.
   */
  for(const dbPool of configuredLPs("eth")){
    try{
      const type = await detectPoolType("eth",dbPool.address);
      if(type !== "v3") continue;

      const pool = await readV3Pool("eth",dbPool.address);

      for(const stable of candidates){
        if(
          same(pool.token0.address,tokenAddress) &&
          same(pool.token1.address,stable.address)
        ){
          results.push({
            price:pool.price0,
            route:`${symbol} → ${stable.name} (Uniswap V3)`,
            stable:stable.name,
            stablePriority:stable.priority,
            hops:1,
            pathLiquidityUSD:null,
            source:"direct-v3",
            pool:dbPool.address
          });
        }

        if(
          same(pool.token1.address,tokenAddress) &&
          same(pool.token0.address,stable.address)
        ){
          results.push({
            price:pool.price1,
            route:`${symbol} → ${stable.name} (Uniswap V3)`,
            stable:stable.name,
            stablePriority:stable.priority,
            hops:1,
            pathLiquidityUSD:null,
            source:"direct-v3",
            pool:dbPool.address
          });
        }
      }
    }catch(e){
      console.warn("V3-Pool konnte für direkten Stablemarkt nicht gelesen werden:",dbPool.address,e);
    }
  }

  return results;
}


/*
 * LETZTER FALLBACK FÜR PROJEKT-TOKENS
 *
 * Für tln_vow_token (z.B. TLN / TLN+) prüfen wir als letzten Schritt
 * nochmals explizit einen direkten V2-Pool gegen USDT.
 *
 * Keine Route über VOW.
 * Keine externe API.
 * Nur Factory.getPair(token, USDT) + getReserves().
 */
async function directUSDTFallback(chain,token){
  const usdt = references[chain].usdt;
  if(!usdt) return null;

  try{
    const pairAddress = await findPair(chain,token.address,usdt);
    if(!pairAddress) return null;

    const pair = await readV2Pool(chain,pairAddress);

    let price = null;
    let tokenReserve = null;
    let usdtReserve = null;

    if(same(pair.token0.address,token.address)){
      price = pair.r1 / pair.r0;
      tokenReserve = pair.r0;
      usdtReserve = pair.r1;
    }else if(same(pair.token1.address,token.address)){
      price = pair.r0 / pair.r1;
      tokenReserve = pair.r1;
      usdtReserve = pair.r0;
    }

    if(!Number.isFinite(price) || price <= 0) return null;

    const liquidityUSD =
      tokenReserve * price +
      usdtReserve;

    return {
      price,
      route:`${token.symbol} → USDT (direkter V2-Fallback)`,
      stable:"USDT",
      hops:1,
      pathLiquidityUSD:liquidityUSD,
      source:"direct-usdt-fallback",
      pool:pairAddress
    };

  }catch(e){
    console.warn(
      "Direkter USDT-Fallback fehlgeschlagen:",
      chain,
      token.symbol,
      token.address,
      e
    );
    return null;
  }
}

async function strictDirectUSDPrice(chain,token){
  const stableSelf = stableReference(chain,token.address);
  if(stableSelf) return stableSelf;

  const v2 = await directV2StableMarkets(chain,token.address);
  const v3 = await directV3StableMarkets(chain,token.address);

  const all = [...v2,...v3];
  if(!all.length) return null;

  /*
   * Auswahl direkter Märkte:
   * 1. Wenn TVL messbar ist: größter direkter Pool.
   * 2. Bei Gleichstand: USDT vor USDC/BUSD.
   * 3. V3 bleibt möglich, wenn kein messbarer V2-Direktmarkt existiert.
   */
  all.sort((a,b)=>{
    const aMeasured = Number.isFinite(a.pathLiquidityUSD);
    const bMeasured = Number.isFinite(b.pathLiquidityUSD);

    if(aMeasured && bMeasured && a.pathLiquidityUSD !== b.pathLiquidityUSD){
      return b.pathLiquidityUSD - a.pathLiquidityUSD;
    }

    if(aMeasured !== bMeasured){
      return aMeasured ? -1 : 1;
    }

    return (a.stablePriority ?? 99) - (b.stablePriority ?? 99);
  });

  return all[0];
}

/* =========================================================
   ÖKOSYSTEM-PREISE
========================================================= */

/*
 * Nur für Tokens, die NICHT zu den externen Core-Assets gehören,
 * darf der vorhandene Pool-Graph verwendet werden.
 *
 * Damit bleiben z.B. v$, v€, v£ oder TLN Gold über ihre echten
 * LP-Verbindungen bewertbar, während BTCB vollständig unabhängig
 * von VOW bleibt.
 */
async function ecosystemUSDPrice(chain,token){
  return await graphUSDPrice(chain,token.address,4);
}

/* =========================================================
   USD PRICE ROUTER
========================================================= */

/* =========================================================
   SPEZIELLE PREISLOGIK FÜR v_currency
========================================================= */

/*
 * Nur für Datensätze mit:
 *   tln_vow_category = "v_currency"
 *
 * gilt bewusst:
 *
 *   v-Währung -> VOW -> USDT
 *
 * Schritt 1:
 *   direkter V2-Pool v-Währung / VOW
 *
 * Schritt 2:
 *   direkter V2-Pool VOW / USDT
 *
 * Keine Suche über v$, v€, v£ untereinander.
 * Kein Graph-Routing für v_currency.
 */
async function vCurrencyUSDPrice(chain,token){
  const vow = references[chain].vow;
  const usdt = references[chain].usdt;

  if(!vow || !usdt) return null;

  try{
    const vToVowPair = await findPair(chain,token.address,vow);
    if(!vToVowPair) return null;

    const vToVow = await getV2Price(
      chain,
      vToVowPair,
      token.address
    );

    if(!vToVow) return null;

    const vowToUsdtPair = await findPair(chain,vow,usdt);
    if(!vowToUsdtPair) return null;

    const vowToUsdt = await getV2Price(
      chain,
      vowToUsdtPair,
      vow
    );

    if(!vowToUsdt) return null;

    /*
     * Für die angezeigte Pfad-Liquidität nehmen wir den
     * kleineren TVL der beiden V2-Pools als Bottleneck.
     */
    const vPool = await readV2Pool(chain,vToVowPair);
    const vowPool = await readV2Pool(chain,vowToUsdtPair);

    let vPoolTVL = null;
    let vowPoolTVL = null;

    // v_currency/VOW-Pool in USD bewerten
    // token USD = (token->VOW) * (VOW->USDT)
    const tokenUsd = vToVow.price * vowToUsdt.price;

    if(same(vPool.token0.address,token.address)){
      vPoolTVL =
        vPool.r0 * tokenUsd +
        vPool.r1 * vowToUsdt.price;
    }else{
      vPoolTVL =
        vPool.r1 * tokenUsd +
        vPool.r0 * vowToUsdt.price;
    }

    // VOW/USDT-Pool
    if(same(vowPool.token0.address,vow)){
      vowPoolTVL =
        vowPool.r0 * vowToUsdt.price +
        vowPool.r1;
    }else{
      vowPoolTVL =
        vowPool.r1 * vowToUsdt.price +
        vowPool.r0;
    }

    const pathLiquidityUSD =
      Number.isFinite(vPoolTVL) && Number.isFinite(vowPoolTVL)
        ? Math.min(vPoolTVL,vowPoolTVL)
        : null;

    return {
      price:tokenUsd,
      route:`${token.symbol} → VOW → USDT`,
      stable:"USDT",
      hops:2,
      pathLiquidityUSD,
      source:"v-currency-direct-vow-usdt",
      pools:[vToVowPair,vowToUsdtPair]
    };

  }catch(e){
    console.warn(
      "v_currency Preisroute fehlgeschlagen:",
      chain,
      token.symbol,
      token.address,
      e
    );

    return null;
  }
}


/* =========================================================
   SPEZIELLE PREISLOGIK FÜR tln_vow_token
========================================================= */

/*
 * Für tln_vow_token gilt:
 *
 * 1. Wenn der Token VOW selbst ist:
 *      VOW -> USDT
 *
 * 2. Für alle anderen tln_vow_token:
 *      zuerst prüfen: TOKEN / VOW Pool vorhanden?
 *
 *      Wenn JA:
 *          TOKEN -> VOW -> USDT
 *
 *      Wenn NEIN:
 *          direkten TOKEN / USDT Pool prüfen
 *
 * Kein allgemeines Graph-Routing für tln_vow_token.
 */
async function projectTokenUSDPrice(chain,token){
  const vow = references[chain].vow;
  const usdt = references[chain].usdt;

  if(!usdt) return null;

  /*
   * VOW selbst:
   * niemals VOW/VOW suchen.
   * Immer direkt gegen USDT.
   */
  if(vow && same(token.address,vow)){
    return await directUSDTFallback(chain,token);
  }

  /*
   * 1. TOKEN / VOW
   */
  if(vow){
    try{
      const tokenVowPair = await findPair(chain,token.address,vow);

      if(tokenVowPair){
        const tokenToVow = await getV2Price(
          chain,
          tokenVowPair,
          token.address
        );

        if(tokenToVow){
          const vowUsdtPair = await findPair(chain,vow,usdt);

          if(vowUsdtPair){
            const vowToUsdt = await getV2Price(
              chain,
              vowUsdtPair,
              vow
            );

            if(vowToUsdt){
              const tokenUsd =
                tokenToVow.price *
                vowToUsdt.price;

              /*
               * Pfad-Liquidität als Bottleneck der beiden V2-Pools.
               */
              let pathLiquidityUSD = null;

              try{
                const tokenVowPool = await readV2Pool(chain,tokenVowPair);
                const vowUsdtPool = await readV2Pool(chain,vowUsdtPair);

                let tokenVowTVL = null;
                let vowUsdtTVL = null;

                if(same(tokenVowPool.token0.address,token.address)){
                  tokenVowTVL =
                    tokenVowPool.r0 * tokenUsd +
                    tokenVowPool.r1 * vowToUsdt.price;
                }else{
                  tokenVowTVL =
                    tokenVowPool.r1 * tokenUsd +
                    tokenVowPool.r0 * vowToUsdt.price;
                }

                if(same(vowUsdtPool.token0.address,vow)){
                  vowUsdtTVL =
                    vowUsdtPool.r0 * vowToUsdt.price +
                    vowUsdtPool.r1;
                }else{
                  vowUsdtTVL =
                    vowUsdtPool.r1 * vowToUsdt.price +
                    vowUsdtPool.r0;
                }

                if(
                  Number.isFinite(tokenVowTVL) &&
                  Number.isFinite(vowUsdtTVL)
                ){
                  pathLiquidityUSD =
                    Math.min(
                      tokenVowTVL,
                      vowUsdtTVL
                    );
                }
              }catch(e){
                console.warn(
                  "Pfad-Liquidität für tln_vow_token konnte nicht berechnet werden:",
                  token.symbol,
                  e
                );
              }

              return {
                price:tokenUsd,
                route:`${token.symbol} → VOW → USDT`,
                stable:"USDT",
                hops:2,
                pathLiquidityUSD,
                source:"tln-vow-token-via-vow",
                pools:[
                  tokenVowPair,
                  vowUsdtPair
                ]
              };
            }
          }
        }
      }
    }catch(e){
      console.warn(
        "TOKEN/VOW-Route konnte nicht gelesen werden:",
        chain,
        token.symbol,
        token.address,
        e
      );
    }
  }

  /*
   * 2. Kein brauchbarer TOKEN/VOW-Pool:
   *    direkter TOKEN / USDT Pool
   */
  return await directUSDTFallback(
    chain,
    token
  );
}

async function getUSD(chain,token){
  const key = chain + ":" + norm(token.address);
  if(priceCache.has(key)) return priceCache.get(key);

  /*
   * Phase 2: Die fachliche Preisentscheidung liegt zentral im
   * WalletPriceEngine. TLN/VOW liefert nur Projekt-Konfiguration
   * (Referenz-Tokens, Kategorie, Pair-Lookup und V3-Pools).
   *
   * Damit benutzen Token-Tabelle, LP-Bewertung und spätere weitere
   * Consumer dieselbe Preisroute und denselben Pair-State-Cache.
   */
  if(window.WalletPriceEngine){
    configureSharedPriceEngine();
    const result = await window.WalletPriceEngine.getTokenPrice({
      projectKey:PROJECT_KEY,
      chain,
      token,
      block:"latest"
    });
    priceCache.set(key,result);
    return result;
  }

  /*
   * Sicherheits-Fallback für direkte Nutzung der Projektdatei ohne
   * geladene gemeinsame Engine. In der produktiven index.html wird
   * price-engine.js vor tln-vow.js geladen und dieser Block nicht benutzt.
   */
  let result = null;
  const dbRow = findDbRow(chain,token.address);
  result = stableReference(chain,token.address);
  if(!result && dbRow && isVoucherRow(dbRow)) result = await vCurrencyUSDPrice(chain,token);
  if(!result && dbRow && isProjectToken(dbRow)) result = await projectTokenUSDPrice(chain,token);
  if(!result && strictCoreSymbol(token.symbol)) result = await strictDirectUSDPrice(chain,token);
  if(!result && (!dbRow || (!isVoucherRow(dbRow) && !isProjectToken(dbRow)))) result = await ecosystemUSDPrice(chain,token);
  priceCache.set(key,result);
  return result;
}

/* =========================================================
   CURRENT V2 POOL PREFETCH
   Performance-only: dieselben on-chain Felder wie bisher werden gelesen,
   aber chainweit gebündelt und in denselben PriceEngine-Cache gelegt.
========================================================= */
const POOL_FACTORY_IFACE = new ethers.Interface(["function factory() view returns (address)"]);

async function prefetchConfiguredPoolTypes(chain){
  const rows=configuredLPs(chain).filter(r=>r?.address && ethers.isAddress(r.address));
  const missing=rows.filter(r=>!poolTypeCache.has(chain+":"+norm(r.address)));
  if(!missing.length)return 0;
  const chunkSize=80;
  let loaded=0;
  for(let offset=0;offset<missing.length;offset+=chunkSize){
    const chunk=missing.slice(offset,offset+chunkSize);
    try{
      const raws=await batchRpcCalls(chain,chunk.map(r=>({to:r.address,data:POOL_FACTORY_IFACE.encodeFunctionData("factory",[])})),"latest");
      raws.forEach((raw,i)=>{
        const [factory]=POOL_FACTORY_IFACE.decodeFunctionResult("factory",raw);
        let type=null;
        if(isConfiguredV2Factory(chain,factory))type="v2";
        if(CONFIG[chain]?.v3Factory && same(factory,CONFIG[chain].v3Factory))type="v3";
        if(type){
          poolTypeCache.set(chain+":"+norm(chunk[i].address),type);
          if(type==="v2") window.WalletPriceEngine?.setKnownPairFactory?.(chain,chunk[i].address,factory);
          loaded++;
        }
      });
    }catch(e){
      // Reine Performance-Vorladung: bei Provider-/Einzelpoolfehlern bleibt der
      // bestehende detectPoolType()-Pfad unverändert als fachlicher Fallback aktiv.
      console.warn(`${chain}: Pooltyp-Prefetch fehlgeschlagen; Lazy-Fallback aktiv`,e);
    }
  }
  return loaded;
}

async function prefetchConfiguredV2PairStates(chain){
  if(!window.WalletPriceEngine?.prefetchPairStates)return 0;
  configureSharedPriceEngine();
  const addresses=configuredLPs(chain)
    .map(r=>r?.address)
    .filter(a=>a && poolTypeCache.get(chain+":"+norm(a))==="v2");
  try{
    return await window.WalletPriceEngine.prefetchPairStates(chain,addresses,"latest",{chunkCalls:72});
  }catch(e){
    console.warn(`${chain}: V2-Pair-State-Prefetch fehlgeschlagen; bestehender Lazy-Reader bleibt aktiv`,e);
    return 0;
  }
}

async function prefetchDiscoveredV2PairStates(chain){
  if(!window.WalletPriceEngine?.prefetchPricePairStates)return 0;
  configureSharedPriceEngine();
  const prefix=chain+":";
  const addresses=[...pairCache.entries()]
    .filter(([key,value])=>String(key).startsWith(prefix) && typeof value==="string" && ethers.isAddress(value) && value!==ethers.ZeroAddress)
    .map(([,value])=>value);
  try{
    // Entdeckte Routing-Pairs brauchen für die Preisermittlung ausschließlich
    // token0/token1/getReserves. LP-Supply/LP-decimals werden nur für die
    // tatsächlich konfigurierten LP-Positionen separat vorgeladen.
    return await window.WalletPriceEngine.prefetchPricePairStates(chain,addresses,"latest",{chunkCalls:72});
  }catch(e){
    console.warn(`${chain}: entdeckter Preis-Pair-State-Prefetch fehlgeschlagen; bestehender Lazy-Reader bleibt aktiv`,e);
    return 0;
  }
}

/* =========================================================
   POOL TYPE
========================================================= */
function isConfiguredV2Factory(chain,address){
  const factories=(CONFIG[chain]?.v2Factories?.length?CONFIG[chain].v2Factories:[CONFIG[chain]?.v2Factory]).filter(Boolean);
  return factories.some(f=>same(f,address));
}

async function detectPoolType(chain,address){
  const key = chain + ":" + norm(address);
  if(poolTypeCache.has(key)) return poolTypeCache.get(key);
  if(!providers[chain]) throw new Error(`${chain}: RPC-Provider für Pool ${address} fehlt.`);
  if(!ethers.isAddress(address)) throw new Error(`${chain}: Ungültige Pool-Adresse ${address}.`);

  let factory;
  try{
    /*
     * Pooltyp muss vor dem V2-Pair-State bestimmt werden.
     * Ein V3-Pool unterstützt kein getReserves()/totalSupply() wie ein V2-Pair.
     * Deshalb hier bewusst nur factory() lesen und erst danach den
     * typ-spezifischen Reader verwenden.
     */
    const minimal = new ethers.Contract(address,["function factory() view returns (address)"],providers[chain]);
    factory = await minimal.factory();
  }catch(e){
    throw new Error(`${chain}: ${address} · factory() fehlgeschlagen: ${e?.shortMessage || e?.reason || e?.message || e}`);
  }

  let type = null;
  if(isConfiguredV2Factory(chain,factory)) type = "v2";
  if(CONFIG[chain]?.v3Factory && same(factory,CONFIG[chain].v3Factory)) type = "v3";
  if(!type) throw new Error(`${chain}: ${address} gehört nicht zu einer konfigurierten V2/V3-Factory (factory=${factory}).`);
  poolTypeCache.set(key,type);
  return type;
}

/* =========================================================
   READ V2 POOL
========================================================= */
async function readV2Pool(chain,address){
  if(!providers[chain]) throw new Error(`${chain}: RPC-Provider für Pool ${address} fehlt.`);

  if(window.WalletPriceEngine){
    configureSharedPriceEngine();
    const state = await window.WalletPriceEngine.getPairState(chain,address,"latest");
    if(!isConfiguredV2Factory(chain,state.factory)) throw new Error("Pool gehört nicht zu einer konfigurierten V2-Factory.");

    const lpSymbolKey = chain + ":" + norm(address);
    let lpSymbol = lpSymbolCache.get(lpSymbolKey) || "LP";
    if(!lpSymbolCache.has(lpSymbolKey)){
      try {
        const pair = new ethers.Contract(address,["function symbol() view returns (string)"],providers[chain]);
        lpSymbol = String(await pair.symbol());
      } catch(e) {
        console.warn(`TLN/VOW ${chain} ${address}: LP symbol() nicht verfügbar`, e);
      }
      lpSymbolCache.set(lpSymbolKey,lpSymbol);
    }

    return {
      type:"v2",
      address,
      token0:state.token0,
      token1:state.token1,
      r0:state.reserve0,
      r1:state.reserve1,
      lpSupply:state.totalSupply,
      lpDecimals:state.lpDecimals,
      lpSymbol
    };
  }

  const pair = new ethers.Contract(address,V2_ABI,providers[chain]);
  const coreCalls = [
    ["token0()", () => pair.token0()],
    ["token1()", () => pair.token1()],
    ["getReserves()", () => pair.getReserves()],
    ["totalSupply()", () => pair.totalSupply()],
    ["decimals()", () => pair.decimals()],
    ["factory()", () => pair.factory()]
  ];
  const settled = await Promise.allSettled(coreCalls.map(([,fn]) => fn()));
  const failedIndex = settled.findIndex(x => x.status === "rejected");
  if(failedIndex >= 0){
    const err = settled[failedIndex].reason;
    throw new Error(`${chain}: ${address} · ${coreCalls[failedIndex][0]} fehlgeschlagen: ${err?.shortMessage || err?.reason || err?.message || err}`);
  }
  const [token0,token1,reserves,totalSupply,lpDecimals,factory] = settled.map(x => x.value);
  if(!token0 || !token1 || same(token0,token1)) throw new Error(`${chain}: ${address} liefert ungültige token0/token1-Adressen.`);
  let lpSymbol = "LP";
  try { lpSymbol = String(await pair.symbol()); } catch(e) {
    console.warn(`TLN/VOW ${chain} ${address}: LP symbol() nicht verfügbar`, e);
  }
  if(!isConfiguredV2Factory(chain,factory)) throw new Error("Pool gehört nicht zu einer konfigurierten V2-Factory.");
  const [t0,t1] = await Promise.all([getToken(chain,token0),getToken(chain,token1)]);
  return {type:"v2",address,token0:t0,token1:t1,r0:Number(ethers.formatUnits(reserves[0],t0.decimals)),r1:Number(ethers.formatUnits(reserves[1],t1.decimals)),lpSupply:Number(ethers.formatUnits(totalSupply,Number(lpDecimals))),lpDecimals:Number(lpDecimals),lpSymbol};
}

/* =========================================================
   READ V3 POOL
========================================================= */
async function readV3Pool(chain,address){
  if(chain !== "eth") throw new Error("V3 ist in dieser Version nur für Ethereum vorgesehen.");

  const cacheKey = chain + ":" + norm(address);
  if(v3PoolCache.has(cacheKey)) return v3PoolCache.get(cacheKey);

  const pool = new ethers.Contract(address,V3_ABI,providers[chain]);
  const [token0,token1,slot0,liquidity,fee,factory] = await Promise.all([
    pool.token0(),
    pool.token1(),
    pool.slot0(),
    pool.liquidity(),
    pool.fee(),
    pool.factory()
  ]);

  if(!CONFIG[chain]?.v3Factory || !same(factory,CONFIG[chain].v3Factory)){
    throw new Error("Pool gehört nicht zur Uniswap-V3-Factory.");
  }

  const [t0,t1] = await Promise.all([getToken(chain,token0),getToken(chain,token1)]);

  const sqrtPriceX96 = Number(slot0.sqrtPriceX96);
  const raw = (sqrtPriceX96 * sqrtPriceX96) / Math.pow(2,192);
  const price1Per0 = raw * Math.pow(10,t0.decimals - t1.decimals);

  const result = {
    type:"v3",
    address,
    token0:t0,
    token1:t1,
    price0:price1Per0,
    price1:1/price1Per0,
    liquidity:liquidity.toString(),
    fee:Number(fee)
  };

  v3PoolCache.set(cacheKey,result);
  return result;
}

/* =========================================================
   TOKEN OVERVIEW
========================================================= */
async function renderTokenTable(chain){
  const body = document.getElementById(chain+"TokenBody");
  const tokens = configuredTokens(chain);

  body.innerHTML = '<tr><td colspan="4" class="loading">Tokens werden geladen…</td></tr>';

  const rendered = [];

  for(const row of tokens){
    try{
      const token = await getToken(chain,row.address);
      const price = await getUSD(chain,token);
      if(price) exportProjectPrice(chain,token.address,price,"token");
      rendered.push({row,token,price});
    }catch(e){
      console.error("Tokenfehler",row.address,e);
    }
  }

  rendered.sort((a,b)=>a.token.symbol.localeCompare(b.token.symbol));
  body.innerHTML = "";

  for(const item of rendered){
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>
        <div class="pair">${item.token.symbol}</div>
        <div class="small">${displayTokenLabel(item.row,item.token)}</div>
      </td>
      <td><div class="address">${item.token.address}</div></td>
      <td><div class="usd">${item.price ? usd(item.price.price) : "nicht verfügbar"}</div></td>
      <td>${item.price
        ? `<div class="route">${item.price.route}</div>
           ${Number.isFinite(item.price.pathLiquidityUSD)
             ? `<div class="small">Pfad-Liquidität: ${usd(item.price.pathLiquidityUSD)}</div>`
             : `<div class="small">Pfad-Liquidität: nicht aus V2-Reserven messbar</div>`}`
        : `<span class="error">Keine Preisroute gefunden</span>`}
      </td>`;
    body.appendChild(tr);
  }

  document.getElementById(chain+"TokenCount").textContent = rendered.length;
}

/* =========================================================
   V2 WALLET
========================================================= */

/* =========================================================
   RENDER V2
========================================================= */
async function renderV2Pool(chain,dbPool,wallet){
  const pool = await readV2Pool(chain,dbPool.address);
  const [price0,price1] = await Promise.all([
    getUSD(chain,pool.token0),
    getUSD(chain,pool.token1)
  ]);

  const value0 = price0 ? pool.r0*price0.price : null;
  const value1 = price1 ? pool.r1*price1.price : null;
  const tvl = value0 !== null && value1 !== null ? value0+value1 : null;
  const lpPrice = tvl !== null && pool.lpSupply > 0 ? tvl/pool.lpSupply : null;

  if(price0) exportProjectPrice(chain,pool.token0.address,price0,"token");
  if(price1) exportProjectPrice(chain,pool.token1.address,price1,"token");
  if(lpPrice !== null && Number.isFinite(lpPrice)){
    exportedPrices.set(chain + "|" + norm(dbPool.address), {
      price:lpPrice,
      change24h:undefined,
      source:"Projekt TLN/VOW · LP",
      route:`TVL / LP-Supply`,
      kind:"lp",valuationBasis:{type:"lp",pool:norm(dbPool.address),token0:norm(pool.token0.address),token1:norm(pool.token1.address),price0:exportedPrices.get(chain+"|"+norm(pool.token0.address))?.valuationBasis,price1:exportedPrices.get(chain+"|"+norm(pool.token1.address))?.valuationBasis}
    });
  }


  const tr = document.createElement("tr");
  tr.innerHTML = `
    <td>
      <div class="badge">${displayPoolLabel(dbPool,pool)}</div>
      <div class="pair">${pool.token0.symbol} / ${pool.token1.symbol}</div>
      <div class="address">${pool.address}</div>
      <div class="small">LP Token: ${pool.lpSymbol}</div>
    </td>
    <td>
      <b>${pool.token0.symbol}</b>
      <div class="small">${pool.token0.name}</div>
      <div class="address">${pool.token0.address}</div>
    </td>
    <td>
      <b>${pool.token1.symbol}</b>
      <div class="small">${pool.token1.name}</div>
      <div class="address">${pool.token1.address}</div>
    </td>
    <td>
      ${formatTokenAmount(pool.r0,pool.token0.symbol)} ${pool.token0.symbol}<br>
      ${formatTokenAmount(pool.r1,pool.token1.symbol)} ${pool.token1.symbol}
    </td>
    <td>
      <div class="price">${fmt(pool.r1/pool.r0,12)}</div>
      <div class="small">${pool.token1.symbol}/${pool.token0.symbol}</div>
      <hr>
      <div class="price">${fmt(pool.r0/pool.r1,12)}</div>
      <div class="small">${pool.token0.symbol}/${pool.token1.symbol}</div>
    </td>
    <td>
      <div class="usd">${price0 ? usd(price0.price) : "nicht verfügbar"}</div>
      <div class="small">${pool.token0.symbol}</div>
      ${price0 ? `<div class="route">${price0.route}</div>${Number.isFinite(price0.pathLiquidityUSD)?`<div class="small">Pfad-Liq.: ${usd(price0.pathLiquidityUSD)}</div>`:""}` : ""}
      <hr>
      <div class="usd">${price1 ? usd(price1.price) : "nicht verfügbar"}</div>
      <div class="small">${pool.token1.symbol}</div>
      ${price1 ? `<div class="route">${price1.route}</div>${Number.isFinite(price1.pathLiquidityUSD)?`<div class="small">Pfad-Liq.: ${usd(price1.pathLiquidityUSD)}</div>`:""}` : ""}
    </td>
    <td>
      <div class="tvl">${tvl !== null ? usd(tvl) : "nicht verfügbar"}</div>
      <div class="small">
        ${pool.token0.symbol}: ${value0 !== null ? usd(value0) : "-"}<br>
        ${pool.token1.symbol}: ${value1 !== null ? usd(value1) : "-"}
      </div>
    </td>
    <td>
      <div class="lp">${lpPrice !== null ? usd(lpPrice) : "nicht verfügbar"}</div>
      <div class="small" title="Poolwert in USD geteilt durch die gesamte LP-Tokenmenge">USD je 1 LP-Token</div>
      <hr>
      <div class="small">Supply: ${formatTokenAmount(pool.lpSupply,pool.lpSymbol,{kind:"lp"})} ${pool.lpSymbol}</div>
      <div class="small">
        1 LP enthält:<br>
        ${pool.lpSupply ? formatTokenAmount(pool.r0/pool.lpSupply,pool.token0.symbol) : "-"} ${pool.token0.symbol}<br>
        ${pool.lpSupply ? formatTokenAmount(pool.r1/pool.lpSupply,pool.token1.symbol) : "-"} ${pool.token1.symbol}
      </div>
    </td>
  `;

  return {
    row:tr,
    tvl:tvl || 0
  };
}

/* =========================================================
   RENDER V3
========================================================= */
async function renderV3Pool(chain,dbPool){
  const pool = await readV3Pool(chain,dbPool.address);
  const [price0,price1] = await Promise.all([
    getUSD(chain,pool.token0),
    getUSD(chain,pool.token1)
  ]);
  if(price0) exportProjectPrice(chain,pool.token0.address,price0,"token");
  if(price1) exportProjectPrice(chain,pool.token1.address,price1,"token");

  const tr = document.createElement("tr");
  tr.innerHTML = `
    <td>
      <div class="badge">${displayPoolLabel(dbPool,pool)}</div>
      <div class="pair">${pool.token0.symbol} / ${pool.token1.symbol}</div>
      <div class="address">${pool.address}</div>
      <div class="small">Uniswap V3 · Fee ${(pool.fee/10000).toFixed(2)}%</div>
    </td>
    <td>
      <b>${pool.token0.symbol}</b>
      <div class="small">${pool.token0.name}</div>
      <div class="address">${pool.token0.address}</div>
    </td>
    <td>
      <b>${pool.token1.symbol}</b>
      <div class="small">${pool.token1.name}</div>
      <div class="address">${pool.token1.address}</div>
    </td>
    <td>
      <div class="small">Current liquidity</div>
      <div class="price">${pool.liquidity}</div>
      <div class="small">V3-Liquidität ist tick-/positionsabhängig.</div>
    </td>
    <td>
      <div class="price">${fmt(pool.price0,12)}</div>
      <div class="small">${pool.token1.symbol}/${pool.token0.symbol}</div>
      <hr>
      <div class="price">${fmt(pool.price1,12)}</div>
      <div class="small">${pool.token0.symbol}/${pool.token1.symbol}</div>
    </td>
    <td>
      <div class="usd">${price0 ? usd(price0.price) : "nicht verfügbar"}</div>
      <div class="small">${pool.token0.symbol}</div>
      ${price0 ? `<div class="route">${price0.route}</div>${Number.isFinite(price0.pathLiquidityUSD)?`<div class="small">Pfad-Liq.: ${usd(price0.pathLiquidityUSD)}</div>`:""}` : ""}
      <hr>
      <div class="usd">${price1 ? usd(price1.price) : "nicht verfügbar"}</div>
      <div class="small">${pool.token1.symbol}</div>
      ${price1 ? `<div class="route">${price1.route}</div>${Number.isFinite(price1.pathLiquidityUSD)?`<div class="small">Pfad-Liq.: ${usd(price1.pathLiquidityUSD)}</div>`:""}` : ""}
    </td>
    <td>
      <div class="warning">V3</div>
      <div class="small">Keine einfache V2-Reserve-TVL. Für exakte V3-TVL müssten die aktiven NFT-Positionen/Ticks ausgewertet werden.</div>
    </td>
    <td>
      <div class="lp">Kein LP-Token</div>
      <div class="small">Uniswap V3 verwendet NFT-Liquiditätspositionen.</div>
    </td>
    `;

  return {row:tr,tvl:0};
}

/* =========================================================
   POOL TABLE
========================================================= */
async function renderPools(chain){
  const body = document.getElementById(chain+"PoolBody");
  const pools = configuredLPs(chain);

  body.innerHTML = '<tr><td colspan="8" class="loading">Pools werden geladen…</td></tr>';

  let totalTVL = 0;
  let processed = 0;
  body.innerHTML = "";

  if(!pools.length){
    body.innerHTML = '<tr><td colspan="8" class="note">Für diese Chain sind in Supabase noch keine TLN/VOW-Liquidity-Pools als <code>lp_token</code> konfiguriert.</td></tr>';
    document.getElementById(chain+"PoolCount").textContent = "0";
    document.getElementById(chain+"TVL").textContent = "-";
    return;
  }

  for(const dbPool of pools){
    const loading = document.createElement("tr");
    loading.innerHTML = `<td colspan="8" class="loading">${dbPool.label || dbPool.address}<br>lese Blockchain-Daten…</td>`;
    body.appendChild(loading);

    try{
      const type = await detectPoolType(chain,dbPool.address);
      const result = type === "v3"
        ? await renderV3Pool(chain,dbPool)
        : await renderV2Pool(chain,dbPool,null);

      body.replaceChild(result.row,loading);
      totalTVL += result.tvl;
      processed++;
    }catch(e){
      console.error("Poolfehler",dbPool.address,e);
      loading.innerHTML = `
        <td colspan="8" class="error">
          <b>${dbPool.label || "Pool"}</b><br>
          ${dbPool.address}<br><br>
          ${e.message}
        </td>`;
    }
  }

  document.getElementById(chain+"PoolCount").textContent = processed;
  document.getElementById(chain+"TVL").textContent = totalTVL ? usd(totalTVL) : "-";
}

/* =========================================================
   DASHBOARD LOAD / DAILY PRICE CACHE
========================================================= */
async function renderDashboard(chain,{cacheMode=false}={}){
  const status=document.getElementById(chain+"Status");
  try{
    document.getElementById(chain+"Summary").style.display="grid";
    const ref=references[chain] || {};
    const stableRefs=[ref.usdt?"USDT":null,ref.usdc?"USDC":null,chain==="bsc"&&ref.busd?"BUSD":null].filter(Boolean);
    status.innerHTML=stableRefs.length
      ? `<span class="success">${cacheMode?"Preis-/Poolstand aus globalem Cache":"Referenzen erkannt"}: ${stableRefs.join(", ")}.</span>`
      : `<span class="warning">Kein USDT/USDC${chain==="bsc"?"/BUSD":""}-Referenzasset erkannt.</span>`;
    await renderTokenTable(chain);
    await renderPools(chain);
    status.innerHTML=`<span class="success">Fertig · ${configuredTokens(chain).length} Tokens · ${configuredLPs(chain).length} LP/Pool-Einträge${cacheMode?" · globaler Cache":" · on-chain aktualisiert"}.</span>`;
  }catch(e){
    console.error(e);
    status.innerHTML=`<span class="error">${e.message}</span>`;
    throw e;
  }
}

async function buildCurrentProjectPrices(chain){
  const tokens=configuredTokens(chain);
  await Promise.all(tokens.map(async row=>{
    try{
      const token=await getToken(chain,row.address);
      const price=await getUSD(chain,token);
      if(price) exportProjectPrice(chain,token.address,price,"token");
    }catch(e){ console.warn("TLN/VOW Preisaufbau Token",chain,row.address,e); }
  }));

  // LP-Preise ohne Tabellen-Render berechnen. So liest der globale 15-Minuten-Job
  // die Chain-Facts genau einmal; ein späteres Öffnen des Projekttabs nutzt dieselben Caches.
  await Promise.all(configuredLPs(chain).map(async dbPool=>{
    try{
      const type=await detectPoolType(chain,dbPool.address);
      if(type==="v3"){
        const pool=await readV3Pool(chain,dbPool.address);
        const [p0,p1]=await Promise.all([getUSD(chain,pool.token0),getUSD(chain,pool.token1)]);
        if(p0) exportProjectPrice(chain,pool.token0.address,p0,"token");
        if(p1) exportProjectPrice(chain,pool.token1.address,p1,"token");
        return;
      }
      const pool=await readV2Pool(chain,dbPool.address);
      const [p0,p1]=await Promise.all([getUSD(chain,pool.token0),getUSD(chain,pool.token1)]);
      if(p0) exportProjectPrice(chain,pool.token0.address,p0,"token");
      if(p1) exportProjectPrice(chain,pool.token1.address,p1,"token");
      if(p0 && p1 && pool.lpSupply>0){
        const tvl=pool.r0*p0.price + pool.r1*p1.price;
        const lpPrice=tvl/pool.lpSupply;
        if(Number.isFinite(lpPrice)) exportedPrices.set(chain+"|"+norm(dbPool.address),{
          price:lpPrice,change24h:undefined,source:"Projekt TLN/VOW · LP",route:"TVL / LP-Supply",kind:"lp",valuationBasis:{type:"lp",pool:norm(dbPool.address),token0:norm(pool.token0.address),token1:norm(pool.token1.address),price0:exportedPrices.get(chain+"|"+norm(pool.token0.address))?.valuationBasis,price1:exportedPrices.get(chain+"|"+norm(pool.token1.address))?.valuationBasis}
        });
      }
    }catch(e){ console.warn("TLN/VOW Preisaufbau Pool",chain,dbPool.address,e); }
  }));
}

async function refreshCurrentPrices({manual=false,render=true}={}){
  if(priceRefreshPromise) return priceRefreshPromise;
  priceRefreshPromise=(async()=>{
    setPriceRefreshBusy(true);
    setPriceStatus(manual?"Aktuelle Preise werden manuell neu ermittelt…":"Aktuelle Projektpreise werden on-chain ermittelt…","loading");
    priceRpcStats.reset();
    const diagnostics={stages:{}};
    await measureProjectPriceStage(diagnostics,"infrastructure",()=>ensureInfrastructure());
    resetCurrentPriceCaches();
    const chains=projectChains.filter(c=>["bsc","eth"].includes(c));
    // Fachlogik unverändert: 7.01 misst nur die bereits bestehenden Stufen tiefer.
    await measureProjectPriceStage(diagnostics,"configuredPoolTypes",()=>Promise.all(chains.map(chain=>prefetchConfiguredPoolTypes(chain))));
    await measureProjectPriceStage(diagnostics,"configuredPairStates",()=>Promise.all(chains.map(chain=>prefetchConfiguredV2PairStates(chain))));
    await measureProjectPriceStage(diagnostics,"references",async()=>{for(const chain of chains)await resolveReferences(chain);});
    await measureProjectPriceStage(diagnostics,"pairDiscovery",()=>Promise.all(chains.map(chain=>prefetchV2PairDiscovery(chain))));
    await measureProjectPriceStage(diagnostics,"discoveredPairStates",()=>Promise.all(chains.map(chain=>prefetchDiscoveredV2PairStates(chain))));
    await measureProjectPriceStage(diagnostics,"priceBuild",()=>Promise.all(chains.map(chain=>buildCurrentProjectPrices(chain))));
    if(render)await measureProjectPriceStage(diagnostics,"render",()=>Promise.all(chains.map(chain=>renderDashboard(chain,{cacheMode:false}))));
    const saved=await measureProjectPriceStage(diagnostics,"snapshotSave",()=>saveCurrentPriceSnapshot());
    currentPriceSource="live";
    const stamp=formatPriceTimestamp(currentPriceCapturedAt || new Date());
    setPriceStatus(saved
      ? `Preisstand: ${stamp} · aktuell on-chain · in Supabase gespeichert.`
      : `Preisstand: ${stamp} · aktuell on-chain · Supabase-Preiscache konnte nicht gespeichert werden.`,
      saved?"success":"warning");
    notifyCurrentPricesUpdated(manual);
    diagnostics.total=priceRpcStats.snapshot();
    diagnostics.totalStageRequests=Object.values(diagnostics.stages).reduce((n,x)=>n+Number(x.requests||0),0);
    console.info("TLN/VOW Preisrefresh abgeschlossen",{render,prices:exportedPrices.size,pairs:pairCache.size,rpc:diagnostics.total,engine:window.WalletPriceEngine?.stats?.()||null,diagnostics});
    try{console.table(Object.fromEntries(Object.entries(diagnostics.stages).map(([k,v])=>[k,{ms:v.elapsedMs,requests:v.requests,ethCalls:v.rpc?.ethCalls||0,bsc:v.rpc?.byChain?.bsc?.ethCalls||0,eth:v.rpc?.byChain?.eth?.ethCalls||0,httpBatches:v.rpc?.httpBatchRequests||0,topResource:Object.keys(v.topResources||{})[0]||"–"}])));}catch(_){ }
    return true;
  })().finally(()=>{setPriceRefreshBusy(false);priceRefreshPromise=null;});
  return priceRefreshPromise;
}

async function loadDailyPrices(){
  await ensureInfrastructure();
  setPriceStatus("Prüfe gespeicherten Preisstand in Supabase…","loading");
  const cached=await loadCurrentPriceSnapshot();
  if(cached?.fresh && hydrateCurrentPriceSnapshot(cached.payload)){
    currentPriceCapturedAt=cached.capturedAt;
    currentPriceSource="supabase";
    await Promise.all(projectChains.filter(c=>["bsc","eth"].includes(c)).map(chain=>renderDashboard(chain,{cacheMode:true})));
    setPriceStatus(`Preisstand: ${formatPriceTimestamp(currentPriceCapturedAt)} · aus globalem Supabase-Cache.`,`success`);
    notifyCurrentPricesUpdated(false);
    return true;
  }
  return await refreshCurrentPrices({manual:false});
}

/* =========================================================
   VOW / v$ · HANDELSANALYSE
   - Token-Transfer-basierte Discovery plus echte Swap-Events verifizierter V2/V3-DEX-Pools
   - Händler = transaction.from (Router-/Aggregator-Sender wird damit
     nicht fälschlich als Wallet aus dem Swap-Event übernommen)
   - TLN-ID nur aus bereits verifiziertem globalem Identity-Cache
========================================================= */
const TRADE_V2_SWAP_IFACE = new ethers.Interface([
  "event Swap(address indexed sender,uint256 amount0In,uint256 amount1In,uint256 amount0Out,uint256 amount1Out,address indexed to)"
]);
const TRADE_V3_SWAP_IFACE = new ethers.Interface([
  "event Swap(address indexed sender,address indexed recipient,int256 amount0,int256 amount1,uint160 sqrtPriceX96,uint128 liquidity,int24 tick)"
]);
const TRADE_V2_SWAP_TOPIC = ethers.id("Swap(address,uint256,uint256,uint256,uint256,address)");
const TRADE_V3_SWAP_TOPIC = ethers.id("Swap(address,address,int256,int256,uint160,uint128,int24)");
const TRADE_WINDOWS = [
  {key:"24h",label:"Letzte 24 h",seconds:24*60*60},
  {key:"7d",label:"Letzte 7 Tage",seconds:7*24*60*60},
  {key:"30d",label:"Letzte 30 Tage",seconds:30*24*60*60}
];
const tradingState={promise:null,data:null,loadedAt:0};
// Verifizierte Zielcontracts, nicht Token-Symbol-Heuristik.
const TRADING_CONTRACTS={
  bsc:{
    "0xf585b5b4f22816baf7629aea55b701662630397b":"vow",
    "0x9c23942ca2c35e06d1d20747f33705983a18d2ab":"vdollar"
  },
  eth:{
    "0x1bbf25e71ec48b84d773809b4ba55b6f4be946fb":"vow",
    "0xba7fe208e0167e4047a996e1efea830515f433f8":"vdollar",
    "0x6c559d849f70477723dc94405018a436fa9fdc12":"vdollar"
  }
};
const TRADING_CACHE_TABLE="tln_vow_trade_cache";
const TRADING_STATE_TABLE="tln_vow_trade_scan_state";
const TRADING_SCHEMA_VERSION=5;
const TRADING_TRANSFER_TOPIC=ethers.id("Transfer(address,address,uint256)");
const TRADING_DISCOVERY_CHUNK={bsc:1200,eth:2000};
const TRADING_REFRESH_MS=5*60*1000;
const TRADING_RETENTION_SECONDS=30*24*60*60;
async function tradingAuthUser(){
  const {data,error}=await sb.auth.getUser();
  if(error||!data?.user?.id)throw new Error("Für den Handels-Cache bitte anmelden.");
  return data.user.id;
}
async function tradingReadCache(userId){
  const limitTime=new Date(Date.now()-TRADING_RETENTION_SECONDS*1000).toISOString();
  const events=[];
  for(let offset=0;;offset+=1000){
    const {data,error}=await sb.from(TRADING_CACHE_TABLE)
      .select("chain_key,pool_address,tx_hash,log_index,token_key,side,amount,wallet_address,block_number,block_time")
      .eq("user_id",userId).gte("block_time",limitTime)
      .order("block_time",{ascending:false}).range(offset,offset+999);
    if(error)throw new Error(`Handels-Cache lesen: ${error.message}`);
    for(const row of data||[])events.push({chain:row.chain_key,pool:row.pool_address,txHash:row.tx_hash,
      logIndex:Number(row.log_index),token:row.token_key,side:row.side,amount:Number(row.amount),
      wallet:row.wallet_address,blockNumber:Number(row.block_number),timestamp:Math.floor(Date.parse(row.block_time)/1000)});
    if((data||[]).length<1000)break;
  }
  return events;
}
async function tradingReadScanState(userId){
  const {data,error}=await sb.from(TRADING_STATE_TABLE)
    .select("chain_key,group_key,last_scanned_block,updated_at")
    .eq("user_id",userId).eq("schema_version",TRADING_SCHEMA_VERSION);
  if(error)throw new Error(`Handels-Scanstatus lesen: ${error.message}`);
  return new Map((data||[]).map(r=>[`${r.chain_key}|${r.group_key}`,r]));
}
async function tradingSaveScanState(userId,chain,group,block){
  const {error}=await sb.from(TRADING_STATE_TABLE).upsert({user_id:userId,chain_key:chain,
    group_key:group,schema_version:TRADING_SCHEMA_VERSION,last_scanned_block:block,
    updated_at:new Date().toISOString()}, {onConflict:"user_id,chain_key,group_key"});
  if(error)throw new Error(`Handels-Scanstatus schreiben: ${error.message}`);
}
async function tradingWriteEvents(userId,events){
  for(let offset=0;offset<events.length;offset+=250){
    const chunk=events.slice(offset,offset+250).map(e=>({user_id:userId,chain_key:e.chain,
      pool_address:e.pool,tx_hash:e.txHash,log_index:e.logIndex,token_key:e.token,side:e.side,
      amount:String(e.amount),wallet_address:e.wallet,block_number:e.blockNumber,
      block_time:new Date(e.timestamp*1000).toISOString()}));
    const {error}=await sb.from(TRADING_CACHE_TABLE).upsert(chunk,{
      onConflict:"user_id,chain_key,tx_hash,log_index,token_key,side"});
    if(error)throw new Error(`Handels-Cache schreiben: ${error.message}`);
  }
}
async function tradingPrune(userId){
  const cutoff=new Date(Date.now()-TRADING_RETENTION_SECONDS*1000).toISOString();
  const {error}=await sb.from(TRADING_CACHE_TABLE).delete().eq("user_id",userId).lt("block_time",cutoff);
  if(error)console.warn("Handels-Cache Bereinigung",error);
}
async function tradingBatchBlockTimes(chain,blockNumbers){
  const unique=[...new Set(blockNumbers)].sort((a,b)=>a-b),map=new Map();
  for(let off=0;off<unique.length;off+=50){
    const part=unique.slice(off,off+50),controller=new AbortController();
    const timeout=setTimeout(()=>controller.abort(),18000);
    try{
      const result=await fetch(CONFIG[chain]?.rpc,{method:"POST",headers:{"content-type":"application/json"},
        body:JSON.stringify(part.map((b,i)=>({jsonrpc:"2.0",id:i+1,method:"eth_getBlockByNumber",params:[tradingBlockHex(b),false]}))),signal:controller.signal});
      if(!result.ok)throw new Error(`${chain}: Blockzeit HTTP ${result.status}`);
      const raw=await result.json();
      if(!Array.isArray(raw))throw new Error(`${chain}: Blockzeit-Batchformat`);
      const byId=new Map(raw.map(v=>[Number(v.id),v]));
      for(let i=0;i<part.length;i++){
        const ts=byId.get(i+1)?.result?.timestamp;
        if(!ts)throw new Error(`${chain}: Blockzeit für Block ${part[i]} fehlt`);
        map.set(part[i],Number(BigInt(ts)));
      }
    }finally{clearTimeout(timeout);}
  }
  return map;
}
function tradingUpdateFromEvents(events,cutoffs,identity,poolCounts,capturedAt){
  tradingState.data={events,cutoffs,identity,poolCounts,summary:tradingAggregate(events,cutoffs),capturedAt};
  tradingState.loadedAt=Date.now();renderTradingSummary();renderTradingTraders();
}


function tradingTargetKey(token){
  const symbol=String(token?.symbol||"").trim().toUpperCase().replace(/[^A-Z0-9]/g,"");
  if(symbol==="VOW")return "vow";
  if(symbol==="V" || symbol==="V$")return "vdollar";
  return null;
}
function tradingTargetLabel(key){return key==="vow"?"VOW":"v$";}
function tradingShortAddress(address){const a=String(address||"");return a&&a.length>14?`${a.slice(0,8)}…${a.slice(-6)}`:(a||"–");}
function tradingFormatAmount(value){
  const n=Number(value||0);
  if(!Number.isFinite(n))return "–";
  return n.toLocaleString("de-CH",{maximumFractionDigits:n>=1000?2:n>=1?4:6});
}
function tradingSetStatus(text,type=""){
  const el=document.getElementById("tlnTradingStatus");
  if(!el)return;
  el.className=type?`status ${type}`:"status";
  el.innerHTML=type==="loading"?`<span class="loading">${text}</span>`:text;
}
function tradingBlockHex(n){return "0x"+Math.max(0,Number(n)||0).toString(16);}
async function tradingRpc(chain,method,params=[]){
  const rpc=CONFIG[chain]?.rpc;
  if(!rpc)throw new Error(`${chain}: RPC fehlt.`);
  const controller=new AbortController();
  const timeout=setTimeout(()=>controller.abort(),18000);
  try{
    const response=await fetch(rpc,{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({jsonrpc:"2.0",id:1,method,params}),signal:controller.signal});
    if(!response.ok)throw new Error(`${chain}: RPC HTTP ${response.status}`);
    const json=await response.json();
    if(json?.error)throw new Error(`${chain}: ${json.error.message||"RPC-Fehler"}`);
    if(json?.result==null)throw new Error(`${chain}: ${method} ohne Ergebnis`);
    return json.result;
  }catch(e){
    if(e?.name==="AbortError")throw new Error(`${chain}: ${method} Timeout (18 s)`);
    throw e;
  }finally{clearTimeout(timeout);}
}
async function tradingBlockTimestamp(chain,blockNumber){
  const raw=await tradingRpc(chain,"eth_getBlockByNumber",[tradingBlockHex(blockNumber),false]);
  if(!raw?.timestamp)throw new Error(`${chain}: Blockzeit nicht lesbar.`);
  return Number(BigInt(raw.timestamp));
}
async function tradingFindBlockAtOrAfter(chain,targetTs,latestBlock,latestTs){
  if(targetTs>=latestTs)return latestBlock;
  let lo=0,hi=latestBlock;
  // Grobe Untergrenze reduziert die Binärsuche und vermeidet unnötig alte Blöcke.
  const avg=chain==="bsc"?3:12;
  lo=Math.max(0,latestBlock-Math.ceil((latestTs-targetTs)/avg)-5000);
  const loTs=await tradingBlockTimestamp(chain,lo).catch(()=>0);
  if(loTs>targetTs)lo=0;
  while(lo<hi){
    const mid=Math.floor((lo+hi)/2);
    const ts=await tradingBlockTimestamp(chain,mid);
    if(ts<targetTs)lo=mid+1;else hi=mid;
  }
  return lo;
}
async function tradingGetLogsRange(chain,addresses,topic,fromBlock,toBlock,progress){
  // Filtert alle relevanten Pools in EINER Log-Abfrage; das spart pro Chunk
  // bis zu N identische Blockbereichsscans bei vielen TLN/VOW-Pools.
  const out=[];
  let start=fromBlock;
  const maxChunk=chain==="bsc"?2000:2000;
  let chunk=maxChunk;
  const minChunk=100;
  let requests=0;
  while(start<=toBlock){
    const end=Math.min(toBlock,start+chunk-1);
    try{
      const rows=await tradingRpc(chain,"eth_getLogs",[{address:addresses,fromBlock:tradingBlockHex(start),toBlock:tradingBlockHex(end),topics:[topic]}]);
      if(!Array.isArray(rows))throw new Error(`${chain}: eth_getLogs lieferte kein Array`);
      out.push(...rows);
      start=end+1;
      requests++;
      if(progress&&(requests===1||requests%5===0||start>toBlock))progress({block:Math.min(end,toBlock),fromBlock,toBlock,count:out.length,requests});
      if(chunk<maxChunk)chunk=Math.min(maxChunk,Math.ceil(chunk*1.25));
    }catch(e){
      if(chunk<=minChunk)throw new Error(`${chain}: Log-Scan bei Block ${start} gescheitert: ${String(e?.message||e)}`);
      chunk=Math.max(minChunk,Math.floor(chunk/2));
    }
  }
  return out;
}
async function tradingBatchTransactionSenders(chain,hashes){
  const unique=[...new Set((hashes||[]).filter(Boolean))];
  const map=new Map();
  const rpc=CONFIG[chain]?.rpc;
  for(let offset=0;offset<unique.length;offset+=80){
    const slice=unique.slice(offset,offset+80);
    const payload=slice.map((hash,i)=>({jsonrpc:"2.0",id:i+1,method:"eth_getTransactionByHash",params:[hash]}));
    const controller=new AbortController();
    const timeout=setTimeout(()=>controller.abort(),18000);
    let json;
    try{
      const response=await fetch(rpc,{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify(payload),signal:controller.signal});
      if(!response.ok)throw new Error(`${chain}: Transaktions-Batch HTTP ${response.status}`);
      json=await response.json();
    }finally{clearTimeout(timeout);}
    if(!Array.isArray(json))throw new Error(`${chain}: Batch-Antwort nicht vollständig`);
    const rows=Array.isArray(json)?json:[json];
    const byId=new Map(rows.map(x=>[Number(x.id),x]));
    slice.forEach((hash,i)=>{
      const tx=byId.get(i+1)?.result;
      if(tx?.from&&ethers.isAddress(tx.from))map.set(hash,norm(tx.from));
    });
  }
  return map;
}
// Token-adressbasierte Pool-Discovery. Ein Scan der ERC20-Transfer-Logs findet
// auch ältere, nicht in defi_project_tokens eingetragene DEX-Pools, sofern sie
// innerhalb des Fensters mit VOW/v$ interagiert haben. Nur verifizierte V2/V3
// Pools bekannter Factories werden als Handelsplätze aufgenommen.
async function tradingTokenContracts(chain){
  const targets=new Map(Object.entries(TRADING_CONTRACTS[chain]||{}));
  if(!targets.size)throw new Error(`${chain}: Keine verifizierten Handelscontracts konfiguriert`);
  for(const [address,key] of targets){
    try{
      const token=await getToken(chain,address);
      if(!token||!ethers.isAddress(token.address))throw new Error("Token-Metadaten fehlen");
    }catch(e){
      console.warn("Handel: Zielcontract-Metadaten nicht geladen",chain,address,e);
    }
  }
  return targets;
}

async function tradingVerifyCandidatePool(chain,address,targetTokens){
  if(!ethers.isAddress(address)||targetTokens.has(norm(address)))return null;
  const a=norm(address);
  try{
    const type=await detectPoolType(chain,a);
    const pool=type==="v3"?await readV3Pool(chain,a):await readV2Pool(chain,a);
    const target0=targetTokens.get(norm(pool.token0.address))||null;
    const target1=targetTokens.get(norm(pool.token1.address))||null;
    if(!target0&&!target1)return null;
    return {chain,address:a,type,token0:pool.token0,token1:pool.token1,
      target0,target1,label:`Entdeckt: ${pool.token0.symbol}/${pool.token1.symbol}`};
  }catch{return null;}
}
// EOAs werden in einem einzigen JSON-RPC-Batch ausgesiebt. Andernfalls
// würde für jeden normalen Tokenempfänger ein teures factory() versucht.
async function tradingContractAddresses(chain,addresses){
  const result=[];
  const rpc=CONFIG[chain]?.rpc;
  for(let i=0;i<addresses.length;i+=75){
    const batch=addresses.slice(i,i+75);
    const controller=new AbortController();
    const timer=setTimeout(()=>controller.abort(),18000);
    try{
      const response=await fetch(rpc,{method:"POST",headers:{"content-type":"application/json"},
        body:JSON.stringify(batch.map((a,j)=>({jsonrpc:"2.0",id:j+1,method:"eth_getCode",params:[a,"latest"]}))),signal:controller.signal});
      if(!response.ok)throw new Error(`${chain}: Code-Prüfung HTTP ${response.status}`);
      const values=await response.json();
      if(!Array.isArray(values))throw new Error(`${chain}: Code-Batchantwort fehlt`);
      const byId=new Map(values.map(x=>[Number(x.id),x]));
      for(let j=0;j<batch.length;j++){
        const item=byId.get(j+1);
        if(item?.error)throw new Error(`${chain}: Code-Prüfung ${item.error.message||"RPC-Fehler"}`);
        if(!item||typeof item.result!=="string")throw new Error(`${chain}: Code-Batch unvollständig`);
        if(item.result!=="0x"&&item.result!=="0x0")result.push(batch[j]);
      }
    }finally{clearTimeout(timer);}
  }
  return result;
}
async function tradingDiscoverPools(chain,userId,states,firstBlock,latestBlock,targetTokens,knownPools){
  const poolMap=new Map(knownPools.map(p=>[p.address,p]));
  // Bereits bestätigte Pools aus persistentem Scan-State wiederherstellen:
  // andernfalls würde ein inzwischen ruhender Pool nach dem Reload verschwinden.
  for(const key of states.keys()){
    const prefix=`${chain}|pool:`;
    if(!key.startsWith(prefix))continue;
    const address=key.split(":").at(-1);
    if(!ethers.isAddress(address)||poolMap.has(norm(address)))continue;
    const pool=await tradingVerifyCandidatePool(chain,address,targetTokens);
    if(pool)poolMap.set(norm(address),pool);
  }
  const tested=new Set(poolMap.keys());
  const zero="0x0000000000000000000000000000000000000000";
  for(const token of targetTokens.keys()){
    const group=`discover:${token}`;
    const previous=states.get(`${chain}|${group}`);
    let current=Math.max(firstBlock,previous?Number(previous.last_scanned_block)-20:firstBlock);
    let span=TRADING_DISCOVERY_CHUNK[chain]||1200;
    while(current<=latestBlock){
      const end=Math.min(latestBlock,current+span-1);
      let logs;
      try{
        logs=await tradingRpc(chain,"eth_getLogs",[{address:token,
          fromBlock:tradingBlockHex(current),toBlock:tradingBlockHex(end),
          topics:[TRADING_TRANSFER_TOPIC]}]);
        if(!Array.isArray(logs))throw new Error("Transfer-Logs ohne Array");
      }catch(e){
        if(span>100){span=Math.max(100,Math.floor(span/2));continue;}
        throw new Error(`${chain}: Token-Discovery Block ${current}: ${String(e.message||e)}`);
      }
      const candidateSet=new Set();
      for(const log of logs){
        if(!log.topics||log.topics.length<3)continue;
        for(const topic of [log.topics[1],log.topics[2]]){
          const addr=norm("0x"+topic.slice(-40));
          if(addr!==zero&&!targetTokens.has(addr)&&!tested.has(addr))candidateSet.add(addr);
        }
      }
      // Alle einmalig auftretenden Gegenparteien werden ebenfalls geprüft.
      // Ohne diese Prüfung könnte ein illiquider Pool übersehen werden.
      const candidates=[...candidateSet];
      const contractAddresses=await tradingContractAddresses(chain,candidates);
      for(const address of candidates)tested.add(address);
      for(const address of contractAddresses){
        const pool=await tradingVerifyCandidatePool(chain,address,targetTokens);
        if(pool)poolMap.set(address,pool);
      }
      // Checkpoint nach vollständiger Verarbeitung der Logs UND Kandidaten.
      await tradingSaveScanState(userId,chain,group,end);
      states.set(`${chain}|${group}`,{last_scanned_block:end});
      current=end+1;
      const pct=Math.floor((end-firstBlock+1)/Math.max(1,latestBlock-firstBlock+1)*100);
      tradingSetStatus(`${chain.toUpperCase()} · Token-Pool-Discovery ${pct}% · ${poolMap.size} bestätigte Pools · ${logs.length} Transfers im Abschnitt · Checkpoint gespeichert`,"loading");
      if(span<TRADING_DISCOVERY_CHUNK[chain])span=Math.min(TRADING_DISCOVERY_CHUNK[chain],Math.ceil(span*1.2));
    }
  }
  return [...poolMap.values()];
}
async function tradingLoadPools(chain){
  const pools=[];
  for(const row of configuredLPs(chain)){
    if(!row?.address||!ethers.isAddress(row.address))continue;
    try{
      const type=await detectPoolType(chain,row.address);
      const pool=type==="v3"?await readV3Pool(chain,row.address):await readV2Pool(chain,row.address);
      const allowed=TRADING_CONTRACTS[chain]||{};
      const k0=allowed[norm(pool.token0.address)]||null,k1=allowed[norm(pool.token1.address)]||null;
      if(!k0&&!k1)continue;
      pools.push({chain,address:norm(row.address),type,token0:pool.token0,token1:pool.token1,target0:k0,target1:k1,label:displayPoolLabel(row,pool)});
    }catch(e){console.warn("TLN/VOW Handelsanalyse Pool übersprungen",chain,row.address,e);}
  }
  return pools;
}
function tradingDecodeLog(pool,log){
  try{
    if(pool.type==="v3"){
      const parsed=TRADE_V3_SWAP_IFACE.parseLog({topics:log.topics,data:log.data});
      const amounts=[parsed.args.amount0,parsed.args.amount1];
      const tokens=[pool.token0,pool.token1],keys=[pool.target0,pool.target1];
      const out=[];
      for(let i=0;i<2;i++){
        if(!keys[i])continue;
        const raw=amounts[i];
        const positive=raw>0n;
        const abs=positive?raw:-raw;
        if(abs===0n)continue;
        out.push({token:keys[i],side:positive?"sell":"buy",amount:Number(ethers.formatUnits(abs,tokens[i].decimals))});
      }
      return out;
    }
    const parsed=TRADE_V2_SWAP_IFACE.parseLog({topics:log.topics,data:log.data});
    const input=[parsed.args.amount0In,parsed.args.amount1In],output=[parsed.args.amount0Out,parsed.args.amount1Out];
    const tokens=[pool.token0,pool.token1],keys=[pool.target0,pool.target1],out=[];
    for(let i=0;i<2;i++){
      if(!keys[i])continue;
      const inRaw=input[i],outRaw=output[i];
      if(inRaw>0n)out.push({token:keys[i],side:"sell",amount:Number(ethers.formatUnits(inRaw,tokens[i].decimals))});
      if(outRaw>0n)out.push({token:keys[i],side:"buy",amount:Number(ethers.formatUnits(outRaw,tokens[i].decimals))});
    }
    return out;
  }catch(e){console.warn("TLN/VOW Swap-Log nicht dekodierbar",pool.address,log?.transactionHash,e);return [];}
}
async function tradingLoadIdentityMap(wallets){
  const ids=new Map(),list=[...new Set((wallets||[]).filter(a=>/^0x[0-9a-f]{40}$/.test(a)))];
  for(let offset=0;offset<list.length;offset+=100){
    const slice=list.slice(offset,offset+100);
    const {data,error}=await sb.from("tln_vow_identity_global_cache")
      .select("wallet_address,node_id,verified_at")
      .eq("chain_key","bsc")
      .in("wallet_address",slice);
    if(error){console.warn("TLN/VOW Händler TLN-ID Cache",error);break;}
    for(const row of data||[]){
      const wallet=norm(row.wallet_address);
      if(wallet&&row.node_id!=null&&!ids.has(wallet))ids.set(wallet,String(row.node_id));
    }
  }
  return ids;
}
function tradingAggregate(events,cutoffs){
  const result={};
  for(const window of TRADE_WINDOWS){
    result[window.key]={bsc:{},eth:{},total:{}};
    for(const chain of ["bsc","eth","total"]){
      for(const token of ["vow","vdollar"])result[window.key][chain][token]={buy:0,sell:0,buyTrades:0,sellTrades:0};
    }
  }
  for(const event of events){
    for(const window of TRADE_WINDOWS){
      if(Number(event.timestamp)<Number(cutoffs[event.chain]?.[window.key]??Infinity))continue;
      const buckets=[result[window.key][event.chain][event.token],result[window.key].total[event.token]];
      for(const b of buckets){b[event.side]+=event.amount;b[event.side+"Trades"]++;}
    }
  }
  return result;
}
function tradingSummaryCell(bucket,side){
  return `${tradingFormatAmount(bucket?.[side]||0)} <span class="muted">(${Number(bucket?.[side+"Trades"]||0)} Trades)</span>`;
}
function renderTradingSummary(){
  const body=document.getElementById("tlnTradingSummaryBody"),data=tradingState.data;
  if(!body||!data)return;
  const rows=[];
  const chainLabel={bsc:'<span class="tln-trade-chain"><span class="tln-trade-chain-icon tln-trade-bsc">BNB</span> BSC</span>',eth:'<span class="tln-trade-chain"><span class="tln-trade-chain-icon tln-trade-eth">◆</span> Ethereum</span>',total:'<strong>∑ Gesamt BSC + ETH</strong>'};
  for(const w of TRADE_WINDOWS){
    rows.push(`<tr class="tln-trade-period-row"><th colspan="6" scope="colgroup">${w.label} <span>VOW / v$ · Handelsvolumen</span></th></tr>`);
    for(const chain of ["bsc","eth","total"]){
      const a=data.summary[w.key][chain];
      rows.push(`<tr class="${chain==='total'?'tln-trade-total-row':'tln-trade-chain-row'}"><td>${chain==='total'?'<strong>SUMME</strong>':'&nbsp;'}</td><td>${chainLabel[chain]}</td><td class="num">${tradingSummaryCell(a.vow,"buy")}</td><td class="num">${tradingSummaryCell(a.vow,"sell")}</td><td class="num">${tradingSummaryCell(a.vdollar,"buy")}</td><td class="num">${tradingSummaryCell(a.vdollar,"sell")}</td></tr>`);
    }
  }
  body.innerHTML=rows.join("");
}

function tradingTraderRows(){
  const data=tradingState.data;if(!data)return [];
  const period=document.getElementById("tlnTradingPeriod")?.value||"30d";
  const chain=document.getElementById("tlnTradingChain")?.value||"total";
  const token=document.getElementById("tlnTradingToken")?.value||"vow";
  const cutoff=data.cutoffs;
  const map=new Map();
  for(const e of data.events){
    if(e.token!==token||!e.wallet)continue;
    if(chain!=="total"&&e.chain!==chain)continue;
    if(Number(e.timestamp)<Number(cutoff[e.chain]?.[period]??Infinity))continue;
    if(!map.has(e.wallet))map.set(e.wallet,{wallet:e.wallet,buy:0,sell:0,buyTrades:0,sellTrades:0,chains:new Set()});
    const row=map.get(e.wallet);row[e.side]+=e.amount;row[e.side+"Trades"]++;row.chains.add(e.chain);
  }
  return [...map.values()].map(x=>({...x,total:x.buy+x.sell,tradeCount:x.buyTrades+x.sellTrades,tlnId:data.identity.get(x.wallet)||null})).sort((a,b)=>b.total-a.total).slice(0,20);
}
// Kopiert die vollständige Händler-Wallet; verkürzte Darstellung bleibt unverändert.
async function tradingCopyWallet(wallet, button){
  if(!/^0x[0-9a-fA-F]{40}$/.test(String(wallet||"")))return;
  try{
    if(navigator.clipboard?.writeText){
      await navigator.clipboard.writeText(wallet);
    }else{
      const field=document.createElement("textarea");
      field.value=wallet;field.setAttribute("readonly","");
      field.style.position="fixed";field.style.opacity="0";
      document.body.appendChild(field);field.select();
      const ok=document.execCommand("copy");field.remove();
      if(!ok)throw new Error("Kopieren nicht verfügbar");
    }
    if(button){const old=button.textContent;button.textContent="✓";setTimeout(()=>{if(button.isConnected)button.textContent=old;},1200);}
  }catch(error){console.warn("Händler-Wallet konnte nicht kopiert werden:",error);if(button)button.title="Kopieren fehlgeschlagen";}
}
function renderTradingTraders(){
  const body=document.getElementById("tlnTradingTradersBody"),data=tradingState.data;if(!body||!data)return;
  const token=document.getElementById("tlnTradingToken")?.value||"vow";
  const rows=tradingTraderRows();
  body.innerHTML=rows.length?rows.map((r,i)=>`<tr><td>${i+1}</td><td><span class="mono" title="${r.wallet}">${tradingShortAddress(r.wallet)}</span><button type="button" class="tln-trade-wallet-copy" title="Vollständige Händler-Wallet kopieren" aria-label="Händler-Wallet kopieren" onclick="TLNVOWProject.copyTradingWallet('${r.wallet}',this)">⧉</button></td><td>${r.tlnId?`<strong>${r.tlnId}</strong>`:"–"}</td><td>${[...r.chains].map(c=>c==="bsc"?"BSC":"ETH").join(" + ")}</td><td class="num">${tradingFormatAmount(r.buy)}</td><td class="num">${tradingFormatAmount(r.sell)}</td><td class="num"><strong>${tradingFormatAmount(r.total)}</strong></td><td class="num">${r.tradeCount}</td></tr>`).join(""):`<tr><td colspan="8">Keine ${tradingTargetLabel(token)}-Trades im gewählten Zeitraum gefunden.</td></tr>`;
}
// Alchemy Transfers API indexiert ERC-20-Transfers tokenbezogen. Ein Transfer ist
// KEIN Trade: erst die nachgeladenen Receipts und verifizierte Pool-Swap-Events
// liefern Kauf/Verkauf, Anzahl und transaction.from. Es gibt keinen Pool-Scan.
const TRADING_ALCHEMY_WINDOW=6*60*60;
async function tradingAlchemyReceiptBatch(chain, hashes){
  const unique=[...new Set(hashes.filter(Boolean))];
  const result=new Map();
  for(let i=0;i<unique.length;i+=10){
    const part=unique.slice(i,i+10);
    const replies=await alchemyRpcBatch(chain,part.map(hash=>({method:"eth_getTransactionReceipt",params:[hash]})),"discovery");
    if(!Array.isArray(replies)||replies.length!==part.length)throw new Error(`${chain}: Alchemy-Receipt-Batch unvollständig`);
    for(let j=0;j<part.length;j++){
      if(!replies[j]||!Array.isArray(replies[j].logs))throw new Error(`${chain}: Receipt fehlt: ${part[j]}`);
      result.set(part[j].toLowerCase(),replies[j]);
    }
  }
  return result;
}
async function tradingAlchemyWindow(chain,startBlock,endBlock,targetTokens,knownPools,userId,cutoffTs,progress){
  const poolMap=new Map(knownPools.map(p=>[norm(p.address),p]));
  const rejected=new Set(),transfers=new Map();
  const contracts=[...targetTokens.keys()];
  // Der pageKey ist nur kurz gültig. Deshalb alle Seiten eines kleinen
  // Blockfensters vollständig abarbeiten, bevor ein Checkpoint geschrieben wird.
  let pageKey=null,pages=0;
  do{
    const query={fromBlock:tradingBlockHex(startBlock),toBlock:tradingBlockHex(endBlock),
      category:["erc20"],contractAddresses:contracts,withMetadata:true,
      order:"asc",maxCount:"0x3e8",excludeZeroValue:true};
    if(pageKey)query.pageKey=pageKey;
    const response=await alchemyRpc(chain,"alchemy_getAssetTransfers",[query],"discovery");
    if(!Array.isArray(response?.transfers))throw new Error(`${chain}: Alchemy Transfers API ohne transfers-Array`);
    for(const tr of response.transfers){
      const hash=String(tr.hash||"").toLowerCase();
      if(!/^0x[0-9a-f]{64}$/.test(hash))continue;
      const timestamp=Date.parse(tr.metadata?.blockTimestamp||"")/1000;
      if(!Number.isFinite(timestamp))throw new Error(`${chain}: Transfer ohne Blockzeit, kann nicht sicher bewertet werden`);
      if(timestamp>=cutoffTs){
        const old=transfers.get(hash);
        if(!old)transfers.set(hash,{timestamp,block:Number(BigInt(tr.blockNum)),from:norm(tr.from)});
      }
    }
    pageKey=response.pageKey||null;
    pages++;
    progress(`Alchemy ${chain.toUpperCase()} · Blockfenster ${startBlock}–${endBlock} · ${pages} Seite(n) · ${transfers.size} Transaktionen`);
    if(pages>10000)throw new Error(`${chain}: Transfer-Pagination ungewöhnlich gross; Scan angehalten`);
  }while(pageKey);
  const hashes=[...transfers.keys()];
  let eventsWritten=0;
  for(let offset=0;offset<hashes.length;offset+=40){
    const part=hashes.slice(offset,offset+40);
    const receipts=await tradingAlchemyReceiptBatch(chain,part);
    const pending=[];
    for(const hash of part){
      const receipt=receipts.get(hash);
      const meta=transfers.get(hash);
      if(!receipt||receipt.status==='0x0')continue;
      const wallet=norm(receipt.from||meta.from);
      if(!ethers.isAddress(wallet))continue;
      for(const log of receipt.logs){
        const topic=log.topics?.[0]?.toLowerCase();
        if(topic!==TRADE_V2_SWAP_TOPIC.toLowerCase()&&topic!==TRADE_V3_SWAP_TOPIC.toLowerCase())continue;
        const address=norm(log.address);
        if(rejected.has(address))continue;
        let pool=poolMap.get(address);
        if(!pool){
          pool=await tradingVerifyCandidatePool(chain,address,targetTokens);
          if(!pool){rejected.add(address);continue;}
          // Swap topic muss auch mit dem verifizierten Pooltyp übereinstimmen.
          poolMap.set(address,pool);
        }
        if((pool.type==='v2'?TRADE_V2_SWAP_TOPIC:TRADE_V3_SWAP_TOPIC).toLowerCase()!==topic)continue;
        const blockNumber=Number(BigInt(log.blockNumber||receipt.blockNumber));
        const logIndex=Number(BigInt(log.logIndex));
        for(const item of tradingDecodeLog(pool,log)){
          pending.push({...item,chain,pool:pool.address,txHash:hash,logIndex,blockNumber,
            timestamp:meta.timestamp,wallet});
        }
      }
    }
    await tradingWriteEvents(userId,pending);
    eventsWritten+=pending.length;
    progress(`Alchemy ${chain.toUpperCase()} · ${offset+part.length}/${hashes.length} Receipts · ${eventsWritten} Trade-Einträge gespeichert`);
  }
  return {pools:poolMap.size,transfers:hashes.length,events:eventsWritten};
}
async function tradingAlchemyChain(chain,userId,states,nowTs,progress){
  const latestBlock=await providers[chain].getBlockNumber();
  const latestTs=await tradingBlockTimestamp(chain,latestBlock);
  const firstBlock=await tradingFindBlockAtOrAfter(chain,nowTs-TRADING_RETENTION_SECONDS,latestBlock,latestTs);
  const targets=await tradingTokenContracts(chain);
  if(!targets.size)throw new Error(`${chain}: VOW-/v$-Contract-Adressen fehlen in den Projektstammdaten`);
  const seeds=await tradingLoadPools(chain);
  const group='alchemy:transfers-v1';
  const previous=states.get(`${chain}|${group}`);
  let next=Math.max(firstBlock,previous?Number(previous.last_scanned_block)-20:firstBlock);
  // Kleine Zeitfenster begrenzen die Transfers-Pagination und ermöglichen
  // dauerhaft gespeicherte Fortschritte ohne flüchtige pageKeys.
  const windowBlocks=chain==='bsc'?7200:1800;
  let total=0,pools=seeds.length;
  while(next<=latestBlock){
    const end=Math.min(latestBlock,next+windowBlocks-1);
    const result=await tradingAlchemyWindow(chain,next,end,targets,seeds,userId,nowTs-TRADING_RETENTION_SECONDS,progress);
    total+=result.events;
    pools=Math.max(pools,result.pools);
    // Cursor erst nach vollständig gelesener Pagination, Receipts und DB-Upserts.
    await tradingSaveScanState(userId,chain,group,end);
    states.set(`${chain}|${group}`,{last_scanned_block:end});
    next=end+1;
    progress(`Alchemy ${chain.toUpperCase()} · ${Math.min(100,Math.round((end-firstBlock+1)/Math.max(1,latestBlock-firstBlock+1)*100))}% · ${total} Trade-Einträge · Checkpoint gespeichert`);
  }
  return {pools,total};
}
// Read-only Handelsansicht: Chain-Abfragen erfolgen ausschließlich im Supabase-Cron-Job.
async function loadTradingAnalysis({force=false}={}){
  if(tradingState.promise)return tradingState.promise;
  if(!force&&tradingState.data&&(Date.now()-tradingState.loadedAt)<TRADING_REFRESH_MS){
    renderTradingSummary();renderTradingTraders();return tradingState.data;
  }
  tradingState.promise=(async()=>{
    const userId=await tradingAuthUser();
    tradingSetStatus('Lade Handelsdaten aus Supabase…','loading');
    const [events,states]=await Promise.all([tradingReadCache(userId),tradingReadScanState(userId)]);
    const nowTs=Math.floor(Date.now()/1000),cutoffs={};
    for(const chain of ['bsc','eth']){
      cutoffs[chain]={};
      for(const w of TRADE_WINDOWS)cutoffs[chain][w.key]=nowTs-w.seconds;
    }
    const identity=await tradingLoadIdentityMap(events.map(e=>e.wallet));
    tradingUpdateFromEvents(events,cutoffs,identity,{bsc:0,eth:0},new Date());
    const stamp=(chain)=>states.get(`${chain}|alchemy:transfers-v1`)?.updated_at||null;
    const times=['bsc','eth'].map(c=>({chain:c,time:stamp(c)}));
    const details=times.map(({chain,time})=>`${chain.toUpperCase()}: ${time?new Date(time).toLocaleString('de-CH'):'noch kein Checkpoint'}`);
    const missing=times.some(x=>!x.time);
    const count=new Set(events.map(e=>`${e.chain}:${e.txHash}`)).size;
    tradingSetStatus(`Supabase · ${count} gecachte Swap-Transaktionen (max. 30 Tage) · ${details.join(' · ')}${missing?' · Mindestens eine Chain noch ohne Scanstatus':''} · Aktualisierung über Cron alle 30 Minuten`,missing?'error':'success');
    return tradingState.data;
  })().catch(e=>{tradingSetStatus(`Handels-Cache: ${String(e?.message||e)}`,'error');throw e;}).finally(()=>{tradingState.promise=null;});
  return tradingState.promise;
}
function ensureTradingLoaded(){return loadTradingAnalysis({force:false});}
// Nur für mögliche bestehende externe Aufrufer beibehalten; ebenfalls reiner Cache-Reload.
function refreshTrading(){return loadTradingAnalysis({force:true});}
function onTradingFilterChange(){renderTradingTraders();}

/* =========================================================
   TABS
========================================================= */
function switchChain(chain){
  document.getElementById("bscTab").classList.toggle("active",chain==="bsc");
  document.getElementById("ethTab").classList.toggle("active",chain==="eth");
  document.getElementById("bscPanel").classList.toggle("active",chain==="bsc");
  document.getElementById("ethPanel").classList.toggle("active",chain==="eth");
}

/* =========================================================
   START
========================================================= */
let initPromise=null;

function ensureLoaded(){
  if(!initPromise){
    initPromise=loadDailyPrices().catch(e=>{ initPromise=null; throw e; });
  }
  return initPromise;
}

async function loadCachedPrices(){
  const cached=await loadCurrentPriceSnapshot();
  if(cached?.payload&&hydrateCurrentPriceSnapshot(cached.payload)){
    currentPriceCapturedAt=cached.capturedAt;currentPriceSource="supabase";notifyCurrentPricesUpdated(false);return true;
  }
  return false;
}

async function manualRefreshPrices(options={}){
  await ensureInfrastructure();
  return await refreshCurrentPrices({manual:true,render:options.render!==false});
}

function getExportedPrice(chain,address){
  if(!address) return null;
  return exportedPrices.get(chain + "|" + norm(address)) || null;
}

return {
  ensureLoaded,
  switchChain,
  refreshPrices:manualRefreshPrices,
  loadCachedPrices,
  getPrice:getExportedPrice,
  displayDecimalsFor,
  formatTokenAmount,
  ensureTradingLoaded,
  refreshTrading,
  onTradingFilterChange,
  copyTradingWallet:tradingCopyWallet,
  getPriceState:()=>({capturedAt:currentPriceCapturedAt,source:currentPriceSource,version:CURRENT_PRICE_SNAPSHOT_VERSION})
};

})();
