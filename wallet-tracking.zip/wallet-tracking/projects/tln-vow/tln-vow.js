// Phase 7.03 · 02.10.2026 04:52:42 CEST: BSC-Voucher-Prefetch an die unveraenderte Fachroute angepasst: auf BSC werden nur Voucher/VOW + VOW/USDT vorab gesucht; ETH behaelt direkte Stablecoin-Kandidaten. Build 20261002-045242.
// Phase 7.02 · 02.10.2026 04:37:13 CEST: Referenzassets werden cache-/stammdaten-first aufgelöst; der bisherige LP-On-Chain-Scan bleibt nur als Fallback. Preisrouten und Preisformeln unverändert. Build 20261002-043713.
// Phase 7.01 · 02.10.2026 04:18:28 CEST: TLN/VOW-Preisrefresh wird ohne Preislogikänderung nach BSC/ETH und Refresh-Stufen diagnostiziert; RPC- und HTTP-Anteile sind je Stufe sichtbar. Build 20261002-041828.
// Phase 6.99 · 01.10.2026 20:12:06 CEST: Preis-Routing-Pairs und LP-Zusatzdaten getrennt; doppelte factory()-Reads entfallen, Preisformeln bleiben unverändert. Build 20261001-201206.
// Phase 6.98 · 01.10.2026 18:19:31 CEST: konfigurierte V2-Pooltypen und alle aktuellen Pair-States werden chainweit vorab gebatcht; Preis-/LP-Felder bleiben unverändert. Build 20261001-181931.
// Phase 6.97 · 01.10.2026 17:36:51 CEST: RPC-Diagnose zaehlt Preis-eth_calls zusätzlich nach ABI-Methode, damit verbliebene Pair-State-Kosten messbar sind. Build 20261001-173651.
// Phase 6.96 · 01.10.2026 17:15:03 CEST: V2-getPair-Discovery wird chain-weit vorab gebatcht; parallele identische Pair-Lookups teilen einen In-Flight-Cache. RPC-Diagnose zaehlt HTTP-Batches/eth_calls. Build 20261001-171503.
// Phase 6.95 · 01.10.2026 16:47:46 CEST: bekannte Token-Metadaten kommen aus predefined_tokens; aktuelle Pair-Reads werden als JSON-RPC-Batch gebündelt. Dashboard-Preisjob bleibt render-frei. Build 20261001-164746.
// Phase 6.94 · 01.10.2026 16:20:46 CEST: globaler Preisjob berechnet TLN/VOW nur noch einmal ohne DOM-Render; Projektpreise werden danach aus demselben Cache exportiert. Preis-Snapshot v2 invalidiert alte Dust-Kurse. Build 20261001-162046.
// Phase 6.93 · 01.10.2026 14:16:13 CEST: Ethereum V2-Pair-Lookup prueft alle aktiven V2-Factorys plus die offizielle Uniswap-V2-Factory; keine Abhaengigkeit mehr von der ersten dex_configs-Zeile. Build 20261001-141613.
// Phase 5.97 · 22.09.2026 23:14:40 CEST: ethers-v6 JsonRpcProvider erhält die Network-Instanz auch in options.staticNetwork; behebt den verbliebenen staticNetwork.matches-Fehler im globalen Preisjob. Build 20260922-231440.
// Phase 5.96 · 22.09.2026 21:35:26 CEST: ethers-v6 staticNetwork erhält echte Network-Instanzen; behebt „staticNetwork.matches is not a function“ bei Preis-/Pool-Providerinitialisierung. Build 20260922-213526.
// Phase 5.80 · 21.09.2026 18:15:39 CEST: gespeicherter Current-Price-Snapshot wird 30s in-flight/session wiederverwendet, damit App-Start und direktes Projektöffnen keinen identischen Supabase-Read erzeugen. Fachliche Preislogik unverändert. Build 20260921-181539.
// Phase 5.78 · 21.09.2026 17:29:35 CEST: DEX/RPC-Provider werden erst im Kurse/Pools-Untertab initialisiert; bekannte BSC/ETH-Netzwerke nutzen staticNetwork ohne zusätzliche Chain-Erkennung. Build 20260921-172935.
window.TLNVOWProject = (() => {

/* =========================================================
   GENERISCHE DEFI-/DEX-KONFIGURATION AUS SUPABASE
========================================================= */
const PROJECT_KEY = "tln_vow";
let PROJECT_NAME = "TLN/VOW";
let CONFIG = {};
let providers = {};
let projectChains = [];

/* =========================================================
   ABIs
========================================================= */
const ERC20_ABI = [
  "function name() view returns (string)",
  "function symbol() view returns (string)",
  "function decimals() view returns (uint8)",
  "function balanceOf(address) view returns (uint256)"
];

const V2_ABI = [
  "function token0() view returns (address)",
  "function token1() view returns (address)",
  "function getReserves() view returns (uint112 reserve0,uint112 reserve1,uint32 blockTimestampLast)",
  "function totalSupply() view returns (uint256)",
  "function balanceOf(address) view returns (uint256)",
  "function decimals() view returns (uint8)",
  "function symbol() view returns (string)",
  "function factory() view returns (address)"
];

const FACTORY_ABI = [
  "function getPair(address tokenA,address tokenB) view returns (address)"
];
const FACTORY_IFACE = new ethers.Interface(FACTORY_ABI);

const PRICE_RPC_METHOD_BY_SELECTOR = new Map([
  [ethers.id("getPair(address,address)").slice(0,10),"getPair"],
  [ethers.id("token0()").slice(0,10),"token0"],
  [ethers.id("token1()").slice(0,10),"token1"],
  [ethers.id("getReserves()").slice(0,10),"getReserves"],
  [ethers.id("totalSupply()").slice(0,10),"totalSupply"],
  [ethers.id("decimals()").slice(0,10),"decimals"],
  [ethers.id("factory()").slice(0,10),"factory"],
  [ethers.id("symbol()").slice(0,10),"symbol"],
  [ethers.id("name()").slice(0,10),"name"],
  [ethers.id("balanceOf(address)").slice(0,10),"balanceOf"],
  [ethers.id("slot0()").slice(0,10),"slot0"],
  [ethers.id("liquidity()").slice(0,10),"liquidity"],
  [ethers.id("fee()").slice(0,10),"fee"]
]);
const priceRpcStats = {
  httpBatchRequests:0,
  ethCalls:0,
  getPairCalls:0,
  pairDiscoveryBatches:0,
  methods:{},
  byChain:{},
  ensureChain(chain){
    const key=String(chain||"unknown");
    if(!this.byChain[key])this.byChain[key]={httpBatchRequests:0,ethCalls:0,getPairCalls:0,pairDiscoveryBatches:0,methods:{}};
    return this.byChain[key];
  },
  countCalls(calls,chain){
    const cs=this.ensureChain(chain);
    for(const call of Array.isArray(calls)?calls:[]){
      const selector=String(call?.data||"").slice(0,10).toLowerCase();
      const name=PRICE_RPC_METHOD_BY_SELECTOR.get(selector)||selector||"unknown";
      this.methods[name]=(this.methods[name]||0)+1;
      cs.methods[name]=(cs.methods[name]||0)+1;
    }
  },
  recordBatch(chain,calls){
    const count=Array.isArray(calls)?calls.length:0,cs=this.ensureChain(chain);
    this.httpBatchRequests++;this.ethCalls+=count;
    cs.httpBatchRequests++;cs.ethCalls+=count;
    this.countCalls(calls,chain);
  },
  recordGetPair(chain,count=1){
    const n=Math.max(0,Number(count)||0),cs=this.ensureChain(chain);
    this.getPairCalls+=n;cs.getPairCalls+=n;
  },
  recordDiscoveryBatch(chain){
    const cs=this.ensureChain(chain);
    this.pairDiscoveryBatches++;cs.pairDiscoveryBatches++;
  },
  reset(){ this.httpBatchRequests=0; this.ethCalls=0; this.getPairCalls=0; this.pairDiscoveryBatches=0; this.methods={}; this.byChain={}; },
  snapshot(){
    return {
      httpBatchRequests:this.httpBatchRequests,ethCalls:this.ethCalls,getPairCalls:this.getPairCalls,pairDiscoveryBatches:this.pairDiscoveryBatches,methods:{...this.methods},
      byChain:Object.fromEntries(Object.entries(this.byChain).map(([chain,v])=>[chain,{...v,methods:{...(v.methods||{})}}]))
    };
  }
};

function subtractCounterMap(after={},before={}){
  const out={};
  for(const key of new Set([...Object.keys(before||{}),...Object.keys(after||{})])){
    const value=Number(after?.[key]||0)-Number(before?.[key]||0);
    if(value)out[key]=value;
  }
  return out;
}
function rpcStatsDelta(before={},after={}){
  const out={
    httpBatchRequests:Number(after.httpBatchRequests||0)-Number(before.httpBatchRequests||0),
    ethCalls:Number(after.ethCalls||0)-Number(before.ethCalls||0),
    getPairCalls:Number(after.getPairCalls||0)-Number(before.getPairCalls||0),
    pairDiscoveryBatches:Number(after.pairDiscoveryBatches||0)-Number(before.pairDiscoveryBatches||0),
    methods:subtractCounterMap(after.methods,before.methods),
    byChain:{}
  };
  for(const chain of new Set([...Object.keys(before.byChain||{}),...Object.keys(after.byChain||{})])){
    const b=before.byChain?.[chain]||{},a=after.byChain?.[chain]||{};
    out.byChain[chain]={
      httpBatchRequests:Number(a.httpBatchRequests||0)-Number(b.httpBatchRequests||0),
      ethCalls:Number(a.ethCalls||0)-Number(b.ethCalls||0),
      getPairCalls:Number(a.getPairCalls||0)-Number(b.getPairCalls||0),
      pairDiscoveryBatches:Number(a.pairDiscoveryBatches||0)-Number(b.pairDiscoveryBatches||0),
      methods:subtractCounterMap(a.methods,b.methods)
    };
  }
  return out;
}
function projectRequestAuditSnapshot(){
  try{return window.getRequestAuditSnapshot?.()||null;}catch(_){return null;}
}
function projectRequestAuditSummary(startIndex){
  const snap=projectRequestAuditSnapshot(),entries=Array.isArray(snap?.entries)?snap.entries:[];
  if(!Number.isInteger(startIndex))return {requests:null,topResources:{},topCallers:{}};
  const rows=entries.slice(Math.max(0,startIndex)),resources={},callers={};
  for(const row of rows){
    const resource=String(row?.resource||"unknown"),caller=String(row?.caller||"unknown");
    resources[resource]=(resources[resource]||0)+1;callers[caller]=(callers[caller]||0)+1;
  }
  const top=o=>Object.fromEntries(Object.entries(o).sort((a,b)=>b[1]-a[1]).slice(0,8));
  return {requests:rows.length,topResources:top(resources),topCallers:top(callers)};
}
async function measureProjectPriceStage(diag,name,fn){
  const reqSnap=projectRequestAuditSnapshot(),startIndex=Array.isArray(reqSnap?.entries)?reqSnap.entries.length:null;
  const before=priceRpcStats.snapshot(),t0=performance.now();
  try{return await fn();}
  finally{
    const after=priceRpcStats.snapshot();
    diag.stages[name]={elapsedMs:Math.round((performance.now()-t0)*10)/10,...projectRequestAuditSummary(startIndex),rpc:rpcStatsDelta(before,after)};
  }
}

const V3_ABI = [
  "function token0() view returns (address)",
  "function token1() view returns (address)",
  "function slot0() view returns (uint160 sqrtPriceX96,int24 tick,uint16 observationIndex,uint16 observationCardinality,uint16 observationCardinalityNext,uint8 feeProtocol,bool unlocked)",
  "function liquidity() view returns (uint128)",
  "function fee() view returns (uint24)",
  "function factory() view returns (address)"
];

/* =========================================================
   STATE / CACHE
========================================================= */
let database = { bsc: [], eth: [] };
let references = {};
const predefinedMeta = new Map();

const tokenCache = new Map();
const pairCache  = new Map();
const priceCache = new Map();
// Öffentliche Preisbrücke zur Hauptseite. Schlüssel immer chain|Contract-Adresse.
const exportedPrices = new Map();

function exportProjectPrice(chain,address,result,kind="token"){
  if(!address || !result || !Number.isFinite(Number(result.price))) return;
  exportedPrices.set(chain + "|" + norm(address), {
    price:Number(result.price),
    change24h:undefined,
    source:chain === "bsc" ? "PancakeSwap" : (chain === "eth" ? "Uniswap" : ("DEX · " + PROJECT_NAME)),
    route:result.route || null,
    kind
  });
}
const v3PoolCache = new Map();
const poolTypeCache = new Map();
const lpSymbolCache = new Map();

const CURRENT_PRICE_SNAPSHOT_TABLE = "defi_current_price_snapshots";
const CURRENT_PRICE_SNAPSHOT_VERSION = "tln-vow-current-price-v2";
const PRICE_TIMEZONE = "Europe/Zurich";
let currentPriceCapturedAt = null;
let currentPriceSource = "live";
let priceRefreshPromise = null;
let infrastructurePromise = null;
let currentPriceSnapshotReadPromise = null;
let currentPriceSnapshotReadCache = null;
const CURRENT_PRICE_SNAPSHOT_READ_TTL_MS = 30000;


/*
 * Preisgraph pro Chain.
 * Voucher-Währungen werden NICHT mehr automatisch über VOW geroutet.
 */
const graphCache = {};

/* =========================================================
   BASICS
========================================================= */
function norm(x){ return String(x || "").trim().toLowerCase(); }
function same(a,b){ return !!a && !!b && norm(a) === norm(b); }

function zurichDay(value=new Date()){
  const d = value instanceof Date ? value : new Date(value);
  if(Number.isNaN(d.getTime())) return null;
  const parts = new Intl.DateTimeFormat("en-CA",{
    timeZone:PRICE_TIMEZONE, year:"numeric", month:"2-digit", day:"2-digit"
  }).formatToParts(d);
  const get=t=>parts.find(p=>p.type===t)?.value;
  return `${get("year")}-${get("month")}-${get("day")}`;
}

function isTodayZurich(iso){
  return !!iso && zurichDay(iso) === zurichDay(new Date());
}

function formatPriceTimestamp(iso){
  if(!iso) return "–";
  const d=new Date(iso);
  if(Number.isNaN(d.getTime())) return "–";
  return d.toLocaleString("de-CH",{timeZone:PRICE_TIMEZONE,dateStyle:"medium",timeStyle:"medium"});
}

function serializableMap(map){
  return [...map.entries()].filter(([,v])=>v && typeof v?.then !== "function");
}

function restoreMap(map,rows){
  map.clear();
  for(const row of Array.isArray(rows)?rows:[]){
    if(Array.isArray(row) && row.length===2 && row[0]) map.set(String(row[0]),row[1]);
  }
}

function setPriceStatus(text,kind="note"){
  const el=document.getElementById("tlnvowPriceStatus");
  if(!el) return;
  el.className=kind;
  el.textContent=text;
}

function setPriceRefreshBusy(busy){
  const btn=document.getElementById("tlnvowRefreshPricesBtn");
  if(btn){
    btn.disabled=!!busy;
    btn.textContent=busy ? "Preise werden aktualisiert…" : "Preise aktualisieren";
  }
}

function rpcBlockTag(block="latest"){
  if(block==null || block==="latest")return "latest";
  const n=Number(block);
  return Number.isFinite(n)?"0x"+Math.max(0,Math.trunc(n)).toString(16):String(block);
}

async function batchRpcCalls(chain,calls,block="latest"){
  const rpc=CONFIG[chain]?.rpc;
  if(!rpc || !Array.isArray(calls) || !calls.length)throw new Error(`${chain}: RPC-Batch nicht verfügbar.`);
  const tag=rpcBlockTag(block);
  const payload=calls.map((x,i)=>({jsonrpc:"2.0",id:i+1,method:"eth_call",params:[{to:x.to,data:x.data},tag]}));
  priceRpcStats.recordBatch(chain,calls);
  const response=await fetch(rpc,{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify(payload)});
  if(!response.ok)throw new Error(`${chain}: RPC-Batch HTTP ${response.status}`);
  const json=await response.json();
  if(!Array.isArray(json))throw new Error(`${chain}: RPC-Batch-Antwort ist kein Array.`);
  const byId=new Map(json.map(x=>[Number(x.id),x]));
  return payload.map(req=>{
    const item=byId.get(req.id);
    if(!item || item.error || typeof item.result!=="string")throw new Error(`${chain}: RPC-Batch-Call ${req.id} fehlgeschlagen${item?.error?.message?`: ${item.error.message}`:""}`);
    return item.result;
  });
}

function configureSharedPriceEngine(){
  if(!window.WalletPriceEngine) return;
  window.WalletPriceEngine.configure(() => ({
    provider: chain => providers[chain] || null,
    batchCall: async (chain,calls,block) => await batchRpcCalls(chain,calls,block),
    tokenMeta: async (chain,address) => await getToken(chain,address),
    references: chain => references[chain] || {},
    tokenCategory: (chain,address) => rowType(findDbRow(chain,address)),
    findPair: async (chain,tokenA,tokenB) => await findPair(chain,tokenA,tokenB),
    listPools: chain => configuredLPs(chain),
    poolType: async (chain,address) => await detectPoolType(chain,address),
    readV3Pool: async (chain,address) => await readV3Pool(chain,address)
  }));
}

/* Zentrale Anzeigepräzision kommt aus public.predefined_tokens.
 * Technische ERC-20 decimals bleiben davon vollständig getrennt. */
function displayDecimalsFor(symbol,{kind="token",summary=false,address=null}={}){
  const globalDigits=window.WalletTokenFormat?.digits;
  if(typeof globalDigits==="function") return globalDigits({chain:"bsc",address,symbol},summary);
  return kind==="lp"?6:6;
}

function formatTokenAmount(value,symbol,options={}){
  const globalFormat=window.WalletTokenFormat?.amount;
  if(typeof globalFormat==="function") return globalFormat(value,{chain:"bsc",address:options?.address||null,symbol},{summary:!!options?.summary});
  const n=Number(value);
  if(!Number.isFinite(n)) return "–";
  return n.toLocaleString("de-CH",{maximumFractionDigits:options?.kind==="lp"?6:6});
}

function fmt(value, decimals=8){
  if(value === null || value === undefined || !Number.isFinite(value)) return "-";
  return value.toLocaleString("de-CH",{maximumFractionDigits:decimals});
}

function usd(value){
  if(value === null || value === undefined || !Number.isFinite(value)) return "nicht verfügbar";
  if(value === 0) return "$0";
  return "$" + value.toLocaleString("en-US",{
    minimumFractionDigits:value < 1 ? 6 : 2,
    maximumFractionDigits:value < 1 ? 10 : 2
  });
}

/*
 * Neue Supabase-Klassifikation.
 *
 * Generische Werte:
 *   voucher_currency
 *   lp_token
 *   defi_token
 *
 * Supabase-Spalten:
 *   defi_project_key
 *   defi_category
 */
function rowType(row){
  if(!row) return "";
  return norm(row.defi_category);
}

function isAllowedRow(row){
  return norm(row?.defi_project_key) === PROJECT_KEY &&
    ["voucher_currency","lp_token","defi_token"].includes(rowType(row));
}

function isLP(row){ return rowType(row) === "lp_token"; }
function isVoucherRow(row){ return rowType(row) === "voucher_currency"; }
function isProjectToken(row){ return rowType(row) === "defi_token"; }

function chainRows(chain){
  return (database[chain] || []).filter(isAllowedRow);
}
function configuredLPs(chain){ return chainRows(chain).filter(isLP); }
function configuredTokens(chain){
  return chainRows(chain).filter(r => {
    if(!r || !r.address) return false;

    const type = rowType(r);

    // Token-Übersicht: ausschließlich echte Projekt-/Voucher-Tokens.
    if(type !== "voucher_currency" && type !== "defi_token"){
      return false;
    }

    return true;
  });
}

function findDbRow(chain,address){
  return chainRows(chain).find(r => r.address && same(r.address,address)) || null;
}

function findTokenByLabel(chain,label){
  return configuredTokens(chain).find(r => norm(r.label) === norm(label)) || null;
}

function findTokenByLabelContains(chain,text){
  return configuredTokens(chain).find(r => norm(r.label).includes(norm(text))) || null;
}

function displayTokenLabel(dbRow,token){
  const label = String(dbRow?.label || "").trim();
  return label || token.name || token.symbol || token.address;
}

function displayPoolLabel(dbRow,pool){
  const label = String(dbRow?.label || "").trim();
  if(label) return label;
  if(pool?.token0 && pool?.token1) return `${pool.token0.symbol} / ${pool.token1.symbol}`;
  return "Liquidity Pool";
}

/*
 * Referenz-Tokens werden NICHT mehr anhand des Supabase-Labels gesucht.
 * Das Label ist nur für die Anzeige.
 * Für USDT/USDC/BUSD/WBNB/BTCB/WETH wird das tatsächliche On-Chain-Symbol
 * des Token-Contracts verwendet. VOW bleibt bewusst fix hinterlegt.
 */
async function loadProjectInfrastructure(){
  const [{data:project,error:projectError},{data:tokens,error:tokenError},{data:dexRows,error:dexError}] = await Promise.all([
    sb.from("defi_projects").select("*").eq("project_key",PROJECT_KEY).eq("enabled",true).maybeSingle(),
    sb.from("defi_project_tokens").select("*").eq("project_key",PROJECT_KEY).eq("enabled",true),
    sb.from("dex_configs").select("*").eq("enabled",true)
  ]);
  if(projectError) throw projectError;
  if(tokenError) throw tokenError;
  if(dexError) throw dexError;
  if(!project) throw new Error(`DeFi-Projekt ${PROJECT_KEY} ist in Supabase nicht aktiv konfiguriert.`);

  PROJECT_NAME = project.name || PROJECT_KEY;
  CONFIG = {};
  providers = {};
  references = {};
  projectChains = [];

  const referenceTokens = (tokens||[]).filter(t => norm(t.role)==="reference");
  for(const ref of referenceTokens){
    const chain = norm(ref.chain_key);
    if(!chain || !CHAIN_CONFIG[chain]) continue;
    if(!CONFIG[chain]) CONFIG[chain]={};
    if(!references[chain]) references[chain]={};
    references[chain].vow = ref.contract_address;
    if(!projectChains.includes(chain)) projectChains.push(chain);
  }

  for(const chain of projectChains){
    const chainDex=(dexRows||[]).filter(d => norm(d.chain_key)===chain);
    const v2Rows=chainDex.filter(d => norm(d.version)==="v2"&&d.factory_address);
    const v3=chainDex.find(d => norm(d.version)==="v3");
    const v2Factories=[...new Set(v2Rows.map(d=>norm(d.factory_address)).filter(Boolean))];
    if(chain==="eth"){
      const uniswapV2=norm("0x5C69bEe701ef814a2B6a3EDD4B1652CB9cc5aA6f");
      if(!v2Factories.includes(uniswapV2))v2Factories.push(uniswapV2);
    }
    CONFIG[chain]={
      rpc: configuredRpcUrl(chain),
      v2Factory:v2Factories[0] || null,
      v2Factories,
      v3Factory:v3?.factory_address || null
    };
    if(!CONFIG[chain].v2Factory) throw new Error(`${PROJECT_NAME}: Für ${chain} fehlt eine aktive V2-DEX-Factory.`);
    const staticNetwork=chain==="bsc"?ethers.Network.from({chainId:56,name:"bsc"}):chain==="eth"?ethers.Network.from({chainId:1,name:"mainnet"}):undefined;
    providers[chain]=staticNetwork
      ? new ethers.JsonRpcProvider(CONFIG[chain].rpc,staticNetwork,{staticNetwork})
      : new ethers.JsonRpcProvider(CONFIG[chain].rpc);
    graphCache[chain]=null;
    references[chain]=references[chain] || {};
  }
}

async function resolveReferences(chain){
  /*
   * Referenz-Assets werden zuerst aus bereits bekannten/cachierten Daten
   * aufgeloest. Das ist fachlich dieselbe Information wie bisher, vermeidet
   * aber den erneuten On-Chain-Scan aller LPs nur zur Symbolerkennung.
   *
   * Reihenfolge:
   * 1) bereits im letzten gueltigen Preisstand aufgeloeste Referenzen,
   * 2) zentraler predefined_tokens-Stammdatensatz,
   * 3) bereits vorab geladene Pair-States der WalletPriceEngine,
   * 4) konfigurierte Projekt-Tokens,
   * 5) alter On-Chain-LP-Scan ausschliesslich als Fallback fuer Luecken.
   *
   * Damit bleibt der alte On-Chain-Weg als Sicherheitsnetz erhalten; sobald
   * die Referenzen bereits eindeutig bekannt sind, entstehen dafuer keine
   * zusaetzlichen RPC-Requests mehr.
   */

  const wanted = chain === "bsc"
    ? ["USDT","USDC","BUSD","WBNB","BTCB"]
    : ["USDT","USDC","WETH"];
  const found = {};
  const put=(symbol,address)=>{
    const sym=String(symbol||"").trim().toUpperCase(),addr=String(address||"").trim();
    if(wanted.includes(sym) && !found[sym] && addr) found[sym]=addr;
  };
  const complete=()=>wanted.every(symbol=>!!found[symbol]);

  // Vorheriger gueltiger Preisstand: dieselben bereits bewiesenen Referenzen
  // wiederverwenden. Das verhindert insbesondere bei manuellen Refreshs einen
  // identischen LP-Metadaten-Scan.
  const previous=references[chain]||{};
  put("USDT",previous.usdt);put("USDC",previous.usdc);put("BUSD",previous.busd);
  put("WBNB",previous.wbnb);put("BTCB",previous.btcb);put("WETH",previous.weth);

  // Zentrale Token-Stammdaten. Diese wurden fuer den Refresh ohnehin einmal
  // geladen und enthalten bei den Standard-Referenzassets Symbol + Adresse.
  if(!complete()){
    for(const [key,row] of predefinedMeta){
      if(!key.startsWith(chain+"|"))continue;
      const symbol=String(row.symbol||row.label||row.name||"").trim().toUpperCase();
      if(wanted.includes(symbol) && row.address) put(symbol,row.address);
    }
  }

  // Die konfigurierten V2-Pairs wurden unmittelbar vor dieser Stufe bereits
  // vorab geladen. Fehlende Referenzen koennen daher aus deren gecachtem
  // token0/token1 gelesen werden, ohne einen weiteren RPC-Aufruf auszufuehren.
  if(!complete()){
    try{
      const state=window.WalletPriceEngine?.exportCurrentState?.();
      for(const entry of Array.isArray(state?.pairPriceStates)?state.pairPriceStates:[]){
        if(!Array.isArray(entry)||entry.length!==2)continue;
        const value=entry[1];
        if(norm(value?.chain)!==chain)continue;
        for(const token of [value?.token0,value?.token1]) put(token?.symbol,token?.address);
      }
    }catch(e){console.warn("Referenz-Assets aus PriceEngine-Cache",chain,e);}
  }

  // Explizit konfigurierte Projekt-/Voucher-Tokens bleiben eine weitere Quelle.
  // getToken() nutzt fuer bekannte predefined_tokens keinen RPC-Call.
  if(!complete()){
    for(const row of configuredTokens(chain)){
      try{
        const token = await getToken(chain,row.address);
        put(token.symbol,token.address);
      }catch(e){
        console.warn("Referenz-Token konnte nicht gelesen werden:",row.address,e);
      }
    }
  }

  // Sicherheits-Fallback: nur falls danach wirklich noch eine Referenz fehlt,
  // wird die bisherige LP-On-Chain-Erkennung ausgefuehrt. Preisberechnung und
  // Auswahl der Referenzassets verlieren dadurch keinen bisherigen Datenweg.
  if(!complete()){
    for(const dbPool of configuredLPs(chain)){
      if(complete())break;
      try{
        const type = await detectPoolType(chain,dbPool.address);
        const pool = type === "v3"
          ? await readV3Pool(chain,dbPool.address)
          : await readV2Pool(chain,dbPool.address);
        for(const token of [pool.token0,pool.token1]) put(token.symbol,token.address);
      }catch(e){
        console.warn("Referenz-Asset konnte aus LP nicht gelesen werden:",dbPool.address,e);
      }
    }
  }

  references[chain] = references[chain] || {};
  references[chain].usdt = found.USDT || null;
  references[chain].usdc = found.USDC || null;
  references[chain].busd = found.BUSD || null;
  references[chain].wbnb = found.WBNB || null;
  references[chain].btcb = found.BTCB || null;
  references[chain].weth = found.WETH || null;

  console.log("Resolved references",chain,references[chain]);
}

/* =========================================================
   SUPABASE
========================================================= */
async function loadSupabase(){
  // Ein zentraler Stammdaten-Read versorgt sowohl Projektklassifikation als auch
  // Token-Metadaten/Stablecoin-Referenzen. Dadurch entfallen pro Token bis zu
  // drei ERC-20-Metadaten-Calls (name/symbol/decimals) beim Preisrefresh.
  const {data:rows,error}=await sb.from("predefined_tokens")
    .select("*")
    .eq("enabled",true);
  if(error) throw error;

  predefinedMeta.clear();
  for(const row of rows||[]){
    const chain=norm(row.chain),address=norm(row.address);
    if(chain&&address&&address!=="native")predefinedMeta.set(`${chain}|${address}`,row);
  }
  database={};
  for(const chain of projectChains){
    database[chain]=(rows||[]).filter(r => norm(r.chain)===chain && isAllowedRow(r));
  }
}

async function ensureInfrastructure(){
  if(!infrastructurePromise){
    infrastructurePromise=(async()=>{
      await loadProjectInfrastructure();
      await loadSupabase();
      configureSharedPriceEngine();
      return true;
    })();
  }
  return infrastructurePromise;
}

function resetCurrentPriceCaches(){
  tokenCache.clear();
  pairCache.clear();
  priceCache.clear();
  exportedPrices.clear();
  v3PoolCache.clear();
  poolTypeCache.clear();
  lpSymbolCache.clear();
  projectChains.forEach(c=>graphCache[c]=null);
  if(window.WalletPriceEngine){
    configureSharedPriceEngine();
    window.WalletPriceEngine.clearCurrent();
  }
}

function buildCurrentPriceSnapshot(){
  return {
    schemaVersion:1,
    projectKey:PROJECT_KEY,
    valuationVersion:CURRENT_PRICE_SNAPSHOT_VERSION,
    references,
    exportedPrices:serializableMap(exportedPrices),
    tokenCache:serializableMap(tokenCache),
    pairCache:serializableMap(pairCache),
    v3PoolCache:serializableMap(v3PoolCache),
    poolTypeCache:serializableMap(poolTypeCache),
    lpSymbolCache:serializableMap(lpSymbolCache),
    priceEngine:window.WalletPriceEngine?.exportCurrentState?.() || null
  };
}

function hydrateCurrentPriceSnapshot(payload){
  if(!payload || Number(payload.schemaVersion)!==1) return false;
  references=payload.references || references;
  restoreMap(exportedPrices,payload.exportedPrices);
  restoreMap(tokenCache,payload.tokenCache);
  restoreMap(pairCache,payload.pairCache);
  restoreMap(v3PoolCache,payload.v3PoolCache);
  restoreMap(poolTypeCache,payload.poolTypeCache);
  restoreMap(lpSymbolCache,payload.lpSymbolCache);
  if(window.WalletPriceEngine && payload.priceEngine){
    configureSharedPriceEngine();
    window.WalletPriceEngine.importCurrentState?.(payload.priceEngine,{replaceCurrent:true});
  }
  return true;
}

async function loadCurrentPriceSnapshot({force=false}={}){
  const now=Date.now();
  if(!force && currentPriceSnapshotReadCache && (now-currentPriceSnapshotReadCache.loadedAt)<CURRENT_PRICE_SNAPSHOT_READ_TTL_MS){
    return currentPriceSnapshotReadCache.value;
  }
  if(!force && currentPriceSnapshotReadPromise) return currentPriceSnapshotReadPromise;
  const run=(async()=>{
    try{
      const {data,error}=await sb.from(CURRENT_PRICE_SNAPSHOT_TABLE)
        .select("captured_at,payload,valuation_version")
        .eq("project_key",PROJECT_KEY)
        .eq("valuation_version",CURRENT_PRICE_SNAPSHOT_VERSION)
        .maybeSingle();
      if(error) throw error;
      const value=data?.payload?{capturedAt:data.captured_at,payload:data.payload,fresh:isTodayZurich(data.captured_at)}:null;
      currentPriceSnapshotReadCache={loadedAt:Date.now(),value};
      return value;
    }catch(e){
      console.warn("TLN/VOW Preiscache konnte nicht aus Supabase geladen werden:",e);
      return null;
    }
  })();
  if(!force) currentPriceSnapshotReadPromise=run;
  try{return await run;}finally{if(currentPriceSnapshotReadPromise===run) currentPriceSnapshotReadPromise=null;}
}

async function saveCurrentPriceSnapshot(){
  const capturedAt=new Date().toISOString();
  const row={
    project_key:PROJECT_KEY,
    valuation_version:CURRENT_PRICE_SNAPSHOT_VERSION,
    captured_at:capturedAt,
    updated_at:capturedAt,
    payload:buildCurrentPriceSnapshot()
  };
  try{
    const {error}=await sb.from(CURRENT_PRICE_SNAPSHOT_TABLE)
      .upsert(row,{onConflict:"project_key,valuation_version"});
    if(error) throw error;
    currentPriceCapturedAt=capturedAt;
    currentPriceSnapshotReadCache={loadedAt:Date.now(),value:{capturedAt,payload:row.payload,fresh:true}};
    return true;
  }catch(e){
    console.warn("TLN/VOW Preiscache konnte nicht in Supabase gespeichert werden:",e);
    return false;
  }
}

function notifyCurrentPricesUpdated(manual=false){
  const detail={projectKey:PROJECT_KEY,capturedAt:currentPriceCapturedAt,manual,prices:Object.fromEntries(exportedPrices)};
  window.dispatchEvent(new CustomEvent("wallettracking:prices-updated",{detail}));
  if(typeof window.onWalletTrackingPricesUpdated === "function"){
    try{ window.onWalletTrackingPricesUpdated(detail); }catch(e){ console.warn("Preis-Update-Hook fehlgeschlagen",e); }
  }
}

/* =========================================================
   TOKEN INFO
========================================================= */
async function getToken(chain,address){
  const key = chain + ":" + norm(address);
  if(tokenCache.has(key)) return tokenCache.get(key);

  const master=predefinedMeta.get(chain+"|"+norm(address));
  const masterSymbol=String(master?.symbol||master?.label||"").trim();
  const masterName=String(master?.name||master?.label||masterSymbol||"").trim();
  const masterDecimals=master?.decimals===null||master?.decimals===undefined||master?.decimals===""?null:Number(master.decimals);
  if(masterSymbol && Number.isFinite(masterDecimals)){
    const result={address,name:masterName||masterSymbol,symbol:masterSymbol,decimals:masterDecimals};
    tokenCache.set(key,result);
    return result;
  }

  const contract = new ethers.Contract(address,ERC20_ABI,providers[chain]);

  // Metadaten sind bewusst fehlertolerant. Einige ältere/projektspezifische
  // ERC-20-Contracts implementieren einzelne optionale Metadata-Reads nicht
  // sauber und können z.B. bei name() mit "execution reverted" antworten.
  // Das darf eine ansonsten gültige LP-/Preisabfrage nicht abbrechen.
  let name = null, symbol = null, decimals = 18;
  try { name = await contract.name(); } catch(e) {
    console.warn(`TLN/VOW ${chain} ${address}: name() nicht verfügbar`, e);
  }
  try { symbol = await contract.symbol(); } catch(e) {
    console.warn(`TLN/VOW ${chain} ${address}: symbol() nicht verfügbar`, e);
  }
  try { decimals = Number(await contract.decimals()); } catch(e) {
    console.warn(`TLN/VOW ${chain} ${address}: decimals() nicht verfügbar; Fallback 18`, e);
    decimals = 18;
  }

  const fallback = String(address).slice(0,8) + "…";
  const result = {
    address,
    name: String(name || symbol || fallback),
    symbol: String(symbol || name || fallback),
    decimals: Number.isFinite(Number(decimals)) ? Number(decimals) : 18
  };
  tokenCache.set(key,result);
  return result;
}

/* =========================================================
   V2 PAIR LOOKUP
========================================================= */
function pairCacheKey(chain,tokenA,tokenB){
  return chain + ":" + [norm(tokenA),norm(tokenB)].sort().join(":");
}

async function lookupPairAcrossFactories(chain,tokenA,tokenB){
  const factories=(CONFIG[chain].v2Factories?.length?CONFIG[chain].v2Factories:[CONFIG[chain].v2Factory]).filter(Boolean);
  if(!factories.length) return null;
  const calls=factories.map(factoryAddress=>({
    to:factoryAddress,
    data:FACTORY_IFACE.encodeFunctionData("getPair",[tokenA,tokenB])
  }));
  try{
    priceRpcStats.recordGetPair(chain,calls.length);
    const raws=await batchRpcCalls(chain,calls,"latest");
    for(let i=0;i<raws.length;i++){
      const [pair]=FACTORY_IFACE.decodeFunctionResult("getPair",raws[i]);
      if(pair && pair!==ethers.ZeroAddress) return String(pair);
    }
    return null;
  }catch(e){
    console.warn(`${chain}: gebündelter V2 Pair-Lookup fehlgeschlagen; Einzel-Fallback`,e);
    for(const factoryAddress of factories){
      try{
        const factory=new ethers.Contract(factoryAddress,FACTORY_ABI,providers[chain]);
        priceRpcStats.recordGetPair(chain,1);
        const pair=await factory.getPair(tokenA,tokenB);
        if(pair!==ethers.ZeroAddress)return pair;
      }catch(inner){console.warn(`${chain}: V2 Pair-Lookup über ${factoryAddress} fehlgeschlagen`,inner);}
    }
    return null;
  }
}

async function findPair(chain,tokenA,tokenB){
  if(!tokenA || !tokenB) return null;

  const key = pairCacheKey(chain,tokenA,tokenB);
  if(pairCache.has(key)) return await pairCache.get(key);

  const pending=lookupPairAcrossFactories(chain,tokenA,tokenB);
  pairCache.set(key,pending);
  try{
    const result=await pending;
    pairCache.set(key,result);
    return result;
  }catch(e){
    pairCache.delete(key);
    throw e;
  }
}

function addPairCandidate(map,chain,a,b){
  if(!a || !b || same(a,b))return;
  const key=pairCacheKey(chain,a,b);
  if(pairCache.has(key) || map.has(key))return;
  map.set(key,{key,a,b});
}

async function prefetchV2PairDiscovery(chain){
  const factories=(CONFIG[chain].v2Factories?.length?CONFIG[chain].v2Factories:[CONFIG[chain].v2Factory]).filter(Boolean);
  if(!factories.length)return;
  const ref=references[chain]||{};
  const candidates=new Map();

  // Gemeinsame Referenzroute nur einmal entdecken.
  addPairCandidate(candidates,chain,ref.vow,ref.usdt);

  for(const row of configuredTokens(chain)){
    const address=row.address;
    const type=rowType(row);
    if(type==="voucher_currency"){
      // Fachregel: BSC-Voucher werden ausschließlich über VOW → USDT bewertet.
      // Direkte USDC/USDT-Paare sind dort nicht nur fachlich unzulässig, sondern
      // müssen deshalb auch nicht für den Preisrefresh vorab entdeckt werden.
      if(chain !== "bsc"){
        addPairCandidate(candidates,chain,address,ref.usdc);
        addPairCandidate(candidates,chain,address,ref.usdt);
      }
      addPairCandidate(candidates,chain,address,ref.vow);
    }else if(type==="defi_token"){
      addPairCandidate(candidates,chain,address,ref.vow);
      addPairCandidate(candidates,chain,address,ref.usdt);
    }
  }

  if(!candidates.size)return;
  const entries=[...candidates.values()];
  const calls=[];
  for(const entry of entries){
    for(let factoryIndex=0;factoryIndex<factories.length;factoryIndex++){
      calls.push({
        entry,
        factoryIndex,
        to:factories[factoryIndex],
        data:FACTORY_IFACE.encodeFunctionData("getPair",[entry.a,entry.b])
      });
    }
  }

  // Kleine Chunks vermeiden Provider-Limits; typisch ist je Chain nur ein Batch nötig.
  const rawByCall=new Array(calls.length);
  const chunkSize=80;
  try{
    for(let offset=0;offset<calls.length;offset+=chunkSize){
      const chunk=calls.slice(offset,offset+chunkSize);
      priceRpcStats.recordDiscoveryBatch(chain);
      priceRpcStats.recordGetPair(chain,chunk.length);
      const raws=await batchRpcCalls(chain,chunk.map(x=>({to:x.to,data:x.data})),"latest");
      raws.forEach((raw,i)=>{ rawByCall[offset+i]=raw; });
    }
    const results=new Map(entries.map(x=>[x.key,null]));
    calls.forEach((call,i)=>{
      if(results.get(call.entry.key))return;
      try{
        const [pair]=FACTORY_IFACE.decodeFunctionResult("getPair",rawByCall[i]);
        if(pair && pair!==ethers.ZeroAddress)results.set(call.entry.key,String(pair));
      }catch(e){ console.warn(`${chain}: getPair-Batch-Antwort konnte nicht dekodiert werden`,call.entry.key,e); }
    });
    for(const entry of entries)pairCache.set(entry.key,results.get(entry.key)||null);
  }catch(e){
    // Kein Fehler für die Preislogik: findPair() übernimmt danach mit In-Flight-Deduplizierung.
    console.warn(`${chain}: Pair-Discovery-Batch fehlgeschlagen; Lazy-Fallback aktiv`,e);
  }
}

/* =========================================================
   V2 PRICE
========================================================= */
async function getV2Price(chain,pairAddress,baseToken){
  if(window.WalletPriceEngine){
    configureSharedPriceEngine();
    return await window.WalletPriceEngine.getV2Price(chain,pairAddress,baseToken,"latest");
  }

  const pair = new ethers.Contract(pairAddress,V2_ABI,providers[chain]);
  const [a,b,res] = await Promise.all([pair.token0(),pair.token1(),pair.getReserves()]);
  const [t0,t1] = await Promise.all([getToken(chain,a),getToken(chain,b)]);
  const r0 = Number(ethers.formatUnits(res[0],t0.decimals));
  const r1 = Number(ethers.formatUnits(res[1],t1.decimals));
  if(!r0 || !r1) return null;
  if(same(baseToken,a)) return {price:r1/r0,quote:t1.address};
  if(same(baseToken,b)) return {price:r0/r1,quote:t0.address};
  return null;
}

/* =========================================================
   STABLECOINS
========================================================= */
function stableReference(chain,address){
  const ref = references[chain];
  if(same(address,ref.usdt)) return {price:1,route:"USDT",hops:0};
  if(same(address,ref.usdc)) return {price:1,route:"USDC",hops:0};
  if(chain === "bsc" && same(address,ref.busd)) return {price:1,route:"BUSD",hops:0};
  return null;
}

async function tokenSymbol(chain,address){
  try { return (await getToken(chain,address)).symbol; }
  catch { return address.slice(0,6)+"…"; }
}

/* =========================================================
   PREISGRAPH AUS DEN SUPABASE-LPs AUFBAUEN
========================================================= */
async function buildPriceGraph(chain){
  if(graphCache[chain]) return graphCache[chain];

  const edges = [];

  for(const dbPool of configuredLPs(chain)){
    try{
      const type = await detectPoolType(chain,dbPool.address);

      if(type === "v2"){
        const pool = await readV2Pool(chain,dbPool.address);

        if(pool.r0 > 0 && pool.r1 > 0){
          edges.push({
            type:"v2",
            from:pool.token0.address,
            to:pool.token1.address,
            rate:pool.r1/pool.r0,
            fromSymbol:pool.token0.symbol,
            toSymbol:pool.token1.symbol,
            pool:dbPool.address,
            reserveFrom:pool.r0,
            reserveTo:pool.r1
          });

          edges.push({
            type:"v2",
            from:pool.token1.address,
            to:pool.token0.address,
            rate:pool.r0/pool.r1,
            fromSymbol:pool.token1.symbol,
            toSymbol:pool.token0.symbol,
            pool:dbPool.address,
            reserveFrom:pool.r1,
            reserveTo:pool.r0
          });
        }
      }

      if(type === "v3"){
        const pool = await readV3Pool(chain,dbPool.address);

        if(Number.isFinite(pool.price0) && pool.price0 > 0){
          edges.push({
            type:"v3",
            from:pool.token0.address,
            to:pool.token1.address,
            rate:pool.price0,
            fromSymbol:pool.token0.symbol,
            toSymbol:pool.token1.symbol,
            pool:dbPool.address,
            reserveFrom:null,
            reserveTo:null
          });

          edges.push({
            type:"v3",
            from:pool.token1.address,
            to:pool.token0.address,
            rate:pool.price1,
            fromSymbol:pool.token1.symbol,
            toSymbol:pool.token0.symbol,
            pool:dbPool.address,
            reserveFrom:null,
            reserveTo:null
          });
        }
      }
    }catch(e){
      console.warn("Preisgraph: Pool konnte nicht gelesen werden:",dbPool.address,e);
    }
  }

  graphCache[chain] = edges;
  return edges;
}

/* =========================================================
   SHORTEST-PATH PREISROUTER
========================================================= */
async function enumerateUSDPaths(chain,tokenAddress,maxHops=4,maxPaths=80){
  const stableSelf = stableReference(chain,tokenAddress);
  if(stableSelf){
    return [{
      price:1,
      route:stableSelf.route,
      stable:stableSelf.route,
      hops:0,
      edges:[],
      pathLiquidityUSD:Infinity
    }];
  }

  const edges = await buildPriceGraph(chain);

  const stablePriority = [
    {name:"USDT", address:references[chain].usdt, priority:0},
    {name:"USDC", address:references[chain].usdc, priority:1},
    ...(chain === "bsc"
      ? [{name:"BUSD", address:references.bsc.busd, priority:2}]
      : [])
  ].filter(x => x.address);

  const stableMap = new Map(
    stablePriority.map(x => [norm(x.address), x])
  );

  const paths = [];
  const startSymbol = await tokenSymbol(chain,tokenAddress);

  async function dfs(currentAddress, multiplier, symbols, pathEdges, visited){
    if(paths.length >= maxPaths) return;
    if(pathEdges.length >= maxHops) return;

    const outgoing = edges.filter(e => same(e.from,currentAddress));

    for(const edge of outgoing){
      const nextKey = norm(edge.to);
      if(visited.has(nextKey)) continue;

      const nextMultiplier = multiplier * edge.rate;
      const nextSymbols = [...symbols,edge.toSymbol];
      const nextEdges = [...pathEdges,edge];

      const stable = stableMap.get(nextKey);

      if(stable){
        paths.push({
          price:nextMultiplier,
          route:nextSymbols.join(" → "),
          stable:stable.name,
          stablePriority:stable.priority,
          hops:nextEdges.length,
          edges:nextEdges,
          pathLiquidityUSD:null
        });
        continue;
      }

      const nextVisited = new Set(visited);
      nextVisited.add(nextKey);

      await dfs(
        edge.to,
        nextMultiplier,
        nextSymbols,
        nextEdges,
        nextVisited
      );
    }
  }

  await dfs(
    tokenAddress,
    1,
    [startSymbol],
    [],
    new Set([norm(tokenAddress)])
  );

  return paths;
}


/*
 * Für einen V2-Pfad lässt sich die USD-Liquidität jedes Hops aus
 * der nachfolgenden USD-Bewertung abschätzen:
 *
 * TVL ≈ ReserveFrom * USD(From) + ReserveTo * USD(To)
 *
 * Da die Preise aus genau diesem Pool stammen, sind beide Seiten
 * im Idealfall annähernd gleichwertig.
 *
 * Als Pfad-Liquidität verwenden wir den kleinsten TVL aller Hops
 * ("Bottleneck"). Eine Route ist nur so stark wie ihr schwächster Pool.
 *
 * V3-Hops besitzen hier keine einfachen reserve0/reserve1-Werte.
 * Sie erhalten deshalb keinen erfundenen TVL-Wert; bei gemischten
 * Routen wird nur die messbare V2-Liquidität verwendet.
 */
function scorePathLiquidity(path){
  if(!path.edges.length){
    path.pathLiquidityUSD = Infinity;
    return path;
  }

  let usdTo = 1; // Stablecoin am Ende
  let bottleneck = Infinity;
  let measurableHops = 0;

  for(let i=path.edges.length-1; i>=0; i--){
    const edge = path.edges[i];

    const usdFrom = edge.rate * usdTo;

    if(
      edge.type === "v2" &&
      Number.isFinite(edge.reserveFrom) &&
      Number.isFinite(edge.reserveTo)
    ){
      const tvl =
        edge.reserveFrom * usdFrom +
        edge.reserveTo * usdTo;

      if(Number.isFinite(tvl) && tvl > 0){
        bottleneck = Math.min(bottleneck,tvl);
        measurableHops++;
      }
    }

    usdTo = usdFrom;
  }

  path.pathLiquidityUSD =
    measurableHops > 0
      ? bottleneck
      : null;

  return path;
}


async function graphUSDPrice(chain,tokenAddress,maxHops=4){
  const paths = await enumerateUSDPaths(chain,tokenAddress,maxHops);

  if(!paths.length) return null;

  paths.forEach(scorePathLiquidity);

  /*
   * Auswahl:
   * 1. messbare Liquidität vorhanden -> höchste Bottleneck-Liquidität
   * 2. bei ähnlicher/gleicher Liquidität: USDT bevorzugen
   * 3. danach kürzere Route
   * 4. reine V3-Routen ohne messbare V2-Reserve bleiben nutzbar,
   *    werden aber hinter messbaren Routen einsortiert.
   */
  paths.sort((a,b)=>{
    const aLiq = a.pathLiquidityUSD;
    const bLiq = b.pathLiquidityUSD;

    const aMeasured = Number.isFinite(aLiq);
    const bMeasured = Number.isFinite(bLiq);

    if(aMeasured && bMeasured && aLiq !== bLiq){
      return bLiq - aLiq;
    }

    if(aMeasured !== bMeasured){
      return aMeasured ? -1 : 1;
    }

    if((a.stablePriority ?? 99) !== (b.stablePriority ?? 99)){
      return (a.stablePriority ?? 99) - (b.stablePriority ?? 99);
    }

    return a.hops - b.hops;
  });

  const best = paths[0];

  return {
    price:best.price,
    route:best.route,
    hops:best.hops,
    stable:best.stable,
    pathLiquidityUSD:best.pathLiquidityUSD,
    alternatives:paths.slice(1,4).map(p=>({
      price:p.price,
      route:p.route,
      stable:p.stable,
      hops:p.hops,
      pathLiquidityUSD:p.pathLiquidityUSD
    }))
  };
}

/* =========================================================
   DIREKTE USD-MÄRKTE FÜR EXTERNE / CORE ASSETS
========================================================= */

/*
 * BTCB, WBNB, WETH und VOW werden NICHT über andere Ecosystem-Tokens geroutet.
 *
 * Für diese Assets gilt:
 *   TOKEN -> USDT
 *   TOKEN -> USDC
 *   TOKEN -> BUSD (nur BSC)
 *
 * Auf Ethereum darf ein direkter Uniswap-V3-Pool ebenfalls als
 * direkter Stablecoin-Markt dienen (z.B. WETH/USDC).
 *
 * Es gibt ausdrücklich KEIN:
 *   BTCB -> VOW -> ...
 *   WBNB -> VOW -> ...
 *   WETH -> VOW -> ...
 */

function strictCoreSymbol(symbol){
  return ["BTCB","WBNB","WETH","BNB","ETH"].includes(
    String(symbol || "").trim().toUpperCase()
  );
}

async function directV2StableMarkets(chain,tokenAddress){
  const candidates = [
    {name:"USDT",address:references[chain].usdt,priority:0},
    {name:"USDC",address:references[chain].usdc,priority:1},
    ...(chain === "bsc"
      ? [{name:"BUSD",address:references.bsc.busd,priority:2}]
      : [])
  ].filter(x => x.address);

  const results = [];
  const symbol = await tokenSymbol(chain,tokenAddress);

  for(const stable of candidates){
    try{
      const pairAddress = await findPair(chain,tokenAddress,stable.address);
      if(!pairAddress) continue;

      const pair = await readV2Pool(chain,pairAddress);

      let tokenReserve = null;
      let stableReserve = null;
      let price = null;

      if(same(pair.token0.address,tokenAddress)){
        tokenReserve = pair.r0;
        stableReserve = pair.r1;
        price = pair.r1 / pair.r0;
      }else if(same(pair.token1.address,tokenAddress)){
        tokenReserve = pair.r1;
        stableReserve = pair.r0;
        price = pair.r0 / pair.r1;
      }

      if(
        price === null ||
        !Number.isFinite(price) ||
        price <= 0
      ) continue;

      /*
       * Da der Quote-Token ein USD-Stablecoin ist, können wir den
       * Pool-TVL ohne weitere Preisroute abschätzen:
       *
       * Token-Seite = tokenReserve * price
       * Stable-Seite = stableReserve * $1
       */
      const liquidityUSD =
        tokenReserve * price +
        stableReserve;

      results.push({
        price,
        route:`${symbol} → ${stable.name}`,
        stable:stable.name,
        stablePriority:stable.priority,
        hops:1,
        pathLiquidityUSD:liquidityUSD,
        source:"direct-v2",
        pool:pairAddress
      });
    }catch(e){
      console.warn("Direkter V2-Stablemarkt konnte nicht gelesen werden:",tokenAddress,stable.name,e);
    }
  }

  return results;
}

async function directV3StableMarkets(chain,tokenAddress){
  if(chain !== "eth") return [];

  const candidates = [
    {name:"USDT",address:references.eth.usdt,priority:0},
    {name:"USDC",address:references.eth.usdc,priority:1}
  ].filter(x => x.address);

  const results = [];
  const symbol = await tokenSymbol(chain,tokenAddress);

  /*
   * Wir verwenden ausschließlich die in Supabase als LP/Pool
   * hinterlegten Uniswap-V3-Pools. Keine externe API.
   */
  for(const dbPool of configuredLPs("eth")){
    try{
      const type = await detectPoolType("eth",dbPool.address);
      if(type !== "v3") continue;

      const pool = await readV3Pool("eth",dbPool.address);

      for(const stable of candidates){
        if(
          same(pool.token0.address,tokenAddress) &&
          same(pool.token1.address,stable.address)
        ){
          results.push({
            price:pool.price0,
            route:`${symbol} → ${stable.name} (Uniswap V3)`,
            stable:stable.name,
            stablePriority:stable.priority,
            hops:1,
            pathLiquidityUSD:null,
            source:"direct-v3",
            pool:dbPool.address
          });
        }

        if(
          same(pool.token1.address,tokenAddress) &&
          same(pool.token0.address,stable.address)
        ){
          results.push({
            price:pool.price1,
            route:`${symbol} → ${stable.name} (Uniswap V3)`,
            stable:stable.name,
            stablePriority:stable.priority,
            hops:1,
            pathLiquidityUSD:null,
            source:"direct-v3",
            pool:dbPool.address
          });
        }
      }
    }catch(e){
      console.warn("V3-Pool konnte für direkten Stablemarkt nicht gelesen werden:",dbPool.address,e);
    }
  }

  return results;
}


/*
 * LETZTER FALLBACK FÜR PROJEKT-TOKENS
 *
 * Für tln_vow_token (z.B. TLN / TLN+) prüfen wir als letzten Schritt
 * nochmals explizit einen direkten V2-Pool gegen USDT.
 *
 * Keine Route über VOW.
 * Keine externe API.
 * Nur Factory.getPair(token, USDT) + getReserves().
 */
async function directUSDTFallback(chain,token){
  const usdt = references[chain].usdt;
  if(!usdt) return null;

  try{
    const pairAddress = await findPair(chain,token.address,usdt);
    if(!pairAddress) return null;

    const pair = await readV2Pool(chain,pairAddress);

    let price = null;
    let tokenReserve = null;
    let usdtReserve = null;

    if(same(pair.token0.address,token.address)){
      price = pair.r1 / pair.r0;
      tokenReserve = pair.r0;
      usdtReserve = pair.r1;
    }else if(same(pair.token1.address,token.address)){
      price = pair.r0 / pair.r1;
      tokenReserve = pair.r1;
      usdtReserve = pair.r0;
    }

    if(!Number.isFinite(price) || price <= 0) return null;

    const liquidityUSD =
      tokenReserve * price +
      usdtReserve;

    return {
      price,
      route:`${token.symbol} → USDT (direkter V2-Fallback)`,
      stable:"USDT",
      hops:1,
      pathLiquidityUSD:liquidityUSD,
      source:"direct-usdt-fallback",
      pool:pairAddress
    };

  }catch(e){
    console.warn(
      "Direkter USDT-Fallback fehlgeschlagen:",
      chain,
      token.symbol,
      token.address,
      e
    );
    return null;
  }
}

async function strictDirectUSDPrice(chain,token){
  const stableSelf = stableReference(chain,token.address);
  if(stableSelf) return stableSelf;

  const v2 = await directV2StableMarkets(chain,token.address);
  const v3 = await directV3StableMarkets(chain,token.address);

  const all = [...v2,...v3];
  if(!all.length) return null;

  /*
   * Auswahl direkter Märkte:
   * 1. Wenn TVL messbar ist: größter direkter Pool.
   * 2. Bei Gleichstand: USDT vor USDC/BUSD.
   * 3. V3 bleibt möglich, wenn kein messbarer V2-Direktmarkt existiert.
   */
  all.sort((a,b)=>{
    const aMeasured = Number.isFinite(a.pathLiquidityUSD);
    const bMeasured = Number.isFinite(b.pathLiquidityUSD);

    if(aMeasured && bMeasured && a.pathLiquidityUSD !== b.pathLiquidityUSD){
      return b.pathLiquidityUSD - a.pathLiquidityUSD;
    }

    if(aMeasured !== bMeasured){
      return aMeasured ? -1 : 1;
    }

    return (a.stablePriority ?? 99) - (b.stablePriority ?? 99);
  });

  return all[0];
}

/* =========================================================
   ÖKOSYSTEM-PREISE
========================================================= */

/*
 * Nur für Tokens, die NICHT zu den externen Core-Assets gehören,
 * darf der vorhandene Pool-Graph verwendet werden.
 *
 * Damit bleiben z.B. v$, v€, v£ oder TLN Gold über ihre echten
 * LP-Verbindungen bewertbar, während BTCB vollständig unabhängig
 * von VOW bleibt.
 */
async function ecosystemUSDPrice(chain,token){
  return await graphUSDPrice(chain,token.address,4);
}

/* =========================================================
   USD PRICE ROUTER
========================================================= */

/* =========================================================
   SPEZIELLE PREISLOGIK FÜR v_currency
========================================================= */

/*
 * Nur für Datensätze mit:
 *   tln_vow_category = "v_currency"
 *
 * gilt bewusst:
 *
 *   v-Währung -> VOW -> USDT
 *
 * Schritt 1:
 *   direkter V2-Pool v-Währung / VOW
 *
 * Schritt 2:
 *   direkter V2-Pool VOW / USDT
 *
 * Keine Suche über v$, v€, v£ untereinander.
 * Kein Graph-Routing für v_currency.
 */
async function vCurrencyUSDPrice(chain,token){
  const vow = references[chain].vow;
  const usdt = references[chain].usdt;

  if(!vow || !usdt) return null;

  try{
    const vToVowPair = await findPair(chain,token.address,vow);
    if(!vToVowPair) return null;

    const vToVow = await getV2Price(
      chain,
      vToVowPair,
      token.address
    );

    if(!vToVow) return null;

    const vowToUsdtPair = await findPair(chain,vow,usdt);
    if(!vowToUsdtPair) return null;

    const vowToUsdt = await getV2Price(
      chain,
      vowToUsdtPair,
      vow
    );

    if(!vowToUsdt) return null;

    /*
     * Für die angezeigte Pfad-Liquidität nehmen wir den
     * kleineren TVL der beiden V2-Pools als Bottleneck.
     */
    const vPool = await readV2Pool(chain,vToVowPair);
    const vowPool = await readV2Pool(chain,vowToUsdtPair);

    let vPoolTVL = null;
    let vowPoolTVL = null;

    // v_currency/VOW-Pool in USD bewerten
    // token USD = (token->VOW) * (VOW->USDT)
    const tokenUsd = vToVow.price * vowToUsdt.price;

    if(same(vPool.token0.address,token.address)){
      vPoolTVL =
        vPool.r0 * tokenUsd +
        vPool.r1 * vowToUsdt.price;
    }else{
      vPoolTVL =
        vPool.r1 * tokenUsd +
        vPool.r0 * vowToUsdt.price;
    }

    // VOW/USDT-Pool
    if(same(vowPool.token0.address,vow)){
      vowPoolTVL =
        vowPool.r0 * vowToUsdt.price +
        vowPool.r1;
    }else{
      vowPoolTVL =
        vowPool.r1 * vowToUsdt.price +
        vowPool.r0;
    }

    const pathLiquidityUSD =
      Number.isFinite(vPoolTVL) && Number.isFinite(vowPoolTVL)
        ? Math.min(vPoolTVL,vowPoolTVL)
        : null;

    return {
      price:tokenUsd,
      route:`${token.symbol} → VOW → USDT`,
      stable:"USDT",
      hops:2,
      pathLiquidityUSD,
      source:"v-currency-direct-vow-usdt",
      pools:[vToVowPair,vowToUsdtPair]
    };

  }catch(e){
    console.warn(
      "v_currency Preisroute fehlgeschlagen:",
      chain,
      token.symbol,
      token.address,
      e
    );

    return null;
  }
}


/* =========================================================
   SPEZIELLE PREISLOGIK FÜR tln_vow_token
========================================================= */

/*
 * Für tln_vow_token gilt:
 *
 * 1. Wenn der Token VOW selbst ist:
 *      VOW -> USDT
 *
 * 2. Für alle anderen tln_vow_token:
 *      zuerst prüfen: TOKEN / VOW Pool vorhanden?
 *
 *      Wenn JA:
 *          TOKEN -> VOW -> USDT
 *
 *      Wenn NEIN:
 *          direkten TOKEN / USDT Pool prüfen
 *
 * Kein allgemeines Graph-Routing für tln_vow_token.
 */
async function projectTokenUSDPrice(chain,token){
  const vow = references[chain].vow;
  const usdt = references[chain].usdt;

  if(!usdt) return null;

  /*
   * VOW selbst:
   * niemals VOW/VOW suchen.
   * Immer direkt gegen USDT.
   */
  if(vow && same(token.address,vow)){
    return await directUSDTFallback(chain,token);
  }

  /*
   * 1. TOKEN / VOW
   */
  if(vow){
    try{
      const tokenVowPair = await findPair(chain,token.address,vow);

      if(tokenVowPair){
        const tokenToVow = await getV2Price(
          chain,
          tokenVowPair,
          token.address
        );

        if(tokenToVow){
          const vowUsdtPair = await findPair(chain,vow,usdt);

          if(vowUsdtPair){
            const vowToUsdt = await getV2Price(
              chain,
              vowUsdtPair,
              vow
            );

            if(vowToUsdt){
              const tokenUsd =
                tokenToVow.price *
                vowToUsdt.price;

              /*
               * Pfad-Liquidität als Bottleneck der beiden V2-Pools.
               */
              let pathLiquidityUSD = null;

              try{
                const tokenVowPool = await readV2Pool(chain,tokenVowPair);
                const vowUsdtPool = await readV2Pool(chain,vowUsdtPair);

                let tokenVowTVL = null;
                let vowUsdtTVL = null;

                if(same(tokenVowPool.token0.address,token.address)){
                  tokenVowTVL =
                    tokenVowPool.r0 * tokenUsd +
                    tokenVowPool.r1 * vowToUsdt.price;
                }else{
                  tokenVowTVL =
                    tokenVowPool.r1 * tokenUsd +
                    tokenVowPool.r0 * vowToUsdt.price;
                }

                if(same(vowUsdtPool.token0.address,vow)){
                  vowUsdtTVL =
                    vowUsdtPool.r0 * vowToUsdt.price +
                    vowUsdtPool.r1;
                }else{
                  vowUsdtTVL =
                    vowUsdtPool.r1 * vowToUsdt.price +
                    vowUsdtPool.r0;
                }

                if(
                  Number.isFinite(tokenVowTVL) &&
                  Number.isFinite(vowUsdtTVL)
                ){
                  pathLiquidityUSD =
                    Math.min(
                      tokenVowTVL,
                      vowUsdtTVL
                    );
                }
              }catch(e){
                console.warn(
                  "Pfad-Liquidität für tln_vow_token konnte nicht berechnet werden:",
                  token.symbol,
                  e
                );
              }

              return {
                price:tokenUsd,
                route:`${token.symbol} → VOW → USDT`,
                stable:"USDT",
                hops:2,
                pathLiquidityUSD,
                source:"tln-vow-token-via-vow",
                pools:[
                  tokenVowPair,
                  vowUsdtPair
                ]
              };
            }
          }
        }
      }
    }catch(e){
      console.warn(
        "TOKEN/VOW-Route konnte nicht gelesen werden:",
        chain,
        token.symbol,
        token.address,
        e
      );
    }
  }

  /*
   * 2. Kein brauchbarer TOKEN/VOW-Pool:
   *    direkter TOKEN / USDT Pool
   */
  return await directUSDTFallback(
    chain,
    token
  );
}

async function getUSD(chain,token){
  const key = chain + ":" + norm(token.address);
  if(priceCache.has(key)) return priceCache.get(key);

  /*
   * Phase 2: Die fachliche Preisentscheidung liegt zentral im
   * WalletPriceEngine. TLN/VOW liefert nur Projekt-Konfiguration
   * (Referenz-Tokens, Kategorie, Pair-Lookup und V3-Pools).
   *
   * Damit benutzen Token-Tabelle, LP-Bewertung und spätere weitere
   * Consumer dieselbe Preisroute und denselben Pair-State-Cache.
   */
  if(window.WalletPriceEngine){
    configureSharedPriceEngine();
    const result = await window.WalletPriceEngine.getTokenPrice({
      projectKey:PROJECT_KEY,
      chain,
      token,
      block:"latest"
    });
    priceCache.set(key,result);
    return result;
  }

  /*
   * Sicherheits-Fallback für direkte Nutzung der Projektdatei ohne
   * geladene gemeinsame Engine. In der produktiven index.html wird
   * price-engine.js vor tln-vow.js geladen und dieser Block nicht benutzt.
   */
  let result = null;
  const dbRow = findDbRow(chain,token.address);
  result = stableReference(chain,token.address);
  if(!result && dbRow && isVoucherRow(dbRow)) result = await vCurrencyUSDPrice(chain,token);
  if(!result && dbRow && isProjectToken(dbRow)) result = await projectTokenUSDPrice(chain,token);
  if(!result && strictCoreSymbol(token.symbol)) result = await strictDirectUSDPrice(chain,token);
  if(!result && (!dbRow || (!isVoucherRow(dbRow) && !isProjectToken(dbRow)))) result = await ecosystemUSDPrice(chain,token);
  priceCache.set(key,result);
  return result;
}

/* =========================================================
   CURRENT V2 POOL PREFETCH
   Performance-only: dieselben on-chain Felder wie bisher werden gelesen,
   aber chainweit gebündelt und in denselben PriceEngine-Cache gelegt.
========================================================= */
const POOL_FACTORY_IFACE = new ethers.Interface(["function factory() view returns (address)"]);

async function prefetchConfiguredPoolTypes(chain){
  const rows=configuredLPs(chain).filter(r=>r?.address && ethers.isAddress(r.address));
  const missing=rows.filter(r=>!poolTypeCache.has(chain+":"+norm(r.address)));
  if(!missing.length)return 0;
  const chunkSize=80;
  let loaded=0;
  for(let offset=0;offset<missing.length;offset+=chunkSize){
    const chunk=missing.slice(offset,offset+chunkSize);
    try{
      const raws=await batchRpcCalls(chain,chunk.map(r=>({to:r.address,data:POOL_FACTORY_IFACE.encodeFunctionData("factory",[])})),"latest");
      raws.forEach((raw,i)=>{
        const [factory]=POOL_FACTORY_IFACE.decodeFunctionResult("factory",raw);
        let type=null;
        if(isConfiguredV2Factory(chain,factory))type="v2";
        if(CONFIG[chain]?.v3Factory && same(factory,CONFIG[chain].v3Factory))type="v3";
        if(type){
          poolTypeCache.set(chain+":"+norm(chunk[i].address),type);
          if(type==="v2") window.WalletPriceEngine?.setKnownPairFactory?.(chain,chunk[i].address,factory);
          loaded++;
        }
      });
    }catch(e){
      // Reine Performance-Vorladung: bei Provider-/Einzelpoolfehlern bleibt der
      // bestehende detectPoolType()-Pfad unverändert als fachlicher Fallback aktiv.
      console.warn(`${chain}: Pooltyp-Prefetch fehlgeschlagen; Lazy-Fallback aktiv`,e);
    }
  }
  return loaded;
}

async function prefetchConfiguredV2PairStates(chain){
  if(!window.WalletPriceEngine?.prefetchPairStates)return 0;
  configureSharedPriceEngine();
  const addresses=configuredLPs(chain)
    .map(r=>r?.address)
    .filter(a=>a && poolTypeCache.get(chain+":"+norm(a))==="v2");
  try{
    return await window.WalletPriceEngine.prefetchPairStates(chain,addresses,"latest",{chunkCalls:72});
  }catch(e){
    console.warn(`${chain}: V2-Pair-State-Prefetch fehlgeschlagen; bestehender Lazy-Reader bleibt aktiv`,e);
    return 0;
  }
}

async function prefetchDiscoveredV2PairStates(chain){
  if(!window.WalletPriceEngine?.prefetchPricePairStates)return 0;
  configureSharedPriceEngine();
  const prefix=chain+":";
  const addresses=[...pairCache.entries()]
    .filter(([key,value])=>String(key).startsWith(prefix) && typeof value==="string" && ethers.isAddress(value) && value!==ethers.ZeroAddress)
    .map(([,value])=>value);
  try{
    // Entdeckte Routing-Pairs brauchen für die Preisermittlung ausschließlich
    // token0/token1/getReserves. LP-Supply/LP-decimals werden nur für die
    // tatsächlich konfigurierten LP-Positionen separat vorgeladen.
    return await window.WalletPriceEngine.prefetchPricePairStates(chain,addresses,"latest",{chunkCalls:72});
  }catch(e){
    console.warn(`${chain}: entdeckter Preis-Pair-State-Prefetch fehlgeschlagen; bestehender Lazy-Reader bleibt aktiv`,e);
    return 0;
  }
}

/* =========================================================
   POOL TYPE
========================================================= */
function isConfiguredV2Factory(chain,address){
  const factories=(CONFIG[chain]?.v2Factories?.length?CONFIG[chain].v2Factories:[CONFIG[chain]?.v2Factory]).filter(Boolean);
  return factories.some(f=>same(f,address));
}

async function detectPoolType(chain,address){
  const key = chain + ":" + norm(address);
  if(poolTypeCache.has(key)) return poolTypeCache.get(key);
  if(!providers[chain]) throw new Error(`${chain}: RPC-Provider für Pool ${address} fehlt.`);
  if(!ethers.isAddress(address)) throw new Error(`${chain}: Ungültige Pool-Adresse ${address}.`);

  let factory;
  try{
    /*
     * Pooltyp muss vor dem V2-Pair-State bestimmt werden.
     * Ein V3-Pool unterstützt kein getReserves()/totalSupply() wie ein V2-Pair.
     * Deshalb hier bewusst nur factory() lesen und erst danach den
     * typ-spezifischen Reader verwenden.
     */
    const minimal = new ethers.Contract(address,["function factory() view returns (address)"],providers[chain]);
    factory = await minimal.factory();
  }catch(e){
    throw new Error(`${chain}: ${address} · factory() fehlgeschlagen: ${e?.shortMessage || e?.reason || e?.message || e}`);
  }

  let type = null;
  if(isConfiguredV2Factory(chain,factory)) type = "v2";
  if(CONFIG[chain]?.v3Factory && same(factory,CONFIG[chain].v3Factory)) type = "v3";
  if(!type) throw new Error(`${chain}: ${address} gehört nicht zu einer konfigurierten V2/V3-Factory (factory=${factory}).`);
  poolTypeCache.set(key,type);
  return type;
}

/* =========================================================
   READ V2 POOL
========================================================= */
async function readV2Pool(chain,address){
  if(!providers[chain]) throw new Error(`${chain}: RPC-Provider für Pool ${address} fehlt.`);

  if(window.WalletPriceEngine){
    configureSharedPriceEngine();
    const state = await window.WalletPriceEngine.getPairState(chain,address,"latest");
    if(!isConfiguredV2Factory(chain,state.factory)) throw new Error("Pool gehört nicht zu einer konfigurierten V2-Factory.");

    const lpSymbolKey = chain + ":" + norm(address);
    let lpSymbol = lpSymbolCache.get(lpSymbolKey) || "LP";
    if(!lpSymbolCache.has(lpSymbolKey)){
      try {
        const pair = new ethers.Contract(address,["function symbol() view returns (string)"],providers[chain]);
        lpSymbol = String(await pair.symbol());
      } catch(e) {
        console.warn(`TLN/VOW ${chain} ${address}: LP symbol() nicht verfügbar`, e);
      }
      lpSymbolCache.set(lpSymbolKey,lpSymbol);
    }

    return {
      type:"v2",
      address,
      token0:state.token0,
      token1:state.token1,
      r0:state.reserve0,
      r1:state.reserve1,
      lpSupply:state.totalSupply,
      lpDecimals:state.lpDecimals,
      lpSymbol
    };
  }

  const pair = new ethers.Contract(address,V2_ABI,providers[chain]);
  const coreCalls = [
    ["token0()", () => pair.token0()],
    ["token1()", () => pair.token1()],
    ["getReserves()", () => pair.getReserves()],
    ["totalSupply()", () => pair.totalSupply()],
    ["decimals()", () => pair.decimals()],
    ["factory()", () => pair.factory()]
  ];
  const settled = await Promise.allSettled(coreCalls.map(([,fn]) => fn()));
  const failedIndex = settled.findIndex(x => x.status === "rejected");
  if(failedIndex >= 0){
    const err = settled[failedIndex].reason;
    throw new Error(`${chain}: ${address} · ${coreCalls[failedIndex][0]} fehlgeschlagen: ${err?.shortMessage || err?.reason || err?.message || err}`);
  }
  const [token0,token1,reserves,totalSupply,lpDecimals,factory] = settled.map(x => x.value);
  if(!token0 || !token1 || same(token0,token1)) throw new Error(`${chain}: ${address} liefert ungültige token0/token1-Adressen.`);
  let lpSymbol = "LP";
  try { lpSymbol = String(await pair.symbol()); } catch(e) {
    console.warn(`TLN/VOW ${chain} ${address}: LP symbol() nicht verfügbar`, e);
  }
  if(!isConfiguredV2Factory(chain,factory)) throw new Error("Pool gehört nicht zu einer konfigurierten V2-Factory.");
  const [t0,t1] = await Promise.all([getToken(chain,token0),getToken(chain,token1)]);
  return {type:"v2",address,token0:t0,token1:t1,r0:Number(ethers.formatUnits(reserves[0],t0.decimals)),r1:Number(ethers.formatUnits(reserves[1],t1.decimals)),lpSupply:Number(ethers.formatUnits(totalSupply,Number(lpDecimals))),lpDecimals:Number(lpDecimals),lpSymbol};
}

/* =========================================================
   READ V3 POOL
========================================================= */
async function readV3Pool(chain,address){
  if(chain !== "eth") throw new Error("V3 ist in dieser Version nur für Ethereum vorgesehen.");

  const cacheKey = chain + ":" + norm(address);
  if(v3PoolCache.has(cacheKey)) return v3PoolCache.get(cacheKey);

  const pool = new ethers.Contract(address,V3_ABI,providers[chain]);
  const [token0,token1,slot0,liquidity,fee,factory] = await Promise.all([
    pool.token0(),
    pool.token1(),
    pool.slot0(),
    pool.liquidity(),
    pool.fee(),
    pool.factory()
  ]);

  if(!CONFIG[chain]?.v3Factory || !same(factory,CONFIG[chain].v3Factory)){
    throw new Error("Pool gehört nicht zur Uniswap-V3-Factory.");
  }

  const [t0,t1] = await Promise.all([getToken(chain,token0),getToken(chain,token1)]);

  const sqrtPriceX96 = Number(slot0.sqrtPriceX96);
  const raw = (sqrtPriceX96 * sqrtPriceX96) / Math.pow(2,192);
  const price1Per0 = raw * Math.pow(10,t0.decimals - t1.decimals);

  const result = {
    type:"v3",
    address,
    token0:t0,
    token1:t1,
    price0:price1Per0,
    price1:1/price1Per0,
    liquidity:liquidity.toString(),
    fee:Number(fee)
  };

  v3PoolCache.set(cacheKey,result);
  return result;
}

/* =========================================================
   TOKEN OVERVIEW
========================================================= */
async function renderTokenTable(chain){
  const body = document.getElementById(chain+"TokenBody");
  const tokens = configuredTokens(chain);

  body.innerHTML = '<tr><td colspan="4" class="loading">Tokens werden geladen…</td></tr>';

  const rendered = [];

  for(const row of tokens){
    try{
      const token = await getToken(chain,row.address);
      const price = await getUSD(chain,token);
      if(price) exportProjectPrice(chain,token.address,price,"token");
      rendered.push({row,token,price});
    }catch(e){
      console.error("Tokenfehler",row.address,e);
    }
  }

  rendered.sort((a,b)=>a.token.symbol.localeCompare(b.token.symbol));
  body.innerHTML = "";

  for(const item of rendered){
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>
        <div class="pair">${item.token.symbol}</div>
        <div class="small">${displayTokenLabel(item.row,item.token)}</div>
      </td>
      <td><div class="address">${item.token.address}</div></td>
      <td><div class="usd">${item.price ? usd(item.price.price) : "nicht verfügbar"}</div></td>
      <td>${item.price
        ? `<div class="route">${item.price.route}</div>
           ${Number.isFinite(item.price.pathLiquidityUSD)
             ? `<div class="small">Pfad-Liquidität: ${usd(item.price.pathLiquidityUSD)}</div>`
             : `<div class="small">Pfad-Liquidität: nicht aus V2-Reserven messbar</div>`}`
        : `<span class="error">Keine Preisroute gefunden</span>`}
      </td>`;
    body.appendChild(tr);
  }

  document.getElementById(chain+"TokenCount").textContent = rendered.length;
}

/* =========================================================
   V2 WALLET
========================================================= */

/* =========================================================
   RENDER V2
========================================================= */
async function renderV2Pool(chain,dbPool,wallet){
  const pool = await readV2Pool(chain,dbPool.address);
  const [price0,price1] = await Promise.all([
    getUSD(chain,pool.token0),
    getUSD(chain,pool.token1)
  ]);

  const value0 = price0 ? pool.r0*price0.price : null;
  const value1 = price1 ? pool.r1*price1.price : null;
  const tvl = value0 !== null && value1 !== null ? value0+value1 : null;
  const lpPrice = tvl !== null && pool.lpSupply > 0 ? tvl/pool.lpSupply : null;

  if(price0) exportProjectPrice(chain,pool.token0.address,price0,"token");
  if(price1) exportProjectPrice(chain,pool.token1.address,price1,"token");
  if(lpPrice !== null && Number.isFinite(lpPrice)){
    exportedPrices.set(chain + "|" + norm(dbPool.address), {
      price:lpPrice,
      change24h:undefined,
      source:"Projekt TLN/VOW · LP",
      route:`TVL / LP-Supply`,
      kind:"lp"
    });
  }


  const tr = document.createElement("tr");
  tr.innerHTML = `
    <td>
      <div class="badge">${displayPoolLabel(dbPool,pool)}</div>
      <div class="pair">${pool.token0.symbol} / ${pool.token1.symbol}</div>
      <div class="address">${pool.address}</div>
      <div class="small">LP Token: ${pool.lpSymbol}</div>
    </td>
    <td>
      <b>${pool.token0.symbol}</b>
      <div class="small">${pool.token0.name}</div>
      <div class="address">${pool.token0.address}</div>
    </td>
    <td>
      <b>${pool.token1.symbol}</b>
      <div class="small">${pool.token1.name}</div>
      <div class="address">${pool.token1.address}</div>
    </td>
    <td>
      ${formatTokenAmount(pool.r0,pool.token0.symbol)} ${pool.token0.symbol}<br>
      ${formatTokenAmount(pool.r1,pool.token1.symbol)} ${pool.token1.symbol}
    </td>
    <td>
      <div class="price">${fmt(pool.r1/pool.r0,12)}</div>
      <div class="small">${pool.token1.symbol}/${pool.token0.symbol}</div>
      <hr>
      <div class="price">${fmt(pool.r0/pool.r1,12)}</div>
      <div class="small">${pool.token0.symbol}/${pool.token1.symbol}</div>
    </td>
    <td>
      <div class="usd">${price0 ? usd(price0.price) : "nicht verfügbar"}</div>
      <div class="small">${pool.token0.symbol}</div>
      ${price0 ? `<div class="route">${price0.route}</div>${Number.isFinite(price0.pathLiquidityUSD)?`<div class="small">Pfad-Liq.: ${usd(price0.pathLiquidityUSD)}</div>`:""}` : ""}
      <hr>
      <div class="usd">${price1 ? usd(price1.price) : "nicht verfügbar"}</div>
      <div class="small">${pool.token1.symbol}</div>
      ${price1 ? `<div class="route">${price1.route}</div>${Number.isFinite(price1.pathLiquidityUSD)?`<div class="small">Pfad-Liq.: ${usd(price1.pathLiquidityUSD)}</div>`:""}` : ""}
    </td>
    <td>
      <div class="tvl">${tvl !== null ? usd(tvl) : "nicht verfügbar"}</div>
      <div class="small">
        ${pool.token0.symbol}: ${value0 !== null ? usd(value0) : "-"}<br>
        ${pool.token1.symbol}: ${value1 !== null ? usd(value1) : "-"}
      </div>
    </td>
    <td>
      <div class="lp">${lpPrice !== null ? usd(lpPrice) : "nicht verfügbar"}</div>
      <div class="small">Wert von 1 ${pool.lpSymbol}</div>
      <hr>
      <div class="small">Supply: ${formatTokenAmount(pool.lpSupply,pool.lpSymbol,{kind:"lp"})} ${pool.lpSymbol}</div>
      <div class="small">
        1 LP enthält:<br>
        ${pool.lpSupply ? formatTokenAmount(pool.r0/pool.lpSupply,pool.token0.symbol) : "-"} ${pool.token0.symbol}<br>
        ${pool.lpSupply ? formatTokenAmount(pool.r1/pool.lpSupply,pool.token1.symbol) : "-"} ${pool.token1.symbol}
      </div>
    </td>
  `;

  return {
    row:tr,
    tvl:tvl || 0
  };
}

/* =========================================================
   RENDER V3
========================================================= */
async function renderV3Pool(chain,dbPool){
  const pool = await readV3Pool(chain,dbPool.address);
  const [price0,price1] = await Promise.all([
    getUSD(chain,pool.token0),
    getUSD(chain,pool.token1)
  ]);
  if(price0) exportProjectPrice(chain,pool.token0.address,price0,"token");
  if(price1) exportProjectPrice(chain,pool.token1.address,price1,"token");

  const tr = document.createElement("tr");
  tr.innerHTML = `
    <td>
      <div class="badge">${displayPoolLabel(dbPool,pool)}</div>
      <div class="pair">${pool.token0.symbol} / ${pool.token1.symbol}</div>
      <div class="address">${pool.address}</div>
      <div class="small">Uniswap V3 · Fee ${(pool.fee/10000).toFixed(2)}%</div>
    </td>
    <td>
      <b>${pool.token0.symbol}</b>
      <div class="small">${pool.token0.name}</div>
      <div class="address">${pool.token0.address}</div>
    </td>
    <td>
      <b>${pool.token1.symbol}</b>
      <div class="small">${pool.token1.name}</div>
      <div class="address">${pool.token1.address}</div>
    </td>
    <td>
      <div class="small">Current liquidity</div>
      <div class="price">${pool.liquidity}</div>
      <div class="small">V3-Liquidität ist tick-/positionsabhängig.</div>
    </td>
    <td>
      <div class="price">${fmt(pool.price0,12)}</div>
      <div class="small">${pool.token1.symbol}/${pool.token0.symbol}</div>
      <hr>
      <div class="price">${fmt(pool.price1,12)}</div>
      <div class="small">${pool.token0.symbol}/${pool.token1.symbol}</div>
    </td>
    <td>
      <div class="usd">${price0 ? usd(price0.price) : "nicht verfügbar"}</div>
      <div class="small">${pool.token0.symbol}</div>
      ${price0 ? `<div class="route">${price0.route}</div>${Number.isFinite(price0.pathLiquidityUSD)?`<div class="small">Pfad-Liq.: ${usd(price0.pathLiquidityUSD)}</div>`:""}` : ""}
      <hr>
      <div class="usd">${price1 ? usd(price1.price) : "nicht verfügbar"}</div>
      <div class="small">${pool.token1.symbol}</div>
      ${price1 ? `<div class="route">${price1.route}</div>${Number.isFinite(price1.pathLiquidityUSD)?`<div class="small">Pfad-Liq.: ${usd(price1.pathLiquidityUSD)}</div>`:""}` : ""}
    </td>
    <td>
      <div class="warning">V3</div>
      <div class="small">Keine einfache V2-Reserve-TVL. Für exakte V3-TVL müssten die aktiven NFT-Positionen/Ticks ausgewertet werden.</div>
    </td>
    <td>
      <div class="lp">Kein LP-Token</div>
      <div class="small">Uniswap V3 verwendet NFT-Liquiditätspositionen.</div>
    </td>
    `;

  return {row:tr,tvl:0};
}

/* =========================================================
   POOL TABLE
========================================================= */
async function renderPools(chain){
  const body = document.getElementById(chain+"PoolBody");
  const pools = configuredLPs(chain);

  body.innerHTML = '<tr><td colspan="8" class="loading">Pools werden geladen…</td></tr>';

  let totalTVL = 0;
  let processed = 0;
  body.innerHTML = "";

  if(!pools.length){
    body.innerHTML = '<tr><td colspan="8" class="note">Für diese Chain sind in Supabase noch keine TLN/VOW-Liquidity-Pools als <code>lp_token</code> konfiguriert.</td></tr>';
    document.getElementById(chain+"PoolCount").textContent = "0";
    document.getElementById(chain+"TVL").textContent = "-";
    return;
  }

  for(const dbPool of pools){
    const loading = document.createElement("tr");
    loading.innerHTML = `<td colspan="8" class="loading">${dbPool.label || dbPool.address}<br>lese Blockchain-Daten…</td>`;
    body.appendChild(loading);

    try{
      const type = await detectPoolType(chain,dbPool.address);
      const result = type === "v3"
        ? await renderV3Pool(chain,dbPool)
        : await renderV2Pool(chain,dbPool,null);

      body.replaceChild(result.row,loading);
      totalTVL += result.tvl;
      processed++;
    }catch(e){
      console.error("Poolfehler",dbPool.address,e);
      loading.innerHTML = `
        <td colspan="8" class="error">
          <b>${dbPool.label || "Pool"}</b><br>
          ${dbPool.address}<br><br>
          ${e.message}
        </td>`;
    }
  }

  document.getElementById(chain+"PoolCount").textContent = processed;
  document.getElementById(chain+"TVL").textContent = totalTVL ? usd(totalTVL) : "-";
}

/* =========================================================
   DASHBOARD LOAD / DAILY PRICE CACHE
========================================================= */
async function renderDashboard(chain,{cacheMode=false}={}){
  const status=document.getElementById(chain+"Status");
  try{
    document.getElementById(chain+"Summary").style.display="grid";
    const ref=references[chain] || {};
    const stableRefs=[ref.usdt?"USDT":null,ref.usdc?"USDC":null,chain==="bsc"&&ref.busd?"BUSD":null].filter(Boolean);
    status.innerHTML=stableRefs.length
      ? `<span class="success">${cacheMode?"Preis-/Poolstand aus globalem Cache":"Referenzen erkannt"}: ${stableRefs.join(", ")}.</span>`
      : `<span class="warning">Kein USDT/USDC${chain==="bsc"?"/BUSD":""}-Referenzasset erkannt.</span>`;
    await renderTokenTable(chain);
    await renderPools(chain);
    status.innerHTML=`<span class="success">Fertig · ${configuredTokens(chain).length} Tokens · ${configuredLPs(chain).length} LP/Pool-Einträge${cacheMode?" · globaler Cache":" · on-chain aktualisiert"}.</span>`;
  }catch(e){
    console.error(e);
    status.innerHTML=`<span class="error">${e.message}</span>`;
    throw e;
  }
}

async function buildCurrentProjectPrices(chain){
  const tokens=configuredTokens(chain);
  await Promise.all(tokens.map(async row=>{
    try{
      const token=await getToken(chain,row.address);
      const price=await getUSD(chain,token);
      if(price) exportProjectPrice(chain,token.address,price,"token");
    }catch(e){ console.warn("TLN/VOW Preisaufbau Token",chain,row.address,e); }
  }));

  // LP-Preise ohne Tabellen-Render berechnen. So liest der globale 15-Minuten-Job
  // die Chain-Facts genau einmal; ein späteres Öffnen des Projekttabs nutzt dieselben Caches.
  await Promise.all(configuredLPs(chain).map(async dbPool=>{
    try{
      const type=await detectPoolType(chain,dbPool.address);
      if(type==="v3"){
        const pool=await readV3Pool(chain,dbPool.address);
        const [p0,p1]=await Promise.all([getUSD(chain,pool.token0),getUSD(chain,pool.token1)]);
        if(p0) exportProjectPrice(chain,pool.token0.address,p0,"token");
        if(p1) exportProjectPrice(chain,pool.token1.address,p1,"token");
        return;
      }
      const pool=await readV2Pool(chain,dbPool.address);
      const [p0,p1]=await Promise.all([getUSD(chain,pool.token0),getUSD(chain,pool.token1)]);
      if(p0) exportProjectPrice(chain,pool.token0.address,p0,"token");
      if(p1) exportProjectPrice(chain,pool.token1.address,p1,"token");
      if(p0 && p1 && pool.lpSupply>0){
        const tvl=pool.r0*p0.price + pool.r1*p1.price;
        const lpPrice=tvl/pool.lpSupply;
        if(Number.isFinite(lpPrice)) exportedPrices.set(chain+"|"+norm(dbPool.address),{
          price:lpPrice,change24h:undefined,source:"Projekt TLN/VOW · LP",route:"TVL / LP-Supply",kind:"lp"
        });
      }
    }catch(e){ console.warn("TLN/VOW Preisaufbau Pool",chain,dbPool.address,e); }
  }));
}

async function refreshCurrentPrices({manual=false,render=true}={}){
  if(priceRefreshPromise) return priceRefreshPromise;
  priceRefreshPromise=(async()=>{
    setPriceRefreshBusy(true);
    setPriceStatus(manual?"Aktuelle Preise werden manuell neu ermittelt…":"Aktuelle Projektpreise werden on-chain ermittelt…","loading");
    priceRpcStats.reset();
    const diagnostics={stages:{}};
    await measureProjectPriceStage(diagnostics,"infrastructure",()=>ensureInfrastructure());
    resetCurrentPriceCaches();
    const chains=projectChains.filter(c=>["bsc","eth"].includes(c));
    // Fachlogik unverändert: 7.01 misst nur die bereits bestehenden Stufen tiefer.
    await measureProjectPriceStage(diagnostics,"configuredPoolTypes",()=>Promise.all(chains.map(chain=>prefetchConfiguredPoolTypes(chain))));
    await measureProjectPriceStage(diagnostics,"configuredPairStates",()=>Promise.all(chains.map(chain=>prefetchConfiguredV2PairStates(chain))));
    await measureProjectPriceStage(diagnostics,"references",async()=>{for(const chain of chains)await resolveReferences(chain);});
    await measureProjectPriceStage(diagnostics,"pairDiscovery",()=>Promise.all(chains.map(chain=>prefetchV2PairDiscovery(chain))));
    await measureProjectPriceStage(diagnostics,"discoveredPairStates",()=>Promise.all(chains.map(chain=>prefetchDiscoveredV2PairStates(chain))));
    await measureProjectPriceStage(diagnostics,"priceBuild",()=>Promise.all(chains.map(chain=>buildCurrentProjectPrices(chain))));
    if(render)await measureProjectPriceStage(diagnostics,"render",()=>Promise.all(chains.map(chain=>renderDashboard(chain,{cacheMode:false}))));
    const saved=await measureProjectPriceStage(diagnostics,"snapshotSave",()=>saveCurrentPriceSnapshot());
    currentPriceSource="live";
    const stamp=formatPriceTimestamp(currentPriceCapturedAt || new Date());
    setPriceStatus(saved
      ? `Preisstand: ${stamp} · aktuell on-chain · in Supabase gespeichert.`
      : `Preisstand: ${stamp} · aktuell on-chain · Supabase-Preiscache konnte nicht gespeichert werden.`,
      saved?"success":"warning");
    notifyCurrentPricesUpdated(manual);
    diagnostics.total=priceRpcStats.snapshot();
    diagnostics.totalStageRequests=Object.values(diagnostics.stages).reduce((n,x)=>n+Number(x.requests||0),0);
    console.info("TLN/VOW Preisrefresh abgeschlossen",{render,prices:exportedPrices.size,pairs:pairCache.size,rpc:diagnostics.total,engine:window.WalletPriceEngine?.stats?.()||null,diagnostics});
    try{console.table(Object.fromEntries(Object.entries(diagnostics.stages).map(([k,v])=>[k,{ms:v.elapsedMs,requests:v.requests,ethCalls:v.rpc?.ethCalls||0,bsc:v.rpc?.byChain?.bsc?.ethCalls||0,eth:v.rpc?.byChain?.eth?.ethCalls||0,httpBatches:v.rpc?.httpBatchRequests||0,topResource:Object.keys(v.topResources||{})[0]||"–"}])));}catch(_){ }
    return true;
  })().finally(()=>{setPriceRefreshBusy(false);priceRefreshPromise=null;});
  return priceRefreshPromise;
}

async function loadDailyPrices(){
  await ensureInfrastructure();
  setPriceStatus("Prüfe gespeicherten Preisstand in Supabase…","loading");
  const cached=await loadCurrentPriceSnapshot();
  if(cached?.fresh && hydrateCurrentPriceSnapshot(cached.payload)){
    currentPriceCapturedAt=cached.capturedAt;
    currentPriceSource="supabase";
    await Promise.all(projectChains.filter(c=>["bsc","eth"].includes(c)).map(chain=>renderDashboard(chain,{cacheMode:true})));
    setPriceStatus(`Preisstand: ${formatPriceTimestamp(currentPriceCapturedAt)} · aus globalem Supabase-Cache.`,`success`);
    notifyCurrentPricesUpdated(false);
    return true;
  }
  return await refreshCurrentPrices({manual:false});
}

/* =========================================================
   TABS
========================================================= */
function switchChain(chain){
  document.getElementById("bscTab").classList.toggle("active",chain==="bsc");
  document.getElementById("ethTab").classList.toggle("active",chain==="eth");
  document.getElementById("bscPanel").classList.toggle("active",chain==="bsc");
  document.getElementById("ethPanel").classList.toggle("active",chain==="eth");
}

/* =========================================================
   START
========================================================= */
let initPromise=null;

function ensureLoaded(){
  if(!initPromise){
    initPromise=loadDailyPrices().catch(e=>{ initPromise=null; throw e; });
  }
  return initPromise;
}

async function loadCachedPrices(){
  const cached=await loadCurrentPriceSnapshot();
  if(cached?.payload&&hydrateCurrentPriceSnapshot(cached.payload)){
    currentPriceCapturedAt=cached.capturedAt;currentPriceSource="supabase";notifyCurrentPricesUpdated(false);return true;
  }
  return false;
}

async function manualRefreshPrices(options={}){
  await ensureInfrastructure();
  return await refreshCurrentPrices({manual:true,render:options.render!==false});
}

function getExportedPrice(chain,address){
  if(!address) return null;
  return exportedPrices.get(chain + "|" + norm(address)) || null;
}

return {
  ensureLoaded,
  switchChain,
  refreshPrices:manualRefreshPrices,
  loadCachedPrices,
  getPrice:getExportedPrice,
  displayDecimalsFor,
  formatTokenAmount,
  getPriceState:()=>({capturedAt:currentPriceCapturedAt,source:currentPriceSource,version:CURRENT_PRICE_SNAPSHOT_VERSION})
};

})();
