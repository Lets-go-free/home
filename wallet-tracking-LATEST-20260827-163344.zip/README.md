# Wallet Tracking – aktueller Stand

Version: 27.08.2026 16:33:44 CEST · Phase 2l · Build 20260827-163344

## Architektur DAO1 / Apertum

Apertum verwendet jetzt eine zentrale Wallet-Historie:

`Apertum Wallet → project_transactions → Claim-Erkennung → project_nft_claims → Auswertungen / Exporte`

Damit wird dieselbe Wallet-Historie nicht mehr separat für Mining, Steuerliste oder andere DAO1-Auswertungen geladen.

## Neu in Phase 2l

### Apertum Transaktionshistorie
- Neuer Bereich **📒 Apertum Transaktionshistorie** im DAO1-Tab.
- Vollständiger Initialscan pro Wallet.
- Folge-Scans nur ab letztem Block minus 250 Block Sicherheitspuffer.
- Speicherung in `project_transactions`.
- Filter: Wallet, Von, Bis, Typ (Alle / Claims / Eingang / Ausgang / Intern).
- Claim-Transaktionen sind direkt in der Gesamtliste sichtbar:
  - NFT
  - NFT-Klassifizierung
  - Reward APTM
  - historischer APTM/USD-Kurs
  - Reward USD
  - Gas APTM / USD
- Die Gesamtliste ist damit als Steuer-/Finanzamt-Grundlage wesentlich besser geeignet.

### Exporte
- **Excel-Export** der aktuell gefilterten Transaktionshistorie.
- **PDF / Drucken** als druckoptimierte A4-Landscape-Ansicht.
- Beide Exporte enthalten Wallet und Datumsbereich.
- Empfehlung: Excel als Arbeits-/Prüfdatei; PDF als Abgabe-/Archivkopie.

### Mining
- Beim Laden gibt es nur noch die Wallet-Auswahl.
- NFT/Klassifizierung beeinflussen den Scan nicht mehr.
- Claim-Erfassung nutzt die zentrale `project_transactions`-Historie.
- Unter **Auswertung filtern** gibt es:
  - Von
  - Bis
  - NFT-Klassifizierung
  - NFT
- Diese Filter wirken nur auf Anzeige und Summen.

## Supabase SQL – aktueller Migrationsstand

Eine bereits erfolgreich ausgeführte Migration **nicht erneut ausführen**.

- `001-dao1-apertum.sql` – bereits früher
- `002-dao1-miner-ownership.sql` – bereits früher
- `003-dao1-miner-nft-name.sql` – bereits früher
- `004-project-nft-classification.sql` – bereits früher
- `005-dao1-claim-cache.sql` – bereits früher
- `006-apertum-transaction-history.sql` – **NEU IN PHASE 2l, einmal ausführen**

Wenn 001–005 bereits erfolgreich gelaufen sind, jetzt **nur 006** ausführen.

## Nach Upload / Migration testen

1. `006-apertum-transaction-history.sql` einmal ausführen.
2. Wallet Tracking neu deployen.
3. DAO1 → Apertum Transaktionshistorie.
4. Wallet wählen → **Apertum-Historie aktualisieren**.
5. Prüfen, ob normale Transaktionen und Claims gemeinsam erscheinen.
6. Datumsfilter testen.
7. Typ `Claims` testen.
8. Excel exportieren.
9. PDF / Drucken testen.
10. Mining-Auswertung starten.
11. Mining unten nach Klassifizierung und NFT filtern.
12. Zweiten Transaktionsscan starten und prüfen, dass er inkrementell läuft.
