# Wallet Tracking – aktueller Stand

Version: 27.08.2026 17:44:29 CEST · Phase 2r · Build 20260827-174429

## Architektur DAO1 / Apertum

`Apertum Wallet → project_transactions → Claim-Erkennung → project_nft_claims → Auswertung / Exporte`

Die Transaktionshistorie ist die zentrale Datenbasis. Wallet-Wechsel und Filter lesen ausschließlich Supabase-Daten. Blockchain-Zugriffe erfolgen nur nach explizitem Klick auf **Apertum-Historie aktualisieren** bzw. beim Mining-Scan, der dieselbe zentrale Historie nutzt.

## Neu in Phase 2r

- Die separate `⛏️ Mining-/Claim-Auswertung` wurde vollständig aus der Oberfläche entfernt.
- `📒 Apertum Transaktionshistorie` ist jetzt die einzige Auswertungsoberfläche.
- Filter erweitert um:
  - Wallet
  - Von / Bis
  - Typ
  - NFT-Klassifizierung
  - NFT
- NFT-Klassifizierung/NFT wirken direkt auf Summary, Detailliste sowie Excel-/PDF-Export.
- Historische NFTs bleiben berücksichtigt, sofern Claims zu ihnen gespeichert sind.
- Wallet-Filter enthält neu **Alle Apertum-Wallets**.
- Bei `Alle Apertum-Wallets` werden Summary und Steuerexport walletübergreifend erstellt; im Export steht die Wallet-Adresse pro Transaktion.
- `Apertum-Historie aktualisieren` verarbeitet bei Auswahl `Alle Apertum-Wallets` die Wallets sequenziell.
- In `🏷️ DAO1 NFT-Klassifizierung` gibt es neu **NFT-Tab öffnen**; die aktuell gewählte Wallet wird dort vorausgewählt.
- Keine neue Supabase-Migration in Phase 2r. `006-apertum-transaction-history.sql` bleibt aktuell.

## Neu in Phase 2q

- Der separate Bereich `⛏️ Apertum Mining Rewards` wurde entfernt.
- Die Mining-/Claim-Auswertung ist jetzt direkt in `📒 Apertum Transaktionshistorie` integriert.
- Sie erscheint dort als auf-/zuklappbarer Unterbereich `⛏️ Mining-/Claim-Auswertung`.
- Standard: **zugeklappt**.
- Mining und Transaktionshistorie verwenden damit sichtbar dieselbe zentrale Datenbasis.
- Historische NFTs werden weiterhin berücksichtigt, sofern sie in `project_nft_ownership` der Wallet geführt werden bzw. Claims zu diesen NFT-IDs gespeichert sind.
- NFT-Klassifizierung bleibt reine Auswertungs-/Filterinformation; Claim-Erkennung ist unabhängig davon.
- Keine neue Supabase-Migration in Phase 2q. `006-apertum-transaction-history.sql` bleibt die aktuelle Migration.

## Neu in Phase 2p

- Änderungen an der DAO1 NFT-Klassifizierung wirken jetzt **sofort** in der geöffneten Seite.
- Nach Speichern oder Entfernen einer Klassifizierung werden ohne Reload neu gerendert:
  - NFT-Klassifizierungstabelle
  - Mining-Auswertungsfilter
  - Mining-Summary und Claim-Tabelle
  - Apertum-Transaktionssummary und Transaktions-Detailliste
  - dadurch auch die Datenbasis für Excel-/PDF-Export
- Dafür wird **kein Blockchain-/Explorer-Scan** und keine erneute Claim-Anreicherung gestartet.
- `project_nfts` bleibt die maßgebliche Quelle; gecachte `nft_subtype`-Werte sind nur Fallback.
- Keine neue Supabase-Migration in Phase 2p. `006-apertum-transaction-history.sql` bleibt die aktuelle Migration.

## Neu in Phase 2o

### Kein 1000-Transaktionen-Limit mehr
- `project_transactions` wird in 1000er-Seiten vollständig aus Supabase gelesen, bis keine weiteren Zeilen vorhanden sind.
- Summary, Filter und Export arbeiten dadurch mit allen gespeicherten Transaktionen.
- Auch `project_nft_claims` wird paginiert gelesen.

### Wallet-Wechsel wirklich nur DB-Read
- Keine Explorer-Abfrage.
- Keine RPC-Abfrage.
- Keine Claim-Anreicherung.
- Es werden ausschließlich die gespeicherten `project_transactions` dieser Wallet geladen.

### Claim-Anreicherung
- Nur bei **Apertum-Historie aktualisieren**.
- Nur `claimReward()`-Transaktionen mit noch leerem `claim_nft_id`.
- Bereits angereicherte Claims werden nicht erneut verarbeitet.
- Historische Kurse werden nur für neue Claim-Anreicherungen ergänzt.

### Klarer Datenstatus
Während der Verarbeitung werden die Phasen sichtbar angezeigt: Explorer laden, Supabase speichern, Claims anreichern, historische Kurse ergänzen und Claim-Daten speichern.

Der Abschlussstatus lautet **✅ Bereit** und zeigt:
- Transaktionen gesamt
- angereicherte Claims
- letzter Scanzeitpunkt
- letzter gespeicherter Block
- offene Claim-Anreicherungen
- Claims ohne historischen USD-Kurs

### Aus Phase 2n weiter enthalten
- NFT-Klassifizierung live aus `project_nfts`
- Summary `Geclaimt APTM`
- Transaktions-Detailliste standardmäßig zugeklappt
- Excel/PDF mit aktueller Klassifizierung

## Supabase SQL – aktueller Migrationsstand

Bereits erfolgreich ausgeführte Migrationen **nicht erneut ausführen**.

- `001-dao1-apertum.sql`
- `002-dao1-miner-ownership.sql`
- `003-dao1-miner-nft-name.sql`
- `004-project-nft-classification.sql`
- `005-dao1-claim-cache.sql`
- `006-apertum-transaction-history.sql` – aktuellste Migration

**Phase 2o benötigt kein neues SQL.** Wenn 001–006 bereits erfolgreich ausgeführt wurden, kein SQL ausführen.

## Test nach Upload

1. Wallet wechseln → nur DB-Laden, danach `✅ Bereit`.
2. Bei >1000 gespeicherten Transaktionen muss die Anzeige >1000 zeigen.
3. `Apertum-Historie aktualisieren` → Fortschrittsphasen sichtbar.
4. Abschluss → `✅ Bereit` mit Scanstand.
5. Wallet erneut wechseln → keine Claim-Anreicherung.
6. Excel/PDF und Datumsfilter mit kompletter Historie testen.
